<#
.SYNOPSIS
    Wheelhouser Git Tools - clone.ps1
.DESCRIPTION
    Clones individual repositories or bulk-clones entire namespaces.
    Supports shorthand formats (owner/repo), bare repository names,
    wildcard namespaces (owner/* such as steve-rock-wheelhouser/*),
    and full Git URLs with automatic SSH/HTTPS protocol fallback.
.PARAMETER Target
    Repository shorthand (owner/repo), bare name, wildcard (owner/*), or Git URL.
.PARAMETER Destination
    Optional destination directory for the cloned repository.
.PARAMETER Dest
    Destination directory alias.
.PARAMETER DryRun
    Preview repositories that would be cloned without cloning.
.PARAMETER SyncExisting
    Pull latest changes if target repository already exists.
.PARAMETER Https
    Clone using HTTPS instead of SSH.
.PARAMETER Token
    GitHub Personal Access Token for private repository discovery.
.PARAMETER Help
    Displays command reference.
.PARAMETER Version
    Displays version information.
#>

# Version Change Log:
# 1.10.0 - Implement git-tools clone <repo> for GitHub repository cloning with automatic SSH/HTTPS fallback and standalone shims.
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1.

[CmdletBinding()]
param(
    [Parameter(Position = 0, Mandatory = $false)]
    [string]$Target,

    [Parameter(Position = 1, Mandatory = $false)]
    [string]$Destination,

    [Alias("dest-dir", "d")][string]$Dest,
    [switch]$DryRun,
    [Alias("s")][switch]$SyncExisting,
    [switch]$Https,
    [string]$Token,
    [switch]$Help,
    [Alias("Version")][switch]$ShowVersion
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainPy = Join-Path $ScriptDir "main.py"
$VERSION = "1.10.1"
if (Test-Path $MainPy) {
    $match = Select-String -Path $MainPy -Pattern '^VERSION\s*=\s*["'']([^"'']+)["'']'
    if ($match -and $match.Matches.Groups.Count -gt 1) {
        $VERSION = $match.Matches.Groups[1].Value
    }
}
$APP_VERSION = $VERSION

if ($Help -or (-not $Target -and -not $ShowVersion)) {
    Write-Host "Wheelhouser Git Tools - Clone Automation (v$APP_VERSION)" -ForegroundColor Cyan
    Write-Host "`nUsage: clone [options] <target> [destination]" -ForegroundColor Yellow
    Write-Host "       clone.ps1 [options] <target> [destination]`n" -ForegroundColor Yellow
    Write-Host "Arguments:" -ForegroundColor White
    Write-Host "  <target>                      Repository shorthand (owner/repo), bare name (repo)," -ForegroundColor Gray
    Write-Host "                                wildcard (owner/*), or full Git URL (SSH or HTTPS)." -ForegroundColor Gray
    Write-Host "  [destination]                 Optional local destination directory." -ForegroundColor Gray
    Write-Host "`nOptions:" -ForegroundColor White
    Write-Host "  -Dest, -dest-dir, -d <dir>    Destination directory for cloned repository." -ForegroundColor Gray
    Write-Host "  -DryRun                       Preview repositories that would be cloned." -ForegroundColor Gray
    Write-Host "  -SyncExisting, -s             Pull latest changes if target already exists." -ForegroundColor Gray
    Write-Host "  -Https                        Clone using HTTPS instead of SSH." -ForegroundColor Gray
    Write-Host "  -Token <token>                GitHub PAT token for private repository discovery." -ForegroundColor Gray
    Write-Host "  -Help                         Show this help documentation." -ForegroundColor Gray
    Write-Host "  -Version                      Show script version." -ForegroundColor Gray
    Write-Host "`nExamples:" -ForegroundColor White
    Write-Host "  clone steve-rock-wheelhouser/tool-box" -ForegroundColor Gray
    Write-Host "  clone steve-rock-wheelhouser/tool-box C:\Projects\tool-box" -ForegroundColor Gray
    Write-Host "  clone steve-rock-wheelhouser/* -DryRun" -ForegroundColor Gray
    exit 0
}

if ($ShowVersion) {
    Write-Host "clone (Wheelhouser Git Tools) v$APP_VERSION"
    exit 0
}

# Delegate execution to main.py clone
$ArgsList = @("clone", $Target)
if ($Destination) { $ArgsList += $Destination }
if ($Dest) { $ArgsList += @("--dest", $Dest) }
if ($DryRun) { $ArgsList += "--dry-run" }
if ($SyncExisting) { $ArgsList += "--sync-existing" }
if ($Https) { $ArgsList += "--https" }
if ($Token) { $ArgsList += @("--token", $Token) }

python $MainPy @ArgsList
exit $LASTEXITCODE

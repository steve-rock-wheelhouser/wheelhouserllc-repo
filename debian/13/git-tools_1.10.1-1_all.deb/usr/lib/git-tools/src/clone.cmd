@echo off
rem Wheelhouser Git Tools - clone.cmd wrapper for PowerShell clone.ps1
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0clone.ps1" %*
if %ERRORLEVEL% EQU 0 goto :eof
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0clone.ps1" %*

#!/usr/bin/env bash
#
# Wheelhouser Git Tools - clone.sh
# Version: 1.10.1
#
# Clones individual repositories or bulk-clones entire namespaces.
# Supports shorthand formats (owner/repo), bare repository names,
# wildcard namespaces (owner/* such as steve-rock-wheelhouser/*),
# and full Git URLs with automatic SSH/HTTPS protocol fallback.
#
# Version Change Log:
# 1.10.1 - Fix NameError in dashboard.py by replacing get_projects_list with list_projects when cloning.
# 1.10.0 - Implement git-tools clone <repo> for GitHub repository cloning with automatic SSH/HTTPS fallback and standalone shims.
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1, update macOS DMG package manifests, and increment version to trigger clean multi-platform build.
# 1.9.0 - Add resilient Developer ID fallback and graceful preflight checks for missing notary-profile on macOS build nodes, resolving notarization and keychain exit code 69 on Intel and headless nodes.
# 1.8.1 - Fix PowerShell parsing error in push.ps1 by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION across push/pull/sync/undo.
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull & push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.10.1}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Clone Automation (v${VERSION})

Usage: clone [options] <target> [destination]
       ./clone.sh [options] <target> [destination]

Arguments:
  <target>                      Repository shorthand (owner/repo), bare name (repo),
                                wildcard (owner/*), or full Git URL (SSH or HTTPS).
  [destination]                 Optional local destination directory (default: persistent projects root).

Options:
  -d, --dest, --dest-dir <dir>  Destination directory for cloned repository.
  --dry-run                     Preview repositories that would be cloned without cloning.
  -s, --sync-existing           Pull latest changes if target repository already exists.
  --https                       Clone using HTTPS instead of SSH.
  --token <token>               GitHub Personal Access Token for private repository discovery.
  -h, --help                    Show this help documentation.
  -v, --version                 Show script version.

Examples:
  clone steve-rock-wheelhouser/tool-box
  clone steve-rock-wheelhouser/tool-box /path/to/my-folder
  clone "steve-rock-wheelhouser/*" --dry-run
  clone tool-box --sync-existing
  clone https://github.com/steve-rock-wheelhouser/tool-box.git

EOF
}

# Handle standalone help or version flags before delegating
for arg in "$@"; do
    if [ "$arg" = "-h" ] || [ "$arg" = "--help" ]; then
        show_help
        exit 0
    elif [ "$arg" = "-v" ] || [ "$arg" = "--version" ]; then
        echo "clone (Wheelhouser Git Tools) v${VERSION}"
        exit 0
    fi
done

if [ $# -eq 0 ]; then
    show_help
    exit 1
fi

MAIN_PY="${SCRIPT_DIR}/main.py"
if [ ! -f "${MAIN_PY}" ]; then
    echo "❌ Error: Could not locate main.py at ${MAIN_PY}" >&2
    exit 1
fi

exec /usr/bin/env python3 "${MAIN_PY}" clone "$@"

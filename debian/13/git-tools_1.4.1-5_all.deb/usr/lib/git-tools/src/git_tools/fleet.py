"""Wheelhouser Git Tools - Multi-Repository Fleet Management.

Provides high-level workspace scanning, dashboard status reporting,
and automated fleet-wide synchronization across multiple Git repositories.
"""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class RepoStatus:
    name: str
    path: Path
    branch: str
    is_clean: bool
    modified_count: int
    untracked_count: int
    ahead: int
    behind: int
    has_upstream: bool
    upstream: str
    last_commit_hash: str
    last_commit_msg: str
    last_commit_date: str


def find_git_repositories(base_dir: Path, max_depth: int = 3) -> List[Path]:
    """Recursively search for Git repositories up to a specified depth."""
    repos: List[Path] = []
    base_dir = base_dir.resolve()

    if (base_dir / ".git").exists():
        return [base_dir]

    def _walk(current: Path, depth: int):
        if depth > max_depth:
            return
        try:
            entries = list(current.iterdir())
        except OSError:
            return

        for entry in sorted(entries):
            # Skip hidden dirs, build artifacts, and virtual environments
            if entry.name.startswith(".") or entry.name in {
                "node_modules",
                "target",
                "build",
                "dist",
                "vendor",
                "__pycache__",
            }:
                continue

            if entry.is_dir():
                if (entry / ".git").exists():
                    repos.append(entry)
                else:
                    _walk(entry, depth + 1)

    _walk(base_dir, 1)
    return repos


def inspect_repository(repo_path: Path) -> Optional[RepoStatus]:
    """Gather detailed status metrics for a single repository."""
    if not (repo_path / ".git").exists():
        return None

    def _run_git(args: List[str]) -> str:
        res = subprocess.run(
            ["git", "-C", str(repo_path)] + args,
            capture_output=True,
            text=True,
            check=False,
        )
        return res.stdout.strip()

    # 1. Branch Name
    branch = _run_git(["symbolic-ref", "--short", "HEAD"])
    if not branch:
        branch = _run_git(["rev-parse", "--short", "HEAD"])
        if not branch:
            branch = "HEAD (empty)"

    # 2. Working tree status
    porcelain = _run_git(["status", "--porcelain"])
    lines = [line for line in porcelain.splitlines() if line.strip()]
    untracked = sum(1 for line in lines if line.startswith("??"))
    modified = len(lines) - untracked
    is_clean = len(lines) == 0

    # 3. Upstream & Commit delta
    upstream = _run_git(["rev-parse", "--abbrev-ref", "@{upstream}"])
    has_upstream = bool(upstream and not upstream.startswith("@{"))
    ahead = 0
    behind = 0

    if has_upstream:
        rev_list = _run_git(["rev-list", "--left-right", "--count", f"{upstream}...HEAD"])
        parts = rev_list.split()
        if len(parts) == 2:
            try:
                behind = int(parts[0])
                ahead = int(parts[1])
            except ValueError:
                pass

    # 4. Last commit details
    last_hash = _run_git(["log", "-1", "--format=%h"])
    last_msg = _run_git(["log", "-1", "--format=%s"])
    last_date = _run_git(["log", "-1", "--format=%cr"])

    return RepoStatus(
        name=repo_path.name,
        path=repo_path,
        branch=branch,
        is_clean=is_clean,
        modified_count=modified,
        untracked_count=untracked,
        ahead=ahead,
        behind=behind,
        has_upstream=has_upstream,
        upstream=upstream if has_upstream else "none",
        last_commit_hash=last_hash,
        last_commit_msg=last_msg,
        last_commit_date=last_date,
    )


def scan_fleet(base_dir: Path) -> List[RepoStatus]:
    """Scan all Git repositories under base_dir and collect status objects."""
    repo_paths = find_git_repositories(base_dir)
    fleet: List[RepoStatus] = []
    for rpath in repo_paths:
        stat = inspect_repository(rpath)
        if stat:
            fleet.append(stat)
    return fleet


def render_fleet_dashboard(fleet: List[RepoStatus]) -> str:
    """Format fleet statuses into a terminal dashboard."""
    if not fleet:
        return "ℹ️ No Git repositories found in the specified path."

    # ANSI Colors
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    DIM = "\033[2m"
    BOLD = "\033[1m"
    RESET = "\033[0m"

    lines: List[str] = []
    lines.append(f"{BOLD}{'=' * 95}{RESET}")
    lines.append(f"{BOLD}           WHEELHOUSER FLEET STATUS DASHBOARD ({len(fleet)} Repositories){RESET}")
    lines.append(f"{BOLD}{'=' * 95}{RESET}")

    header = f"{'REPOSITORY':<24} {'BRANCH':<14} {'LOCAL STATUS':<18} {'REMOTE SYNC':<18} {'LAST COMMIT':<20}"
    lines.append(f"{BOLD}{header}{RESET}")
    lines.append(f"{DIM}{'-' * 95}{RESET}")

    for s in fleet:
        # Local Status string
        if s.is_clean:
            local_str = f"{GREEN}Clean{RESET}"
        else:
            parts = []
            if s.modified_count:
                parts.append(f"{s.modified_count} mod")
            if s.untracked_count:
                parts.append(f"{s.untracked_count} untracked")
            local_str = f"{YELLOW}{', '.join(parts)}{RESET}"

        # Remote Sync string
        if not s.has_upstream:
            sync_str = f"{DIM}No Upstream{RESET}"
        elif s.ahead == 0 and s.behind == 0:
            sync_str = f"{GREEN}✓ In Sync{RESET}"
        elif s.ahead > 0 and s.behind > 0:
            sync_str = f"{RED}⚡ Diverged (↑{s.ahead} ↓{s.behind}){RESET}"
        elif s.ahead > 0:
            sync_str = f"{YELLOW}↑ Ahead by {s.ahead}{RESET}"
        else:
            sync_str = f"{CYAN}↓ Behind by {s.behind}{RESET}"

        # Truncate commit msg if needed
        c_msg = s.last_commit_msg
        if len(c_msg) > 22:
            c_msg = c_msg[:19] + "..."
        commit_str = f"{s.last_commit_hash} {c_msg}" if s.last_commit_hash else f"{DIM}no commits{RESET}"

        row = f"{CYAN}{s.name:<24}{RESET} {s.branch:<14} {local_str:<27} {sync_str:<27} {commit_str}"
        lines.append(row)

    lines.append(f"{BOLD}{'=' * 95}{RESET}")
    return "\n".join(lines)


def pull_fleet(base_dir: Path) -> List[tuple[str, bool, str]]:
    """Execute pull on all discovered Git repositories."""
    repo_paths = find_git_repositories(base_dir)
    results: List[tuple[str, bool, str]] = []

    for rpath in repo_paths:
        print(f"🔄 Updating '{rpath.name}'...")
        res = subprocess.run(
            ["git", "-C", str(rpath), "pull", "--autostash", "--rebase"],
            capture_output=True,
            text=True,
            check=False,
        )
        success = res.returncode == 0
        output = res.stdout.strip() if success else res.stderr.strip()
        results.append((rpath.name, success, output))

    return results

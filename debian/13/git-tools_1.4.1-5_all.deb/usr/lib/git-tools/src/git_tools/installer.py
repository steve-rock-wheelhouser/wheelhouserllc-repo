"""Wheelhouser Git Tools - Cross-Platform Installer & Shim Manager.

Manages registration and removal of global push, pull, and git-tools CLI shims
across Linux, macOS, and Windows environments.

Version Change Log:
# 1.1.3 - Eliminate duplicate desktop launcher in applications and dock favorites.
# 1.1.2 - Support dual launcher/software center icon assets and directory cleanup.
# 1.1.1 - Isolate installer test sandboxes from user desktop environment.
# 1.1.0 - Add standard src/main.py and src/main.sh entry points and version synchronization.
"""

from __future__ import annotations

import os
import platform
import shutil
import stat
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def get_default_install_dir(system_wide: bool = False) -> Path:
    """Return the canonical installation bin directory for the current operating system."""
    system = platform.system().lower()

    if system_wide:
        if system == "windows":
            prog_data = os.environ.get("ProgramData", r"C:\ProgramData")
            return Path(prog_data) / "Wheelhouser" / "git-tools" / "bin"
        return Path("/usr/local/bin")

    # User-level installation
    home = Path.home()
    if system == "windows":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / "Programs" / "git-tools" / "bin"
        return home / "bin"

    return home / ".local" / "bin"


def get_source_scripts_dir() -> Path:
    """Get the path to the directory containing the source workflow scripts."""
    target_script = "push.ps1" if os.name == "nt" else "push.sh"

    # 1. If running as a frozen PyInstaller binary
    if getattr(sys, "frozen", False):
        # Check PyInstaller unpack directory
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            cand = Path(meipass)
            if (cand / target_script).is_file():
                return cand
            if (cand / "src" / target_script).is_file():
                return cand / "src"

        # Check directory adjacent to executable (e.g. MSIX installed package root)
        exe_dir = Path(sys.executable).resolve().parent
        if (exe_dir / target_script).is_file():
            return exe_dir
        if (exe_dir / "src" / target_script).is_file():
            return exe_dir / "src"

    # 2. Check relative to this source file (src/git_tools/installer.py -> src/)
    try:
        cand = Path(__file__).resolve().parent.parent
        if (cand / target_script).is_file():
            return cand
    except Exception:
        pass

    # 3. Check default user install directory
    try:
        default_dir = get_default_install_dir()
        if (default_dir / target_script).is_file():
            return default_dir
    except Exception:
        pass

    # Fallback to parent of parent of current module
    return Path(__file__).resolve().parent.parent


def is_dir_in_path(target_dir: Path) -> bool:
    """Check if the given directory is present in the current PATH environment variable."""
    path_entries = [Path(p).resolve() for p in os.environ.get("PATH", "").split(os.pathsep) if p]
    target_resolved = target_dir.resolve()
    return target_resolved in path_entries


def make_executable(path: Path) -> None:
    """Add executable permissions to a file on POSIX systems."""
    if os.name != "nt":
        current_mode = path.stat().st_mode
        path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def install_tools(
    target_dir: Optional[Path] = None,
    system_wide: bool = False,
    setup_git_aliases: bool = True,
) -> Tuple[bool, List[str], List[str]]:
    """Install git-tools shims and scripts to the specified or default bin directory.

    Returns (success, installed_items, warnings).
    """
    if target_dir is None:
        target_dir = get_default_install_dir(system_wide=system_wide)

    src_dir = get_source_scripts_dir()
    installed_items: List[str] = []
    warnings: List[str] = []

    try:
        target_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return False, [], [f"Failed to create target directory '{target_dir}': {e}"]

    # Define files to install
    # 1. push/pull/sync/undo shell and powershell/cmd scripts
    # 2. command shims (push, pull, sync, git-sync, undo)
    # 3. git-tools CLI launcher
    script_files = [
        "push.sh",
        "pull.sh",
        "sync.sh",
        "undo.sh",
        "push.ps1",
        "pull.ps1",
        "sync.ps1",
        "undo.ps1",
        "push.cmd",
        "pull.cmd",
        "sync.cmd",
        "undo.cmd",
        "main.py",
        "main.sh",
        "build-remote.sh",
    ]

    for fname in script_files:
        src_file = src_dir / fname
        if src_file.exists():
            dest_file = target_dir / fname
            try:
                shutil.copy2(src_file, dest_file)
                make_executable(dest_file)
                installed_items.append(str(dest_file))
            except Exception as e:
                warnings.append(f"Could not copy '{fname}' to '{dest_file}': {e}")

    # On POSIX (Linux/macOS), create direct shims or symlinks
    if os.name != "nt":
        for cmd_name, script_name in [
            ("push", "push.sh"),
            ("pull", "pull.sh"),
            ("sync", "sync.sh"),
            ("git-sync", "sync.sh"),
            ("undo", "undo.sh"),
            ("build-remote", "build-remote.sh"),
        ]:
            dest_cmd = target_dir / cmd_name
            target_script = target_dir / script_name
            try:
                if dest_cmd.exists() or dest_cmd.is_symlink():
                    dest_cmd.unlink()
                # Create wrapper script or symlink
                dest_cmd.symlink_to(target_script.name)
                make_executable(dest_cmd)
                installed_items.append(str(dest_cmd))
            except Exception:
                # If symlink fails, copy directly
                try:
                    shutil.copy2(src_dir / script_name, dest_cmd)
                    make_executable(dest_cmd)
                    installed_items.append(str(dest_cmd))
                except Exception as e:
                    warnings.append(f"Failed to create '{cmd_name}' shim: {e}")

        # Install git-tools executable
        cli_src = src_dir / "git-tools"
        cli_dest = target_dir / "git-tools"
        if cli_src.exists():
            try:
                shutil.copy2(cli_src, cli_dest)
                make_executable(cli_dest)
                installed_items.append(str(cli_dest))
            except Exception as e:
                warnings.append(f"Failed to install git-tools CLI: {e}")

        # Install git_tools Python package directory alongside executables
        pkg_src = src_dir / "git_tools"
        pkg_dest = target_dir / "git_tools"
        if pkg_src.is_dir():
            try:
                if pkg_dest.exists():
                    shutil.rmtree(pkg_dest)
                shutil.copytree(pkg_src, pkg_dest)
                installed_items.append(str(pkg_dest))
            except Exception as e:
                warnings.append(f"Failed to install git_tools package: {e}")

        # Install git-tools-launcher executable
        launcher_src = src_dir / "git-tools-launcher"
        launcher_dest = target_dir / "git-tools-launcher"
        if launcher_src.exists():
            try:
                shutil.copy2(launcher_src, launcher_dest)
                make_executable(launcher_dest)
                installed_items.append(str(launcher_dest))
            except Exception as e:
                warnings.append(f"Failed to install git-tools-launcher: {e}")

        # On Linux, register .desktop, .metainfo.xml, and icons for GNOME / desktop integration
        if platform.system() == "Linux":
            is_default = (target_dir.resolve() == get_default_install_dir(system_wide=system_wide).resolve())
            if system_wide:
                apps_dir = Path("/usr/share/applications")
                metainfo_dir = Path("/usr/share/metainfo")
                icons_dir = Path("/usr/share/icons/hicolor/scalable/apps")
            elif is_default:
                data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
                apps_dir = data_home / "applications"
                metainfo_dir = data_home / "metainfo"
                icons_dir = data_home / "icons/hicolor/scalable/apps"
            else:
                apps_dir = target_dir.parent / "share" / "applications"
                metainfo_dir = target_dir.parent / "share" / "metainfo"
                icons_dir = target_dir.parent / "share" / "icons" / "hicolor" / "scalable" / "apps"

            proj_root = src_dir.parent
            desktop_src = proj_root / "build-linux/git-tools.desktop"
            metainfo_src = proj_root / "build-linux/com.wheelhouser.git-tools.metainfo.xml"

            icon_launcher_src = proj_root / "assets/icons/git-tools.svg"
            if not icon_launcher_src.exists():
                icon_launcher_src = proj_root / "assets/icons/icon.svg"

            icon_rdnn_src = proj_root / "assets/icons/com.wheelhouser.git-tools.svg"
            if not icon_rdnn_src.exists():
                icon_rdnn_src = proj_root / "assets/icons/icon.svg"

            try:
                if desktop_src.exists():
                    apps_dir.mkdir(parents=True, exist_ok=True)
                    desktop_dest = apps_dir / "git-tools.desktop"
                    shutil.copy2(desktop_src, desktop_dest)
                    make_executable(desktop_dest)
                    # Remove any legacy duplicate launcher symlinks to prevent duplicate dock icons
                    desktop_alias = apps_dir / "com.wheelhouser.git-tools.desktop"
                    if desktop_alias.exists() or desktop_alias.is_symlink():
                        desktop_alias.unlink()
                    installed_items.append(f"Desktop Entry ('{desktop_dest}')")

                    # Also install to ~/Desktop for quick launcher access on user installs
                    if is_default and not system_wide:
                        desktop_folder = Path.home() / "Desktop"
                        if desktop_folder.exists():
                            old_desktop = desktop_folder / "com.wheelhouser.git-tools.desktop"
                            if old_desktop.exists() or old_desktop.is_symlink():
                                old_desktop.unlink()
                            user_desktop_dest = desktop_folder / "git-tools.desktop"
                            shutil.copy2(desktop_src, user_desktop_dest)
                            make_executable(user_desktop_dest)
                            subprocess.run(["gio", "set", str(user_desktop_dest), "metadata::trusted", "true"], capture_output=True, check=False)
                            installed_items.append(f"Desktop Launcher ('{user_desktop_dest}')")

                if metainfo_src.exists():
                    metainfo_dir.mkdir(parents=True, exist_ok=True)
                    metainfo_dest = metainfo_dir / "com.wheelhouser.git-tools.metainfo.xml"
                    shutil.copy2(metainfo_src, metainfo_dest)
                    meta_alias = metainfo_dir / "git-tools.metainfo.xml"
                    if meta_alias.exists() or meta_alias.is_symlink():
                        meta_alias.unlink()
                    meta_alias.symlink_to(metainfo_dest.name)
                    installed_items.append(f"AppStream Metadata ('{metainfo_dest}')")

                if icon_launcher_src.exists():
                    icons_dir.mkdir(parents=True, exist_ok=True)
                    icon_launcher_dest = icons_dir / "git-tools.svg"
                    shutil.copy2(icon_launcher_src, icon_launcher_dest)
                    installed_items.append(f"Application Icon ('{icon_launcher_dest}')")

                if icon_rdnn_src.exists():
                    icons_dir.mkdir(parents=True, exist_ok=True)
                    icon_rdnn_dest = icons_dir / "com.wheelhouser.git-tools.svg"
                    shutil.copy2(icon_rdnn_src, icon_rdnn_dest)
                    installed_items.append(f"Software Center Icon ('{icon_rdnn_dest}')")

                man_src = proj_root / "man" / "git-tools.8"
                if man_src.exists():
                    man_dir = apps_dir.parent / "man" / "man8"
                    man_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(man_src, man_dir / "git-tools.8")
                    installed_items.append(f"Manual Page ('{man_dir / 'git-tools.8'}')")

                subprocess.run(["update-desktop-database", str(apps_dir)], capture_output=True, check=False)
                icon_parent = icons_dir.parent.parent.parent
                subprocess.run(["gtk-update-icon-cache", "-q", "-t", str(icon_parent)], capture_output=True, check=False)
            except Exception as e:
                warnings.append(f"Could not register desktop entry: {e}")

    # Set up global Git aliases if requested and Git is available
    if setup_git_aliases:
        try:
            if os.name == "nt":
                ps_path = target_dir / "push.ps1"
                pl_path = target_dir / "pull.ps1"
                sy_path = target_dir / "sync.ps1"
                un_path = target_dir / "undo.ps1"
                subprocess.run(
                    ["git", "config", "--global", "alias.push-repo", f"!powershell -NoProfile -ExecutionPolicy Bypass -File \"{ps_path}\""],
                    check=False,
                    capture_output=True,
                )
                subprocess.run(
                    ["git", "config", "--global", "alias.pull-repo", f"!powershell -NoProfile -ExecutionPolicy Bypass -File \"{pl_path}\""],
                    check=False,
                    capture_output=True,
                )
                subprocess.run(
                    ["git", "config", "--global", "alias.sync-repo", f"!powershell -NoProfile -ExecutionPolicy Bypass -File \"{sy_path}\""],
                    check=False,
                    capture_output=True,
                )
                subprocess.run(
                    ["git", "config", "--global", "alias.undo-commit", f"!powershell -NoProfile -ExecutionPolicy Bypass -File \"{un_path}\""],
                    check=False,
                    capture_output=True,
                )
            else:
                subprocess.run(["git", "config", "--global", "alias.push-repo", "!push"], check=False, capture_output=True)
                subprocess.run(["git", "config", "--global", "alias.pull-repo", "!pull"], check=False, capture_output=True)
                subprocess.run(["git", "config", "--global", "alias.sync-repo", "!sync"], check=False, capture_output=True)
                subprocess.run(["git", "config", "--global", "alias.undo-commit", "!undo"], check=False, capture_output=True)
            installed_items.append("Git Global Aliases ('git push-repo', 'git pull-repo', 'git sync-repo', 'git undo-commit')")
        except Exception as e:
            warnings.append(f"Failed to configure Git global aliases: {e}")

    # Check if target directory is in PATH
    if not is_dir_in_path(target_dir):
        warnings.append(
            f"Directory '{target_dir}' is NOT currently in your PATH environment variable. "
            f"Add 'export PATH=\"{target_dir}:$PATH\"' to your ~/.bashrc or ~/.zshrc."
        )

    return True, installed_items, warnings


def uninstall_tools(
    target_dir: Optional[Path] = None,
    system_wide: bool = False,
    remove_git_aliases: bool = True,
) -> Tuple[bool, List[str], List[str]]:
    """Uninstall git-tools shims and scripts from target directory."""
    if target_dir is None:
        target_dir = get_default_install_dir(system_wide=system_wide)

    removed_items: List[str] = []
    warnings: List[str] = []

    files_to_remove = [
        "push",
        "pull",
        "sync",
        "git-sync",
        "undo",
        "push.sh",
        "pull.sh",
        "sync.sh",
        "undo.sh",
        "push.ps1",
        "pull.ps1",
        "sync.ps1",
        "undo.ps1",
        "push.cmd",
        "pull.cmd",
        "sync.cmd",
        "undo.cmd",
        "git-tools",
        "git-tools.cmd",
        "git-tools.ps1",
        "git-tools-launcher",
        "main.py",
        "main.sh",
        "build-remote.sh",
        "build-remote",
        "git_tools",
    ]

    for fname in files_to_remove:
        fpath = target_dir / fname
        if fpath.exists() or fpath.is_symlink():
            try:
                if fpath.is_dir() and not fpath.is_symlink():
                    shutil.rmtree(fpath)
                else:
                    fpath.unlink()
                removed_items.append(str(fpath))
            except Exception as e:
                warnings.append(f"Failed to remove '{fpath}': {e}")

    # On Linux, clean up .desktop, .metainfo.xml, and icons
    if platform.system() == "Linux":
        is_default = (target_dir.resolve() == get_default_install_dir(system_wide=system_wide).resolve())
        if system_wide:
            apps_dir = Path("/usr/share/applications")
            metainfo_dir = Path("/usr/share/metainfo")
            icons_dir = Path("/usr/share/icons/hicolor/scalable/apps")
        elif is_default:
            data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
            apps_dir = data_home / "applications"
            metainfo_dir = data_home / "metainfo"
            icons_dir = data_home / "icons/hicolor/scalable/apps"
        else:
            apps_dir = target_dir.parent / "share" / "applications"
            metainfo_dir = target_dir.parent / "share" / "metainfo"
            icons_dir = target_dir.parent / "share" / "icons" / "hicolor" / "scalable" / "apps"

        for dfile in [apps_dir / "com.wheelhouser.git-tools.desktop", apps_dir / "git-tools.desktop"]:
            if dfile.exists() or dfile.is_symlink():
                try:
                    dfile.unlink()
                    removed_items.append(str(dfile))
                except Exception as e:
                    warnings.append(f"Failed to remove '{dfile}': {e}")

        # Also remove from ~/Desktop if it exists
        if is_default and not system_wide:
            desktop_folder = Path.home() / "Desktop"
            for dfile in [desktop_folder / "com.wheelhouser.git-tools.desktop", desktop_folder / "git-tools.desktop"]:
                if dfile.exists() or dfile.is_symlink():
                    try:
                        dfile.unlink()
                        removed_items.append(str(dfile))
                    except Exception as e:
                        warnings.append(f"Failed to remove '{dfile}': {e}")

        for mfile in [metainfo_dir / "com.wheelhouser.git-tools.metainfo.xml", metainfo_dir / "git-tools.metainfo.xml"]:
            if mfile.exists() or mfile.is_symlink():
                try:
                    mfile.unlink()
                    removed_items.append(str(mfile))
                except Exception as e:
                    warnings.append(f"Failed to remove '{mfile}': {e}")

        for ifile in [icons_dir / "com.wheelhouser.git-tools.svg", icons_dir / "git-tools.svg"]:
            if ifile.exists() or ifile.is_symlink():
                try:
                    ifile.unlink()
                    removed_items.append(str(ifile))
                except Exception as e:
                    warnings.append(f"Failed to remove '{ifile}': {e}")

        # Remove manpage
        for mfile in [apps_dir.parent / "man" / "man8" / "git-tools.8", apps_dir.parent / "man" / "man8" / "git-tools.8.gz"]:
            if mfile.exists() or mfile.is_symlink():
                try:
                    mfile.unlink()
                    removed_items.append(str(mfile))
                except Exception as e:
                    warnings.append(f"Failed to remove '{mfile}': {e}")

        subprocess.run(["update-desktop-database", str(apps_dir)], capture_output=True, check=False)
        icon_parent = icons_dir.parent.parent.parent
        subprocess.run(["gtk-update-icon-cache", "-q", "-t", str(icon_parent)], capture_output=True, check=False)

        # Prune GNOME dock favorites if present
        try:
            res = subprocess.run(["gsettings", "get", "org.gnome.shell", "favorite-apps"], capture_output=True, text=True, check=False)
            if res.returncode == 0 and ("git-tools.desktop" in res.stdout or "com.wheelhouser.git-tools.desktop" in res.stdout):
                import ast
                favs = ast.literal_eval(res.stdout.strip())
                new_favs = [f for f in favs if f not in ("git-tools.desktop", "com.wheelhouser.git-tools.desktop")]
                subprocess.run(["gsettings", "set", "org.gnome.shell", "favorite-apps", str(new_favs)], capture_output=True, check=False)
                removed_items.append("GNOME dock favorites entry")
        except Exception:
            pass

    if remove_git_aliases:
        try:
            for alias in ["push-repo", "pull-repo", "sync-repo", "undo-commit"]:
                subprocess.run(["git", "config", "--global", "--unset", f"alias.{alias}"], check=False, capture_output=True)
            removed_items.append("Git Global Aliases ('git push-repo', 'git pull-repo', 'git sync-repo', 'git undo-commit')")
        except Exception as e:
            warnings.append(f"Could not unset Git global aliases: {e}")

    return True, removed_items, warnings

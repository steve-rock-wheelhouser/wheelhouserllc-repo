"""Wheelhouser Git Tools Version Information.

Dynamically inherits VERSION from src/main.py as the single source of truth.
"""

from __future__ import annotations

import re
from pathlib import Path


def _resolve_version() -> str:
    try:
        main_py = Path(__file__).resolve().parent.parent / "main.py"
        if main_py.exists():
            match = re.search(r"^VERSION\s*=\s*['\"]([^'\"]+)['\"]", main_py.read_text(encoding="utf-8"), re.MULTILINE)
            if match:
                return match.group(1)
    except Exception:
        pass
    return "1.4.1"


__version__ = _resolve_version()
VERSION = __version__
APP_VERSION = __version__

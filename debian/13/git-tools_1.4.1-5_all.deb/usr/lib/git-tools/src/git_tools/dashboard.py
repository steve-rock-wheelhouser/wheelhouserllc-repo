"""Wheelhouser Git Tools - Interactive Terminal Dashboard.

Provides an interactive terminal dashboard featuring:
- App title set to 'git-tools'
- Persistent projects root configuration (~/Projects on Linux/macOS, C:/Users/<user>/ on Windows)
- Real-time arrow-key (Up/Down) navigation to select active project
- Instant persistence of selected project and root across sessions
- Direct single-key invocation of push, pull, sync, undo, graph, secret audit, and fleet status
"""

from __future__ import annotations

import os
import platform
import select
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .branch import (
    list_repository_branches,
    render_branches_dashboard,
    switch_repository_branch,
)
from .config import (
    get_config_path,
    get_current_project,
    get_default_projects_root,
    get_projects_root,
    list_projects,
    load_config,
    set_current_project,
    set_projects_root,
)
from .fleet import inspect_repository, render_fleet_dashboard, scan_fleet
from .installer import get_source_scripts_dir
from .version import __version__

# Enable Virtual Terminal Processing on Windows if available
if os.name == "nt":
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass

# In-memory repository status cache to prevent sluggish subprocess execution on keystrokes
_repo_status_cache: Dict[str, Tuple[float, Any]] = {}


def get_cached_repo_status(repo_path: Optional[Path], ttl: float = 15.0) -> Any:
    """Retrieve repository status, utilizing in-memory cache to prevent lag during rapid navigation."""
    if not repo_path or not (repo_path / ".git").exists():
        return None
    key = str(repo_path.resolve())
    now = time.time()
    if key in _repo_status_cache:
        cached_time, cached_val = _repo_status_cache[key]
        if now - cached_time < ttl:
            return cached_val
    stat = inspect_repository(repo_path)
    _repo_status_cache[key] = (now, stat)
    return stat


def clear_repo_status_cache(repo_path: Optional[Path] = None) -> None:
    """Invalidate cached status for a repository or clear all caches."""
    if repo_path:
        _repo_status_cache.pop(str(repo_path.resolve()), None)
    else:
        _repo_status_cache.clear()


def launch_in_macos_terminal() -> bool:
    """Launch the interactive dashboard inside macOS Terminal.app when clicked in Finder."""
    if sys.platform != "darwin":
        return False
    if getattr(sys, "frozen", False):
        exe_path = str(Path(sys.executable).resolve())
    else:
        cand = Path(__file__).resolve().parent.parent / "git-tools"
        exe_path = str(cand if cand.exists() else Path(sys.executable))

    script = f'''tell application "Terminal"
        activate
        do script "'{exe_path}' dashboard"
    end tell'''
    try:
        subprocess.Popen(["osascript", "-e", script])
        return True
    except Exception:
        return False


# ANSI escape styling constants - Cursor Home + Clear to EOS prevents screen blink/flicker
ESC_CLEAR = "\033[H\033[J"
ESC_TITLE = "\033]0;git-tools\007"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
MAGENTA = "\033[35m"
BLUE = "\033[34m"
REVERSE = "\033[7m"
RESET = "\033[0m"


def set_terminal_title(title: str = "git-tools") -> None:
    """Set the terminal emulator window and icon title."""
    try:
        sys.stdout.write(f"\033]0;{title}\007")
        sys.stdout.flush()
    except Exception:
        pass


def _get_key_unix() -> str:
    """Read a single keypress or escape sequence on Unix."""
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        seq = os.read(fd, 32)
        if not seq:
            return ""

        # If solitary ESC byte, wait briefly to see if cursor sequence follows
        if seq == b"\x1b":
            r, _, _ = select.select([sys.stdin], [], [], 0.05)
            if r:
                seq += os.read(fd, 31)

        # Parse cursor / arrow keys (ANSI, SS3 application mode, extended keys)
        if seq in (b"\x1b[A", b"\x1bOA", b"\x1b[1;2A", b"\x1b[1;5A", b"\x1b[1;3A"):
            return "UP"
        elif seq in (b"\x1b[B", b"\x1bOB", b"\x1b[1;2B", b"\x1b[1;5B", b"\x1b[1;3B"):
            return "DOWN"
        elif seq in (b"\x1b[C", b"\x1bOC", b"\x1b[1;2C", b"\x1b[1;5C", b"\x1b[1;3C"):
            return "RIGHT"
        elif seq in (b"\x1b[D", b"\x1bOD", b"\x1b[1;2D", b"\x1b[1;5D", b"\x1b[1;3D"):
            return "LEFT"
        elif seq in (b"\x1b[5~", b"\x1b[5"):
            return "PAGE_UP"
        elif seq in (b"\x1b[6~", b"\x1b[6"):
            return "PAGE_DOWN"
        elif seq in (b"\x1b[H", b"\x1b[1~"):
            return "HOME"
        elif seq in (b"\x1b[F", b"\x1b[4~"):
            return "END"
        elif seq in (b"\r", b"\n"):
            return "ENTER"
        elif seq == b" ":
            return "SPACE"
        elif seq == b"\x03":
            return "CTRL_C"
        elif seq in (b"\x04", b"\x1a"):
            return "QUIT"
        elif seq == b"\x1b":
            return "ESC"

        try:
            return seq.decode("utf-8", errors="ignore")
        except Exception:
            return ""
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _get_key_windows() -> str:
    """Read a single keypress or escape sequence on Windows."""
    import msvcrt

    getch = getattr(msvcrt, "getch")
    ch = getch()
    if ch in (b"\x00", b"\xe0"):
        ch2 = getch()
        if ch2 == b"H":
            return "UP"
        elif ch2 == b"P":
            return "DOWN"
        elif ch2 == b"M":
            return "RIGHT"
        elif ch2 == b"K":
            return "LEFT"
        elif ch2 == b"I":
            return "PAGE_UP"
        elif ch2 == b"Q":
            return "PAGE_DOWN"
        return "SPECIAL"
    elif ch in (b"\r", b"\n"):
        return "ENTER"
    elif ch == b"\x03":
        return "CTRL_C"
    try:
        return ch.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def read_key() -> str:
    """Read keypress portably across Unix and Windows platforms."""
    if not sys.stdin.isatty():
        line = sys.stdin.readline()
        return line.strip()

    if os.name == "nt":
        return _get_key_windows()
    return _get_key_unix()


def run_action_in_dir(cmd_args: List[str], target_dir: Path) -> int:
    """Execute command args within the given directory and wait for return."""
    print(f"\n{DIM}--> [{target_dir.name}] {' '.join(cmd_args)}{RESET}\n")
    try:
        proc = subprocess.run(cmd_args, cwd=str(target_dir))
        return proc.returncode
    except Exception as e:
        print(f"❌ Execution failed: {e}", file=sys.stderr)
        return 1


def interactive_dashboard() -> int:
    """Main interactive terminal dashboard loop."""
    set_terminal_title("git-tools")

    # Load configuration
    projects_root = get_projects_root()
    curr_proj_name = get_current_project()

    # If non-interactive environment, check for macOS Finder launch or print overview
    if not sys.stdin.isatty():
        if sys.platform == "darwin":
            if launch_in_macos_terminal():
                return 0
        print(f"git-tools v{__version__} - Non-interactive mode")
        print(f"Projects Root: {projects_root}")
        print(f"Current Project: {curr_proj_name}")
        return 0

    selected_idx = 0
    message = ""
    cached_projects_root: Optional[Path] = None
    projects: List[Path] = []

    while True:
        # Refresh projects list from projects_root only when root changes or list is empty
        if cached_projects_root != projects_root or not projects:
            projects = list_projects(projects_root)
            cached_projects_root = projects_root

        # Match selected index with saved current_project if available and valid
        if curr_proj_name and any(p.name == curr_proj_name for p in projects):
            for i, p in enumerate(projects):
                if p.name == curr_proj_name:
                    selected_idx = i
                    break
        elif projects:
            selected_idx = max(0, min(selected_idx, len(projects) - 1))
            curr_proj_name = projects[selected_idx].name
        else:
            selected_idx = 0
            curr_proj_name = None

        active_path = projects_root / curr_proj_name if curr_proj_name else None
        active_status = get_cached_repo_status(active_path) if active_path and active_path.exists() else None

        # Render Terminal Screen
        sys.stdout.write(ESC_CLEAR)
        set_terminal_title("git-tools")

        print(f"{BOLD}{CYAN}=================================================================={RESET}")
        print(f"{BOLD}             WHEELHOUSER GIT TOOLS v{__version__} - DASHBOARD{RESET}")
        print(f"{BOLD}{CYAN}=================================================================={RESET}")
        print(f"{BOLD}Projects Root:{RESET}   {projects_root} {DIM}(Press 'r' to change){RESET}")
        
        if active_path:
            status_text = ""
            if active_status:
                sync_state = "✓ Clean" if active_status.is_clean else f"{active_status.modified_count} mod, {active_status.untracked_count} untracked"
                remote_state = ""
                if active_status.ahead > 0:
                    remote_state += f" ↑{active_status.ahead}"
                if active_status.behind > 0:
                    remote_state += f" ↓{active_status.behind}"
                if not remote_state:
                    remote_state = " [In Sync]"
                status_text = f" ({active_status.branch}) [{sync_state}{remote_state}]"
            else:
                status_text = f" {DIM}(Not a Git repository){RESET}"
            print(f"{BOLD}Active Project:{RESET}  {GREEN}{BOLD}{curr_proj_name}{RESET}{status_text}")
        else:
            print(f"{BOLD}Active Project:{RESET}  {YELLOW}(None found in {projects_root}){RESET}")

        print(f"{BOLD}Config File:{RESET}     {DIM}{get_config_path()}{RESET}")
        print(f"{CYAN}------------------------------------------------------------------{RESET}")

        # Render Project Navigator List
        if not projects:
            print(f"\n  {YELLOW}⚠️  No projects found under {projects_root}.{RESET}")
            print(f"  {DIM}Press 'r' to change the Projects Root path.{RESET}\n")
        else:
            total_projects = len(projects)
            page_size = 8
            start_page = max(0, min(selected_idx - page_size // 2, total_projects - page_size))
            end_page = min(total_projects, start_page + page_size)

            print(f"{BOLD}Projects ({total_projects} total) - {CYAN}Use [↑]/[↓] arrows to navigate project/{RESET}:")
            if start_page > 0:
                print(f"  {DIM}▲ {start_page} more project(s) above...{RESET}")

            for idx in range(start_page, end_page):
                proj = projects[idx]
                is_selected = (idx == selected_idx)
                
                # Check repo branch/status preview with cache
                branch_label = ""
                git_dir = proj / ".git"
                if git_dir.exists():
                    p_stat = get_cached_repo_status(proj)
                    if p_stat:
                        c_marker = f"{GREEN}✓{RESET}" if p_stat.is_clean else f"{YELLOW}•{RESET}"
                        branch_label = f" [{p_stat.branch}] {c_marker}"
                    else:
                        branch_label = " [git]"
                else:
                    branch_label = f" {DIM}[dir]{RESET}"

                if is_selected:
                    print(f"  {BOLD}{CYAN}► {idx + 1:2d}. {REVERSE} {proj.name:<24} {RESET}{branch_label}")
                else:
                    print(f"    {idx + 1:2d}. {proj.name:<24}{branch_label}")

            if end_page < total_projects:
                print(f"  {DIM}▼ {total_projects - end_page} more project(s) below...{RESET}")

        print(f"{CYAN}------------------------------------------------------------------{RESET}")
        print(f"{BOLD}Quick Actions for '{curr_proj_name or 'project'}':{RESET}")
        print(f"  {CYAN}[1]{RESET} Push (Pre-commit audit & upstream)  {CYAN}[5]{RESET} Visual Git Graph")
        print(f"  {CYAN}[2]{RESET} Pull (Autostash rebase)             {CYAN}[6]{RESET} Scan Secrets Audit")
        print(f"  {CYAN}[3]{RESET} Sync (Bidirectional pull + push)    {CYAN}[7]{RESET} Prune Merged Branches (dry-run)")
        print(f"  {CYAN}[4]{RESET} Undo (Safe commit rollback)         {CYAN}[8]{RESET} Fleet Status Dashboard")
        print(f"  {CYAN}[9]{RESET} Build (Remote via Orchestra)        {CYAN}[b]{RESET} Branches (View & Switch)")
        print(f"  {CYAN}[s]{RESET} System Status Diagnostics           {CYAN}[r]{RESET} Set Projects Root directory")
        print(f"  {CYAN}[q]{RESET} Exit Dashboard")
        print(f"{CYAN}=================================================================={RESET}")

        if message:
            print(f"\n{message}\n")
            message = ""

        # Wait for keypress
        key = read_key()

        if key in ("UP", "k"):
            if projects:
                selected_idx = (selected_idx - 1) % len(projects)
                curr_proj_name = projects[selected_idx].name
        elif key in ("DOWN", "j"):
            if projects:
                selected_idx = (selected_idx + 1) % len(projects)
                curr_proj_name = projects[selected_idx].name
        elif key in ("PAGE_UP",):
            if projects:
                selected_idx = max(0, selected_idx - 5)
                curr_proj_name = projects[selected_idx].name
        elif key in ("PAGE_DOWN",):
            if projects:
                selected_idx = min(len(projects) - 1, selected_idx + 5)
                curr_proj_name = projects[selected_idx].name
        elif key in ("HOME",):
            if projects:
                selected_idx = 0
                curr_proj_name = projects[selected_idx].name
        elif key in ("END",):
            if projects:
                selected_idx = len(projects) - 1
                curr_proj_name = projects[selected_idx].name
        elif key in ("ENTER", " "):
            if projects:
                curr_proj_name = projects[selected_idx].name
                set_current_project(curr_proj_name)
                message = f"{GREEN}✔ Current project set to '{curr_proj_name}' (saved persistently).{RESET}"
        elif key in ("q", "Q", "QUIT", "CTRL_C"):
            if curr_proj_name:
                set_current_project(curr_proj_name)
            print("\nGoodbye!\n")
            break
        elif key in ("ESC",):
            # Solitary Escape key cancels messages or selection; does NOT exit
            message = ""
        elif key in ("r", "R"):
            # Set projects root
            print()
            try:
                new_root_input = input(f"Enter new Projects Root directory [current: {projects_root}]: ").strip()
                if new_root_input:
                    resolved = set_projects_root(new_root_input)
                    projects_root = resolved
                    cached_projects_root = None
                    clear_repo_status_cache()
                    message = f"{GREEN}✔ Projects root updated to '{resolved}' (saved persistently).{RESET}"
            except (KeyboardInterrupt, EOFError):
                pass
        elif key == "1":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            if curr_proj_name:
                set_current_project(curr_proj_name)
            src_dir = get_source_scripts_dir()
            script = src_dir / ("push.ps1" if os.name == "nt" else "push.sh")
            cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] if os.name == "nt" else [str(script)]
            ret = run_action_in_dir(cmd, active_path)
            clear_repo_status_cache(active_path)
            if ret == 130:
                message = f"{YELLOW}ℹ️ Push cancelled (ESC pressed).{RESET}"
            else:
                input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "2":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            if curr_proj_name:
                set_current_project(curr_proj_name)
            src_dir = get_source_scripts_dir()
            script = src_dir / ("pull.ps1" if os.name == "nt" else "pull.sh")
            cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] if os.name == "nt" else [str(script)]
            run_action_in_dir(cmd, active_path)
            clear_repo_status_cache(active_path)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "3":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            if curr_proj_name:
                set_current_project(curr_proj_name)
            src_dir = get_source_scripts_dir()
            script = src_dir / ("sync.ps1" if os.name == "nt" else "sync.sh")
            cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] if os.name == "nt" else [str(script)]
            ret = run_action_in_dir(cmd, active_path)
            clear_repo_status_cache(active_path)
            if ret == 130:
                message = f"{YELLOW}ℹ️ Sync cancelled (ESC pressed).{RESET}"
            else:
                input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "4":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            if curr_proj_name:
                set_current_project(curr_proj_name)
            src_dir = get_source_scripts_dir()
            script = src_dir / ("undo.ps1" if os.name == "nt" else "undo.sh")
            cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] if os.name == "nt" else [str(script)]
            run_action_in_dir(cmd, active_path)
            clear_repo_status_cache(active_path)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "5":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            run_action_in_dir(["git", "log", "--graph", "--all", "--decorate", "--oneline", "--color", "-n", "20"], active_path)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "6":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            cmd = [sys.executable, "-m", "git_tools.cli", "scan-secrets", str(active_path)]
            run_action_in_dir(cmd, active_path)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "7":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            cmd = [sys.executable, "-m", "git_tools.cli", "prune-branches", "--dry-run"]
            run_action_in_dir(cmd, active_path)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "8":
            scan_target = projects_root if projects_root.exists() else Path.cwd()
            print(f"\nScanning fleet under '{scan_target}'...\n")
            fleet = scan_fleet(scan_target)
            print(render_fleet_dashboard(fleet))
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key == "9":
            if not active_path:
                message = f"{RED}❌ No active project selected.{RESET}"
                continue
            if curr_proj_name:
                set_current_project(curr_proj_name)
            cmd = [sys.executable, "-m", "git_tools.cli", "build", curr_proj_name or active_path.name]
            subprocess.run(cmd)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key in ("s", "S"):
            cmd = [sys.executable, "-m", "git_tools.cli", "status"]
            subprocess.run(cmd)
            input(f"\n{DIM}Press Enter to return to dashboard...{RESET}")
        elif key in ("b", "B"):
            if not active_path or not (active_path / ".git").exists():
                message = f"{RED}❌ Active project is not a Git repository.{RESET}"
                continue

            branches = list_repository_branches(active_path)
            sys.stdout.write(ESC_CLEAR)
            print(render_branches_dashboard(branches, active_path.name))
            print(f"\n{BOLD}Options:{RESET}")
            print(f"  • Enter branch number {CYAN}[1-{len(branches)}]{RESET} to switch")
            print(f"  • Enter branch name to switch")
            print(f"  • Enter {CYAN}[c]{RESET} to create and switch to a new branch")
            print(f"  • Press {CYAN}[ENTER]{RESET} to return to dashboard\n")

            try:
                choice = input(f"Branch action > ").strip()
                if choice:
                    if choice.lower() == "c":
                        new_branch = input("Enter new branch name: ").strip()
                        if new_branch:
                            ok, out = switch_repository_branch(active_path, new_branch, create=True)
                            if ok:
                                message = f"{GREEN}✔ {out}{RESET}"
                            else:
                                message = f"{RED}❌ {out}{RESET}"
                    elif choice.isdigit():
                        num = int(choice)
                        if 1 <= num <= len(branches):
                            target_branch = branches[num - 1].name
                            if branches[num - 1].is_remote and "/" in target_branch:
                                target_branch = target_branch.split("/", 1)[1]
                            ok, out = switch_repository_branch(active_path, target_branch, create=False)
                            if ok:
                                message = f"{GREEN}✔ {out}{RESET}"
                            else:
                                message = f"{RED}❌ {out}{RESET}"
                        else:
                            message = f"{RED}❌ Invalid branch number: {num}{RESET}"
                    else:
                        ok, out = switch_repository_branch(active_path, choice, create=False)
                        if ok:
                            message = f"{GREEN}✔ {out}{RESET}"
                        else:
                            message = f"{RED}❌ {out}{RESET}"
            except (KeyboardInterrupt, EOFError):
                pass

    return 0

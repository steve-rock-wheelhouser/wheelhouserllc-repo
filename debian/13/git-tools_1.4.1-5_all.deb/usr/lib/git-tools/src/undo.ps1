<#
.SYNOPSIS
    Wheelhouser Git Tools - undo.ps1
.DESCRIPTION
    Safely undos the most recent Git commit (git reset --soft HEAD~1),
    keeping all file modifications staged and preserved in the working tree.
.PARAMETER Hard
    Dangerous: Discards all file modifications (git reset --hard HEAD~1).
.PARAMETER Yes
    Skip confirmation prompt when using -Hard.
.PARAMETER Help
    Displays command reference.
.PARAMETER Version
    Displays version information.
#>

# Version Change Log:
# 1.3.0 - Released as GPLv3. Added dynamic version resolution from main.py.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.1 - Initial release of safe commit undo utility for PowerShell.

[CmdletBinding()]
param(
    [switch]$Hard,
    [switch]$Yes,
    [switch]$Help,
    [switch]$Version
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainPy = Join-Path $ScriptDir "main.py"
$VERSION = "1.4.1"
if (Test-Path $MainPy) {
    $match = Select-String -Path $MainPy -Pattern '^VERSION\s*=\s*["'']([^"'']+)["'']'
    if ($match -and $match.Matches.Groups.Count -gt 1) {
        $VERSION = $match.Matches.Groups[1].Value
    }
}
$APP_VERSION = $VERSION

if ($Help) {
    Write-Host "Wheelhouser Git Tools - Safe Commit Undo (v$APP_VERSION)" -ForegroundColor Cyan
    Write-Host "`nUsage: undo [options]" -ForegroundColor Yellow
    Write-Host "       undo.ps1 [options]`n" -ForegroundColor Yellow
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -Hard               Dangerous: Discard all file modifications (git reset --hard HEAD~1)."
    Write-Host "  -Yes                Skip confirmation prompt when using -Hard."
    Write-Host "  -Help               Show this documentation."
    Write-Host "  -Version            Show script version."
    exit 0
}

if ($Version) {
    Write-Host "undo (Wheelhouser Git Tools) v$APP_VERSION"
    exit 0
}

$ErrorActionPreference = "Stop"

# Verify git repository
$isGit = git rev-parse --is-inside-work-tree 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error: Current directory is not inside a Git repository." -ForegroundColor Red
    exit 1
}

# Verify parent commit
$hasParent = git rev-parse HEAD~1 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error: Repository is on initial commit. There is no parent commit to undo to." -ForegroundColor Red
    exit 1
}

$commitHash = (git rev-parse --short HEAD).Trim()
$commitMsg = (git log -1 --pretty=format:"%s").Trim()

Write-Host "==================================================================" -ForegroundColor DarkCyan
Write-Host "⏪ Undoing Commit: $commitHash (`"$commitMsg`")" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor DarkCyan

if ($Hard) {
    if (-not $Yes) {
        $confirm = Read-Host "⚠️ WARNING: -Hard will PERMANENTLY delete uncommitted changes. Proceed? [y/N]"
        if ($confirm -notmatch '^[Yy]$') {
            Write-Host "Aborted. No changes made." -ForegroundColor Yellow
            exit 0
        }
    }
    git reset --hard HEAD~1
    Write-Host "==================================================================" -ForegroundColor DarkGreen
    Write-Host "✅ [SUCCESS] Reverted to previous commit (changes discarded)." -ForegroundColor Green
    Write-Host "==================================================================" -ForegroundColor DarkGreen
} else {
    git reset --soft HEAD~1
    Write-Host "==================================================================" -ForegroundColor DarkGreen
    Write-Host "✅ [SUCCESS] Successfully rolled back commit $commitHash!" -ForegroundColor Green
    Write-Host "📁 All file modifications remain safely staged in your working tree." -ForegroundColor White
    Write-Host "   • Run 'git status' to inspect modified files." -ForegroundColor Gray
    Write-Host "   • Run 'push `"new commit message`"' when ready to re-commit." -ForegroundColor Gray
    Write-Host "==================================================================" -ForegroundColor DarkGreen
}

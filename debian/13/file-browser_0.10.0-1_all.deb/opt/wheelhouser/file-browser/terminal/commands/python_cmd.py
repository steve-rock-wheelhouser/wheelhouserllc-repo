# This file is part of Wheelhouser Shell, a terminal emulator application.
import sys
import os
import tempfile
from pathlib import Path
from typing import Optional, Tuple, List
from PySide6.QtCore import QProcess, QProcessEnvironment
from command_registry import Command


def _is_valid_executable(target: Path) -> bool:
    """Verifies that the target path is an existing, executable binary file."""
    if not target.is_file():
        return False
    if not os.access(str(target), os.X_OK):
        return False
    # To avoid picking up the dummy 0-byte MS Store execution alias which opens the Store UI,
    # test run it if its size is 0 bytes on Windows.
    if sys.platform == "win32" and target.stat().st_size == 0:
        import subprocess
        try:
            res = subprocess.run(
                [str(target), "-V"],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
                timeout=2.0,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if res.returncode != 0:
                return False
        except Exception:
            return False
    return True


def _inject_python_to_path(session, py_dir: Path) -> None:
    """Prepends the discovered Python directory and its Scripts subdir into session PATH."""
    try:
        current_paths = [p for p in session.env.get("PATH", "").split(os.pathsep) if p]
        dir_str = str(py_dir)
        scripts_dir = str(py_dir / "Scripts")
        to_add = [dir_str]
        if os.path.isdir(scripts_dir):
            to_add.append(scripts_dir)
        for d in reversed(to_add):
            if d not in current_paths:
                current_paths.insert(0, d)
        session.env["PATH"] = os.pathsep.join(current_paths)
    except Exception:
        pass


def resolve_python_executable(session) -> Tuple[Optional[str], Optional[str]]:
    """
    Resolves the appropriate Python executable to run across platforms and packaging modes.
    Returns (executable_path, error_message).
    """
    executable = sys.executable

    is_compiled = getattr(sys, "frozen", False)
    if not is_compiled:
        is_compiled = "__compiled__" in globals()
    if not is_compiled and hasattr(sys, "modules") and sys.modules.get("__main__"):
        is_compiled = hasattr(sys.modules["__main__"], "__compiled__")
    # Also check if sys.executable looks like a non-existent fake python.exe in a temp dir
    if not is_compiled and executable and not os.path.exists(executable):
        is_compiled = True

    if not is_compiled and executable and os.path.exists(executable):
        return executable, None

    # Tier 1: Check active virtual environment or local project virtualenv in working directory
    active_venv = getattr(session, "active_venv", None)
    venv_dirs: List[Path] = []
    if active_venv and isinstance(active_venv, str):
        venv_dirs.append(Path(active_venv))

    cwd_path = Path(session.cwd) if getattr(session, "cwd", None) else Path.cwd()
    for v_name in (".venv", "venv", "env"):
        venv_dirs.append(cwd_path / v_name)

    for v_dir in venv_dirs:
        sub = "Scripts" if sys.platform == "win32" else "bin"
        cand_name = "python.exe" if sys.platform == "win32" else "python"
        target = v_dir / sub / cand_name
        if _is_valid_executable(target):
            _inject_python_to_path(session, v_dir / sub)
            return str(target), None

    # Tier 2: Check session PATH (excluding temp directories and frozen app bundle)
    path_var = session.env.get("PATH", os.environ.get("PATH", ""))
    candidates = ["py.exe", "python.exe", "python3.exe"] if sys.platform == "win32" else ["python3", "python"]

    try:
        sys_temp = Path(tempfile.gettempdir()).resolve()
    except Exception:
        sys_temp = Path(tempfile.gettempdir())

    try:
        sys_frozen = Path(sys.executable).resolve().parent if sys.executable else None
    except Exception:
        sys_frozen = None

    for path_dir in path_var.split(os.pathsep):
        if not path_dir.strip():
            continue
        try:
            p_dir = Path(path_dir).resolve()
        except Exception:
            continue

        try:
            if p_dir == sys_temp or sys_temp in p_dir.parents:
                continue
            if sys_frozen and p_dir == sys_frozen:
                continue
        except Exception:
            pass

        str_dir = str(p_dir).lower()
        if "appdata\\local\\temp" in str_dir:
            continue

        for name in candidates:
            target = p_dir / name
            if _is_valid_executable(target):
                return str(target), None

    # Tier 3 & 4: Windows Registry and Well-Known System Locations
    if sys.platform == "win32":
        # Registry discovery via winreg
        try:
            import winreg  # type: ignore[import-not-found]
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for arch in (0, getattr(winreg, "KEY_WOW64_64KEY", 0), getattr(winreg, "KEY_WOW64_32KEY", 0)):
                    try:
                        access = winreg.KEY_READ | arch
                        with winreg.OpenKey(hive, r"Software\Python\PythonCore", 0, access) as core_key:
                            num_subkeys, _, _ = winreg.QueryInfoKey(core_key)
                            versions = []
                            for i in range(num_subkeys):
                                try:
                                    versions.append(winreg.EnumKey(core_key, i))
                                except OSError:
                                    pass
                            versions.sort(reverse=True)
                            for ver in versions:
                                try:
                                    with winreg.OpenKey(core_key, rf"{ver}\InstallPath", 0, access) as ip_key:
                                        try:
                                            exe_val, _ = winreg.QueryValueEx(ip_key, "ExecutablePath")
                                            if exe_val and _is_valid_executable(Path(exe_val)):
                                                _inject_python_to_path(session, Path(exe_val).parent)
                                                return str(exe_val), None
                                        except OSError:
                                            pass
                                        try:
                                            dir_val, _ = winreg.QueryValue(ip_key, "")
                                            if dir_val:
                                                for cand in candidates:
                                                    cand_target = Path(dir_val) / cand
                                                    if _is_valid_executable(cand_target):
                                                        _inject_python_to_path(session, Path(dir_val))
                                                        return str(cand_target), None
                                        except OSError:
                                            pass
                                except OSError:
                                    pass
                    except OSError:
                        pass
        except Exception:
            pass

        # Well-known fallback filesystem probing
        probe_dirs: List[Path] = []
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            py_root = Path(local_app_data) / "Programs" / "Python"
            if py_root.is_dir():
                probe_dirs.extend(sorted(py_root.glob("Python3*"), reverse=True))
            probe_dirs.append(Path(local_app_data) / "Programs" / "Python Launcher")
            probe_dirs.append(Path(local_app_data) / "Microsoft" / "WindowsApps")

        for pf_var in ("ProgramFiles", "ProgramFiles(x86)"):
            pf = os.environ.get(pf_var)
            if pf:
                py_root = Path(pf)
                if py_root.is_dir():
                    probe_dirs.extend(sorted(py_root.glob("Python3*"), reverse=True))
                probe_dirs.append(Path(pf) / "Python Launcher")

        sys_root = os.environ.get("SystemRoot", r"C:\Windows")
        probe_dirs.append(Path(sys_root))

        sys_drive = os.environ.get("SystemDrive", "C:")
        drive_root = Path(sys_drive + "\\")
        if drive_root.is_dir():
            probe_dirs.extend(sorted(drive_root.glob("Python3*"), reverse=True))

        for p_dir in probe_dirs:
            if not p_dir.is_dir():
                continue
            for name in candidates:
                target = p_dir / name
                if _is_valid_executable(target):
                    _inject_python_to_path(session, p_dir)
                    return str(target), None

    err = (
        "Error: Python interpreter not found in PATH or standard installation locations.\n"
        "Please install Python from https://www.python.org or ensure python.exe is in your PATH."
    )
    return None, err


class PythonCommand(Command):
    def __init__(self):
        super().__init__("python", "Executes a Python script.")

    def execute(self, session, args):
        executable, error_msg = resolve_python_executable(session)
        if not executable:
            session.print_output(error_msg or "Error: Python interpreter not found.")
            return

        if not args:
            session.print_output("Usage: python <script_name.py> [args] or python [flags]")
            return

        # Use -u for unbuffered output to ensure real-time updates
        cmd_args = ["-u"]
        if args[0].startswith("-"):
            cmd_args.extend(args)
        else:
            script_path = session.resolve_path(args[0])
            cmd_args.append(script_path)
            cmd_args.extend(args[1:])

        # Debug output to show exactly what is being executed
        if not getattr(session, "store_release", False):
            session.print_output(f"Debug: Executing '{executable}' with args: {cmd_args}\n")

        process = QProcess(session)
        process.setProgram(executable)
        process.setArguments(cmd_args)
        process.setWorkingDirectory(session.cwd)

        env = QProcessEnvironment.systemEnvironment()
        for k, v in session.env.items():
            env.insert(k, v)
        process.setProcessEnvironment(env)

        process.readyReadStandardOutput.connect(
            lambda: session.print_output(
                bytes(process.readAllStandardOutput().data()).decode("utf-8", errors="replace")
            )
        )
        process.readyReadStandardError.connect(
            lambda: session.print_output(
                f"\033[31m{bytes(process.readAllStandardError().data()).decode('utf-8', errors='replace')}\033[0m"
            )
        )
        process.finished.connect(lambda: setattr(session, "running_process", None))
        process.errorOccurred.connect(
            lambda err: session.print_output(
                f"Python process error: {process.errorString()} (Exec: {executable})"
            )
        )

        session.running_process = process
        process.start()
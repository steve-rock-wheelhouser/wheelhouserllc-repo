#!/usr/bin/python3
# -*- coding: utf-8 -*-
# This module handles license management for the application, including trial usage tracking,
# license verification, and activation checks.
#
#
# Copyright (C) 2025 steve.rock@wheelhouser.com
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
#
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

import hashlib
import json
import requests
from pathlib import Path
try:
    from platformdirs import user_data_dir
except ImportError:
    def user_data_dir(app_name="FileBrowser", app_author=None):
        import os, sys
        if sys.platform == "win32":
            base = os.environ.get("APPDATA", os.path.expanduser("~"))
            return os.path.join(base, app_author or "", app_name) if app_author else os.path.join(base, app_name)
        elif sys.platform == "darwin":
            return os.path.expanduser(f"~/Library/Application Support/{app_name}")
        else:
            xdg = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
            return os.path.join(xdg, app_name)
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.fernet import Fernet  # type: ignore
import base64
import logging

#============================================================================================
# License Manager for Notez
# Handles trial usage tracking, license verification, and activation checks.
# Version 1.4.0 - Refactor license manager to use Windows Registry on Windows, and add more robust machine ID retrieval on all platforms. Add diagnostic script to help users identify issues with license storage and machine ID retrieval.
#============================================================================================
class AppLicenseManager:
    def __init__(self, app_name, app_author, public_key_hex, max_trial_saves=2):
        self.app_name = app_name
        self.app_author = app_author
        # Public key for ECDSA verification (from your GCP server)
        self.public_key_hex = public_key_hex
        self.max_trial_saves = max_trial_saves
        
        # OS-agnostic storage path
        import os
        self.data_dir = Path(user_data_dir(app_name, app_author))
        
        # Set up logging to file in data_dir for debugging compiled version
        # We try to create the directory first so the log file can be written
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass # We will log this failure immediately after setup
        
        # Try to set permissions to ensure writability
        try:
            import os
            os.chmod(str(self.data_dir), 0o700)  # Set read/write/execute for owner only
        except Exception:
            pass
        self.state_file = self.data_dir / "sys_info.enc"
        
        # Set up logging to file in data_dir for debugging compiled version
        # log_path = self.data_dir / 'license_debug.log'
        # logging.basicConfig(
        #     filename=str(log_path),
        #     format='%(asctime)s - %(levelname)s - %(message)s',
        #     level=logging.DEBUG,
        #     force=True
        # )

        # logging.debug(f"LOCALAPPDATA env: {os.environ.get('LOCALAPPDATA')}")
        # logging.debug(f"user_data_dir result: {self.data_dir}")
        # logging.debug(f"data_dir created: {self.data_dir.exists()}")

        # Try to set permissions to ensure writability
        try:
            import os
            os.chmod(str(self.data_dir), 0o700)  # Set read/write/execute for owner only
            logging.debug("permissions set on data_dir")
        except Exception as e:
            logging.error(f"failed to set permissions on data_dir: {e}")
        self.state_file = self.data_dir / "sys_info.enc"
        # Secondary backup file in user home directory (hidden/dotfile) to prevent simple deletion bypass
        self.backup_file = Path.home() / ".notez_license_backup.enc"
        logging.debug(f"License Manager Initialized. Data Dir: {self.data_dir}")
        logging.debug(f"State File Path: {self.state_file}")

        self.machine_id = self._generate_machine_id()
        self.fernet = self._get_cipher()

    def _generate_machine_id(self):
        """Generates a unique hardware hash based on hostname and MAC address."""
        import platform
        import uuid
        import os
        import sys
        
        # Try to get a stable Windows MachineGUID first to avoid VPN/Network adapter shifts
        combined = None
        if os.name == 'nt':
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Cryptography", 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
                combined, _ = winreg.QueryValueEx(key, "MachineGuid")
                winreg.CloseKey(key)
                logging.debug(f"Using Windows MachineGuid: {combined}")
            except Exception as e:
                logging.debug(f"Failed to get Windows MachineGuid: {e}")
        
        elif sys.platform == 'darwin':
            # macOS: Use IOPlatformUUID
            try:
                import subprocess
                cmd = "ioreg -d2 -c IOPlatformExpertDevice | awk -F\\\" '/IOPlatformUUID/{print $(NF-1)}'"
                output = subprocess.check_output(cmd, shell=True).decode().strip()
                if output:
                    combined = output
                    logging.debug(f"Using macOS IOPlatformUUID: {combined}")
            except Exception as e:
                logging.debug(f"Failed to get macOS IOPlatformUUID: {e}")

        elif sys.platform == 'linux':
            # Linux: Use /etc/machine-id
            try:
                if os.path.exists("/etc/machine-id"):
                    with open("/etc/machine-id", "r") as f:
                        combined = f.read().strip()
                    logging.debug(f"Using Linux /etc/machine-id: {combined}")
                elif os.path.exists("/var/lib/dbus/machine-id"):
                    with open("/var/lib/dbus/machine-id", "r") as f:
                        combined = f.read().strip()
                    logging.debug(f"Using Linux /var/lib/dbus/machine-id: {combined}")
            except Exception as e:
                logging.debug(f"Failed to get Linux machine-id: {e}")
        
        if not combined:
            # Fallback to MAC address and hostname
            mac = uuid.getnode()
            hostname = platform.node()
            combined = f"{mac}:{hostname}"
            logging.debug(f"Using Legacy ID (MAC:Hostname): {combined}")

        hash_val = hashlib.sha256(combined.encode()).hexdigest()
        logging.debug(f"Final Machine ID: {hash_val}")
        
        return hash_val

    def _get_cipher(self):
        """Creates a deterministic encryption key based on the Machine ID."""
        # This ensures the file is unreadable if moved to another machine
        # Use PBKDF2 with a hardcoded salt to strengthen the key derivation
        salt = b'Wheelhouser_Notez_by_Wheelhouser_Salt_v1'
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self.machine_id.encode()))
        return Fernet(key)

    def _read_encrypted_file(self, file_path):
        """Helper to read and decrypt a state file safely."""
        if not file_path.exists():
            return None
        try:
            with open(file_path, 'rb') as f:
                encrypted_data = f.read()
            decrypted_data = self.fernet.decrypt(encrypted_data)
            return json.loads(decrypted_data)
        except Exception as e:
            logging.warning(f"Failed to read/decrypt {file_path}: {e}")
            return None

    def _write_encrypted_file(self, file_path, data):
        """Helper to encrypt and write a state file."""
        try:
            import os
            # On Windows, if the file exists and is hidden, we must unhide it before writing
            if os.name == 'nt' and file_path.exists():
                try:
                    import ctypes
                    # FILE_ATTRIBUTE_NORMAL = 0x80
                    ctypes.windll.kernel32.SetFileAttributesW(str(file_path), 0x80)
                except Exception:
                    pass

            encrypted_data = self.fernet.encrypt(json.dumps(data).encode())
            with open(file_path, 'wb') as f:
                f.write(encrypted_data)
            
            # On Windows, explicitly hide the backup file so it isn't visible to casual users
            if os.name == 'nt' and file_path == self.backup_file:
                try:
                    import ctypes
                    # FILE_ATTRIBUTE_HIDDEN = 0x02
                    ctypes.windll.kernel32.SetFileAttributesW(str(file_path), 0x02)
                except Exception:
                    pass
        except Exception as e:
            logging.error(f"Failed to write {file_path}: {e}")

    def get_trial_status(self):
        """Reads the encrypted save counter with redundancy check."""
        primary = self._read_encrypted_file(self.state_file)
        backup = self._read_encrypted_file(self.backup_file)

        # If both missing, clean slate
        if not primary and not backup:
            return {"saves": 0, "active": False}
        
        # If one is missing, restore from the other
        if primary and not backup:
            self._write_encrypted_file(self.backup_file, primary)
            return primary
        if backup and not primary:
            self._write_encrypted_file(self.state_file, backup)
            return backup
            
        # Both exist: Conflict resolution
        # Priority 1: If either is active (paid), use that
        if primary.get("active") and not backup.get("active"):
            self._write_encrypted_file(self.backup_file, primary)
            return primary
        if backup.get("active") and not primary.get("active"):
            self._write_encrypted_file(self.state_file, backup)
            return backup
            
        # Priority 2: Use the one with HIGHER usage (more saves) to prevent rollback
        p_saves = primary.get("saves", 0)
        b_saves = backup.get("saves", 0)
        
        if p_saves >= b_saves:
            # Sync backup if needed
            if p_saves > b_saves:
                self._write_encrypted_file(self.backup_file, primary)
            return primary
        else:
            # Backup has more usage, restore primary
            self._write_encrypted_file(self.state_file, backup)
            return backup

    def can_save(self):
        """Check if the user is allowed to perform a save operation."""
        status = self.get_trial_status()
        can = status["active"] or status["saves"] < self.max_trial_saves
        logging.debug(f"can_save: active={status['active']}, saves={status['saves']}, max={self.max_trial_saves}, can_save={can}")
        return can

    def increment_saves(self):
        """Increment the save counter after a successful save."""
        status = self.get_trial_status()
        new_saves = status["saves"] + 1
        logging.debug(f"increment_saves: old_saves={status['saves']}, new_saves={new_saves}")
        self.update_trial(new_saves)

    def update_trial(self, saves):
        """Saves the current trial usage encrypted."""
        status = self.get_trial_status()
        data = {"saves": saves, "active": status.get("active", False)}
        if "sig" in status:
            data["sig"] = status["sig"]
        logging.debug(f"update_trial data: {data}")
        
        # Write to both locations
        self._write_encrypted_file(self.state_file, data)
        self._write_encrypted_file(self.backup_file, data)

    def verify_license(self, signature_hex):
        """
        Validates a signed license file from GCP.
        The signature is a hash of (MachineID + AppID) signed by the Private Key.
        """
        try:
            public_key = ec.EllipticCurvePublicKey.from_encoded_point(
                ec.SECP256R1(), bytes.fromhex(self.public_key_hex)
            )
            
            # The data we expect the server to have signed
            data_to_verify = f"{self.machine_id}:{self.app_name}".encode()
            logging.debug(f"data_to_verify: {data_to_verify}")
            
            public_key.verify(
                bytes.fromhex(signature_hex),
                data_to_verify,
                ec.ECDSA(hashes.SHA256())
            )
            logging.debug("signature verified")
            return True
        except Exception as e:
            logging.error(f"signature verification failed: {e}")
            return False

    def poll_for_activation(self, gcp_url, app_name=None, price_id=None):
        """Checks the GCP server to see if a payment was successful."""
        logging.debug(f"poll_for_activation called with gcp_url={gcp_url}")
        logging.debug(f"machine_id={self.machine_id}")
        logging.debug(f"app_name={app_name}, price_id={price_id}")
        try:
            payload = {"mid": self.machine_id}
            if app_name:
                payload["app"] = app_name
            if price_id:
                payload["price_id"] = price_id
            
            check_url = f"{gcp_url}/check"
            logging.debug(f"Making request to: {check_url} with params {payload}")
            response = requests.get(check_url, params=payload, timeout=10)  # Enable SSL verification for HTTPS
            logging.debug(f"poll response status: {response.status_code}")
            logging.debug(f"poll response headers: {dict(response.headers)}")
            if response.status_code == 200:
                try:
                    json_data = response.json()
                    logging.debug(f"response JSON: {json_data}")
                    sig = json_data.get("signature")
                    logging.debug(f"received signature: {sig}")
                    if sig and self.verify_license(sig):
                        logging.debug("license verified, storing")
                        # Save verified status locally
                        self._store_final_license(sig)
                        return True
                    else:
                        logging.debug("signature verification failed")
                except json.JSONDecodeError as e:
                    logging.error(f"JSON decode error: {e}")
                    logging.error(f"response text: {response.text}")
            else:
                logging.error(f"HTTP error {response.status_code}: {response.text}")
            logging.debug("license not verified")
            return False
        except requests.exceptions.RequestException as e:
            logging.error(f"network error: {e}")
            return False
        except Exception as e:
            logging.error(f"poll exception: {e}")
            return False

    def restore_license(self, gcp_url, app_name):
        """
        Checks if a valid license exists on the server and restores it locally.
        Returns True if restored, False otherwise.
        """
        return self.poll_for_activation(gcp_url, app_name=app_name)

    def _store_final_license(self, sig):
        """Permanently locks the app as 'Paid'."""
        logging.debug(f"_store_final_license called with sig={sig}")
        data = {"saves": 0, "active": True, "sig": sig}
        logging.debug(f"storing data: {data}")
        
        # Write to both locations
        self._write_encrypted_file(self.state_file, data)
        self._write_encrypted_file(self.backup_file, data)
        
        # Additional debugging: List directory contents
        import os
        try:
            files = os.listdir(str(self.data_dir))
            logging.debug(f"Files in directory: {files}")
        except Exception as e:
            logging.error(f"Failed to list directory with os.listdir: {e}")
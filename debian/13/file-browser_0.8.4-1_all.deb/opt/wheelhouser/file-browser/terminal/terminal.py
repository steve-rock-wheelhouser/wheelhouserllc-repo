#!/usr/bin/python3
# -*- coding: utf-8 -*-
# TerminalWidget - A simple terminal interface for file management and command execution within the application.
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development, basic file browsing features
# 0.2.0 - Added terminal widget with basic commands (ls, cd,
# 0.3.0 - Added file operations (mkdir, rm, cp, mv)
# 0.4.0 - Added support for running system commands and ANSI colors
# 0.5.0 - Added Tab completion and command history
# 0.5.1 - Added command chaining with ';'
# 0.5.2 - Improved error handling and edge case handling
# 0.6.0 - Added support for command aliases and environment variables
# 0.7.0 - Add support for pipes and redirection
# 0.8.0 - Add support for virtual environments and Python package management commands (pip install, pip list, etc.)
# 0.9.0 - Add support for scripting and automation, allowing users to write and execute scripts directly within the terminal widget, enabling more complex workflows and tasks to be automated without leaving the app.
# 0.10.0 - Add support for multiple tabs in the terminal widget, allowing users to have multiple terminal sessions open simultaneously and easily switch between them, improving multitasking and productivity within the app.
# 0.11.0 - Add support for custom themes, font size, font family, and color schemes for the terminal widget, allowing users to personalize the appearance of the terminal to their liking. This will enhance the user experience and make the terminal more visually appealing.
# 0.12.0 - Apply the same tab "add button" sytling to the terminal tab that was used for the file browser, creating a more cohesive and visually consistent user interface across the application.
# 0.13.0 - Remove "Current Directory" display and replace the Terminal Tab name to be the CWD.needs to update when user changes directory using "cd" command, so that they always know where they are in the file system. This will improve usability and reduce confusion when navigating through directories in the terminal widget.
# 0.14.0 - Decouple commands from the TerminalSession class and implement a Command pattern with a CommandRegistry to manage available commands. This will make it easier to add new commands in the future and improve code organization and maintainability.
# 0.15.0 - Apply the exact same sytling from the file-broswer terminal tab to the terminal app to include custom close and color coding.
# 0.16.0 - The terminal tabs need to reflect the path in the tab name, so that users can easily see which directory they are in for each terminal tab. This will improve usability and make it easier to manage multiple terminal sessions with different working directories. 
# 0.17.0 - Added xterm color coding to the terminal output, so that users can see colored output from commands that support ANSI colors, improving readability and making it easier to distinguish different types of output in the terminal widget.
# 0.17.1 - Update cd to recognize "~" as the home directory, so that users can easily navigate to their home directory using the "cd ~" command, improving usability and providing a more familiar command experience in the terminal widget.
# 0.17.2 - ls command should accept standard flags like -l, -a, and -h, so that users can customize the output of the ls command to show more detailed information, hidden files, or human-readable file sizes, improving the functionality and usefulness of the ls command in the terminal widget.
# 0.17.3 - Added app icon.png and icon.ico to the terminal app, so that it has a professional and polished appearance when running as a standalone application, improving the overall user experience and making it visually consistent with the rest of the app.
# 0.17.4 - Added support for Windows and Linux line endings in the terminal output, so that users can see properly formatted output regardless of the operating system they are using, improving cross-platform compatibility and readability of command output in the terminal widget.
# 0.17.5 - Added support for cat command to display the contents of files directly in the terminal output, allowing users to quickly view file contents without needing to open them in a separate editor, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.5.1 - Tab complete must stop if there are multiple matches in the current directory.
# 0.17.6 - Added support for find command to search for files and directories based on name patterns, allowing users to quickly locate files within the terminal widget without needing to use a separate search tool, improving usability and providing a more powerful file management experience in the terminal widget.
# 0.17.7 - Added support for tail command to display the last few lines of a file and follow updates in real-time, allowing users to monitor log files or other continuously updated files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.8 - Added support for head command to display the first few lines of a file, allowing users to quickly view the beginning of files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.9 - Added support for wc command to count lines, words, and characters in files, allowing users to quickly get file statistics directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.10 - Added support for diff command to compare the contents of two files and display the differences, allowing users to quickly identify changes between files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.11 - Added support for grep command to search for specific patterns within files and display matching lines, allowing users to quickly find relevant information within files directly in the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.12 - Added support for sed command to perform basic text transformations on files, allowing users to quickly modify file contents directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.13 - Added support for awk command to perform more advanced text processing and data extraction from files, allowing users to quickly analyze and manipulate file contents directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.14 - Added support for tar command to create and extract tar archives, allowing users to easily manage compressed files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.15 - Added support for zip and unzip commands to create and extract zip archives, allowing users to easily manage compressed files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.16 - Added support for curl command to make HTTP requests and interact with web APIs directly from the terminal widget, allowing users to quickly test and interact with web services without needing to use a separate tool, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.17 - Added support for wget command to download files from the internet directly from the terminal widget, allowing users to easily retrieve files without needing to use a separate tool, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.18 - Added support for ping command to test network connectivity and diagnose network issues directly from the terminal widget, allowing users to quickly check their network status without needing to use a separate tool, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.19 - Added support for traceroute command to trace the route packets take to a network host, allowing users to diagnose network issues and understand their network path directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.20 - Added support for nano command to provide a simple text editor within the terminal widget, allowing users to quickly create and edit files without needing to use a separate editor, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.21 - Added support for uniq command to filter out duplicate lines in files, allowing users to quickly clean up and analyze file contents directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.22 - Added support for sort command to sort lines in files, allowing users to quickly organize and analyze file contents directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.23 - Added support for ps command to display information about running processes, allowing users to quickly check their system status and manage processes directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.24 - Added support for htop command to provide an interactive process viewer with more features than top, allowing users to easily manage their system processes directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.25 - Added support for df command to display disk space usage, allowing users to quickly check their storage status directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.26 - Added support for du command to display disk usage of files and directories, allowing users to quickly analyze their storage usage directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.27 - Added support for kill command to terminate processes by PID or name, allowing users to easily manage their system processes directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.28 - Added support for touch command to create empty files or update the timestamps of existing files, allowing users to quickly manage their files directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.29 - Added support for free command to display memory usage, allowing users to quickly check their system memory status directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.30 - Added support for less command to view file contents one page at a time, allowing users to easily read through large files directly within the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.31 - Added support for sudo command to run commands with elevated privileges, allowing users to perform administrative tasks directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.32 - Added support for chown command to change file ownership, allowing users to manage file permissions and ownership directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.33 - Added support for chmod command to change file permissions, allowing users to manage file permissions directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.34 - Added support for ln command to create symbolic links, allowing users to easily manage their files and directories with links directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.35 - Added support for ssh command to connect to remote servers, allowing users to manage their remote systems directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.36 - Added support for scp command to copy files between
# 0.17.37 - Added support for rsync command to synchronize files and directories between locations, allowing users to easily manage their file backups and transfers directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.38 - Added support for whoami command to display the current user, allowing users to quickly check their user identity directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.39 - Added support for date command to display the current date and time, allowing users to quickly check their system date and time directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.17.40 - Added support for uptime command to display how long the system has been running, allowing users to quickly check their system uptime directly from the terminal widget, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.18.0 - Added About Dialog button with version, author, company info, website link, and update check functionality, providing users with easy access to important information about the terminal application and allowing them to easily check for updates, improving user experience and keeping users informed about the latest features and improvements in the terminal widget.
# 0.18.1 - Added green "$:" prompt for the terminal input, improving the visual appearance and making it easier for users to identify where to enter their commands in the terminal widget.
# 0.18.2 - Reverse the background color coding for the active and not active tabs in the terminal widget, making the active tab Lighter and the inactive tabs darker, improving visual clarity and making it easier for users to identify which terminal tab is currently active.
# 0.18.3 - "Help" should list commands in alphabetical order and put 2 tabs after the name to improve readability, so that users can more easily find the command they are looking for in the help output, improving usability and providing a better user experience in the terminal widget.
# 0.18.4 - Improved formatting on the help output, ensuring consistent spacing and alignment for better readability and user experience.
# 0.18.5 - Add support for Preferences in a drop down menu such as Text Size and Font Family.
# 0.18.6 - Make the Preferences persistent across sessions by saving the settings to a configuration file, allowing users to maintain their preferred terminal appearance and settings even after closing and reopening the application, improving usability and providing a more personalized experience in the terminal widget.
# 0.18.7 - Use hamburger.png for the preferences button icon.
# 0.18.8 - Update Title Bar Header to only show "Terminal" instead of "Wheelhouser Terminal <Version>"
# 0.18.9 - About button should have no border.
# 0.18.10 - If the User resizes the window, have that size be persistenent across sessions by saving the size to a configuration file.
# 0.18.11 - Format the style of the "Update available in MS Store" button to be the same as the one in the file browser.
# 0.18.12 - Have the current font size and family preferences indicated in the drop down so the user knows what the current values are.
# 0.18.13 - Updated price ID and fixed font name typo.
# 0.18.14 - Added support for executing Python scripts directly from the terminal widget using the "python" command, allowing users to run their Python scripts without needing to switch to a separate terminal application, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.18.15 - Update nano to retain dimensions and position across sessions, improving usability and providing a more consistent experience when using the nano text editor within the terminal widget.
# 0.18.16 - Command history must be persistent across sessions, allowing users to access their previous commands even after closing and reopening the terminal application, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.18.17 - Have nano inherit the same font size and family preferences as the terminal widget, providing a more consistent and personalized experience when using the nano text editor within the terminal widget.
# 0.18.18 - nano update styling to match the same color scheme as the terminal widget, creating a more cohesive and visually consistent user interface when using the nano text editor within the terminal widget.
# 0.18.19 - nano line number background should be a darker shade of the terminal background color, improving readability and creating a more visually consistent user interface when using the nano text editor within the terminal widget.
# 0.18.20 - Update nano to version 0.1.7. Python syntax highlighter to be more like VS code's default dark theme for better readability and aesthetics.
# 0.18.21 - Updated nano to verion 0.1.8 Tab=4 spaces
# 0.18.22 - Updated nano to version 0.1.9. Constants and import modules are to be white.
# 0.18.23 - Updated nano to version 0.1.10. True/False/None/self/cls are now Dark Blue.
# 0.18.24 - Updated nano to version 0.1.11. UPPER_CASE constants and Numbers are now White.
# 0.18.25 - Updated nano to version 0.1.12. ints and floats are to be yellow-green like vs code.
# 0.19.0 - Updated nano to version 0.1.13. Added syntax highlighting for multi-lined docstrings in Python, improving readability and making it easier to distinguish docstrings from regular strings in the nano text editor within the terminal widget.
# 0.19.1 - Updated nano to version 0.1.14. Added support for automatic tab indentation in Python files, improving usability and making it easier to write properly indented Python code in the nano text editor within the terminal widget.
# 0.19.2 - Implement Control Sequence Processing (ANSI/VT100) to correctly interpret Carriage Return (\r), Line Feed (\n), and Erase In Line (\033[K). This is critical for supporting progress bars, spinners, and "live" status updates within the terminal output, ensuring a professional command-line experience.
# 0.19.3 - Character Encoding & Font Rendering: Ensure full UTF-8 support for modern CLI iconography (checkmarks, etc.), implement fallback handling for missing glyphs, and enforce strict monospaced integrity for perfect table alignment.
# 0.19.4 - Buffer & Viewport Management: Implement dynamic line wrapping based on viewport width, text reflow on resize, and a scrollback buffer supporting at least 1000 lines with smooth scrolling.
# 0.19.5 - Visual Styling (SGR Sequences): Add support for the full ANSI 16-color palette (standard and bright), text attributes like Bold, Italic, and Underline, and background color highlights.
# 0.19.6 - Shell Integration: Improve standard stream handling to correctly separate stdout and stderr, allowing for distinct styling (e.g., coloring stderr red) and better error visibility.
# 0.19.7 - Add support for right-click context menu in the terminal widget, providing quick access to common file operations and terminal commands, improving usability and making it easier for users to interact with the terminal widget.
# 0.19.8 - Improved error handling and edge case handling in the terminal widget, ensuring more robust and reliable operation under various conditions.
# 0.19.9 - Add support for customizable keyboard shortcuts in the terminal widget, allowing users to assign their own shortcuts for common commands and actions, improving usability and providing a more personalized experience in the terminal widget.
# 0.19.10 - Add support for preferences of text color and theme in the termainal. I like XTerm, but it looks like another one has been applied.  Let's make this a persistent choice.
# 0.19.11 - Have the view port scroll up with a $: prompot, just like it does in linux when a user presses enter on an empy line. This will ensure that the user always sees the prompt and has a consistent experience with real terminal applications.
# 0.19.12 - Have the Tabs and Directories be persistent across sessions, so that when a user opens a new terminal tab, it opens to the last directory they were in, and if they close a tab and open a new one, it should remember the last directory and tabs they had open. This will improve usability and provide a more seamless experience when using multiple terminal tabs within the application.
# 0.19.13 - ls; pwd or pwd; ls does not add a new line between the output of the two commands, which makes it hard to read. Add a new line between the output of chained commands
# 0.19.14 - Add support for environment variable management in the terminal widget, allowing users to set, view, and manage environment variables directly within the terminal, improving functionality and providing a more complete command-line experience.
# 0.19.15 - When I enter a command, a new line must be added, so that the output of the command is separated from the command itself, improving readability and providing a more professional command-line experience in the terminal widget.
# 0.19.16 - Updating Keyboard shortcuts are not working as expected.
# 0.19.17 - The keyboard shortcuts need to respect the case of the keys and display it correctly in the viewport.  Ctrl+p should not trigger when I press Ctrl+Shift+p (P), and vice versa. This will improve usability and prevent unintended actions when using keyboard shortcuts in the terminal widget.
# 0.19.18 - make the display of the keyboard shortcut display lower case if the command sequence did not include the shift key. For example, if I record <ctrl+p> I expect to see Ctrl+p, not Ctrl+P displayed.
# 0.19.19 - If I close a tab, the one next (left) to it should become active. This will improve usability and provide a more intuitive experience when managing multiple terminal tabs within the application.
# 0.19.20 - Even though I have deleted the license file and ran reset_license.py, the About is still showing a "Pro" license.  It should not have a license unless I have purchased one.
# 0.19.41 - Make the boarder on Fedora Linux the same as the one on Windows, so that users on Fedora have the same visual experience as users on Windows, improving cross-platform consistency and providing a more cohesive user interface for all users of the terminal widget.
# 0.19.42 - Center the preferences check mark or give it more padding on the the left side.
# 0.19.43 - debugging python commands need to have a \n added to prevent lines from running on
# 0.19.44 - Turn off debug output for python commands when STROE_RELEASE is set to true, so that users do not see the debug output when running Python commands in the terminal widget, providing a cleaner and more professional user experience in release builds of the application.
# 0.19.45 - Tool Tip styling must be black without a border radius and minimal padding to match the tooltip styling in the file browser.
# 0.19.46 - Add the current working dir to command prompt, so that users can always see their current directory in the terminal prompt, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.19.47 - Remove "Enter Command" and set the color of the prompt to be consistent with the color scheme of the terminal widget, improving visual consistency and providing a more cohesive user interface in the terminal widget.
# 0.20.0 - Added support for adding custom themes and fonts via plugins, allowing users to further customize the appearance of the terminal widget to their liking, improving user experience and providing a more visually appealing terminal widget..
# 0.20.1 - Have the active tab pick up the background color of the theme, and apply it to the tab left, top, and right borders.
# 0.20.2 - Apply the border styling to the tab navigator arrow buttons the same as the preferences button, so it looks consistent and visually cohesive with the rest of the terminal widget's user interface.
# 0.20.3 - Make the tab navigator arrow buttons wider and more visible, improving usability and making it easier for users to navigate between terminal tabs when they have many tabs open, enhancing the overall user experience in the terminal widget.
# 0.20.4 - Fixed the size of the tab navigator scroll buttons to be 30x30px using direct widget manipulation, ensuring they match the preferences button size.
# 0.20.5 - Re-applied CSS sizing for tab navigator buttons to ensure 30x30px dimensions and corrected tooltip behavior for the back button.
# 0.20.6 - Implemented event filter on QTabBar to robustly enforce scroll button sizing and tooltips on resize and layout events.
# 0.20.7 - Fixed AttributeError in TerminalSession event filter by moving tab bar event handling to TerminalWidget.
# 0.20.8 - Reverted tab navigator scroll buttons to default PySide size and behavior.
# 0.20.9 - Added nano support for .json color coding and updated the nano version.
# 0.20.10 - add json bracket color coding to nano, so that when users open .json files in the nano text editor within the terminal widget, the brackets will be color coded for better readability and easier navigation of the file structure.
# 0.20.11 - Updated nano to support rainbow bracket highlighting for JSON files, improving readability of nested structures.
# 0.20.12 - Updated dark theme in main() to run on systems with no dark theme support, ensuring the terminal widget has a consistent appearance across all platforms, even those without native dark theme support.
# 0.20.13 - Fixed an issue where all font families were checked in the preferences menu on initial launch by improving the active font detection logic to handle font stacks correctly.
# 0.20.14 - Add more fonts to the font family preferences, including popular programming fonts like Fira Code, JetBrains Mono, and Cascadia Mono, giving users more options to customize the appearance of their terminal widget and improve readability based on their personal preferences.
# 0.20.15 - Create C:\Users\<USER>\AppData\Local\Wheelhouser\Terminal\themes and fonts directories if they do not exist, ensuring that users have a designated location to add their custom themes and fonts for the terminal widget, improving usability and providing a more seamless experience when customizing the terminal widget's appearance.
# 0.20.16 - Command line font must be the same as the terminal font, so that when users set a custom font for the terminal widget, the command line input will also use that same font, creating a more cohesive and visually consistent user interface in the terminal widget.
# 0.20.17 - Set the default font on fedora linux to monospace, so that users on Fedora have a good default font for the terminal widget that is consistent with their system's default monospaced font, improving usability and providing a better user experience for Fedora users of the terminal widget. 
# 0.20.18 - The custom checkmark used for font size and theme is missing on fedora linux for font family.
# 0.21.0 - Add assets/fonts/* to ensure that all systems have the same set of default fonts available for the terminal widget, improving cross-platform consistency and providing a more cohesive user experience when customizing the font family in the terminal widget.
# 0 21.1 - Dispaly font families alphabetically in the preferences menu, making it easier for users to find and select their desired font family when customizing the terminal widget's appearance, improving usability and providing a better user experience in the terminal widget.
# 0.21.2 - The scroll bar in Fedora Linux has an undesireable white borader around it.  Update the styling to remove that border and make it look the same as the scroll bar in Windows, improving cross-platform consistency and providing a more visually cohesive user interface for all users of the terminal widget.
# 0.22.0 - Add support for real-time terminal viewport feedback during commands: dfn, ping, ssh
# 0.22.1 - Fix 'command not found' errors for system utilities (ping, etc.) by ensuring standard binary paths (/usr/bin, /sbin, etc.) are included in the environment PATH on Linux/macOS.
# 0.22.3 - Improved command resolution logic to handle cases where shutil.which fails but the command exists in standard locations, and cleaned up unused imports.
# 0.22.4 - Use login shell (bash -l) for system commands on Linux/macOS to ensure proper environment and PATH loading, fixing issues where commands like 'ping' were not found.
# 0.22.5 - Explicitly inject standard binary paths into the shell command execution to resolve persistent 'command not found' errors for system utilities on Linux/macOS.
# 0.22.6 - Added support for ctrl+z, ctrl+c, and ctrl+d to send SIGTSTP, SIGINT, and EOF signals to the running process in the terminal widget, allowing users to manage their processes more effectively and providing a more complete command-line experience in the terminal widget.
# 0.22.7 - Display a notification when a process is stopped with ctrl+z, ctrl+c, or ctrl+d in the terminal widget, providing feedback to users about the status of their processes and improving usability when managing processes directly from the terminal widget.
# 0.22.8 - Cleaned up Ctrl+C and Ctrl+Z messages by adding newlines to prevent output overwriting and ensure cleaner terminal feedback.
# 0.22.9 - Automatically add '-tt' flag to ssh commands to force pseudo-tty allocation, fixing "Pseudo-terminal will not be allocated" errors and enabling interactive remote sessions.
# 0.22.10 - Fix bug with ssh commands being printed twice in the terminal by suppressing local echo for ssh processes which already echo back.
# 0.22.11 - Add real-time feedback for dnf commands by capturing and displaying stdout and stderr in the terminal widget as the command executes, allowing users to see the progress and output of their dnf commands in real-time, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.22.12 - Make the focus move to the terminal command line by default when the app is opened.
# 0.23.0 - Added support for adding custom commands via plugins, allowing users to extend the functionality of the terminal widget with their own commands and scripts, improving flexibility and providing a more personalized experience in the terminal widget.
# 0.23.1 - Added 'plugins' command to list loaded command plugins and their status, aiding in debugging and verification of custom plugin loading.
# 0.23.2 - Added support for automatically registering shell scripts (.sh, .bat, etc.) in the plugins/commands directory as executable commands, allowing users to run them by filename (without extension) directly from the terminal.
# 0.24.0 - Add Dynamically update the line number background color the same as the terminal background color, based on the theme, improving readability and creating a more visually consistent user interface when using the nano text editor within the terminal widget.
# 0.24.1 - Add transparency support for the terminal widget, allowing users to adjust the opacity of the terminal background to their liking, improving aesthetics and providing a more personalized experience when using the terminal widget.
# 0.24.2 - To keep the terminal tab names shorter, only display up to the last 3 directories in the path, so that users can still see relevant directory information without the tab names becoming too long and unwieldy, improving usability and providing a cleaner user interface in the terminal widget.
# 0.24.3 - Update Tab font family to be the same as the terminal font family, creating a more cohesive and visually consistent user interface in the terminal widget.
# 0.24.4 - Fix the black line that appears on the right side of the terminal widget.
# 0.24.5 - If the theme bg is light, make the tab font color black, and if the theme bg is dark, make the tab font color white, so that the tab titles are always visible and readable regardless of the chosen theme, improving usability and providing a more visually consistent user interface in the terminal widget.
# 0.24.6 - Add support for the Tree command.
# 0.24.7 - Add a preference to set the number of lines to keep in the scrollback buffer, allowing users to customize how much command history they can access in the terminal widget, improving usability and providing a more personalized experience when using the terminal widget.
# 0.24.8 - Fix ls command to list all files and directories alphabetically irrespective of the case of the first letter, so that users can see all files and directories in the output of the ls command regardless of how they are capitalized, improving usability and providing a more complete command-line experience in the terminal widget.
# 0.24.9 - Improve ls command by displaying content in columns based on the width of the terminal widget, making better use of the available space and improving readability of the ls command output in the terminal widget.
# 0.24.10 - If the current working dir is ~, display it as C:\Users\<USER> on Windows or /home/<USER> on Linux, so that users can easily recognize when they are in their home directory in the terminal widget, improving usability and providing a more familiar command-line experience in the terminal widget.
#
#
# Future Roadmap:
# 0.2X.x - Added support for customizable tab titles in the terminal widget, allowing users to set their own titles for each terminal tab instead of just showing the current working directory, improving usability and providing a more personalized experience when managing multiple terminal tabs within the application.
#
#
#
#===========================================================================================


import sys
import os
import re
import shutil
import logging
import signal
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QTabWidget, QTabBar, QDialog, QLabel, QHBoxLayout, QPushButton, QMenu, QTableWidget, QTableWidgetItem, QHeaderView, QToolButton, QSlider, QWidgetAction, QFrame
from PySide6.QtCore import Signal, Qt, QEvent, QUrl, QSettings, QSize, QProcess, QEventLoop, QProcessEnvironment
from PySide6.QtGui import QIcon, QPixmap, QDesktopServices, QActionGroup, QTextCursor, QTextOption, QShortcut, QKeySequence, QPalette, QColor, QFontDatabase, QPainter

from command_registry import CommandRegistry
from commands.files import LsCommand, CdCommand, PwdCommand, MkdirCommand, RmCommand, CpCommand, MvCommand
from commands.cat import CatCommand
from commands.find import FindCommand
from commands.tail import TailCommand
from commands.head import HeadCommand
from commands.wc import WcCommand
from commands.diff import DiffCommand
from commands.grep import GrepCommand
from commands.sed import SedCommand
from commands.awk import AwkCommand
from commands.tar import TarCommand
from commands.zip import ZipCommand, UnzipCommand
from commands.curl import CurlCommand
from commands.tree import TreeCommand
from commands.wget import WgetCommand
from commands.traceroute import TracerouteCommand
from commands.nano import NanoCommand
from commands.uniq import UniqCommand
from commands.sort import SortCommand
from commands.ps import PsCommand
from commands.htop import HtopCommand
from commands.df import DfCommand
from commands.du import DuCommand
from commands.kill import KillCommand
from commands.touch import TouchCommand
from commands.free import FreeCommand
from commands.less import LessCommand
from commands.sudo import SudoCommand
from commands.chown import ChownCommand
from commands.chmod import ChmodCommand
from commands.ln import LnCommand
from commands.scp import ScpCommand
from commands.rsync import RsyncCommand
from commands.whoami import WhoamiCommand
from commands.date import DateCommand
from commands.uptime import UptimeCommand
from commands.shell import ClearCommand, HelpCommand, AliasCommand, UnaliasCommand, SourceCommand, DotCommand
from commands.utils import VenvCommand, TabCommand, ThemeCommand
from commands.git import GitCommand
from commands.env import ExportCommand, UnsetCommand, EnvCommand
from update_manager import UpdateCheckThread
from license_manager import AppLicenseManager
from commands.python_cmd import PythonCommand
from plugin_manager import PluginManager
from commands.plugins import PluginsCommand

THEMES = {
    
    "Wheelhouser Dark": {
        "bg": "#121212", "fg": "#cccccc",
        "ansi": [
            '#000000', '#cd3131', '#0dbc79', '#e5e510', '#2472c8', '#bc3fbc', '#11a8cd', '#e5e5e5',
            '#666666', '#f14c4c', '#23d18b', '#f5f543', '#3b8eea', '#d670d6', '#29b8db', '#ffffff'
        ]
    },
    "XTerm": {
        "bg": "#000000", "fg": "#ffffff",
        "ansi": [
            '#000000', '#cd0000', '#00cd00', '#cdcd00', '#0000ee', '#cd00cd', '#00cdcd', '#e5e5e5',
            '#7f7f7f', '#ff0000', '#00ff00', '#ffff00', '#5c5cff', '#ff00ff', '#00ffff', '#ffffff'
        ]
    },
    "Solarized Dark": {
        "bg": "#002b36", "fg": "#839496",
        "ansi": [
            '#073642', '#dc322f', '#859900', '#b58900', '#268bd2', '#d33682', '#2aa198', '#eee8d5',
            '#002b36', '#cb4b16', '#586e75', '#657b83', '#839496', '#6c71c4', '#93a1a1', '#fdf6e3'
        ]
    },
    "Ubuntu": {
        "bg": "#300a24", "fg": "#ffffff",
        "ansi": [
            '#2e3436', '#cc0000', '#4e9a06', '#c4a000', '#3465a4', '#75507b', '#06989a', '#d3d7cf',
            '#555753', '#ef2929', '#8ae234', '#fce94f', '#729fcf', '#ad7fa8', '#34e2e2', '#eeeeec'
        ]
    },
    "PowerShell": {
        "bg": "#012456", "fg": "#cccccc",
        "ansi": [
            '#000000', '#800000', '#008000', '#808000', '#000080', '#800080', '#008080', '#c0c0c0',
            '#808080', '#ff0000', '#00ff00', '#ffff00', '#0000ff', '#ff00ff', '#00ffff', '#ffffff'
        ]
    },
    "Light Saber": {
        "bg": "#FAFAFA", "fg": "#1A1A1A",
        "ansi": [
            "#1A1A1A", "#C0392B", "#27AE60", "#B8860B", "#2980B9", "#8E44AD", "#16A085", "#BDC3C7",
            "#7F8C8D", "#E74C3C", "#2ECC71", "#F39C12", "#3498DB", "#9B59B6", "#1ABC9C", "#FFFFFF"
        ]
    }
}

#===========================================================================================
#--- Terminal Application with Dark Theme ---
#===========================================================================================
APP_NAME = "Terminal"
APP_AUTHOR = "WheelhouserLLC"
APP_VERSION = "0.24.10"
COMPANY_NAME = "Wheelhouser LLC"
WEBSITE_URL = "https://wheelhouser.com"
LICENSE_PUBLIC_KEY = "033a080c1ebbebb110a4ed5bc41e7e6a7bcb56016f617604e3a913dd4b5ddb2265"
LICENSE_SERVER_URL = "https://app.marqueemagic.shop"
#STRIPE_PRICE_ID = "price_1T5ZrsDXL1bcRrN4JlHrP3fl" # Live Stripe Price ID for Terminal Pro
ENABLE_AI = False # Set to False to disable AI features for Store release
STORE_RELEASE = True # Set to True to reduce log verbosity for Store release

#============================================================================================
# Terminal provides a simple terminal interface within the application, allowing users to run basic shell commands and manage files without leaving the app. It supports commands like ls, cd, mkdir, rm, cp, mv, and also allows running arbitrary system commands with ANSI color support for better readability.
#============================================================================================
class TerminalSession(QFrame):
    cwd_changed = Signal(str)
    new_tab_requested = Signal(str)
    close_requested = Signal()

    def __init__(self, plugin_manager, start_path=None, parent=None):
        super().__init__(parent)
        try:
            # On Windows, os.getcwd() can fail if the path was deleted (e.g., a USB drive)
            default_cwd = os.getcwd()
        except (FileNotFoundError, OSError):
            default_cwd = os.path.expanduser("~")
            
        self.cwd = start_path if start_path and os.path.exists(start_path) else default_cwd
        self.plugin_manager = plugin_manager
        self.running_process = None
        self.current_process_cmd = None
        self.command_history = []
        self.load_history()
        self._capture_mode = False
        self._captured_output = []
        self.aliases = {}
        self.env = os.environ.copy()
        
        # 0.22.1 - Ensure standard paths are present for system commands (like ping)
        if sys.platform != "win32":
            current_paths = self.env.get("PATH", "").split(os.pathsep)
            default_paths = ["/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"]
            for p in default_paths:
                if p not in current_paths and os.path.exists(p):
                    current_paths.append(p)
            self.env["PATH"] = os.pathsep.join(current_paths)
            
        # Force UTF-8 for Python subprocesses to avoid UnicodeEncodeError on Windows
        self.env["PYTHONIOENCODING"] = "utf-8"
        # 0.22.11 - Force unbuffered output for Python scripts (like dnf) to ensure real-time feedback
        self.env["PYTHONUNBUFFERED"] = "1"
        self.env["LANG"] = "en_US.UTF-8"
        self.env["LC_ALL"] = "en_US.UTF-8"
        self.active_venv = None
        self.store_release = STORE_RELEASE
        self.history_index = len(self.command_history)
        self.completion_state = None
        self.stdin = None
        self.opacity = 1.0 # Default opacity
        self.setFrameShape(QFrame.NoFrame)
        self.current_theme = {
            "bg": "#121212",
            "fg": "#cccccc",
            "font_family": 'Consolas, "Courier New", Menlo, "DejaVu Sans Mono", "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", Monospace',
            "font_size": 12,
            "ansi": self.plugin_manager.get_theme("Light Saber")["ansi"]
        }
        self.setup_ui()
        self.registry = CommandRegistry()
        self.register_default_commands()
        self.setAcceptDrops(True)
        self.cwd_changed.connect(self.update_prompt_label)
        
    def load_history(self):
        """
        Loads command history from a file in the user's home directory.
        This makes the command history persistent across sessions.
        The history file is a simple text file with one command per line.
        If the file doesn't exist, an empty history is used.
        """
        history_path = os.path.join(os.path.expanduser("~"), ".wheelhouser_terminal_history")
        if os.path.exists(history_path):
            try:
                with open(history_path, "r", encoding="utf-8") as f:
                    self.command_history = [line.rstrip('\n') for line in f.readlines() if line.strip()]
            except Exception:
                pass

    def save_history_item(self, cmd):
        """
        Appends a command to the history file.
        This is called every time a command is executed, ensuring that the
        history is always up-to-date.
        """
        history_path = os.path.join(os.path.expanduser("~"), ".wheelhouser_terminal_history")
        try:
            with open(history_path, "a", encoding="utf-8") as f:
                f.write(cmd + "\n")
        except Exception:
            pass
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        self.output_area = QTextEdit()
        self.output_area.setReadOnly(True)
        self.output_area.setAcceptDrops(False)
        # 0.19.4 - Buffer & Viewport Management: Dynamic wrapping and reflow
        self.output_area.setLineWrapMode(QTextEdit.WidgetWidth)
        self.output_area.setWordWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
        
        # 0.19.7 - Right-click context menu
        self.output_area.setContextMenuPolicy(Qt.CustomContextMenu)
        self.output_area.customContextMenuRequested.connect(self.show_context_menu)
        
        self.input_container = QWidget()
        self.input_layout = QHBoxLayout(self.input_container)
        self.input_layout.setContentsMargins(5, 5, 5, 5)
        self.input_layout.setSpacing(5)
        
        self.prompt_label = QLabel(self.get_prompt_text())
        
        self.input_line = QLineEdit()
        self.input_line.returnPressed.connect(self.process_command)
        self.input_line.installEventFilter(self)
        self.input_line.setPlaceholderText("")
        
        self.input_layout.addWidget(self.prompt_label)
        self.input_layout.addWidget(self.input_line)
        
        layout.addWidget(self.output_area)
        layout.addWidget(self.input_container)
        
        self.apply_theme()
        
        self.print_output(f"Wheelhouser Shell v{APP_VERSION}")
        self.print_output("\nType 'help' for available commands.")

    def register_default_commands(self):
        commands = [
            LsCommand(), CdCommand(), PwdCommand(), MkdirCommand(),
            RmCommand(), CpCommand(), MvCommand(), CatCommand(), FindCommand(), TailCommand(), HeadCommand(), WcCommand(), DiffCommand(), GrepCommand(), SedCommand(), AwkCommand(), TarCommand(), ZipCommand(), UnzipCommand(), CurlCommand(), TreeCommand(), WgetCommand(), TracerouteCommand(), NanoCommand(), UniqCommand(), SortCommand(), PsCommand(), HtopCommand(), DfCommand(), DuCommand(), KillCommand(), TouchCommand(), FreeCommand(), LessCommand(), SudoCommand(), ChownCommand(), ChmodCommand(), LnCommand(), ScpCommand(), RsyncCommand(), WhoamiCommand(), DateCommand(), UptimeCommand(), ClearCommand(),
            HelpCommand(), AliasCommand(), UnaliasCommand(),
            VenvCommand(), SourceCommand(), DotCommand(),
            TabCommand(), ThemeCommand(), GitCommand(), PythonCommand(),
            ExportCommand(), UnsetCommand(), EnvCommand(),
            PluginsCommand()
        ]
        
        for cmd in commands:
            self.registry.register(cmd)
            
        # Register commands from plugins
        if self.plugin_manager:
            self.plugin_manager.register_commands(self.registry)

    def get_prompt_text(self):
        # Per 0.24.10, display the full path, including for the home directory.
        return f"{self.cwd} $:"

    def get_ansi_prompt(self):
        # Per 0.24.10, display the full path, including for the home directory.
        return f"\033[1;32m{self.cwd} $:\033[0m"

    def update_prompt_label(self, path=None):
        self.prompt_label.setText(self.get_prompt_text())

    def apply_theme(self):
        fg = self.current_theme["fg"]
        family = self.current_theme["font_family"]
        size = self.current_theme["font_size"]
        ansi = self.current_theme.get("ansi", self.plugin_manager.get_theme("Light Saber")["ansi"])
        
        # Trigger repaint for background
        self.update()

        self.output_area.setStyleSheet(f"""
            QTextEdit {{
                background-color: transparent; 
                color: {fg}; 
                font-family: {family}; 
                border: none;
                font-size: {size}px;
                padding: 5px;
            }}
        """)
        
        self.input_container.setStyleSheet("""
            background-color: transparent;
            border-top: 1px solid #333;
        """)
        
        self.prompt_label.setStyleSheet(f"""
            QLabel {{
                color: {ansi[2]};
                font-family: {family};
                font-size: {size}px;
                font-weight: bold;
                border: none;
                background-color: transparent;
            }}
        """)
        
        self.input_line.setStyleSheet(f"""
            QLineEdit {{
                background-color: transparent; 
                color: {fg}; 
                font-family: {family}; 
                border: none;
                padding: 0px;
                font-size: {size}px;
            }}
        """)

    def paintEvent(self, event):
        painter = QPainter(self)
        bg_hex = self.current_theme.get("bg", "#121212")
        color = QColor(bg_hex)
        color.setAlphaF(self.opacity)
        painter.fillRect(self.rect(), color)

    def show_context_menu(self, pos):
        menu = self.output_area.createStandardContextMenu()
        menu.addSeparator()
        
        # Paste Action
        clipboard = QApplication.clipboard()
        if clipboard.text():
            action_paste = menu.addAction("Paste")
            action_paste.triggered.connect(self.paste_to_input)
            
        menu.addSeparator()
        
        # Terminal Actions
        action_clear = menu.addAction("Clear")
        action_clear.triggered.connect(lambda: self.execute_command_line("clear"))
        
        menu.addSeparator()
        
        # File System Actions
        action_open_cwd = menu.addAction("Open Folder")
        action_open_cwd.triggered.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self.cwd)))
        
        # Context sensitive actions based on selection
        cursor = self.output_area.textCursor()
        selected_text = cursor.selectedText().strip()
        if selected_text:
            potential_path = self.resolve_path(selected_text)
            if os.path.exists(potential_path):
                menu.addSeparator()
                action_open = menu.addAction(f"Open '{selected_text}'")
                action_open.triggered.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(potential_path)))
                
                if os.path.isdir(potential_path):
                    action_cd = menu.addAction(f"cd to '{selected_text}'")
                    action_cd.triggered.connect(lambda: self.execute_command_line(f'cd "{selected_text}"'))
                elif os.path.isfile(potential_path):
                    action_nano = menu.addAction("Edit with nano")
                    action_nano.triggered.connect(lambda: self.execute_command_line(f'nano "{selected_text}"'))

        menu.exec(self.output_area.mapToGlobal(pos))

    def paste_to_input(self):
        clipboard = QApplication.clipboard()
        text = clipboard.text()
        if text:
            self.input_line.insert(text)
            self.input_line.setFocus()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            paths = []
            for url in urls:
                if url.isLocalFile():
                    paths.append(url.toLocalFile())
            
            if paths:
                text_paths = []
                for p in paths:
                    if " " in p:
                        text_paths.append(f'"{p}"')
                    else:
                        text_paths.append(p)
                
                self.input_line.insert(" ".join(text_paths))
                self.input_line.setFocus()

    def set_current_directory(self, path):
        if os.path.exists(path):
            if os.path.abspath(path) != os.path.abspath(self.cwd):
                self.cwd = path
                self.cwd_changed.emit(path)

    def eventFilter(self, obj, event):
        if obj == self.input_line and event.type() == QEvent.KeyPress:
            # 0.22.6 - Handle Control Signals
            if event.modifiers() & Qt.ControlModifier:
                if event.key() == Qt.Key_C:
                    self.handle_ctrl_c()
                    return True
                elif event.key() == Qt.Key_Z:
                    self.handle_ctrl_z()
                    return True
                elif event.key() == Qt.Key_D:
                    self.handle_ctrl_d()
                    return True

            if event.key() == Qt.Key_Tab:
                self.handle_tab_completion()
                return True
            else:
                self.completion_state = None

            if event.key() == Qt.Key_Up:
                self.navigate_history(-1)
                return True
            elif event.key() == Qt.Key_Down:
                self.navigate_history(1)
                return True
        return super().eventFilter(obj, event)

    def handle_ctrl_c(self):
        if self.running_process and self.running_process.state() == QProcess.Running:
            self.print_output("^C\n")
            if sys.platform == "win32":
                self.running_process.kill()
            else:
                try:
                    os.kill(self.running_process.processId(), signal.SIGINT)
                except Exception:
                    pass
        else:
            self.input_line.clear()
            self.print_output("^C\n")
            self.print_output(f"{self.get_ansi_prompt()}")

    def handle_ctrl_z(self):
        if self.running_process and self.running_process.state() == QProcess.Running:
            self.print_output("^Z\n")
            if sys.platform != "win32":
                try:
                    os.kill(self.running_process.processId(), signal.SIGTSTP)
                    self.print_output("[1]+  Stopped\n")
                except Exception:
                    pass

    def handle_ctrl_d(self):
        if self.running_process and self.running_process.state() == QProcess.Running:
            self.running_process.closeWriteChannel()
        elif not self.input_line.text():
            self.print_output("exit\n")
            self.close_requested.emit()

    def navigate_history(self, direction):
        if not self.command_history:
            return

        self.history_index += direction
        
        if self.history_index < 0:
            self.history_index = 0
        elif self.history_index > len(self.command_history):
            self.history_index = len(self.command_history)

        if self.history_index < len(self.command_history):
            self.input_line.setText(self.command_history[self.history_index])
        else:
            self.input_line.clear()

    def handle_tab_completion(self):
        if self.completion_state:
            self.completion_state['index'] = (self.completion_state['index'] + 1) % len(self.completion_state['matches'])
            self._apply_completion()
            return

        text = self.input_line.text()
        cursor_pos = self.input_line.cursorPosition()
        
        start = cursor_pos
        while start > 0 and not text[start-1].isspace():
            start -= 1
            
        token = text[start:cursor_pos]
        
        # Determine directory and prefix
        dir_path = self.cwd
        prefix = token
        dirname = ""
        
        if os.path.sep in token or '/' in token:
            expanded_token = os.path.expanduser(token)
            if os.path.isabs(expanded_token):
                abs_path = expanded_token
            else:
                abs_path = os.path.join(self.cwd, expanded_token)

            if token.endswith(os.path.sep) or token.endswith('/'):
                dir_path = abs_path
                prefix = ""
                dirname = token
            else:
                dir_path = os.path.dirname(abs_path)
                prefix = os.path.basename(abs_path)
                dirname = os.path.dirname(token)
            
        if not os.path.isdir(dir_path):
            return

        try:
            matches = [f for f in os.listdir(dir_path) if f.startswith(prefix)]
            matches.sort()
            
            if not matches:
                return

            processed_matches = []
            for match in matches:
                if os.path.isdir(os.path.join(dir_path, match)):
                    match += os.path.sep
                
                if dirname or os.path.sep in token or '/' in token:
                    base = dirname if dirname else os.path.dirname(token)
                    completion = os.path.join(base, match)
                    if '/' in token and os.path.sep == '\\':
                        completion = completion.replace('\\', '/')
                else:
                    completion = match
                processed_matches.append(completion)

            if len(processed_matches) == 1:
                completion = processed_matches[0]
                new_text = text[:start] + completion + text[cursor_pos:]
                self.input_line.setText(new_text)
                self.input_line.setCursorPosition(start + len(completion))
            else:
                common = os.path.commonprefix(processed_matches)
                if len(common) > len(token):
                    new_text = text[:start] + common + text[cursor_pos:]
                    self.input_line.setText(new_text)
                    self.input_line.setCursorPosition(start + len(common))
                else:
                    self.completion_state = {
                        'matches': processed_matches,
                        'index': 0,
                        'start_pos': start,
                        'original_text': text,
                        'token_len': len(token)
                    }
                    self._apply_completion()
        except (OSError, Exception) as e:
            logging.warning(f"Tab completion error: {e}")

    def _apply_completion(self):
        if not self.completion_state:
            return
            
        match = self.completion_state['matches'][self.completion_state['index']]
        start = self.completion_state['start_pos']
        end = start + self.completion_state['token_len']
        original_text = self.completion_state['original_text']
        
        new_text = original_text[:start] + match + original_text[end:]
        self.input_line.setText(new_text)
        self.input_line.setCursorPosition(start + len(match))

    def print_output(self, text):
        if self._capture_mode:
            self._captured_output.append(text)
        else:
            cursor = self.output_area.textCursor()
            cursor.movePosition(QTextCursor.End)
            
            # Split by control characters: \r, \n, \x1b[K (Erase Line), \x1b[nG (Cursor Horizontal Absolute)
            parts = re.split(r'(\r|\n|\x1b\[K|\x1b\[\d+G)', text)
            
            for part in parts:
                if part == '\r':
                    cursor.movePosition(QTextCursor.StartOfBlock)
                elif part == '\n':
                    cursor.movePosition(QTextCursor.EndOfBlock)
                    cursor.insertBlock()
                elif part == '\x1b[K':
                    cursor.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
                    cursor.removeSelectedText()
                elif part.startswith('\x1b[') and part.endswith('G'):
                    # Handle Cursor Horizontal Absolute (CHA) - \033[nG
                    try:
                        col = int(part[2:-1])
                        cursor.movePosition(QTextCursor.StartOfBlock)
                        cursor.movePosition(QTextCursor.Right, QTextCursor.MoveAnchor, col - 1)
                    except ValueError:
                        pass
                elif part:
                    # Calculate plain text length to handle overwrite simulation
                    # We must account for tab expansion which happens in _apply_ansi_colors
                    expanded = self._expand_tabs(part)
                    plain = re.sub(r'\x1b\[[0-9;]*m', '', expanded)
                    length = len(plain)
                    
                    if not cursor.atBlockEnd():
                        # Simulate overwrite mode by deleting existing characters
                        pos = cursor.position()
                        cursor.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
                        remaining_len = len(cursor.selectedText())
                        cursor.setPosition(pos) # Deselect
                        
                        to_delete = min(length, remaining_len)
                        if to_delete > 0:
                            cursor.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor, to_delete)
                            cursor.removeSelectedText()
                    
                    html = self._apply_ansi_colors(part)
                    cursor.insertHtml(html)
            
            self.output_area.setTextCursor(cursor)
            sb = self.output_area.verticalScrollBar()
            sb.setValue(sb.maximum())

    def process_command(self):
        cmd_text = self.input_line.text()
        
        if self.running_process and self.running_process.state() == QProcess.Running:
            self.input_line.clear()
            # 0.22.10 - Don't echo locally for ssh, as it echoes back (due to -tt)
            if self.current_process_cmd not in ("ssh", "ssh.exe"):
                self.print_output(cmd_text)
            self.running_process.write((cmd_text + "\n").encode('utf-8'))
            return

        cmd_text = cmd_text.strip()
        self.input_line.clear()
        
        if not cmd_text:
            # 0.19.11 - Scroll up with prompt on empty enter
            self.print_output(f"\n{self.get_ansi_prompt()}")
            return
            
        if not self.command_history or self.command_history[-1] != cmd_text:
            self.command_history.append(cmd_text)
            self.save_history_item(cmd_text)
        self.history_index = len(self.command_history)
        
        self.execute_command_line(cmd_text)

    def execute_command_line(self, cmd_text, echo=True):
        if echo:
            self.print_output(f"\n{self.get_ansi_prompt()} {cmd_text}")
            # 0.19.15 - Add newline after command echo for separation
            self.print_output("\n")

        # Handle command chaining with ';'
        commands = [c.strip() for c in cmd_text.split(';') if c.strip()]
        
        for i, cmd_part in enumerate(commands):
            self._execute_single_command(cmd_part)
            
            # 0.19.13 - Ensure separation between chained commands
            if i < len(commands) - 1:
                cursor = self.output_area.textCursor()
                cursor.movePosition(QTextCursor.End)
                if not cursor.atBlockStart():
                    self.print_output("\n")

    def _split_command(self, cmd_text):
        # Regex to match quoted strings or non-whitespace sequences
        # Added operators: |, >, >>
        pattern = r'"[^"]*"|\'[^\']*\'|>>|>|\||[^\s|><]+'
        return re.findall(pattern, cmd_text)

    def _unquote(self, s):
        if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
            return s[1:-1]
        return s

    def _execute_single_command(self, cmd_text):
        tokens = self._split_command(cmd_text)
        if not tokens:
            return
            
        # Alias expansion (single pass)
        if tokens[0] in self.aliases:
            alias_val = self.aliases[tokens[0]]
            alias_parts = self._split_command(alias_val)
            tokens = alias_parts + tokens[1:]

        # Check for pipes
        if '|' in tokens:
            self._handle_pipes(tokens)
            return

        # Check for redirection
        if '>' in tokens or '>>' in tokens:
            self._handle_redirection(tokens)
            return

        self._run_command(tokens)

    def _run_command(self, tokens, input_data=None):
        cmd = tokens[0]
        # Unquote args for built-ins
        args = [self._unquote(t) for t in tokens[1:]]

        # Check Registry first
        command = self.registry.get_command(cmd)
        if command:
            try:
                self.stdin = input_data
                command.execute(self, args)
                self.stdin = None
            except Exception as e:
                self.print_output(f"Error executing {cmd}: {e}")
            return

        # Fallback to remaining internal methods or system
        try:
            self.run_system_command(tokens, input_data)
        except Exception as e:
            self.print_output(f"Error: {str(e)}")

    def resolve_path(self, path):
        if not path:
            return self.cwd
        try:
            if path.startswith("~"):
                path = os.path.expanduser(path)
            return os.path.normpath(os.path.join(self.cwd, path))
        except Exception:
            return path

    def _handle_stdout(self):
        if self.running_process:
            data = self.running_process.readAllStandardOutput().data().decode('utf-8', errors='replace')
            self.print_output(data)

    def _handle_stderr(self):
        if self.running_process:
            data = self.running_process.readAllStandardError().data().decode('utf-8', errors='replace')
            self.print_output(f"\033[31m{data}\033[0m")

    def run_system_command(self, cmd_tokens, input_data=None):
        # Check if CWD exists before spawning subprocess
        if not os.path.exists(self.cwd):
            self.print_output(f"\033[33mWarning: Current directory '{self.cwd}' no longer exists. Resetting to home.\033[0m")
            self.cwd = os.path.expanduser("~")
            self.cwd_changed.emit(self.cwd)
            
        # 0.22.2 - Resolve command path explicitly to avoid shell PATH issues
        cmd = cmd_tokens[0]
        if os.path.sep not in cmd:
            resolved_path = shutil.which(cmd, path=self.env.get("PATH"))
            if not resolved_path and sys.platform != "win32":
                # 0.22.3 - Fallback search in standard directories if shutil.which fails
                common_dirs = ["/usr/bin", "/bin", "/usr/sbin", "/sbin", "/usr/local/bin"]
                for d in common_dirs:
                    potential = os.path.join(d, cmd)
                    if os.path.exists(potential) and os.access(potential, os.X_OK):
                        resolved_path = potential
                        break
            if resolved_path:
                cmd_tokens[0] = resolved_path

        # 0.22.9 - Force pseudo-tty allocation for ssh to enable interactive sessions
        base_cmd = os.path.basename(cmd_tokens[0]).lower()
        if base_cmd in ("ssh", "ssh.exe"):
            if "-tt" not in cmd_tokens:
                cmd_tokens.insert(1, "-tt")
        
        self.current_process_cmd = base_cmd

        cmd_text = " ".join(cmd_tokens)
        
        self.running_process = QProcess(self)
        self.running_process.setProcessChannelMode(QProcess.SeparateChannels)
        self.running_process.setWorkingDirectory(self.cwd)
        
        # Set environment
        env = QProcessEnvironment.systemEnvironment()
        for k, v in self.env.items():
            env.insert(k, v)
        self.running_process.setProcessEnvironment(env)
        
        self.running_process.readyReadStandardOutput.connect(self._handle_stdout)
        self.running_process.readyReadStandardError.connect(self._handle_stderr)
        
        if sys.platform == "win32":
            self.running_process.start("cmd.exe", ["/c", cmd_text])
        else:
            # 0.22.5 - Explicitly inject standard paths into the shell command to guarantee availability
            # of common utilities like ping, even if the shell environment is restricted.
            std_paths = "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
            cmd_text = f"export PATH=$PATH:{std_paths}; {cmd_text}"
            self.running_process.start("/bin/bash", ["-c", cmd_text])
            
        if not self.running_process.waitForStarted():
            self.print_output(f"Error starting process: {self.running_process.errorString()}")
            self.running_process = None
            self.current_process_cmd = None
            return

        if input_data:
            self.running_process.write(input_data.encode('utf-8'))
            self.running_process.closeWriteChannel()

        loop = QEventLoop()
        self.running_process.finished.connect(loop.quit)
        loop.exec()
        
        self.running_process = None
        self.current_process_cmd = None

    def _handle_pipes(self, tokens):
        commands = []
        current_cmd = []
        for t in tokens:
            if t == '|':
                commands.append(current_cmd)
                current_cmd = []
            else:
                current_cmd.append(t)
        commands.append(current_cmd)
        
        input_data = None
        for i, cmd_tokens in enumerate(commands):
            capture = (i < len(commands) - 1)
            if capture:
                self._capture_mode = True
                self._captured_output = []
                
            self._run_command(cmd_tokens, input_data)
            
            if capture:
                self._capture_mode = False
                input_data = "\n".join(self._captured_output)
                self._captured_output = []

    def _handle_redirection(self, tokens):
        operator = '>>' if '>>' in tokens else '>'
        try:
            op_index = tokens.index(operator)
        except ValueError:
            return
            
        if op_index == len(tokens) - 1:
            self.print_output("Syntax error: missing redirection target")
            return
            
        cmd_tokens = tokens[:op_index]
        target_file = self._unquote(tokens[op_index + 1])
        target_path = self.resolve_path(target_file)
        
        self._capture_mode = True
        self._captured_output = []
        self._run_command(cmd_tokens)
        self._capture_mode = False
        
        output_text = "\n".join(self._captured_output)
        self._captured_output = []
        
        mode = 'a' if operator == '>>' else 'w'
        try:
            with open(target_path, mode, encoding='utf-8') as f:
                f.write(output_text + "\n")
        except Exception as e:
            self.print_output(f"Redirection error: {e}")

    def _get_xterm_color(self, n):
        # Standard colors 0-15
        standard = [
            '#000000', '#cd3131', '#0dbc79', '#e5e510', '#2472c8', '#bc3fbc', '#11a8cd', '#e5e5e5',
            '#666666', '#f14c4c', '#23d18b', '#f5f543', '#3b8eea', '#d670d6', '#29b8db', '#ffffff'
        ]
        if 0 <= n <= 15:
            return standard[n]
        
        # 6x6x6 Color Cube 16-231
        if 16 <= n <= 231:
            n -= 16
            r = (n // 36) * 51
            g = ((n % 36) // 6) * 51
            b = (n % 6) * 51
            return f'#{r:02x}{g:02x}{b:02x}'
            
        # Grayscale 232-255
        if 232 <= n <= 255:
            gray = 8 + (n - 232) * 10
            return f'#{gray:02x}{gray:02x}{gray:02x}'
            
        return '#ffffff'

    def _expand_tabs(self, text, tab_width=8):
        # Split by ANSI codes to handle visible length
        parts = re.split(r'(\033\[[\d;]*m)', text)
        result = []
        col = 0
        for part in parts:
            if part.startswith('\033['):
                result.append(part)
            else:
                for char in part:
                    if char == '\t':
                        spaces = tab_width - (col % tab_width)
                        result.append(' ' * spaces)
                        col += spaces
                    elif char == '\n':
                        result.append(char)
                        col = 0
                    else:
                        result.append(char)
                        col += 1
        return "".join(result)

    def _apply_ansi_colors(self, text):
        text = self._expand_tabs(text)
        text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace("\n", "<br>")
        text = text.replace(" ", "&nbsp;")
        
        def replace(match):
            params = match.group(1).split(';')
            if not params or params == ['']:
                return '</span>'
            
            style = []
            result = ""
            i = 0
            
            # Use theme colors or fallback.
            ansi_colors = self.current_theme.get("ansi", self.plugin_manager.get_theme("Light Saber")["ansi"])

            while i < len(params):
                try:
                    code = int(params[i])
                except ValueError:
                    i += 1
                    continue

                if code == 0:
                    result += '</span>'
                    style = []
                elif code == 1:
                    style.append("font-weight:bold")
                elif code == 3:
                    style.append("font-style:italic")
                elif code == 4:
                    style.append("text-decoration:underline")
                elif 30 <= code <= 37:
                    style.append(f"color:{ansi_colors[code-30]}")
                elif 40 <= code <= 47:
                    style.append(f"background-color:{ansi_colors[code-40]}")
                elif 90 <= code <= 97:
                    style.append(f"color:{ansi_colors[code-90+8]}")
                elif 100 <= code <= 107:
                    style.append(f"background-color:{ansi_colors[code-100+8]}")
                elif code == 39:
                    style.append(f"color:{self.current_theme['fg']}")
                elif code == 49:
                    style.append(f"background-color:{self.current_theme['bg']}")
                elif code == 38:
                    if i + 2 < len(params) and params[i+1] == '5':
                        try:
                            color = self._get_xterm_color(int(params[i+2]))
                            style.append(f"color:{color}")
                            i += 2
                        except Exception:
                            pass
                    elif i + 4 < len(params) and params[i+1] == '2':
                        try:
                            r, g, b = int(params[i+2]), int(params[i+3]), int(params[i+4])
                            style.append(f"color:rgb({r},{g},{b})")
                            i += 4
                        except Exception:
                            pass
                elif code == 48:
                    if i + 2 < len(params) and params[i+1] == '5':
                        try:
                            color = self._get_xterm_color(int(params[i+2]))
                            style.append(f"background-color:{color}")
                            i += 2
                        except Exception:
                            pass
                    elif i + 4 < len(params) and params[i+1] == '2':
                        try:
                            r, g, b = int(params[i+2]), int(params[i+3]), int(params[i+4])
                            style.append(f"background-color:rgb({r},{g},{b})")
                            i += 4
                        except Exception:
                            pass
                i += 1
            
            if style:
                result += f'<span style="{";".join(style)}">'
            return result
            
        return re.sub(r'\033\[([\d;]*)m', replace, text)

#============================================================================================
# --- Resource Path Handling for Assets ---
#=============================================================================================
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev, PyInstaller, and Nuitka """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    
    # Check relative to executable (for Nuitka standalone)
    exe_dir = os.path.dirname(sys.executable)
    if os.path.exists(os.path.join(exe_dir, "assets")):
        return os.path.join(exe_dir, relative_path)

    base_path = os.path.dirname(os.path.abspath(__file__))
    
    # Check if assets exist in current dir
    if os.path.exists(os.path.join(base_path, "assets")):
        return os.path.join(base_path, relative_path)
        
    # Check sibling directory 'file-browser'
    sibling_path = os.path.join(os.path.dirname(base_path), "file-browser", relative_path)
    if os.path.exists(sibling_path):
        return sibling_path
        
    return os.path.join(base_path, relative_path)

#============================================================================================
# --- Dialogs for Key Capture and Shortcuts Editing ---
#============================================================================================
class KeyCaptureDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Press Key")
        self.setFixedSize(300, 150)
        self.key_sequence = None
        
        layout = QVBoxLayout(self)
        self.lbl = QLabel("Press the new key combination...")
        self.lbl.setAlignment(Qt.AlignCenter)
        self.lbl.setStyleSheet("font-size: 14px; color: #ccc;")
        layout.addWidget(self.lbl)
        
        self.setStyleSheet("background-color: #252525; color: white;")

    def keyPressEvent(self, event):
        key = event.key()
        modifiers = event.modifiers()
        
        # Ignore standalone modifiers
        if key in (Qt.Key_Control, Qt.Key_Shift, Qt.Key_Alt, Qt.Key_Meta):
            return
            
        if key == Qt.Key_Escape:
            self.reject()
            return
            
        sequence = QKeySequence(modifiers | Qt.Key(key))
        text = sequence.toString(QKeySequence.PortableText)
        
        # 0.19.18 - Lowercase display if Shift not pressed for letters
        if Qt.Key_A <= key <= Qt.Key_Z:
            if not (modifiers & Qt.ShiftModifier):
                parts = text.split('+')
                if parts and len(parts[-1]) == 1 and parts[-1].isupper():
                    parts[-1] = parts[-1].lower()
                    text = "+".join(parts)
                    
        self.key_sequence = text
        self.accept()

#============================================================================================
# --- ShortcutsEditorDialog provides a user interface for viewing and modifying keyboard shortcuts. It displays a table of actions and their associated shortcuts, allows users to edit shortcuts by double-clicking, and includes options to reset to default shortcuts or save changes. The dialog is styled to match the terminal's theme for a cohesive user experience.
#============================================================================================
class ShortcutsEditorDialog(QDialog):
    def __init__(self, current_shortcuts, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Keyboard Shortcuts")
        self.resize(500, 400)
        self.shortcuts = current_shortcuts.copy()
        self.setup_ui()
        self.setStyleSheet("""
            QDialog { background-color: #1e1e1e; color: white; }
            QTableWidget { background-color: #252525; color: white; gridline-color: #444; border: 1px solid #444; }
            QHeaderView::section { background-color: #333; color: white; padding: 4px; border: 1px solid #444; }
            QPushButton { background-color: #333; color: white; border: 1px solid #555; padding: 6px; border-radius: 4px; }
            QPushButton:hover { background-color: #444; border-color: #007AFF; }
            QTableWidget::item:selected { background-color: #007AFF; }
        """)

    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Action", "Shortcut"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        
        self.load_table()
        layout.addWidget(self.table)
        
        help_lbl = QLabel("Double-click a row to edit the shortcut.")
        help_lbl.setStyleSheet("color: #888; font-style: italic; margin: 5px;")
        layout.addWidget(help_lbl)
        
        btn_layout = QHBoxLayout()
        reset_btn = QPushButton("Reset Defaults")
        reset_btn.clicked.connect(self.reset_defaults)
        
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        
        btn_layout.addWidget(reset_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        self.table.cellDoubleClicked.connect(self.edit_shortcut)

    def load_table(self):
        self.table.setRowCount(0)
        for action, key in self.shortcuts.items():
            row = self.table.rowCount()
            self.table.insertRow(row)
            
            name_item = QTableWidgetItem(action.replace("_", " ").title())
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(row, 0, name_item)
            
            key_item = QTableWidgetItem(key)
            key_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(row, 1, key_item)
            
            # Store action key in user data
            name_item.setData(Qt.UserRole, action)

    def edit_shortcut(self, row, col):
        action = self.table.item(row, 0).data(Qt.UserRole)
        dialog = KeyCaptureDialog(self)
        if dialog.exec() == QDialog.Accepted and dialog.key_sequence:
            self.shortcuts[action] = dialog.key_sequence
            self.table.item(row, 1).setText(dialog.key_sequence)

    def reset_defaults(self):
        defaults = {
            "new_tab": "Ctrl+T",
            "close_tab": "Ctrl+W",
            "next_tab": "Ctrl+Tab",
            "prev_tab": "Ctrl+Shift+Tab",
            "copy": "Ctrl+Shift+C",
            "paste": "Ctrl+Shift+V",
            "clear": "Ctrl+L",
            "zoom_in": "Ctrl+=",
            "zoom_out": "Ctrl+-"
        }
        self.shortcuts = defaults
        self.load_table()

#============================================================================================
# --- TerminalWidget manages multiple terminal sessions in tabs, allowing users to run multiple command-line sessions simultaneously. It provides a user-friendly interface for switching between sessions, creating new sessions, and closing sessions, while also emitting signals for directory changes to keep the UI in sync with the current working directory of each session.
#============================================================================================
class TerminalWidget(QWidget):
    cwd_changed = Signal(str)

    def __init__(self, start_path=None, parent=None):
        super().__init__(parent)
        self.start_path = start_path
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        self.max_lines = self.settings.value("scrollback_lines", 1000, type=int)
        self.opacity = self.settings.value("opacity", 1.0, type=float)
        self.font_size = self.settings.value("font_size", 12, type=int)
        
        default_font = 'Consolas, "Courier New", Menlo, "DejaVu Sans Mono", "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", Monospace'
        if sys.platform == "linux":
            try:
                with open("/etc/os-release", "r") as f:
                    if "fedora" in f.read().lower():
                        default_font = "Monospace"
            except Exception:
                pass

        self.font_family = self.settings.value("font_family", default_font)
        self.theme_name = self.settings.value("theme_name", "Light Saber")
        self.license_manager = AppLicenseManager(APP_NAME, APP_AUTHOR, LICENSE_PUBLIC_KEY)
        
        # Initialize Plugin Manager
        self.plugin_manager = PluginManager(APP_NAME, APP_AUTHOR, THEMES)
        
        # Load bundled fonts
        assets_fonts = resource_path(os.path.join("assets", "fonts"))
        self.plugin_manager.load_fonts_from_dir(assets_fonts)
        
        self.setObjectName("terminalWidget")
        self.plugin_manager.load_plugins()
        
        self.setup_ui()
        self.apply_styles()
        
        # Initialize shortcuts
        self.default_shortcuts = {
            "new_tab": "Ctrl+T",
            "close_tab": "Ctrl+W",
            "next_tab": "Ctrl+Tab",
            "prev_tab": "Ctrl+Shift+Tab",
            "copy": "Ctrl+Shift+C",
            "paste": "Ctrl+Shift+V",
            "clear": "Ctrl+L",
            "zoom_in": "Ctrl+=",
            "zoom_out": "Ctrl+-"
        }
        self.shortcuts = self.settings.value("shortcuts", self.default_shortcuts)
        if not isinstance(self.shortcuts, dict):
            self.shortcuts = self.default_shortcuts
            
        # Fix for Zoom In shortcut on some keyboards/layouts where Ctrl++ requires shift or numpad
        if self.shortcuts.get("zoom_in") == "Ctrl++":
            self.shortcuts["zoom_in"] = "Ctrl+="
            self.settings.setValue("shortcuts", self.shortcuts)
            
        self.shortcut_objects = []
        self.apply_shortcuts()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(False)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.tabBarClicked.connect(self.on_tab_bar_clicked)

        # Add dummy "+" tab
        self.tabs.addTab(QWidget(), "+")
        self.tabs.setTabToolTip(0, "New Tab")
        self.tabs.tabBar().setTabButton(0, QTabBar.RightSide, None)

        # Corner Widget Container
        corner_widget = QWidget()
        corner_widget.setObjectName("cornerWidget")
        corner_layout = QHBoxLayout(corner_widget)
        corner_layout.setContentsMargins(0, 0, 0, 0)
        corner_layout.setSpacing(2)

        # Preferences Button
        self.btn_prefs = QToolButton()
        self.btn_prefs.setObjectName("prefsButton")
        self.btn_prefs.setToolTip("Preferences")
        self.btn_prefs.setCursor(Qt.PointingHandCursor)
        self.btn_prefs.setPopupMode(QToolButton.InstantPopup)
        #self.btn_prefs.setFixedSize(26, 26)
        
        icon_path = resource_path(os.path.join("assets", "icons", "hamburger.png"))
        if os.path.exists(icon_path):
            self.btn_prefs.setIcon(QIcon(icon_path))
            self.btn_prefs.setIconSize(QSize(30, 30))
        else:
            self.btn_prefs.setText("⚙")
        
        self.prefs_menu = QMenu(self)
        
        # Font Size
        size_menu = self.prefs_menu.addMenu("Font Size")
        self.size_group = QActionGroup(self)
        for size in [10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36, 48, 64]:
            action = size_menu.addAction(f"{size}px")
            action.setCheckable(True)
            if size == self.font_size:
                action.setChecked(True)
            self.size_group.addAction(action)
            action.triggered.connect(lambda checked, s=size: self.set_font_size(s))
            
        # Font Family
        font_menu = self.prefs_menu.addMenu("Font Family")
        self.font_group = QActionGroup(self)
        
        # Check available system fonts
        system_fonts = set(QFontDatabase.families())
        
        # Candidates to check (clean names)
        candidates = [
            "Consolas", "Courier New", "Menlo", "DejaVu Sans Mono", 
            "Fira Code", "JetBrains Mono", "Cascadia Mono", "Source Code Pro", 
            "Hack", "Inconsolata"
        ]
        
        fonts = []
        for f in candidates:
            if f in system_fonts:
                # Add quotes if spaces exist for CSS compatibility
                fonts.append(f"'{f}'" if " " in f else f)
        
        # Always add Monospace as fallback
        if "Monospace" not in fonts:
            fonts.append("Monospace")
        
        # Add custom fonts from plugins
        custom_fonts = self.plugin_manager.get_custom_fonts()
        if custom_fonts:
            for cf in custom_fonts:
                formatted_cf = f"'{cf}'" if " " in cf else cf
                if formatted_cf not in fonts:
                    fonts.append(formatted_cf)
        
        # Sort fonts alphabetically for better UX
        fonts.sort(key=lambda x: x.replace("'", "").replace('"', "").lower())
            
        # Determine effective font for checkmark
        current_setting = self.font_family
        active_check = None
        
        # Clean list of available fonts in menu
        menu_fonts_clean = [f.replace("'", "").replace('"', "").strip() for f in fonts]
        
        if "," in current_setting:
            # It's a stack, find first available
            stack = [s.replace("'", "").replace('"', "").strip() for s in current_setting.split(",")]
            for s in stack:
                if s in menu_fonts_clean:
                    active_check = s
                    break
            if not active_check:
                active_check = "Monospace"
        else:
            active_check = current_setting.replace("'", "").replace('"', "").strip()

        for font in fonts:
            action = font_menu.addAction(font.replace("'", ""))
            action.setCheckable(True)
            
            clean_font = font.replace("'", "").replace('"', "").strip()
            
            if clean_font == active_check:
                action.setChecked(True)
            self.font_group.addAction(action)
            action.triggered.connect(lambda checked, f=font: self.set_font_family(f))
            
        # Theme
        theme_menu = self.prefs_menu.addMenu("Theme")
        self.theme_group = QActionGroup(self)
        for theme in self.plugin_manager.get_theme_names():
            action = theme_menu.addAction(theme)
            action.setCheckable(True)
            if theme == self.theme_name:
                action.setChecked(True)
            self.theme_group.addAction(action)
            action.triggered.connect(lambda checked, t=theme: self.set_theme(t))
            
        self.prefs_menu.addSeparator()
        action_open_plugins = self.prefs_menu.addAction("Open Plugins Folder")
        action_open_plugins.triggered.connect(self.open_plugins_folder)
        
        action_shortcuts = self.prefs_menu.addAction("Keyboard Shortcuts")
        action_shortcuts.triggered.connect(self.show_shortcuts_dialog)
            
        self.prefs_menu.addSeparator()

        # Opacity Slider
        opacity_menu = self.prefs_menu.addMenu("Opacity")
        slider_widget = QWidget()
        slider_layout = QHBoxLayout(slider_widget)
        slider_layout.setContentsMargins(10, 5, 10, 5)
        opacity_slider = QSlider(Qt.Horizontal)
        opacity_slider.setRange(20, 100)
        opacity_slider.setValue(int(self.opacity * 100))
        opacity_slider.valueChanged.connect(self.set_opacity)
        slider_layout.addWidget(opacity_slider)
        slider_action = QWidgetAction(self)
        slider_action.setDefaultWidget(slider_widget)
        opacity_menu.addAction(slider_action)

        self.prefs_menu.addSeparator()

        # Scrollback Buffer
        scrollback_menu = self.prefs_menu.addMenu("Scrollback")
        self.scrollback_group = QActionGroup(self)
        for lines in [500, 1000, 2000, 5000, 10000]:
            action = scrollback_menu.addAction(f"{lines} lines")
            action.setCheckable(True)
            if lines == self.max_lines:
                action.setChecked(True)
            self.scrollback_group.addAction(action)
            action.triggered.connect(lambda checked, lin=lines: self.set_scrollback_lines(lin))

        self.btn_prefs.setMenu(self.prefs_menu)

        self.btn_about = QPushButton("About")
        self.btn_about.setObjectName("aboutButton")
        self.btn_about.setCursor(Qt.PointingHandCursor)
        self.btn_about.clicked.connect(self.show_about_dialog)
        
        corner_layout.addWidget(self.btn_prefs)
        corner_layout.addWidget(self.btn_about)

        self.tabs.setCornerWidget(corner_widget, Qt.TopRightCorner)

        layout.addWidget(self.tabs)
        
        self.restore_session_state()

    def save_session_state(self):
        sessions = []
        # Iterate up to count()-1 because the last tab is the dummy "+" tab
        for i in range(self.tabs.count() - 1):
            widget = self.tabs.widget(i)
            if isinstance(widget, TerminalSession):
                sessions.append(widget.cwd)
        self.settings.setValue("open_tabs", sessions)
        self.settings.setValue("current_tab_index", self.tabs.currentIndex())

    def restore_session_state(self):
        saved_tabs = self.settings.value("open_tabs")
        current_index = self.settings.value("current_tab_index", 0, type=int)
        
        restored = False
        if saved_tabs and isinstance(saved_tabs, list):
            for path in saved_tabs:
                if os.path.exists(path):
                    self.add_tab(path)
                    restored = True
        
        if restored:
            # Ensure index is valid (accounting for dummy tab)
            if 0 <= current_index < self.tabs.count() - 1:
                self.tabs.setCurrentIndex(current_index)
            else:
                self.tabs.setCurrentIndex(self.tabs.count() - 2)
        else:
            self.add_tab(self.start_path)

    def get_contrast_text_color(self, hex_color):
        color = QColor(hex_color)
        # Calculate luminance
        luminance = 0.2126 * color.red() + 0.7152 * color.green() + 0.0722 * color.blue()
        return "#000000" if luminance > 128 else "#ffffff"

    def apply_styles(self):
        close_icon = resource_path(os.path.join("assets", "icons", "custom_close.png"))
        close_icon = close_icon.replace("\\", "/")

        # Get current theme background for active tab
        theme_data = self.plugin_manager.get_theme(self.theme_name)
        theme_bg_hex = theme_data.get("bg", "#121212") if theme_data else "#121212"
        
        # Calculate contrast text color for active tab
        tab_text_color = self.get_contrast_text_color(theme_bg_hex)
        
        qcolor = QColor(theme_bg_hex)
        r, g, b, _ = qcolor.getRgb()
        #alpha = int(self.opacity * 255)
        #theme_bg_rgba = f"rgba({r}, {g}, {b}, {alpha})"

        self.setStyleSheet(f"""
            QWidget#terminalWidget {{
                background: transparent;
            }}
            QWidget {{
                /* Default for menus, etc. */
                background-color: transparent;
                border: none;
                color: #ffffff;
                font-family: "Segoe UI", "Arial", "Liberation Sans", "DejaVu Sans", sans-serif;
                font-size: 14px;
            }}
            QToolTip {{
                background-color: #000000;
                color: #ffffff;
                border: none;
                border-radius: 0px;
                padding: 2px;
            }}
            QTabWidget {{
                border: none;
                padding: 0px;
                margin: 0px;
                background-color: transparent;
            }}
            QTabWidget::right-corner {{
                background-color: #101010;
                border: none;
            }}
            QWidget#cornerWidget {{
                border: none;
                background-color: #101010;
            }}
            QTabWidget::tab-bar {{
                border: none;
                left: 0;
            }}
            QTabBar {{
                background: #101010;
                border: none;
                min-height: 30px;
                qproperty-drawBase: 0;
            }}
            QTabWidget::pane {{
                border: 0px;
                background-color: transparent;
                top: 0px;
            }}
            QTabBar::tab {{
                background: transparent;
                color: #888;
                padding: 4px 12px;
                height: 30px;
                border: 1px solid transparent;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                margin-right: 2px;
                margin-top: 0px;
                font-family: {self.font_family};
            }}
            QTabBar::tab:selected {{
                background: {theme_bg_hex};
                color: {tab_text_color};
                border-left: 1px solid {theme_bg_hex};
                border-top: 1px solid {theme_bg_hex};
                border-right: 1px solid {theme_bg_hex};
                border-bottom: 1px solid {theme_bg_hex}; 
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }}
            QTabBar::tab:hover {{
                background: #252525;
            }}
            QTabBar::close-button {{
                image: url({close_icon});
                subcontrol-position: right;
                margin-right: 5px;
                padding: 2px;
                width: 12px;
                height: 12px;
                border-radius: 2px;
            }}
            QTabBar::close-button:hover {{
                background-color: #550000;
                border: 1px solid #aa0000;
                border-radius: 2px;
            }}
            QTabBar QToolButton {{
                background-color: #1e1e1e;
                background-color: transparent;
                padding: 0px;
                margin: 0px;
                border: 1px solid transparent;
                border-radius: 0px;
            }}
            QTabBar QToolButton:hover {{
                background-color: #444444;
                border: 1px solid #007AFF;
                border-radius: 4px;
            }}
            QTabBar QToolButton:pressed {{
                background-color: #333333;
                border: 1px solid #1e1e1e;
                border-radius: 4px;
            }}
            QTabBar::tab:last {{
                background: transparent;
                border: none;
                margin-left: 2px;
            }}
            QTabBar::tab:last:hover {{
                background-color: #424242;
                border-radius: 4px;
            }}
            QTabBar::tab:last:selected {{
                background: transparent;
                border: none;
            }}
            QPushButton#aboutButton {{
                background-color: transparent;
                padding: 4px 12px;
                height: 30px;
                color: #00BFFF;
                margin-right: 5px;
                border: 1px solid transparent;
            }}
            QPushButton#aboutButton:hover {{
                background-color: #444444;
                border: #007AFF solid 1px;
                border-radius: 4px;
            }}
            QPushButton#aboutButton:pressed {{
                background-color: #333333;
                border: none;
            }}
            QToolButton#prefsButton {{
                background-color: transparent;
                padding: 0px;
                margin-left: 4px;
                color: #cccccc;
                width: 30px;
                height: 30px;
                border: none;
                border-radius: 0px;
            }}
            QToolButton#prefsButton:hover {{
                background-color: #444444;
                border: 1px solid #007AFF;
                border-radius: 4px;
            }}
            QToolButton#prefsButton:pressed {{
                background-color: #333333;
                border: 1px solid #1e1e1e;
                border-radius: 4px;
            }}
            QToolButton#prefsButton::menu-indicator {{
                background-color: transparent;
                width: 0px;
            }}
            QMenu {{
                background-color: #252525;
                border: 1px solid #1e1e1e;
            }}
            QMenu::item {{
                padding: 6px 32px 6px 32px;
                background-color: transparent;
                color: #ffffff;
            }}
            QMenu::item:selected {{
                background-color: #333333;
                border: 1px solid #007AFF;
                border-radius: 4px;
            }}
            QMenu::indicator {{
                left: 8px;
                width: 16px;
                height: 16px;
            }}
            QScrollBar:vertical {{
                border: none;
                background: #1e1e1e;
                width: 12px;
                margin: 0px;
            }}
            QScrollBar::handle:vertical {{
                background: #444;
                min-height: 20px;
                border-radius: 6px;
            }}
            QScrollBar::handle:vertical:hover {{ background: #555; }}
            QScrollBar:horizontal {{
                border: none;
                background: #1e1e1e;
                height: 12px;
                margin: 0px;
            }}
            QScrollBar::handle:horizontal {{
                background: #444;
                min-width: 20px;
                border-radius: 6px;
            }}
            QScrollBar::handle:horizontal:hover {{ background: #555; }}
            QScrollBar::add-line, QScrollBar::sub-line {{ border: none; background: none; }}
            QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
        """)

    def on_tab_bar_clicked(self, index):
        if index == self.tabs.count() - 1:
            self.add_tab()

    def _shorten_path(self, path):
        if not path:
            return "Terminal"

        # Per 0.24.10, do not abbreviate the home directory with '~'.
        # Normalize separators
        path = str(path).replace('/', os.sep).replace('\\', os.sep)
        parts = [p for p in path.split(os.sep) if p]

        if len(parts) > 3:
            return os.path.join("...", *parts[-3:])

        return path

    def add_tab(self, path=None):
        if path is None:
            current = self.tabs.currentWidget()
            if current and isinstance(current, TerminalSession):
                path = current.cwd
            else:
                path = os.getcwd()

        session = TerminalSession(self.plugin_manager, path)
        session.opacity = self.opacity
        session.current_theme["font_size"] = self.font_size
        session.current_theme["font_family"] = self.font_family
        theme_data = self.plugin_manager.get_theme(self.theme_name)
        if theme_data:
            session.current_theme["bg"] = theme_data["bg"]
            session.current_theme["fg"] = theme_data["fg"]
            session.current_theme["ansi"] = theme_data["ansi"]
        session.apply_theme()
        session.output_area.document().setMaximumBlockCount(self.max_lines)
        session.cwd_changed.connect(self.cwd_changed.emit)
        session.cwd_changed.connect(self.update_tab_title)
        session.new_tab_requested.connect(self.add_tab)
        session.close_requested.connect(lambda: self.close_tab(self.tabs.indexOf(session)))
        
        tab_name = self._shorten_path(path)
        index = self.tabs.insertTab(self.tabs.count() - 1, session, tab_name)
        self.tabs.setTabToolTip(index, path)
        self.tabs.setCurrentWidget(session)
        session.input_line.setFocus()
        
        # Ensure dummy tab (last one) has no close button
        self.tabs.tabBar().setTabButton(self.tabs.count() - 1, QTabBar.RightSide, None)

    def update_tab_title(self, path):
        sender = self.sender()
        index = self.tabs.indexOf(sender)
        if index >= 0:
            name = self._shorten_path(path)
            self.tabs.setTabText(index, name)
            self.tabs.setTabToolTip(index, path)
            
    def apply_shortcuts(self):
        # Clear existing
        for s in self.shortcut_objects:
            s.setParent(None)
        self.shortcut_objects.clear()
        
        # Create new
        for action, key in self.shortcuts.items():
            if not key: 
                continue
            
            seq = QKeySequence(key)
            shortcut = QShortcut(seq, self)
            shortcut.setContext(Qt.WindowShortcut)
            
            if action == "new_tab":
                shortcut.activated.connect(lambda: self.add_tab())
            elif action == "close_tab":
                shortcut.activated.connect(lambda: self.close_tab(self.tabs.currentIndex()))
            elif action == "next_tab":
                shortcut.activated.connect(self.next_tab)
            elif action == "prev_tab":
                shortcut.activated.connect(self.prev_tab)
            elif action == "copy":
                shortcut.activated.connect(self.copy_selection)
            elif action == "paste":
                shortcut.activated.connect(self.paste_clipboard)
            elif action == "clear":
                shortcut.activated.connect(self.clear_terminal)
            elif action == "zoom_in":
                shortcut.activated.connect(self.zoom_in)
            elif action == "zoom_out":
                shortcut.activated.connect(self.zoom_out)
                
            self.shortcut_objects.append(shortcut)

    def show_shortcuts_dialog(self):
        dialog = ShortcutsEditorDialog(self.shortcuts, self)
        if dialog.exec() == QDialog.Accepted:
            self.shortcuts = dialog.shortcuts
            self.settings.setValue("shortcuts", self.shortcuts)
            self.apply_shortcuts()

    def open_plugins_folder(self):
        """Opens the plugins directory in the system file explorer."""
        plugin_dir = self.plugin_manager.plugin_dir
        self.plugin_manager.ensure_directories()
        QDesktopServices.openUrl(QUrl.fromLocalFile(plugin_dir))

    def next_tab(self):
        idx = self.tabs.currentIndex()
        if idx < self.tabs.count() - 2: # -2 because of dummy tab
            self.tabs.setCurrentIndex(idx + 1)
        else:
            self.tabs.setCurrentIndex(0)

    def prev_tab(self):
        idx = self.tabs.currentIndex()
        if idx > 0:
            self.tabs.setCurrentIndex(idx - 1)
        else:
            self.tabs.setCurrentIndex(self.tabs.count() - 2)

    def copy_selection(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, TerminalSession):
            widget.output_area.copy()

    def paste_clipboard(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, TerminalSession):
            widget.paste_to_input()

    def clear_terminal(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, TerminalSession):
            widget.execute_command_line("clear")

    def zoom_in(self):
        self.set_font_size(self.font_size + 2)

    def zoom_out(self):
        self.set_font_size(max(8, self.font_size - 2))

    def close_tab(self, index):
        if index == self.tabs.count() - 1:
            return
            
        if self.tabs.count() > 2:
            # 0.19.19 - Select left tab on close if it's the current one
            if index == self.tabs.currentIndex() and index > 0:
                self.tabs.setCurrentIndex(index - 1)
                
            self.tabs.removeTab(index)
            self.tabs.tabBar().setTabButton(self.tabs.count() - 1, QTabBar.RightSide, None)

    def set_current_directory(self, path):
        widget = self.tabs.currentWidget()
        if isinstance(widget, TerminalSession):
            widget.set_current_directory(path)

    def eventFilter(self, obj, event):
        return super().eventFilter(obj, event)

    @property
    def input_line(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, TerminalSession):
            return widget.input_line
        return None

    def set_scrollback_lines(self, lines):
        self.max_lines = lines
        self.settings.setValue("scrollback_lines", lines)
        for i in range(self.tabs.count() - 1):
            widget = self.tabs.widget(i)
            if isinstance(widget, TerminalSession):
                widget.output_area.document().setMaximumBlockCount(lines)

    def set_font_size(self, size):
        self.font_size = size
        self.settings.setValue("font_size", size)
        for i in range(self.tabs.count()):
            widget = self.tabs.widget(i)
            if isinstance(widget, TerminalSession):
                widget.current_theme["font_size"] = size
                widget.apply_theme()

    def set_font_family(self, family):
        self.font_family = family
        self.settings.setValue("font_family", family)
        for i in range(self.tabs.count()):
            widget = self.tabs.widget(i)
            if isinstance(widget, TerminalSession):
                widget.current_theme["font_family"] = family
                widget.apply_theme()
        self.apply_styles()

    def set_theme(self, theme_name):
        theme_data = self.plugin_manager.get_theme(theme_name)
        if theme_data:
            self.theme_name = theme_name
            self.settings.setValue("theme_name", theme_name)
            for i in range(self.tabs.count()):
                widget = self.tabs.widget(i)
                if isinstance(widget, TerminalSession):
                    widget.current_theme["bg"] = theme_data["bg"]
                    widget.current_theme["fg"] = theme_data["fg"]
                    widget.current_theme["ansi"] = theme_data["ansi"]
                    widget.apply_theme()
            self.apply_styles()

    def set_opacity(self, value):
        self.opacity = value / 100.0
        self.settings.setValue("opacity", self.opacity)
        
        # Update all existing tabs
        for i in range(self.tabs.count() - 1):
            widget = self.tabs.widget(i)
            if isinstance(widget, TerminalSession):
                widget.opacity = self.opacity
                widget.apply_theme()
        self.apply_styles()

    def show_about_dialog(self):
        """Shows the custom About dialog with an integrated update checker."""
               
        dialog = QDialog(self)
        dialog.setWindowTitle(f"About {APP_NAME}")
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowCloseButtonHint)
        dialog.setMinimumSize(550, 400) # Larger to fit new version data
        
        dialog.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #ffffff;
                font-family: "Segoe UI", "Arial", sans-serif;
                font-size: 14px;
            }
            QLabel {
                color: #ffffff;
            }
            QPushButton {
                background-color: #323232;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 6px;
                min-height: 20px;
                color: #ffffff;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
            QPushButton:pressed {
                background-color: #333333;
            }
            QPushButton:disabled {
                background-color: #1e1e1e;
                color: #555;
                border: 1px solid #333;
            }
        """)
        
        main_layout = QVBoxLayout(dialog)
        
        # --- Top Section: Icon & Text (Mimicking QMessageBox) ---
        top_layout = QHBoxLayout()
        
        icon_label = QLabel()
        icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
        pixmap = QPixmap(icon_path)
        if not pixmap.isNull():
            icon_label.setPixmap(pixmap.scaled(128, 128, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            icon_label.setAlignment(Qt.AlignCenter)
        top_layout.addWidget(icon_label)
        
        license_status = "Pro License" if self.license_manager.get_trial_status()["active"] else "Trial Version"
        
        text_label = QLabel(
            f"<h3>{APP_NAME}</h3>"
            f"<div style='font-size: 14px;'>"
            f"Terminal Emulator<br>"
            f"Built with a sleek dark-themed interface, it offers a distraction-free environment for command-line operations.<br><br>"
            f"<span style='color: #00BFFF;'>"
            f"Version {APP_VERSION} ({license_status})<br>"
            f"</span><br>"
            f"© 2026 {COMPANY_NAME}<br>"
            f"Visit our website: <a href='{WEBSITE_URL}' style='color: #00BFFF;'>{WEBSITE_URL.replace('https://', '')}</a>"
            f"</div>"
        )
        text_label.setWordWrap(True)
        text_label.setOpenExternalLinks(True)
        top_layout.addWidget(text_label, stretch=1)
        
        main_layout.addLayout(top_layout)
        
        # --- Middle Section: Update Checker ---
        self.update_status_label = QLabel("Checking for updates...")
        self.update_status_label.setStyleSheet("color: #888; font-style: italic; margin-top: 10px;")
        self.update_status_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(self.update_status_label)
        
        self.btn_store_update = QPushButton("Download Update")
        self.btn_store_update.setStyleSheet("background-color: #007AFF; color: white; font-weight: bold; padding: 6px; margin: 0px 50px;")
        self.btn_store_update.hide() # Hidden until an update is found
        main_layout.addWidget(self.btn_store_update)
        
        main_layout.addStretch()
        
        # --- Bottom Section: Buttons ---
        btn_layout = QHBoxLayout()
        
        # logs_btn = QPushButton("Open Log Folder")
        # logs_btn.setMinimumWidth(140)
        # logs_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self.log_dir)))
        
        ok_btn = QPushButton("OK")
        ok_btn.setMinimumWidth(140)
        ok_btn.clicked.connect(dialog.accept)
        
        # btn_layout.addWidget(logs_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        
        main_layout.addLayout(btn_layout)
        
        # --- Start Cross-Platform Update Check ---
        version_url = f"https://wheelhouser.com/updates/{APP_NAME.lower()}/version.json" 
        self.update_thread = UpdateCheckThread(APP_VERSION, version_url)
        
        def on_update_available(latest_version, target_url, release_notes):
            self.update_status_label.setText(f"Version {latest_version} is available!")
            self.update_status_label.setStyleSheet("color: #4CAF50; font-weight: bold; margin-top: 10px;")
            
            if sys.platform == "win32":
                self.btn_store_update.setText("Update via Microsoft Store")
            else:
                self.btn_store_update.setText("Download Update")
                
            self.btn_store_update.show()
            
            # Use a fresh connection to avoid closure issues
            self.btn_store_update.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(target_url)))
            
        def on_up_to_date():
            self.update_status_label.setText("You are on the latest version.")
            self.update_status_label.setStyleSheet("color: #aaa; margin-top: 10px;")
            
        def on_update_error(err):
            self.update_status_label.setText("Could not check for updates.")
            self.update_status_label.setStyleSheet("color: #d32f2f; margin-top: 10px;")
            logging.warning(f"Update check failed: {err}")

        # Wire up the thread signals to our local functions
        self.update_thread.update_available.connect(on_update_available)
        self.update_thread.up_to_date.connect(on_up_to_date)
        self.update_thread.error.connect(on_update_error)
        
        # Fire off the background thread
        self.update_thread.start()
        
        # Block interaction with the main window until this is closed
        dialog.exec()

#============================================================================================
# --- TerminalMainWindow is the main application window that contains the tabbed terminal interface. It manages the overall layout, user preferences, and session state. It also handles application-level events such as closing and opening tabs, and integrates the settings for font, theme, and shortcuts across all terminal sessions. The class ensures a cohesive user experience by applying consistent styles and managing the lifecycle of terminal sessions effectively.    
#============================================================================================
class TerminalMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Terminal")

        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")

        self.terminal = TerminalWidget()
        self.setCentralWidget(self.terminal)
        
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        self.resize(self.settings.value("window_size", QSize(800, 600)))
        
        icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        # 0.22.12 - Ensure focus is on the input line at startup
        if self.terminal.input_line:
            self.terminal.input_line.setFocus()

    def closeEvent(self, event):
        self.settings.setValue("window_size", self.size())
        self.terminal.save_session_state()
        super().closeEvent(event)

#============================================================================================
# --- Main Function ---
#============================================================================================
def main():
    logging.basicConfig(level=logging.INFO)
    
    if os.name == 'nt':
        import ctypes
        myappid = f'WheelhouserLLC.Terminal.{APP_VERSION}'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

    app = QApplication(sys.argv)

    # This is a bit of a hack to ensure the dark palette is applied correctly on WeOS, as sometimes the default palette can override it. By setting the style to "Fusion" first, we get a clean slate to apply our custom dark palette without interference from the OS's default theming.
    # This may have to be made OS specific to run on all OSes.
    # 1. Force the cross-platform "Fusion" style (removes OS-specific ugly borders)
    app.setStyle("Fusion")

    # 2. Force the Qt6 Engine into Dark Mode (Overrides the OS completely)
    app.styleHints().setColorScheme(Qt.ColorScheme.Dark)

    # (You can keep your custom QPalette code below this if you want specific hex colors, 
    # but this single line above might do 100% of the work for you).

    # 2.1. Build a professional Dark Palette
    dark_palette = QPalette()
    dark_palette.setColor(QPalette.Window, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.WindowText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.Base, QColor(25, 25, 25, 255))
    dark_palette.setColor(QPalette.Base, QColor(255, 255, 255, 0))
    dark_palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53, 255))
    dark_palette.setColor(QPalette.ToolTipBase, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ToolTipText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.Text, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.Button, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ButtonText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.BrightText, QColor(255, 0, 0))
    dark_palette.setColor(QPalette.Link, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.HighlightedText, QColor(0, 0, 0))

    # 3. Apply the palette to the application
    app.setPalette(dark_palette)

    window = TerminalMainWindow()
    window.show()
    sys.exit(app.exec())

#============================================================================================
# --- Main Application ---
#============================================================================================   
if __name__ == "__main__":
    main()
import os
from pathlib import Path
from platformdirs import user_data_dir

APP_NAME = "Terminal"
APP_AUTHOR = "WheelhouserLLC"

def reset_license():
    print("--- Resetting Terminal License Data ---")
    
    # Path 1: AppData
    data_dir = Path(user_data_dir(APP_NAME, APP_AUTHOR))
    primary_file = data_dir / "sys_info.enc"
    
    # Path 2: Home Dir Backup
    backup_file = Path.home() / ".terminal_license_backup.enc"
    
    files_to_delete = [primary_file, backup_file]
    
    for file_path in files_to_delete:
        if file_path.exists():
            try:
                # Handle Windows hidden files if necessary
                if os.name == 'nt':
                    try:
                        import ctypes
                        # Set to normal (remove ReadOnly/Hidden) just in case
                        ctypes.windll.kernel32.SetFileAttributesW(str(file_path), 0x80)
                    except Exception:
                        pass
                
                os.remove(file_path)
                print(f"[OK] Deleted: {file_path}")
            except Exception as e:
                print(f"[ERROR] Could not delete {file_path}: {e}")
        else:
            print(f"[SKIP] Not found: {file_path}")
            
    print("\nReset complete. You can now restart Terminal with a fresh trial.")

if __name__ == "__main__":
    reset_license()

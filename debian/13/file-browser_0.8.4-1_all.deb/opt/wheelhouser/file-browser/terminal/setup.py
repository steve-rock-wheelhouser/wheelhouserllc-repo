from setuptools import setup, find_packages

setup(
    name="wheelhouser-terminal",
    version="0.24.10",
    packages=find_packages(include=['commands', 'commands.*']),
    py_modules=[
        "terminal",
        "command_registry",
        "plugin_manager",
        "theme_manager",
        "license_manager",
        "update_manager"
    ],
    install_requires=[
        "PySide6"
    ]
)

"""Compatibility shim exposing TerminalWidget and main entrypoint for embedded terminal integration."""
from .terminal import TerminalWidget, main

__all__ = ["TerminalWidget", "main"]

if __name__ == "__main__":
    main()

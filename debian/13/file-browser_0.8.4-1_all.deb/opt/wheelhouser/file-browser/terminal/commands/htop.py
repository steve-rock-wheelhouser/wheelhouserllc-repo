#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Htop Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of htop command.
#
# Future features may include:
# - More detailed process info
# - Sorting by columns
#============================================================================================

import platform
import subprocess
from PySide6.QtWidgets import QDialog, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QHBoxLayout, QHeaderView, QLabel
from PySide6.QtCore import QTimer, Qt

from command_registry import Command

COMMAND_NAME = "htop"
VERSION = "0.1.0"
DESCRIPTION = "Interactive process viewer"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class HtopDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("htop - Process Viewer")
        self.resize(800, 600)
        self.setup_ui()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_processes)
        self.timer.start(3000) # Refresh every 3 seconds to avoid too much overhead
        self.refresh_processes()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        self.info_label = QLabel("Loading processes...")
        self.info_label.setStyleSheet("color: #ccc; font-weight: bold;")
        layout.addWidget(self.info_label)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["PID", "User", "CPU", "Mem", "Command"])
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setStyleSheet("background-color: #1e1e1e; color: #ffffff; gridline-color: #333;")
        self.table.horizontalHeader().setStyleSheet("background-color: #333; color: #fff;")
        layout.addWidget(self.table)
        
        btn_layout = QHBoxLayout()
        self.btn_kill = QPushButton("Kill Process")
        self.btn_kill.clicked.connect(self.kill_process)
        self.btn_kill.setStyleSheet("background-color: #d32f2f; color: white; padding: 5px; border: none; border-radius: 3px;")
        
        self.btn_refresh = QPushButton("Refresh Now")
        self.btn_refresh.clicked.connect(self.refresh_processes)
        self.btn_refresh.setStyleSheet("background-color: #007AFF; color: white; padding: 5px; border: none; border-radius: 3px;")

        self.btn_close = QPushButton("Close")
        self.btn_close.clicked.connect(self.accept)
        self.btn_close.setStyleSheet("background-color: #444; color: white; padding: 5px; border: none; border-radius: 3px;")
        
        btn_layout.addWidget(self.btn_kill)
        btn_layout.addWidget(self.btn_refresh)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_close)
        layout.addLayout(btn_layout)

    def refresh_processes(self):
        system = platform.system().lower()
        processes = []
        
        try:
            if system == "windows":
                # tasklist /FO CSV /NH
                cmd = ["tasklist", "/FO", "CSV", "/NH"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                output = result.stdout
                import csv
                import io
                reader = csv.reader(io.StringIO(output))
                for row in reader:
                    if len(row) >= 5:
                        # Image Name, PID, Session Name, Session#, Mem Usage
                        processes.append({
                            "pid": row[1],
                            "user": "N/A",
                            "cpu": "N/A",
                            "mem": row[4],
                            "cmd": row[0]
                        })
            else:
                # ps -eo pid,user,%cpu,%mem,comm
                cmd = ["ps", "-eo", "pid,user,%cpu,%mem,comm"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                output = result.stdout
                lines = output.strip().split('\n')[1:]
                for line in lines:
                    parts = line.split(None, 4)
                    if len(parts) == 5:
                        processes.append({
                            "pid": parts[0],
                            "user": parts[1],
                            "cpu": parts[2],
                            "mem": parts[3],
                            "cmd": parts[4]
                        })
        except Exception as e:
            self.info_label.setText(f"Error fetching processes: {e}")
            return

        # Save current selection
        current_row = self.table.currentRow()
        selected_pid = None
        if current_row >= 0:
            item = self.table.item(current_row, 0)
            if item:
                selected_pid = item.text()

        self.table.setRowCount(len(processes))
        self.table.setSortingEnabled(False)
        
        for i, proc in enumerate(processes):
            pid_item = QTableWidgetItem(proc["pid"])
            # Try to sort PIDs numerically
            pid_item.setData(Qt.DisplayRole, int(proc["pid"]) if proc["pid"].isdigit() else proc["pid"])
            
            self.table.setItem(i, 0, pid_item)
            self.table.setItem(i, 1, QTableWidgetItem(proc["user"]))
            self.table.setItem(i, 2, QTableWidgetItem(proc["cpu"]))
            self.table.setItem(i, 3, QTableWidgetItem(proc["mem"]))
            self.table.setItem(i, 4, QTableWidgetItem(proc["cmd"]))
            
            if selected_pid and proc["pid"] == selected_pid:
                self.table.selectRow(i)

        self.table.setSortingEnabled(True)
        self.info_label.setText(f"Processes: {len(processes)}")

    def kill_process(self):
        row = self.table.currentRow()
        if row >= 0:
            pid_item = self.table.item(row, 0)
            if not pid_item: 
                return
            pid = str(pid_item.data(Qt.DisplayRole)) # Get text or int
            
            try:
                if platform.system().lower() == "windows":
                    subprocess.run(["taskkill", "/F", "/PID", pid], check=True, capture_output=True)
                else:
                    subprocess.run(["kill", "-9", pid], check=True, capture_output=True)
                self.refresh_processes()
            except subprocess.CalledProcessError as ex:
                self.info_label.setText(f"Failed to kill {ex} with PID {pid}. Access Denied?")
            except Exception as ex:
                self.info_label.setText(f"Error: {ex}")

class HtopCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME}\n{DESCRIPTION}\n\nOptions:\n  --version    output version information and exit\n  --help       display this help and exit")
            return

        dialog = HtopDialog(parent=session)
        dialog.exec()
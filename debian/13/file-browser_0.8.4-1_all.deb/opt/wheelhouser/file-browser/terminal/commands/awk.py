#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Awk Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of awk command.
#
# Future features may include:
# - Support for full awk language (conditions, loops, variables)
# - Support for BEGIN and END blocks
#============================================================================================

import os

from command_registry import Command

COMMAND_NAME = "awk"
VERSION = "0.1.0"
DESCRIPTION = "Pattern scanning and processing language"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class AwkCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [program] [file]...\n{DESCRIPTION}\n\nOptions:\n  -F fs        define the input field separator\n  --version    output version information and exit\n  --help       display this help and exit")
            return

        # 2. Parse Arguments & Flags
        field_sep = None
        program = None
        files = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-F":
                if i + 1 < len(args):
                    field_sep = args[i+1]
                    i += 1
                else:
                    session.print_output("awk: option requires an argument -- F")
                    return
            elif arg.startswith("-F"):
                field_sep = arg[2:]
            elif arg.startswith("-") and arg != "-":
                 # Ignore unknown flags for now
                 pass
            else:
                if program is None:
                    program = arg
                else:
                    files.append(arg)
            i += 1
            
        if not program:
             session.print_output("awk: usage: awk [-F fs] program [file ...]")
             return

        # Simple parser for {print $1, $3}
        prog_body = program.strip()
        if prog_body.startswith("'") and prog_body.endswith("'"):
             prog_body = prog_body[1:-1]
        if prog_body.startswith('"') and prog_body.endswith('"'):
             prog_body = prog_body[1:-1]
             
        if not (prog_body.startswith("{") and prog_body.endswith("}")):
             session.print_output(f"awk: currently only supports '{{print ...}}' syntax. Got: {program}")
             return
             
        content = prog_body[1:-1].strip()
        if not content.startswith("print"):
             session.print_output(f"awk: currently only supports 'print' statements. Got: {content}")
             return
             
        print_args = content[5:].strip()
        tokens = [t.strip() for t in print_args.split(',')]
        
        def process_line(line):
            line = line.rstrip('\n\r')
            if not line: 
                return
            
            fields = line.split(field_sep) if field_sep else line.split()
            
            output_parts = []
            for token in tokens:
                if token == "$0":
                    output_parts.append(line)
                elif token.startswith("$"):
                    try:
                        idx = int(token[1:])
                        if 1 <= idx <= len(fields):
                            output_parts.append(fields[idx-1])
                        else:
                            output_parts.append("")
                    except ValueError:
                        output_parts.append(token)
                else:
                    # String literal? remove quotes
                    if (token.startswith('"') and token.endswith('"')) or (token.startswith("'") and token.endswith("'")):
                        output_parts.append(token[1:-1])
                    else:
                        output_parts.append(token)
            
            session.print_output(" ".join(output_parts))

        # 3. Main Logic
        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                for line in session.stdin.splitlines():
                    process_line(line)
            return

        for filename in files:
            path = session.resolve_path(filename)
            if not os.path.exists(path):
                session.print_output(f"awk: cannot open {filename}: No such file or directory")
                continue
            
            if os.path.isdir(path):
                session.print_output(f"awk: {filename}: Is a directory")
                continue

            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    for line in f:
                        process_line(line)
            except Exception as e:
                session.print_output(f"awk: error processing {filename}: {e}")
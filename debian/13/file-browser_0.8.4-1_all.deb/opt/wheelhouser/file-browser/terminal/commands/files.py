#!/usr/bin/python3
# -*- coding: utf-8 -*-
# TerminalWidget - A simple terminal interface for file management and command execution within the application.
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development, basic file browsing features
# 0.1.1 - Update ls to display output in columns

# Future features may include:
# - Support for file permissions and ownership in ls
# - Support for symbolic links in ls
# - Support for file size formatting in ls
# - Support for recursive directory listing in ls
# - Support for file copying and moving with progress indication
# - Support for file searching with find command
# - Support for file content viewing with cat command
#============================================================================================

import os
import sys
import shutil
import datetime
import stat
from command_registry import Command

VERSION = "0.1.0"

#============================================================================================
# --- File Management Commands ---
#============================================================================================
class LsCommand(Command):
    def __init__(self):
        super().__init__("ls", "List directory contents.")

    def execute(self, session, args):
        show_hidden = '-a' in args
        long_format = '-l' in args
        human_readable = '-h' in args

        paths = [arg for arg in args if not arg.startswith('-')]
        if not paths:
            paths = [session.cwd]

        for path in paths:
            resolved_path = session.resolve_path(path)
            if not os.path.exists(resolved_path) or not os.path.isdir(resolved_path):
                session.print_output(f"ls: cannot access '{path}': No such file or directory\n")
                continue

            try:
                items = os.listdir(resolved_path)
                items.sort(key=str.lower)

                if not show_hidden:
                    items = [item for item in items if not item.startswith('.')]

                if long_format:
                    output = self._long_format_output(resolved_path, items, human_readable, session)
                else:
                    output = self._columnar_output(resolved_path, items, session)
                
                session.print_output(output + "\n")

            except Exception as e:
                session.print_output(f"ls: {e}\n")

    def _format_size(self, size, human_readable):
        if not human_readable:
            return str(size)
        
        for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
            if abs(size) < 1024.0:
                return f"{size:3.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}Y"

    def _long_format_output(self, dir_path, items, human_readable, session):
        lines = []
        for item in items:
            item_path = os.path.join(dir_path, item)
            try:
                stats = os.stat(item_path)
                mode_str = stat.filemode(stats.st_mode)
                nlink = stats.st_nlink
                uid = stats.st_uid
                gid = stats.st_gid
                size = self._format_size(stats.st_size, human_readable)
                mtime = datetime.datetime.fromtimestamp(stats.st_mtime).strftime('%b %d %H:%M')
                
                display_item = item
                if os.path.isdir(item_path):
                    display_item = f"\033[1;34m{item}\033[0m"

                lines.append(f"{mode_str} {nlink:>2} {uid:<8} {gid:<8} {size:>6} {mtime} {display_item}")
            except FileNotFoundError:
                lines.append(f"?????????? {'?':>2} {'?':<8} {'?':<8} {'?':>6} ? ? ? {item}")
            except Exception as e:
                session.print_output(f"Error getting info for {item}: {e}\n")
        return "\n".join(lines)

    def _columnar_output(self, dir_path, items, session):
        if not items:
            return ""

        colored_items = []
        max_len = 0
        
        for item in items:
            item_path = os.path.join(dir_path, item)
            display_item = item
            if os.path.isdir(item_path):
                display_item = f"\033[1;34m{item}\033[0m"
            elif os.access(item_path, os.X_OK):
                 if sys.platform == 'win32':
                     if item.lower().endswith(('.exe', '.bat', '.cmd', '.ps1', '.py')):
                         display_item = f"\033[1;32m{item}\033[0m"
                 else:
                     display_item = f"\033[1;32m{item}\033[0m"
            
            colored_items.append(display_item)
            max_len = max(max_len, len(item))
            
        col_width = max_len + 2
        
        font_metrics = session.output_area.fontMetrics()
        char_width = font_metrics.horizontalAdvance(' ')
        if char_width <= 0: 
            char_width = 8
        available_width_px = session.output_area.viewport().width() - 20
        term_width_chars = max(1, available_width_px // char_width)
        
        num_cols = max(1, term_width_chars // col_width)
        num_rows = (len(colored_items) + num_cols - 1) // num_cols
        
        lines = []
        for r in range(num_rows):
            line_items = []
            for c in range(num_cols):
                idx = c * num_rows + r
                if idx < len(colored_items):
                    padding = " " * (col_width - len(items[idx]))
                    line_items.append(colored_items[idx] + padding)
            lines.append("".join(line_items))
            
        return "\n".join(lines)

#============================================================================================
# --- CD Management Commands ---
#============================================================================================
class CdCommand(Command):
    def __init__(self):
        super().__init__("cd", "Change the shell working directory")

    def execute(self, session, args):
        path = os.path.expanduser("~")
        if args:
            path = session.resolve_path(args[0])
        
        if os.path.isdir(path):
            session.cwd = path
            session.cwd_changed.emit(path)
        else:
            session.print_output(f"cd: {path}: No such file or directory")

#============================================================================================
# --- PWD Management Commands ---
#============================================================================================
class PwdCommand(Command):
    def __init__(self):
        super().__init__("pwd", "Print name of current/working directory")

    def execute(self, session, args):
        session.print_output(session.cwd)

#============================================================================================
# --- Directory Management Commands ---
#============================================================================================
class MkdirCommand(Command):
    def __init__(self):
        super().__init__("mkdir", "Make directories")

    def execute(self, session, args):
        if not args:
            session.print_output("mkdir: missing operand")
            return
        for arg in args:
            path = session.resolve_path(arg)
            try:
                os.makedirs(path, exist_ok=True)
            except Exception as e:
                session.print_output(f"mkdir: cannot create directory '{arg}': {e}")

#============================================================================================
# --- RM Management Commands ---
#============================================================================================
class RmCommand(Command):
    def __init__(self):
        super().__init__("rm", "Remove files or directories")

    def execute(self, session, args):
        if not args:
            session.print_output("rm: missing operand")
            return
        
        recursive = "-r" in args or "-rf" in args or "-R" in args
        force = "-f" in args or "-rf" in args
        
        targets = [arg for arg in args if not arg.startswith("-")]
        
        for target in targets:
            path = session.resolve_path(target)
            if not os.path.exists(path):
                if not force:
                    session.print_output(f"rm: cannot remove '{target}': No such file or directory")
                continue
            
            try:
                if os.path.isdir(path):
                    if recursive:
                        shutil.rmtree(path)
                    else:
                        session.print_output(f"rm: cannot remove '{target}': Is a directory")
                else:
                    os.remove(path)
            except Exception as e:
                session.print_output(f"rm: cannot remove '{target}': {e}")

#============================================================================================
# --- CP Management Commands ---
#============================================================================================
class CpCommand(Command):
    def __init__(self):
        super().__init__("cp", "Copy files and directories")

    def execute(self, session, args):
        if len(args) < 2:
            session.print_output("cp: missing file operand")
            return
            
        src = session.resolve_path(args[0])
        dst = session.resolve_path(args[1])
        
        try:
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
        except Exception as e:
            session.print_output(f"cp: error: {e}")

#============================================================================================
# --- MV Management Commands ---
#============================================================================================
class MvCommand(Command):
    def __init__(self):
        super().__init__("mv", "Move (rename) files")

    def execute(self, session, args):
        if len(args) < 2:
            session.print_output("mv: missing file operand")
            return
            
        src = session.resolve_path(args[0])
        dst = session.resolve_path(args[1])
        
        try:
            shutil.move(src, dst)
        except Exception as e:
            session.print_output(f"mv: error: {e}")
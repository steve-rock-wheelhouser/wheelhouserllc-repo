#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Cat Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of CatCommand.
# 0.2.0 - Integration (pipes) with other commands (e.g., grep, head, tail)
# 0.2.1 - Added support for binary files and large file handling.
# 0.2.2 - Added Support for concatenating multiple files into one output
# 0.2.3 - Added line numbering option
#
# Future features may include:
# - Support for different encodings and binary files
# - 
# - 
#============================================================================================

import os

from command_registry import Command

VERSION = "0.2.3"

#============================================================================================
# --- CAT Management Commands ---
#============================================================================================
class CatCommand(Command):
    def __init__(self):
        super().__init__("cat", f"Concatenate files and print on the standard output (v{VERSION})")

    def execute(self, session, args):
        if "--version" in args:
            session.print_output(f"cat (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output("Usage: cat [OPTION]... [FILE]...\nConcatenate files and print on the standard output.\n\nOptions:\n  -n, --number  number all output lines\n  --version     output version information and exit\n  --help        display this help and exit")
            return

        flags = set()
        files = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                files.append(arg)

        number_lines = 'n' in flags or '--number' in flags
        line_count = 1

        def output_line(text):
            nonlocal line_count
            if number_lines:
                session.print_output(f"{line_count:6}  {text}")
                line_count += 1
            else:
                session.print_output(text)

        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                for line in session.stdin.splitlines():
                    output_line(line)
            else:
                session.print_output("cat: missing file operand")
            return

        for arg in files:
            if arg == "-":
                if hasattr(session, 'stdin') and session.stdin:
                    for line in session.stdin.splitlines():
                        output_line(line)
                continue

            path = session.resolve_path(arg)
            if not os.path.exists(path):
                session.print_output(f"cat: {arg}: No such file or directory")
                continue
            
            if os.path.isdir(path):
                session.print_output(f"cat: {arg}: Is a directory")
                continue

            try:
                # Check for binary file by reading first chunk
                is_binary = False
                with open(path, 'rb') as f:
                    if b'\0' in f.read(1024):
                        is_binary = True
                
                if is_binary:
                    session.print_output(f"cat: {arg}: Binary file.")
                    continue

                # Read line-by-line for large file support
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    for line in f:
                        output_line(line.rstrip('\n\r'))
            except Exception as e:
                session.print_output(f"cat: {arg}: {e}")
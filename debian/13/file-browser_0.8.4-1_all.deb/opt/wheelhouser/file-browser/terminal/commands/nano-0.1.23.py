#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Nano Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of nano command.
# 0.1.1 - Added ctrl+s and ctrl+q shortcuts for save and exit.
# 0.1.2 - Added line numbers and syntax highlighting.
# 0.1.3 - Apply wheelhouser terminal dark theme to editor and added settings persistence for window geometry.
# 0.1.4 - Inherit font preferences from terminal session.
# 0.1.5 - Updated styling to match terminal native look (borderless, matching background).
# 0.1.6 - Make the line number background match the terminal background color for a more seamless look.
# 0.1.7 - Update python syntax highlighter to be more like VS code's default dark theme for better readability and aesthetics.
# 0.1.8 - make a tab 4 spaces instead of a literal tab character for better consistency across different environments and editors. 
# 0.1.9 - Update syntax highlighting: Constants and import modules are now white.
# 0.1.10 - Update syntax highlighting: True/False/None/self/cls are now Dark Blue (#569CD6).
# 0.1.11 - Update syntax highlighting: UPPER_CASE constants and Numbers are now White (#FFFFFF).
# 0.1.12 - Update syntax highlighting: ints and floats are to be yellow-green (#B5CEA8).
# 0.1.13 - Added syntax highlighting for multi-lined docstrings in Python.
# 0.1.14 - Added support for automatic tab indentation in Python files.
# 0.1.15 - Added JSON syntax highlighting.
# 0.1.16 - Added JSON bracket highlighting.
# 0.1.17 - Added rainbow bracket highlighting for JSON files.
# 0.1.18 - Added syntax highlight for shell scripts (e.g. .sh, .bash) 
# 0.1.19 - Added support for lighlighting power shell scripts (e.g. .ps1)
# 0.1.20 - Addedd support for highlighting for html files
# 0.1.21 - Addedd support for highlighting for css files
# 0.1.22 - Addedd support for highlighting for js files
# 0.1.23 - Added support fot highlighting for markdown files
#
# Future features may include:
# 
#
#============================================================================================

import os
import re
from PySide6.QtWidgets import QDialog, QVBoxLayout, QPlainTextEdit, QPushButton, QHBoxLayout, QWidget, QTextEdit
from PySide6.QtGui import QShortcut, QKeySequence, QColor, QPainter, QSyntaxHighlighter, QTextCharFormat, QTextFormat, QFont
from PySide6.QtCore import Qt, QRect, QSize, QSettings

from command_registry import Command

COMMAND_NAME = "nano"
VERSION = "0.1.23"
DESCRIPTION = "Simple text editor"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.codeEditor = editor

    def sizeHint(self):
        return QSize(self.codeEditor.lineNumberAreaWidth(), 0)

    def paintEvent(self, event):
        self.codeEditor.lineNumberAreaPaintEvent(event)

#=========================================================================================
# --- Code Editor with Line Numbers ---
#=========================================================================================
class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lineNumberArea = LineNumberArea(self)
        self.blockCountChanged.connect(self.updateLineNumberAreaWidth)
        self.updateRequest.connect(self.updateLineNumberArea)
        self.cursorPositionChanged.connect(self.highlightCurrentLine)
        self.updateLineNumberAreaWidth(0)
        self.highlightCurrentLine()
        self.auto_indent = False

    def lineNumberAreaWidth(self):
        digits = 1
        max_val = max(1, self.blockCount())
        while max_val >= 10:
            max_val //= 10
            digits += 1
        space = 10 + self.fontMetrics().horizontalAdvance('9') * digits
        return space

    def updateLineNumberAreaWidth(self, _):
        self.setViewportMargins(self.lineNumberAreaWidth(), 0, 0, 0)

    def updateLineNumberArea(self, rect, dy):
        if dy:
            self.lineNumberArea.scroll(0, dy)
        else:
            self.lineNumberArea.update(0, rect.y(), self.lineNumberArea.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.updateLineNumberAreaWidth(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.lineNumberArea.setGeometry(QRect(cr.left(), cr.top(), self.lineNumberAreaWidth(), cr.height()))

    def lineNumberAreaPaintEvent(self, event):
        painter = QPainter(self.lineNumberArea)
        painter.fillRect(event.rect(), QColor("#121212"))

        block = self.firstVisibleBlock()
        blockNumber = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(blockNumber + 1)
                painter.setPen(QColor("#858585"))
                painter.drawText(0, int(top), self.lineNumberArea.width() - 5, self.fontMetrics().height(),
                                 Qt.AlignRight, number)
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            blockNumber += 1

    def highlightCurrentLine(self):
        extraSelections = []
        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()
            lineColor = QColor("#1f1f1f")
            selection.format.setBackground(lineColor)
            selection.format.setProperty(QTextFormat.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            extraSelections.append(selection)
        self.setExtraSelections(extraSelections)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Tab:
            self.insertPlainText("    ")
            return
            
        if self.auto_indent and event.key() == Qt.Key_Return:
            cursor = self.textCursor()
            # If at start of line, just insert newline without calculating indent
            if cursor.positionInBlock() == 0:
                super().keyPressEvent(event)
                return

            block = self.document().findBlock(cursor.position())
            text = block.text()
            
            indent = ""
            for char in text:
                if char.isspace():
                    indent += char
                else:
                    break
            
            if text.rstrip().endswith(":"):
                indent += "    "
            
            super().keyPressEvent(event)
            self.insertPlainText(indent)
            return
            
        super().keyPressEvent(event)

#=========================================================================================
# --- Basic Syntax Highlighter for Python (can be extended for other languages) ---
#=========================================================================================
class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Identifiers (Light Blue) #9CDCFE - Default for variables/properties
        identifierFormat = QTextCharFormat()
        identifierFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'), identifierFormat))

        # 2. Control Flow Keywords (Purple) #C586C0
        controlFlowFormat = QTextCharFormat()
        controlFlowFormat.setForeground(QColor("#C586C0"))
        controlFlowPatterns = r'\b(if|else|elif|while|for|return|try|except|finally|break|continue|pass|raise|yield|await|async|import|from|as)\b'
        self.highlightingRules.append((re.compile(controlFlowPatterns), controlFlowFormat))

        # 3. Storage/Definition Keywords (Blue) #569CD6
        storageFormat = QTextCharFormat()
        storageFormat.setForeground(QColor("#569CD6"))
        storagePatterns = r'\b(def|class|lambda|with|in|is|not|and|or|global|nonlocal|del|assert)\b'
        self.highlightingRules.append((re.compile(storagePatterns), storageFormat))

        # 4. Function Calls (Yellow) #DCDCAA
        funcCallFormat = QTextCharFormat()
        funcCallFormat.setForeground(QColor("#DCDCAA"))
        self.highlightingRules.append((re.compile(r'\b([a-zA-Z_][a-zA-Z0-9_]*)(?=\s*\()'), funcCallFormat))

        # 5. Class Names / Types (Teal) #4EC9B0
        classFormat = QTextCharFormat()
        classFormat.setForeground(QColor("#4EC9B0"))
        self.highlightingRules.append((re.compile(r'\b[A-Z][a-zA-Z0-9_]*\b'), classFormat))

        # 6. Constants (UPPER_CASE) (White) #FFFFFF
        upperFormat = QTextCharFormat()
        upperFormat.setForeground(QColor("#FFFFFF"))
        self.highlightingRules.append((re.compile(r'\b[A-Z_][A-Z0-9_]*\b'), upperFormat))

        # 7. Built-in Constants (Dark Blue) #569CD6
        constantFormat = QTextCharFormat()
        constantFormat.setForeground(QColor("#569CD6"))
        constantPatterns = r'\b(True|False|None|self|cls)\b'
        self.highlightingRules.append((re.compile(constantPatterns), constantFormat))

        # 7. Decorators (Yellow) #DCDCAA
        decoratorFormat = QTextCharFormat()
        decoratorFormat.setForeground(QColor("#DCDCAA"))
        self.highlightingRules.append((re.compile(r'@[a-zA-Z_][a-zA-Z0-9_]*'), decoratorFormat))

        # 8. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'(\".*?\"|\'.*?\')'), stringFormat))

        # 9. Comments (Green) #6A9955
        commentFormat = QTextCharFormat()
        commentFormat.setForeground(QColor("#6A9955"))
        self.highlightingRules.append((re.compile(r'(#.*$)'), commentFormat))

        # 10. Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b\d+(\.\d+)?\b'), numberFormat))
        
        # Define White Format for Imports
        whiteFormat = QTextCharFormat()
        whiteFormat.setForeground(QColor("#FFFFFF"))
        
        # 11. Imports (White) #FFFFFF - Matches "import x" or "from y"
        # We use group 2 to only highlight the module name, not the keyword
        self.highlightingRules.append((re.compile(r'\b(import|from)\s+([a-zA-Z0-9_.]+)'), whiteFormat, 2))
        
        # Multi-line Docstrings (String Color) #CE9178
        self.docStringFormat = QTextCharFormat()
        self.docStringFormat.setForeground(QColor("#CE9178"))

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            group = rule[2] if len(rule) > 2 else 0
            
            for match in pattern.finditer(text):
                start = match.start(group)
                length = match.end(group) - start
                if length > 0:
                    self.setFormat(start, length, format)
        
        # Multi-line strings
        self.setCurrentBlockState(0)
        
        start_index = 0
        if self.previousBlockState() != 1 and self.previousBlockState() != 2:
            start_index = -1
            match_double = re.search(r'"""', text)
            match_single = re.search(r"'''", text)
            
            if match_double and match_single:
                if match_double.start() < match_single.start():
                    start_index = match_double.start()
                    state = 1
                else:
                    start_index = match_single.start()
                    state = 2
            elif match_double:
                start_index = match_double.start()
                state = 1
            elif match_single:
                start_index = match_single.start()
                state = 2
        else:
            state = self.previousBlockState()

        while start_index >= 0:
            delimiter = r'"""' if state == 1 else r"'''"
            offset = 3 if (self.previousBlockState() != state or start_index > 0) else 0
            
            match_end = re.search(delimiter, text[start_index + offset:])
            
            if match_end:
                length = match_end.end() + offset
                self.setFormat(start_index, length, self.docStringFormat)
                current_end_pos = start_index + length
                
                start_index = -1
                self.setCurrentBlockState(0)
                
                match_double = re.search(r'"""', text[current_end_pos:])
                match_single = re.search(r"'''", text[current_end_pos:])
                
                if match_double or match_single:
                    if match_double and match_single:
                        start_index = current_end_pos + (match_double.start() if match_double.start() < match_single.start() else match_single.start())
                        state = 1 if match_double.start() < match_single.start() else 2
                    else:
                        start_index = current_end_pos + (match_double.start() if match_double else match_single.start())
                        state = 1 if match_double else 2
            else:
                self.setCurrentBlockState(state)
                self.setFormat(start_index, len(text) - start_index, self.docStringFormat)
                break

#=========================================================================================
# --- JSON Syntax Highlighter ---
#=========================================================================================
class JsonHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # Rainbow Brackets Colors
        self.rainbowColors = [
            QColor("#FFD700"), # Gold
            QColor("#da70d6"), # Orchid
            QColor("#179fff"), # Light Sky Blue
        ]

        # 1. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'("[^"\\]*(\\.[^"\\]*)*")'), stringFormat))

        # 2. Constants (Dark Blue) #569CD6
        constantFormat = QTextCharFormat()
        constantFormat.setForeground(QColor("#569CD6"))
        self.highlightingRules.append((re.compile(r'\b(true|false|null)\b'), constantFormat))

        # 3. Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?\b'), numberFormat))

        # 4. Keys (Light Blue) #9CDCFE - Must be applied after strings to overwrite
        keyFormat = QTextCharFormat()
        keyFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'("[^"\\]*(\\.[^"\\]*)*")\s*:'), keyFormat, 1))

    def highlightBlock(self, text):
        # Apply regex rules first (Strings, Numbers, Keys, Constants)
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            group = rule[2] if len(rule) > 2 else 0
            
            for match in pattern.finditer(text):
                start = match.start(group)
                length = match.end(group) - start
                if length > 0:
                    self.setFormat(start, length, format)

        # Apply Rainbow Brackets with depth tracking
        # previousBlockState() returns the nesting depth at the end of the previous block
        depth = max(0, self.previousBlockState())
        
        i = 0
        while i < len(text):
            char = text[i]
            
            # Skip escaped characters
            if char == '\\':
                i += 2
                continue
            
            # Skip strings to avoid coloring brackets inside them
            if char == '"':
                i += 1
                while i < len(text):
                    if text[i] == '\\':
                        i += 2
                        continue
                    if text[i] == '"':
                        break
                    i += 1
                i += 1
                continue
                
            if char in '{[':
                color = self.rainbowColors[depth % len(self.rainbowColors)]
                fmt = QTextCharFormat()
                fmt.setForeground(color)
                self.setFormat(i, 1, fmt)
                depth += 1
            elif char in '}]':
                if depth > 0:
                    depth -= 1
                    color = self.rainbowColors[depth % len(self.rainbowColors)]
                    fmt = QTextCharFormat()
                    fmt.setForeground(color)
                    self.setFormat(i, 1, fmt)
                else:
                    # Unmatched closing bracket, use level 0 color
                    color = self.rainbowColors[0]
                    fmt = QTextCharFormat()
                    fmt.setForeground(color)
                    self.setFormat(i, 1, fmt)
            
            i += 1
            
        self.setCurrentBlockState(depth)

#=========================================================================================
# --- Shell Syntax Highlighter ---
#=========================================================================================
class ShellHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Keywords (Purple) #C586C0
        keywordFormat = QTextCharFormat()
        keywordFormat.setForeground(QColor("#C586C0"))
        keywords = r'\b(if|then|else|elif|fi|case|esac|for|select|while|until|do|done|in|function|time|coproc)\b'
        self.highlightingRules.append((re.compile(keywords), keywordFormat))

        # 2. Builtins/Commands (Blue) #569CD6
        builtinFormat = QTextCharFormat()
        builtinFormat.setForeground(QColor("#569CD6"))
        builtins = r'\b(echo|printf|read|cd|pwd|pushd|popd|dirs|let|eval|set|unset|export|declare|typeset|readonly|local|source|alias|unalias|test|exit|return|true|false|break|continue|shift|trap|wait|exec|ulimit|umask|bg|fg|jobs|kill|history)\b'
        self.highlightingRules.append((re.compile(builtins), builtinFormat))

        # 3. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        # Double quotes allowing escaped quotes
        self.highlightingRules.append((re.compile(r'("[^"\\]*(\\.[^"\\]*)*")'), stringFormat))
        # Single quotes (literal)
        self.highlightingRules.append((re.compile(r"('.*?')"), stringFormat))

        # 4. Variables (Light Blue) #9CDCFE
        variableFormat = QTextCharFormat()
        variableFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\$[a-zA-Z_][a-zA-Z0-9_]*'), variableFormat))
        self.highlightingRules.append((re.compile(r'\$\{[a-zA-Z_][a-zA-Z0-9_]*\}'), variableFormat))

        # 5. Comments (Green) #6A9955
        commentFormat = QTextCharFormat()
        commentFormat.setForeground(QColor("#6A9955"))
        self.highlightingRules.append((re.compile(r'(#.*$)'), commentFormat))

        # 6. Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b\d+\b'), numberFormat))

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, format)

#=========================================================================================
# --- PowerShell Syntax Highlighter ---
#=========================================================================================
class PowerShellHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Keywords (Purple) #C586C0
        keywordFormat = QTextCharFormat()
        keywordFormat.setForeground(QColor("#C586C0"))
        keywords = r'\b(if|else|elseif|switch|for|foreach|in|while|do|until|break|continue|return|function|filter|workflow|try|catch|finally|throw|exit|trap|data|dynamicparam|param|begin|process|end)\b'
        self.highlightingRules.append((re.compile(keywords, re.IGNORECASE), keywordFormat))

        # 2. Cmdlets (Yellow) #DCDCAA
        cmdletFormat = QTextCharFormat()
        cmdletFormat.setForeground(QColor("#DCDCAA"))
        self.highlightingRules.append((re.compile(r'\b[a-z]+-[a-z]+\b', re.IGNORECASE), cmdletFormat))

        # 3. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'("[^"\\]*(\\.[^"\\]*)*")'), stringFormat))
        self.highlightingRules.append((re.compile(r"('.*?')"), stringFormat))

        # 4. Variables (Light Blue) #9CDCFE
        variableFormat = QTextCharFormat()
        variableFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\$[a-z0-9_:]+', re.IGNORECASE), variableFormat))

        # 5. Comments (Green) #6A9955
        commentFormat = QTextCharFormat()
        commentFormat.setForeground(QColor("#6A9955"))
        self.highlightingRules.append((re.compile(r'(#.*$)'), commentFormat))

        # 6. Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b\d+\b'), numberFormat))

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, format)

#=========================================================================================
# --- HTML Syntax Highlighter ---
#=========================================================================================
class HtmlHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Tags (Dark Blue) #569CD6
        tagFormat = QTextCharFormat()
        tagFormat.setForeground(QColor("#569CD6"))
        self.highlightingRules.append((re.compile(r'</?[a-zA-Z0-9_:-]+'), tagFormat))
        self.highlightingRules.append((re.compile(r'>'), tagFormat))

        # 2. Attributes (Light Blue) #9CDCFE
        attrFormat = QTextCharFormat()
        attrFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\b[a-zA-Z0-9_:-]+(?=\=)'), attrFormat))

        # 3. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'("[^"]*")'), stringFormat))
        self.highlightingRules.append((re.compile(r"('[^']*')"), stringFormat))

        # 4. Comments (Green) #6A9955
        self.commentFormat = QTextCharFormat()
        self.commentFormat.setForeground(QColor("#6A9955"))
        self.commentStart = re.compile(r'<!--')
        self.commentEnd = re.compile(r'-->')

    def highlightBlock(self, text):
        for pattern, format in self.highlightingRules:
            for match in pattern.finditer(text):
                self.setFormat(match.start(), match.end() - match.start(), format)

        self.setCurrentBlockState(0)
        startIndex = 0
        if self.previousBlockState() != 1:
            startIndex = -1
            match = self.commentStart.search(text)
            if match:
                startIndex = match.start()
        
        while startIndex >= 0:
            match = self.commentEnd.search(text, startIndex)
            if match:
                length = match.end() - startIndex
                self.setFormat(startIndex, length, self.commentFormat)
                startIndex = -1
                match = self.commentStart.search(text, match.end())
                if match:
                    startIndex = match.start()
            else:
                self.setCurrentBlockState(1)
                self.setFormat(startIndex, len(text) - startIndex, self.commentFormat)
                break

#=========================================================================================
# --- CSS Syntax Highlighter ---
#=========================================================================================
class CssHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Classes (Teal) #4EC9B0
        classFormat = QTextCharFormat()
        classFormat.setForeground(QColor("#4EC9B0"))
        self.highlightingRules.append((re.compile(r'\.[a-zA-Z0-9_-]+'), classFormat))

        # 2. IDs (Light Blue) #9CDCFE
        idFormat = QTextCharFormat()
        idFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'#[a-zA-Z0-9_-]+'), idFormat))

        # 3. Properties (Light Blue) #9CDCFE
        propertyFormat = QTextCharFormat()
        propertyFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\b[a-zA-Z-]+(?=\s*:)'), propertyFormat))

        # 4. Values - Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b\d+(\.\d+)?(px|em|rem|%|vh|vw|s|ms|deg)?\b'), numberFormat))

        # 5. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'("[^"]*")'), stringFormat))
        self.highlightingRules.append((re.compile(r"('[^']*')"), stringFormat))

        # 6. Comments (Green) #6A9955
        self.commentFormat = QTextCharFormat()
        self.commentFormat.setForeground(QColor("#6A9955"))
        self.commentStart = re.compile(r'/\*')
        self.commentEnd = re.compile(r'\*/')

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, format)

        self.setCurrentBlockState(0)
        startIndex = 0
        if self.previousBlockState() != 1:
            startIndex = -1
            match = self.commentStart.search(text)
            if match:
                startIndex = match.start()
        
        while startIndex >= 0:
            match = self.commentEnd.search(text, startIndex)
            if match:
                length = match.end() - startIndex
                self.setFormat(startIndex, length, self.commentFormat)
                startIndex = -1
                match = self.commentStart.search(text, match.end())
                if match:
                    startIndex = match.start()
            else:
                self.setCurrentBlockState(1)
                self.setFormat(startIndex, len(text) - startIndex, self.commentFormat)
                break

#=========================================================================================
# --- JavaScript Syntax Highlighter ---
#=========================================================================================
class JavaScriptHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Keywords (Purple) #C586C0
        keywordFormat = QTextCharFormat()
        keywordFormat.setForeground(QColor("#C586C0"))
        keywords = r'\b(break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|finally|for|function|if|import|in|instanceof|new|return|super|switch|this|throw|try|typeof|var|void|while|with|yield|let|static|enum|await|async)\b'
        self.highlightingRules.append((re.compile(keywords), keywordFormat))

        # 2. Built-in Objects (Teal) #4EC9B0
        typeFormat = QTextCharFormat()
        typeFormat.setForeground(QColor("#4EC9B0"))
        types = r'\b(Array|Boolean|Date|Error|Function|JSON|Math|Number|Object|RegExp|String|Symbol|Map|Set|Promise|Proxy|Reflect|Intl)\b'
        self.highlightingRules.append((re.compile(types), typeFormat))

        # 3. Constants (Dark Blue) #569CD6
        constantFormat = QTextCharFormat()
        constantFormat.setForeground(QColor("#569CD6"))
        self.highlightingRules.append((re.compile(r'\b(true|false|null|undefined|NaN|Infinity)\b'), constantFormat))

        # 4. Function Calls (Yellow) #DCDCAA
        funcCallFormat = QTextCharFormat()
        funcCallFormat.setForeground(QColor("#DCDCAA"))
        self.highlightingRules.append((re.compile(r'\b([a-zA-Z_][a-zA-Z0-9_]*)(?=\s*\()'), funcCallFormat))

        # 5. Strings (Orange) #CE9178
        stringFormat = QTextCharFormat()
        stringFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'("[^"\\]*(\\.[^"\\]*)*")'), stringFormat))
        self.highlightingRules.append((re.compile(r"('[^'\\]*(\\.[^'\\]*)*')"), stringFormat))
        self.highlightingRules.append((re.compile(r"(`[^`\\]*(\\.[^`\\]*)*`)"), stringFormat))

        # 6. Comments (Green) #6A9955
        self.commentFormat = QTextCharFormat()
        self.commentFormat.setForeground(QColor("#6A9955"))
        self.highlightingRules.append((re.compile(r'(//.*$)'), self.commentFormat))

        # 7. Numbers (Yellow-Green) #B5CEA8
        numberFormat = QTextCharFormat()
        numberFormat.setForeground(QColor("#B5CEA8"))
        self.highlightingRules.append((re.compile(r'\b\d+(\.\d+)?\b'), numberFormat))

        self.commentStart = re.compile(r'/\*')
        self.commentEnd = re.compile(r'\*/')

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, format)

        self.setCurrentBlockState(0)
        startIndex = 0
        if self.previousBlockState() != 1:
            startIndex = -1
            match = self.commentStart.search(text)
            if match:
                startIndex = match.start()
        
        while startIndex >= 0:
            match = self.commentEnd.search(text, startIndex)
            if match:
                length = match.end() - startIndex
                self.setFormat(startIndex, length, self.commentFormat)
                startIndex = -1
                match = self.commentStart.search(text, match.end())
                if match:
                    startIndex = match.start()
            else:
                self.setCurrentBlockState(1)
                self.setFormat(startIndex, len(text) - startIndex, self.commentFormat)
                break

#=========================================================================================
# --- Markdown Syntax Highlighter ---
#=========================================================================================
class MarkdownHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlightingRules = []

        # 1. Headers (Blue) #569CD6
        headerFormat = QTextCharFormat()
        headerFormat.setForeground(QColor("#569CD6"))
        headerFormat.setFontWeight(QFont.Bold)
        self.highlightingRules.append((re.compile(r'^#{1,6}\s+.*$'), headerFormat))

        # 2. Bold (White) #FFFFFF
        boldFormat = QTextCharFormat()
        boldFormat.setForeground(QColor("#FFFFFF"))
        boldFormat.setFontWeight(QFont.Bold)
        self.highlightingRules.append((re.compile(r'\*\*.*?\*\*'), boldFormat))
        self.highlightingRules.append((re.compile(r'__.*?__'), boldFormat))

        # 3. Italic (Light Grey) #D4D4D4
        italicFormat = QTextCharFormat()
        italicFormat.setForeground(QColor("#D4D4D4"))
        italicFormat.setFontItalic(True)
        self.highlightingRules.append((re.compile(r'\*.*?\*'), italicFormat))
        self.highlightingRules.append((re.compile(r'_.*?_'), italicFormat))

        # 4. Lists (Yellow) #DCDCAA
        listFormat = QTextCharFormat()
        listFormat.setForeground(QColor("#DCDCAA"))
        self.highlightingRules.append((re.compile(r'^\s*[-*+]\s+'), listFormat))
        self.highlightingRules.append((re.compile(r'^\s*\d+\.\s+'), listFormat))

        # 5. Code (Orange) #CE9178
        codeFormat = QTextCharFormat()
        codeFormat.setForeground(QColor("#CE9178"))
        self.highlightingRules.append((re.compile(r'`[^`]*`'), codeFormat))

        # 6. Blockquotes (Green) #6A9955
        quoteFormat = QTextCharFormat()
        quoteFormat.setForeground(QColor("#6A9955"))
        self.highlightingRules.append((re.compile(r'^\s*>.*$'), quoteFormat))

        # 7. Links (Light Blue) #9CDCFE
        linkFormat = QTextCharFormat()
        linkFormat.setForeground(QColor("#9CDCFE"))
        self.highlightingRules.append((re.compile(r'\[.*?\]\(.*?\)'), linkFormat))

    def highlightBlock(self, text):
        for rule in self.highlightingRules:
            pattern = rule[0]
            format = rule[1]
            
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, format)

#=========================================================================================
# --- Nano Editor Dialog ---
#=========================================================================================
class NanoEditorDialog(QDialog):
    def __init__(self, filepath, content="", font_family="Consolas", font_size=12, parent=None):
        super().__init__(parent)
        self.filepath = filepath
        self.setWindowTitle(f"nano - {os.path.basename(filepath)}")
        self.font_family = font_family.replace("'", "").replace('"', "")
        self.font_size = font_size
        
        self.settings = QSettings("Wheelhouser LLC", "Terminal")
        geometry = self.settings.value("nano_geometry")
        if geometry:
            self.restoreGeometry(geometry)
        else:
            self.resize(600, 400)
            
        self.setStyleSheet("""
            QDialog {
                background-color: #121212;
                color: #cccccc;
            }
            QPushButton {
                background-color: #323232;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 6px 12px;
                color: #ffffff;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
        """)
        self.setup_ui(content)

    def setup_ui(self, content):
        layout = QVBoxLayout(self)
        
        self.text_edit = CodeEditor()
        self.text_edit.setPlainText(content)
        # Use styleSheet for font to handle font stacks (e.g. "Consolas, Monospace") correctly
        self.text_edit.setStyleSheet(f"""
            QPlainTextEdit {{
                background-color: #121212; 
                color: #cccccc; 
                border: none;
                font-family: {self.font_family};
                font-size: {self.font_size}px;
            }}
        """)
        self.text_edit.updateLineNumberAreaWidth(0)
        layout.addWidget(self.text_edit)

        # Apply syntax highlighting if it's a python file
        if self.filepath.endswith(".py"):
            self.highlighter = PythonHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith(".json"):
            self.highlighter = JsonHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith((".sh", ".bash", ".zsh")):
            self.highlighter = ShellHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith((".ps1", ".psm1", ".psd1")):
            self.highlighter = PowerShellHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith((".html", ".htm")):
            self.highlighter = HtmlHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith(".css"):
            self.highlighter = CssHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith(".js"):
            self.highlighter = JavaScriptHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        elif self.filepath.endswith(".md"):
            self.highlighter = MarkdownHighlighter(self.text_edit.document())
            self.text_edit.auto_indent = True
        
        btn_layout = QHBoxLayout()
        self.btn_save = QPushButton("Save && Close")
        self.btn_save.clicked.connect(self.accept)
        # Primary button style override
        self.btn_save.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                border: 1px solid #007AFF;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)
        
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_save)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

        self.shortcut_save = QShortcut(QKeySequence("Ctrl+S"), self)
        self.shortcut_save.activated.connect(self.accept)
        
        self.shortcut_quit = QShortcut(QKeySequence("Ctrl+Q"), self)
        self.shortcut_quit.activated.connect(self.reject)

    def get_content(self):
        return self.text_edit.toPlainText()

    def done(self, result):
        self.settings.setValue("nano_geometry", self.saveGeometry())
        super().done(result)

#=========================================================================================
# --- Nano Command Implementation ---
#=========================================================================================
class NanoCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [FILE]\n{DESCRIPTION}\n\nOptions:\n  --version    output version information and exit\n  --help       display this help and exit")
            return

        # 2. Parse Arguments
        filename = None
        for arg in args:
            if not arg.startswith("-"):
                filename = arg
                break
        
        if not filename:
            session.print_output("nano: missing filename")
            return

        filepath = session.resolve_path(filename)
        content = ""
        
        if os.path.exists(filepath):
            if os.path.isdir(filepath):
                session.print_output(f"nano: {filename}: Is a directory")
                return
            try:
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
            except Exception as e:
                session.print_output(f"nano: error reading {filename}: {e}")
                return
        
        # 3. Open Editor Dialog
        font_family = session.current_theme.get("font_family", "Consolas")
        font_size = session.current_theme.get("font_size", 12)
        
        dialog = NanoEditorDialog(filepath, content, font_family, font_size, parent=session)
        if dialog.exec() == QDialog.Accepted:
            new_content = dialog.get_content()
            try:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                session.print_output(f"Saved {filename}")
            except Exception as e:
                session.print_output(f"nano: error writing {filename}: {e}")
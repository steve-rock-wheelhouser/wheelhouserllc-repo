#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Tail Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of tail command.
#
# Future features may include:
# - Support for -f (follow) mode (requires async/threading support in terminal)
# - Support for byte offsets (-c)
#============================================================================================

import os
from collections import deque

from command_registry import Command

COMMAND_NAME = "tail"
VERSION = "0.1.0"
DESCRIPTION = "Output the last part of files"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class TailCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -n, --lines=[+]NUM  output the last NUM lines, instead of the last 10\n  --version           output version information and exit\n  --help              display this help and exit")
            return

        # 2. Parse Arguments & Flags
        num_lines = 10
        files = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-n" or arg == "--lines":
                if i + 1 < len(args):
                    try:
                        num_lines = int(args[i+1])
                        i += 1
                    except ValueError:
                        session.print_output(f"tail: invalid number of lines: '{args[i+1]}'")
                        return
                else:
                    session.print_output(f"tail: option requires an argument -- '{arg}'")
                    return
            elif arg.startswith("-n"):
                # Handle -n50 syntax
                try:
                    num_lines = int(arg[2:])
                except ValueError:
                    session.print_output(f"tail: invalid number of lines: '{arg[2:]}'")
                    return
            elif arg.startswith("-") and arg != "-":
                session.print_output(f"tail: unknown option -- '{arg}'")
                return
            else:
                files.append(arg)
            i += 1

        # 3. Main Logic
        if not files:
            session.print_output("tail: missing file operand")
            return

        multiple_files = len(files) > 1

        for idx, filename in enumerate(files):
            path = session.resolve_path(filename)
            
            if not os.path.exists(path):
                session.print_output(f"tail: cannot open '{filename}' for reading: No such file or directory")
                continue
            
            if multiple_files:
                if idx > 0:
                    session.print_output("")
                session.print_output(f"==> {filename} <==")

            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    for line in deque(f, num_lines):
                        session.print_output(line.rstrip('\n\r'))
            except Exception as e:
                session.print_output(f"tail: error reading '{filename}': {e}")
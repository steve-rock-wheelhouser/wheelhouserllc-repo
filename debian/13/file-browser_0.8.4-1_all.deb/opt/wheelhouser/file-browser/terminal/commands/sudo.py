#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Sudo Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of sudo command.
#
# Future features may include:
# - Support for -u (user) flag parsing in help
#============================================================================================

import sys
import subprocess
from PySide6.QtWidgets import QInputDialog, QLineEdit

from command_registry import Command

COMMAND_NAME = "sudo"
VERSION = "0.1.0"
DESCRIPTION = "Execute a command as another user"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class SudoCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... COMMAND\n{DESCRIPTION}\n\nOptions:\n  --version     output version information and exit\n  --help        display this help and exit")
            return

        # 2. Main Logic
        if sys.platform == "win32":
            session.print_output("sudo: not supported on Windows. Please run the application as Administrator.")
            return

        if not args:
            session.print_output("sudo: missing command")
            return

        # Prompt for password
        password, ok = QInputDialog.getText(session, "sudo", "Enter password for sudo:", QLineEdit.Password)
        if not ok:
            return

        # Prepare command: sudo -S reads password from stdin
        cmd = ["sudo", "-S"] + args
        
        try:
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=session.cwd,
                env=session.env
            )
            
            stdout, stderr = process.communicate(input=password + "\n")
            
            if stdout:
                session.print_output(stdout.rstrip())
            if stderr:
                # sudo -S writes the password prompt to stderr, so we print it
                session.print_output(stderr.rstrip())
                
        except Exception as e:
            session.print_output(f"sudo: error: {e}")
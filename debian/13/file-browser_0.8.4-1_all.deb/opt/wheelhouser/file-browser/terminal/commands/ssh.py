#!/usr/bin/python3
# -*- coding: utf-8 -*-
# SSH Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of ssh command.
#
# Future features may include:
# - Support for -i (identity file) parsing in help
#============================================================================================

import shutil

from command_registry import Command

COMMAND_NAME = "ssh"
VERSION = "0.1.0"
DESCRIPTION = "Open SSH client (remote login program)"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class SshCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... destination [command]\n{DESCRIPTION}\n\nOptions:\n  -p port       Port to connect to on the remote host\n  -i identity   Selects a file from which the identity (private key) is read\n  --version     output version information and exit\n  --help        display this help and exit\n\nNote: Interactive password prompts are not supported. Use SSH keys for authentication.")
            return

        # 2. Main Logic
        if not shutil.which("ssh"):
            session.print_output("ssh: command not found. Please ensure OpenSSH client is installed and in your PATH.")
            return

        if not args:
            session.print_output("ssh: usage: ssh [options] destination [command]")
            return

        # Pass through to system command
        # Note: We pass session.stdin to support piping into ssh (e.g. echo "ls" | ssh host)
        full_cmd = ["ssh"] + args
        
        # run_system_command handles execution and output capture
        session.run_system_command(full_cmd, session.stdin)
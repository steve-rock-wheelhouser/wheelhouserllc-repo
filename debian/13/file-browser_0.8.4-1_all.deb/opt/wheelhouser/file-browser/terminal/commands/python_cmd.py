# This file is part of Wheelhouser Shell, a terminal emulator application.
import sys
import os
import tempfile
from PySide6.QtCore import QProcess, QProcessEnvironment
from pathlib import Path
from command_registry import Command

class PythonCommand(Command):
    def __init__(self):
        super().__init__("python", "Executes a Python script.")

    def execute(self, session, args):
        executable = sys.executable
        
        is_compiled = getattr(sys, 'frozen', False)
        if not is_compiled:
            is_compiled = '__compiled__' in globals()
        if not is_compiled and hasattr(sys, 'modules') and sys.modules.get('__main__'):
            is_compiled = hasattr(sys.modules['__main__'], '__compiled__')
        # Also check if sys.executable looks like a non-existent fake python.exe in a temp dir
        if not is_compiled and executable and not os.path.exists(executable):
            is_compiled = True
            
        if is_compiled:
            path_var = session.env.get("PATH", os.environ.get("PATH"))
            
            # Prioritize 'py' launcher on Windows as it's unlikely to be in the Nuitka bundle
            candidates = ["py.exe", "python.exe", "python3.exe"] if sys.platform == "win32" else ["python3", "python"]
            
            executable = None
            
            try:
                # Resolve system temp to canonical path (long path, no symlinks)
                sys_temp = Path(tempfile.gettempdir()).resolve()
            except Exception:
                sys_temp = Path(tempfile.gettempdir())

            try:
                # Resolve frozen app dir
                sys_frozen = Path(sys.executable).resolve().parent
            except Exception:
                sys_frozen = None

            # Manually iterate PATH to find a valid python that is NOT in a temp dir
            for path_dir in path_var.split(os.pathsep):
                if not path_dir.strip(): 
                    continue
                
                try:
                    p_dir = Path(path_dir).resolve()
                except Exception:
                    continue
                
                # Check if this directory is inside the system temp directory or is the frozen dir
                # This handles Nuitka's temp extraction folder robustly
                try:
                    if p_dir == sys_temp or sys_temp in p_dir.parents:
                        continue
                    if sys_frozen and p_dir == sys_frozen:
                        continue
                except Exception:
                    pass
                
                # Fallback string check for temp
                str_dir = str(p_dir).lower()
                if "appdata\\local\\temp" in str_dir:
                    continue

                # Check candidates in this directory
                for name in candidates:
                    target = p_dir / name
                    if target.is_file():
                         # Check executable permission/validity
                         if os.access(str(target), os.X_OK):
                             # To avoid picking up the dummy 0-byte MS Store python.exe which opens the Store UI,
                             # we test run it if its size is 0 bytes.
                             if sys.platform == "win32" and target.stat().st_size == 0:
                                 import subprocess
                                 try:
                                     res = subprocess.run(
                                         [str(target), "-V"],
                                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000),
                                         timeout=2.0,
                                         stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL
                                     )
                                     if res.returncode != 0:
                                         continue
                                 except Exception:
                                     continue
                             
                             executable = str(target)
                             break
                
                if executable:
                    break
            
            if not executable:
                session.print_output("Error: Python interpreter not found in PATH (excluding temp directories).")
                return

        if not args:
            session.print_output("Usage: python <script_name.py> [args] or python [flags]")
            return

        # Use -u for unbuffered output to ensure real-time updates
        cmd_args = ["-u"]
        if args[0].startswith("-"):
            cmd_args.extend(args)
        else:
            script_path = session.resolve_path(args[0])
            cmd_args.append(script_path)
            cmd_args.extend(args[1:])
        
        # Debug output to show exactly what is being executed
        if not getattr(session, 'store_release', False):
            session.print_output(f"Debug: Executing '{executable}' with args: {cmd_args}\n")
        
        process = QProcess(session)
        process.setProgram(executable)
        process.setArguments(cmd_args)
        process.setWorkingDirectory(session.cwd)
        
        env = QProcessEnvironment.systemEnvironment()
        for k, v in session.env.items():
            env.insert(k, v)
        process.setProcessEnvironment(env)
        
        process.readyReadStandardOutput.connect(lambda: session.print_output(process.readAllStandardOutput().data().decode('utf-8', errors='replace')))
        process.readyReadStandardError.connect(lambda: session.print_output(f"\033[31m{process.readAllStandardError().data().decode('utf-8', errors='replace')}\033[0m"))
        process.finished.connect(lambda: setattr(session, 'running_process', None))
        process.errorOccurred.connect(lambda err: session.print_output(f"Python process error: {process.errorString()} (Exec: {executable})"))
        
        session.running_process = process
        process.start()
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# WC Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of wc command.
#
# Future features may include:
# - Support for max line length (-L)
#============================================================================================

import os

from command_registry import Command

COMMAND_NAME = "wc"
VERSION = "0.1.0"
DESCRIPTION = "Print newline, word, and byte counts for each file"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class WcCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -c, --bytes  print the byte counts\n  -m, --chars  print the character counts\n  -l, --lines  print the newline counts\n  -w, --words  print the word counts\n  --help       display this help and exit\n  --version    output version information and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        files = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                files.append(arg)

        show_bytes = 'c' in flags or '--bytes' in flags
        show_chars = 'm' in flags or '--chars' in flags
        show_lines = 'l' in flags or '--lines' in flags
        show_words = 'w' in flags or '--words' in flags

        # Default behavior if no specific flags
        if not (show_bytes or show_chars or show_lines or show_words):
            show_lines = True
            show_words = True
            show_bytes = True

        total_lines = 0
        total_words = 0
        total_bytes = 0
        total_chars = 0
        results = []

        def process_content(content_bytes, name):
            nonlocal total_lines, total_words, total_bytes, total_chars
            
            lines = content_bytes.count(b'\n')
            words = len(content_bytes.split())
            bytes_count = len(content_bytes)
            chars_count = len(content_bytes.decode('utf-8', errors='replace')) if show_chars else 0

            total_lines += lines
            total_words += words
            total_bytes += bytes_count
            total_chars += chars_count

            output_parts = []
            if show_lines: 
                output_parts.append(f"{lines:>4}")
            if show_words: 
                output_parts.append(f"{words:>4}")
            if show_bytes: 
                output_parts.append(f"{bytes_count:>4}")
            if show_chars: 
                output_parts.append(f"{chars_count:>4}")
            output_parts.append(name)
            results.append(" ".join(output_parts))

        # 3. Main Logic
        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                content = session.stdin if isinstance(session.stdin, bytes) else session.stdin.encode('utf-8')
                process_content(content, "")
            else:
                session.print_output("wc: missing file operand")
                return
        else:
            for filename in files:
                path = session.resolve_path(filename)
                if not os.path.exists(path):
                    session.print_output(f"wc: {filename}: No such file or directory")
                    continue
                if os.path.isdir(path):
                    session.print_output(f"wc: {filename}: Is a directory")
                    continue
                
                try:
                    with open(path, 'rb') as f:
                        process_content(f.read(), filename)
                except Exception as e:
                    session.print_output(f"wc: {filename}: {e}")

        for res in results:
            session.print_output(res)

        if len(files) > 1:
            output_parts = []
            if show_lines: 
                output_parts.append(f"{total_lines:>4}")
            if show_words: 
                output_parts.append(f"{total_words:>4}")
            if show_bytes: 
                output_parts.append(f"{total_bytes:>4}")
            if show_chars: 
                output_parts.append(f"{total_chars:>4}")
            output_parts.append("total")
            session.print_output(" ".join(output_parts))
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# WAI Assistant UI and Integration Module
# Provides a drop-in GUI and manager for the Wheelhouser AI Orchestrator.
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
#
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial release with basic chat interface and WAI integration.

#===========================================================================================

import json
import uuid
import logging
import html
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QTextEdit, QCheckBox, 
                               QLineEdit, QPushButton, QHBoxLayout)
from PySide6.QtCore import Qt, QObject, Signal, QThread
try:
    from wheelhouser_client import WheelhouserClient
except ImportError:
    from src.wheelhouser_client import WheelhouserClient

class WAIWorker(QThread):
    """Background worker to handle WAI requests without freezing the UI."""
    finished = Signal(dict)
    error = Signal(str)

    def __init__(self, client, text, state):
        super().__init__()
        self.client = client
        self.text = text
        self.state = state

    def run(self):
        try:
            response = self.client.resolve(self.text, self.state)
            self.finished.emit(response)
        except Exception as e:
            self.error.emit(str(e))

class WAIDialog(QDialog):
    def __init__(self, client, get_context_cb, execute_pipeline_cb, parent=None):
        super().__init__(parent)
        self.client = client
        self.get_context_cb = get_context_cb
        self.execute_pipeline_cb = execute_pipeline_cb
        self.session_id = str(uuid.uuid4())
        
        self.setWindowTitle("WAI Assistant")
        self.resize(400, 600)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet("border: 1px solid #555; background-color: #252525;")
        layout.addWidget(self.chat_display)
        
        self.chk_include_text = QCheckBox("Include Text Content")
        self.chk_include_text.setToolTip("Send the text content of the current note to WAI for context.")
        self.chk_include_text.setChecked(True)
        self.chk_include_text.setStyleSheet("color: #bbb; margin: 5px 0;")
        layout.addWidget(self.chk_include_text)

        input_layout = QHBoxLayout()
        
        self.btn_clear = QPushButton("🗑️")
        self.btn_clear.setFixedSize(32, 32)
        self.btn_clear.setToolTip("Clear Chat History")
        self.btn_clear.setStyleSheet("background-color: #333; border: 1px solid #555; border-radius: 4px;")
        self.btn_clear.clicked.connect(self.request_clear)
        
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Type your request...")
        self.input_field.setStyleSheet("border: 1px solid #555; padding: 5px; background-color: #252525;")
        self.input_field.returnPressed.connect(self.send_message)
        
        self.send_btn = QPushButton("Send")
        self.send_btn.setCursor(Qt.PointingHandCursor)
        self.send_btn.clicked.connect(self.send_message)
        
        input_layout.addWidget(self.btn_clear)
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)
        
        self.append_message("WAI", "Hello! I can help you draw. Describe what you want.")

    def send_message(self):
        text = self.input_field.text().strip()
        if not text:
            return
            
        self.append_message("You", text)
        self.input_field.clear()
        
        # Lock UI inputs during processing, but keep window responsive
        self.input_field.setEnabled(False)
        self.send_btn.setEnabled(False)
        self.btn_clear.setEnabled(False) 
        
        self.start_request(text)

    def start_request(self, text, retry=False):
        try:
            # Gather context on main thread
            current_state = self.get_context_cb(include_text=self.chk_include_text.isChecked())
            current_state["session_id"] = self.session_id

            state_dump = json.dumps(current_state)
            logging.info(f"Sending WAI request: {text}")
            logging.info(f"Context payload size: {len(state_dump)} chars.")
            
            self.worker = WAIWorker(self.client, text, current_state)
            self.worker.finished.connect(lambda resp: self.handle_response(resp, text, retry))
            self.worker.error.connect(self.handle_error)
            self.worker.start()
        except Exception as e:
            self.handle_error(str(e))

    def handle_response(self, response, text, retry):
        is_token_error = False
        try:
            response_text = response.get("response_text", "Done.")
            
            # Catch token/quota limits returned from the Orchestrator
            is_token_error = any(phrase in response_text.lower() for phrase in ["exceed context window", "token limit", "quota"])
            
            if is_token_error:
                if not retry:
                    self.append_message("System", "Context limit reached. Automatically rotating session and retrying...")
                    
                    # Generate a new session silently, completely bypassing the UI clear function
                    self.session_id = str(uuid.uuid4())
                    
                    # Wait slightly and retry
                    self.start_request(text, retry=True)
                    return
                else:
                    self.append_message("System", "Error: The server rejected the request again. The Wheelhouser Orchestrator is likely out of API quota, or its internal prompt is too large.")
                    self.unlock_ui()
                    return

            self.append_message("WAI", response_text)
            logging.info(f"WAI Response: {response_text}")
            
            if "pipeline" in response and self.execute_pipeline_cb:
                self.execute_pipeline_cb(response["pipeline"])
                    
        except Exception as e:
            self.append_message("System", f"Error processing response: {str(e)}")
        finally:
            if not is_token_error:
                self.unlock_ui()

    def handle_error(self, error_msg):
        self.append_message("System", f"Error: {error_msg}")
        self.unlock_ui()

    def unlock_ui(self):
        self.input_field.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.btn_clear.setEnabled(True)
        self.input_field.setFocus()

    def append_message(self, sender, text):
        color = "#00BFFF" if sender == "WAI" else "#FFFFFF"
        if sender == "System": 
            color = "#FF4444"
        safe_text = html.escape(text)
        self.chat_display.append(f"<div style='margin-bottom: 5px;'><b style='color:{color};'>{sender}:</b> {safe_text}</div>")
        sb = self.chat_display.verticalScrollBar()
        sb.setValue(sb.maximum())

    def request_clear(self):
        """Manually requested clear from user. No arguments, strictly manual."""
        self.session_id = str(uuid.uuid4())
        self.chat_display.clear()
        self.append_message("WAI", "Hello! I can help you draw. Describe what you want.")

class WAIAssistantManager(QObject):
    """Manager class to encapsulate the client and the dialog UI."""
    connectionChanged = Signal(bool)

    def __init__(self, app_name, parent_widget, get_context_cb, execute_pipeline_cb):
        super().__init__(parent_widget)
        self.app_name = app_name
        self.client = WheelhouserClient(app_name)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.start()
        
        self.dialog = WAIDialog(
            client=self.client,
            get_context_cb=get_context_cb,
            execute_pipeline_cb=execute_pipeline_cb,
            parent=parent_widget
        )

    def _on_connect(self):
        self.connectionChanged.emit(True)

    def _on_disconnect(self):
        self.connectionChanged.emit(False)

    def open_dialog(self):
        if not self.client.connected:
            return False
        
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
        return True

    def stop(self):
        self.client.stop()
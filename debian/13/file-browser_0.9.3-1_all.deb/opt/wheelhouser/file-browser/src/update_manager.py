#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Update Manager for Wheelhouser Applications
# Handles checking for updates, notifying users, and directing them to the update source.
# update_manager.py
# Handles cross-platform version checking and update routing.
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
#
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial release with basic update checking functionality.

#===========================================================================================


import sys
import requests
import logging
from PySide6.QtCore import QThread, Signal

class UpdateCheckThread(QThread):
    # Signal signature: latest_version, platform_url, release_notes
    update_available = Signal(str, str, str)
    up_to_date = Signal()
    error = Signal(str)

    def __init__(self, current_version, version_url):
        super().__init__()
        self.current_version = current_version
        self.version_url = version_url

    def run(self):
        try:
            response = requests.get(self.version_url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                # 1. Determine current platform key
                platform_key = None
                if sys.platform == "win32":
                    platform_key = "windows"
                elif sys.platform == "darwin":
                    platform_key = "macos"
                elif sys.platform.startswith("linux"):
                    platform_key = "linux"
                    
                # 2. Get platform-specific data block
                platform_data = data.get(platform_key)
                
                # If the OS isn't in the JSON at all, safely abort
                if not platform_data:
                    logging.info(f"Update check skipped: No configuration found for {sys.platform}.")
                    self.up_to_date.emit()
                    return
                    
                latest_version = platform_data.get("latest_version", "0.0.0")
                target_url = platform_data.get("url", data.get("fallback_url", ""))
                release_notes = platform_data.get("release_notes", "")
                
                # 3. Simple Version Comparison
                def parse_version(v):
                    return tuple(map(int, (v.split("."))))
                
                if parse_version(latest_version) > parse_version(self.current_version):
                    self.update_available.emit(latest_version, target_url, release_notes)
                else:
                    self.up_to_date.emit()
            else:
                self.error.emit(f"Server returned HTTP {response.status_code} at {self.version_url}")
                
        except requests.RequestException as e:
            self.error.emit(f"Network error: {str(e)}")
        except Exception as e:
            self.error.emit(f"Parsing error: {str(e)}")
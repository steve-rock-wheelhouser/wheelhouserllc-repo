class Command:
    """Base class for all terminal commands."""
    def __init__(self, name, description=""):
        self.name = name
        self.description = description

    def execute(self, session, args):
        raise NotImplementedError

class CommandRegistry:
    """Registry to manage available commands."""
    def __init__(self):
        self._commands = {}

    def register(self, command):
        self._commands[command.name] = command

    def get_command(self, name):
        return self._commands.get(name)

    def list_commands(self):
        return self._commands.values()
"""Backward compatibility shim exposing APP_VERSION, TerminalWidget, TerminalMainWindow, and main from src/main.py."""
import sys
import os

_dir = os.path.dirname(os.path.abspath(__file__))
_src = os.path.join(_dir, "src")
for _p in (_dir, _src):
    if _p not in sys.path:
        sys.path.insert(0, _p)

APP_VERSION = "0.32.0"

try:
    from src.main import TerminalWidget, TerminalMainWindow, main
except (ImportError, Exception):
    try:
        from main import TerminalWidget, TerminalMainWindow, main  # type: ignore
    except (ImportError, Exception):
        TerminalWidget = None  # type: ignore
        TerminalMainWindow = None  # type: ignore
        main = None  # type: ignore

__all__ = ["APP_VERSION", "TerminalWidget", "TerminalMainWindow", "main"]

if __name__ == "__main__":
    if callable(main):
        main()

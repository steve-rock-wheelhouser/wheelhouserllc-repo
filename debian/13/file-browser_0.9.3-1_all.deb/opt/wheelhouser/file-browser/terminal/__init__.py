import sys
import os

package_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(package_dir, "src")
for p in (package_dir, src_dir):
    if p not in sys.path:
        sys.path.insert(0, p)

# Expose the main widget for easy import
# Usage: from terminal import TerminalWidget
try:
    from .src.main import TerminalWidget, TerminalMainWindow, main
except ImportError:
    from src.main import TerminalWidget, TerminalMainWindow, main  # type: ignore

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]

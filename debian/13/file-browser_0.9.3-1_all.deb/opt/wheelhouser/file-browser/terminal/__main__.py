import sys
import os
import importlib

if __name__ == "__main__":
    # Ensure we can import the package modules
    # This allows running 'python -m terminal' from the parent directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

    # Use importlib to avoid static analysis errors with dynamic paths
    module = importlib.import_module("terminal.terminal")
    module.main()
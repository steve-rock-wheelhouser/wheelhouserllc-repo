#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Wget Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of wget command.
#
# Future features may include:
# - Support for recursive download (-r)
# - Support for resuming downloads (-c)
#============================================================================================

import os
import requests

from command_registry import Command

COMMAND_NAME = "wget"
VERSION = "0.1.0"
DESCRIPTION = "The non-interactive network downloader"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class WgetCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [URL]...\n{DESCRIPTION}\n\nOptions:\n  -O, --output-document=FILE   write documents to FILE\n  --version                    output version information and exit\n  --help                       display this help and exit")
            return

        # 2. Parse Arguments & Flags
        url = None
        output_file = None
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-O":
                if i + 1 < len(args):
                    output_file = args[i+1]
                    i += 1
                else:
                    session.print_output("wget: option requires an argument -- O")
                    return
            elif arg.startswith("--output-document="):
                output_file = arg.split("=", 1)[1]
            elif arg.startswith("-") and arg != "-":
                pass # Ignore unknown flags
            else:
                url = arg
            i += 1
            
        if not url:
            session.print_output("wget: missing URL")
            return

        if not url.startswith("http"):
            url = "http://" + url

        # 3. Main Logic
        try:
            if not output_file:
                output_file = os.path.basename(url.split("?")[0])
                if not output_file:
                    output_file = "index.html"
            
            output_path = session.resolve_path(output_file)
            
            session.print_output(f"-- {url}")
            session.print_output(f"Saving to: '{output_file}'")
            
            response = requests.get(url, stream=True)
            response.raise_for_status()
            
            block_size = 8192
            downloaded = 0
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=block_size):
                    f.write(chunk)
                    downloaded += len(chunk)
                    
            session.print_output(f"Downloaded: {output_file} ({downloaded} bytes)")
            
        except Exception as e:
            session.print_output(f"wget: error: {e}")

#!/usr/bin/python3
# -*- coding: utf-8 -*-
# TerminalWidget - A simple terminal interface for file management and command execution within the application.
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development, basic file browsing features

from command_registry import Command

VERSION = "0.1.0"

#============================================================================================
# --- Utility Commands ---
#============================================================================================
class VenvCommand(Command):
    def __init__(self):
        super().__init__("venv", "Manage virtual environments")

    def execute(self, session, args):
        session.print_output("venv: Virtual environment management not yet implemented.")

#============================================================================================
# --- Tab Command ---
#============================================================================================
class TabCommand(Command):
    def __init__(self):
        super().__init__("tab", "Manage terminal tabs")

    def execute(self, session, args):
        if not args:
            session.print_output("tab: usage: tab [new]")
            return
        
        if args[0] == "new":
            session.new_tab_requested.emit(session.cwd)
        else:
            session.print_output(f"tab: unknown subcommand '{args[0]}'")

#============================================================================================
# --- Theme Command ---
#============================================================================================
class ThemeCommand(Command):
    def __init__(self):
        super().__init__("theme", "Change terminal theme")

    def execute(self, session, args):
        session.print_output("theme: Theme management not yet implemented.")
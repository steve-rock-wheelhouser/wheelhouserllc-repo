#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Man Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of man command with internal troff/groff viewer.
# 0.2.0 - Standardize Linux/Unix man page structure (POSIX / man-pages(7) format) for built-in and system commands; prioritize system man pages (Section 1) with groff/cat overstrike and ANSI cleaning, and provide comprehensive fallback synthesizer with SYNOPSIS, OPTIONS, EXAMPLES, EXIT STATUS, and SEE ALSO.

import os
import sys
import re
import subprocess
from typing import List, Optional, Any

from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QPushButton,
    QLineEdit,
    QLabel,
    QToolTip,
    QApplication,
)
from PySide6.QtGui import QFont, QKeySequence, QShortcut, QCursor
from PySide6.QtCore import Qt

from command_registry import Command

COMMAND_NAME = "man"
VERSION = "0.2.0"
DESCRIPTION = "Format and display manual pages"


#============================================================================================
# --- Man Viewer Dialog ---
#============================================================================================
class ManDialog(QDialog):
    """Interactive reader dialog for manual pages."""

    def __init__(self, topic: str, content: str, parent: Optional[Any] = None):
        super().__init__(parent)
        self.topic = topic
        self.content = content
        self.setWindowTitle(f"Manual Page: {topic}")
        self.resize(860, 650)
        self.setStyleSheet("""
            QDialog {
                background-color: #0b1329;
                color: #f1f5f9;
            }
        """)
        self._setup_ui()
        self._setup_shortcuts()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # Header / Search Bar
        search_layout = QHBoxLayout()
        search_lbl = QLabel("🔍 Find:")
        search_lbl.setStyleSheet("color: #94a3b8; font-weight: 600; font-size: 9.5pt;")
        search_layout.addWidget(search_lbl)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search in manual page (press Enter)...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: #0f172a;
                color: #f1f5f9;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 9.5pt;
            }
            QLineEdit:focus {
                border-color: #38bdf8;
            }
        """)
        self.search_input.returnPressed.connect(self._find_next)
        search_layout.addWidget(self.search_input)

        find_btn = QPushButton("Next")
        find_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        find_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 9pt;
            }
            QPushButton:hover {
                background-color: #334155;
            }
        """)
        find_btn.clicked.connect(self._find_next)
        search_layout.addWidget(find_btn)

        layout.addLayout(search_layout)

        # Text Viewer
        self.text_edit = QTextEdit()
        self.text_edit.setPlainText(self.content)
        self.text_edit.setReadOnly(True)
        font = QFont("JetBrains Mono", 10)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.text_edit.setFont(font)
        self.text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #020617;
                color: #e2e8f0;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 12px;
                line-height: 1.4;
            }
        """)
        layout.addWidget(self.text_edit, stretch=1)

        # Footer Actions
        footer_layout = QHBoxLayout()

        copy_btn = QPushButton("📋 Copy All")
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #38bdf8;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 16px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                color: #7dd3fc;
            }
        """)
        copy_btn.clicked.connect(self._copy_all)
        footer_layout.addWidget(copy_btn)

        footer_layout.addStretch()

        help_hint = QLabel("Press 'q' or 'Esc' to exit")
        help_hint.setStyleSheet("color: #64748b; font-size: 9pt; font-style: italic;")
        footer_layout.addWidget(help_hint)

        close_btn = QPushButton("Quit (q)")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setMinimumWidth(90)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 18px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
            }
        """)
        close_btn.clicked.connect(self.accept)
        footer_layout.addWidget(close_btn)

        layout.addLayout(footer_layout)

    def _setup_shortcuts(self):
        # Allow pressing 'q' to close, conforming to less/man convention
        q_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Q), self)
        q_shortcut.activated.connect(self.accept)

    def _find_next(self):
        term = self.search_input.text()
        if not term:
            return
        found = self.text_edit.find(term)
        if not found:
            # Wrap around to beginning
            cursor = self.text_edit.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            self.text_edit.setTextCursor(cursor)
            self.text_edit.find(term)

    def _copy_all(self):
        clipboard = QApplication.clipboard()
        if clipboard:
            clipboard.setText(self.text_edit.toPlainText())
            QToolTip.showText(QCursor.pos(), "Copied manual page to clipboard!", self, msecShowTime=1500)


#============================================================================================
# --- Fallback Troff Formatter ---
#============================================================================================
def format_troff_plain(raw_content: str) -> str:
    """Format troff man page lines into clean readable plain text without requiring groff."""
    lines: List[str] = []
    in_sh = False

    for line in raw_content.splitlines():
        line_s = line.strip()
        if line_s.startswith('.\\"'):
            continue
        if line_s.startswith(".TH"):
            parts = line_s.split()
            title = parts[1] if len(parts) > 1 else "MANUAL"
            sec = parts[2] if len(parts) > 2 else "1"
            header_str = f"{title}({sec})"
            lines.append(f"{header_str:<35}User Commands{header_str:>35}\n")
            continue
        if line_s.startswith(".SH"):
            sec_name = line_s[3:].strip().strip('"')
            lines.append(f"\n{sec_name.upper()}")
            in_sh = True
            continue
        if line_s.startswith(".SS"):
            sub_name = line_s[3:].strip().strip('"')
            lines.append(f"\n  {sub_name}")
            continue
        if line_s.startswith(".TP"):
            continue
        if line_s.startswith(".PP") or line_s.startswith(".br"):
            lines.append("")
            continue
        if line_s.startswith(".RS") or line_s.startswith(".RE"):
            continue

        clean_l = line
        # Clean font macros
        clean_l = re.sub(r"^\.B(?:R|I)?\s+", "", clean_l)
        clean_l = re.sub(r"^\.I(?:R|B)?\s+", "", clean_l)
        clean_l = re.sub(r"\\f[BIRP]", "", clean_l)
        clean_l = re.sub(r"\\f\(..", "", clean_l)
        clean_l = re.sub(r"\\-", "-", clean_l)
        clean_l = re.sub(r"\\\(co", "©", clean_l)
        clean_l = clean_l.replace(r'\"', '"')

        if in_sh:
            lines.append(f"       {clean_l}")
        else:
            lines.append(clean_l)

    return "\n".join(lines)


#============================================================================================
# --- Command Implementation ---
#============================================================================================
class ManCommand(Command):
    """Built-in man command providing documentation lookup inside Terminal."""

    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session: Any, args: List[str]) -> None:
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(
                f"Usage: {COMMAND_NAME} [OPTION...] [COMMAND]\n"
                f"{DESCRIPTION}\n\n"
                f"Options:\n"
                f"  --no-pager   output manual page directly to the terminal\n"
                f"  --version    output version information and exit\n"
                f"  --help       display this help and exit\n"
            )
            return

        # 2. Extract Options and Topic
        no_pager = False
        filtered_args = []
        for arg in args:
            if arg == "--no-pager":
                no_pager = True
            elif arg.startswith("-") and arg != "-":
                continue
            else:
                filtered_args.append(arg)

        if not filtered_args:
            session.print_output("What manual page do you want?\nFor example, try 'man terminal'.")
            return

        topic = filtered_args[0].strip()

        # 3. Resolve Man Page Content
        content, found_path = self._resolve_man_page(session, topic)

        if not content:
            session.print_output(f"No manual entry for {topic}")
            return

        # 4. Display or Print Output
        is_headless = (
            os.environ.get("QT_QPA_PLATFORM") == "offscreen"
            or no_pager
            or getattr(session, "is_headless", False)
            or not hasattr(session, "output_area")
        )

        if is_headless:
            session.print_output(content + "\n")
            return

        dialog = ManDialog(topic, content, parent=session)
        dialog.exec()

    def _resolve_man_page(self, session: Any, topic: str) -> tuple[Optional[str], Optional[str]]:
        """Finds and formats manual text for the requested topic."""
        # 1. Search for explicit project/custom .1 manpage file (e.g. terminal.1)
        file_path = self._find_man_file(session, topic)
        if file_path and os.path.isfile(file_path):
            content = self._render_man_file(file_path)
            if content:
                return content, file_path

        # 2. Query system native man command (standard Section 1 or general manpages)
        system_man = self._query_system_man(topic)
        if system_man:
            return system_man, None

        # 3. Search built-in command registry and synthesize POSIX/Linux standard manpage
        registry = getattr(session, "registry", None)
        if registry:
            cmd = registry.get_command(topic)
            if cmd:
                return self._synthesize_builtin_man(cmd, topic), None

        return None, None

    def _find_man_file(self, session: Any, topic: str) -> Optional[str]:
        """Locates .1 files in project or package search paths."""
        lowered = topic.lower()
        candidates = [
            f"{lowered}.1",
            f"terminal.1" if lowered in ("terminal", "wheelhouser-terminal") else None,
        ]

        search_dirs: List[str] = []

        # Current working directory / repo root paths
        base_dir = os.path.abspath(os.path.dirname(__file__))
        repo_root = os.path.abspath(os.path.join(base_dir, ".."))
        parent_root = os.path.abspath(os.path.join(repo_root, ".."))

        search_dirs.extend([
            os.path.join(repo_root, "man"),
            os.path.join(repo_root, "src", "man"),
            os.path.join(parent_root, lowered, "man"),
            os.path.expanduser("~/.local/share/man/man1"),
        ])

        # If resource_path is available from main module
        try:
            from main import resource_path  # type: ignore
            res_path = resource_path(f"man/{lowered}.1")
            if res_path and os.path.exists(res_path):
                return res_path
            if lowered in ("terminal", "wheelhouser-terminal"):
                res_term = resource_path("man/terminal.1")
                if res_term and os.path.exists(res_term):
                    return res_term
        except Exception:
            pass

        for candidate in candidates:
            if not candidate:
                continue
            for d in search_dirs:
                target = os.path.join(d, candidate)
                if os.path.isfile(target):
                    return target

        return None

    def _render_man_file(self, file_path: str) -> Optional[str]:
        """Renders a troff manpage file using groff or pure Python fallback."""
        try:
            res = subprocess.run(
                ["groff", "-man", "-Tutf8", file_path],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if res.returncode == 0 and res.stdout.strip():
                # Clean overstrikes and ANSI escapes if groff emitted any
                cleaned = re.sub(r'.\x08', '', res.stdout)
                return re.sub(r"\x1b\[[0-9;]*m", "", cleaned)
        except Exception:
            pass

        # Fallback to pure-Python parser
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read()
            return format_troff_plain(raw)
        except Exception:
            return None

    def _synthesize_builtin_man(self, cmd: Any, topic: str) -> str:
        """Constructs a clean, standard Linux/Unix (man-pages(7)) compliant manual page for commands."""
        name_upper = topic.upper()
        header = f"{name_upper}(1)"

        synopsis = f"{topic} [OPTION]... [ARG]..."
        description_text = getattr(cmd, "description", "Internal terminal command")
        parsed_options: List[tuple[str, str]] = []

        try:
            class _HelpCaptureSession:
                def __init__(self):
                    self.output: List[str] = []
                def print_output(self, text: str) -> None:
                    self.output.append(text)

            cap = _HelpCaptureSession()
            cmd.execute(cap, ["--help"])
            raw_help = "\n".join(cap.output)

            in_options = False
            for line in raw_help.splitlines():
                sline = line.strip()
                if sline.startswith("Usage:"):
                    synopsis = sline[6:].strip()
                elif sline.startswith("Options:"):
                    in_options = True
                elif in_options:
                    if sline:
                        parts = re.split(r"\s{2,}", sline, maxsplit=1)
                        if len(parts) == 2:
                            parsed_options.append((parts[0].strip(), parts[1].strip()))
                        elif parts:
                            parsed_options.append((parts[0].strip(), ""))
                elif sline and not sline.startswith("Usage:") and not sline.startswith("Options:"):
                    if not description_text or description_text == "Internal terminal command":
                        description_text = sline
        except Exception:
            pass

        # Curated standard examples for common built-in commands
        examples_map = {
            "kill": [
                ("kill 1234", "Terminate process with PID 1234 using default termination signal (SIGTERM / 15)."),
                ("kill -9 1234", "Forcefully terminate process with PID 1234 immediately without cleanup (SIGKILL / 9)."),
                ("kill -f 1234", "Forcefully terminate process with PID 1234 (cross-platform force flag)."),
                ("kill -f firefox", "Forcefully terminate all processes matching the name 'firefox'."),
            ],
            "ps": [
                ("ps", "Display processes running in the current user session."),
                ("ps aux", "List all running system processes with detailed CPU and memory metrics."),
            ],
            "plugins": [
                ("plugins", "List all currently loaded command, theme, and font plugins."),
            ],
            "alias": [
                ("alias", "Display all currently active command aliases."),
                ("alias ll='ls -la'", "Define a new shortcut alias 'll' that maps to 'ls -la'."),
            ],
            "unalias": [
                ("unalias ll", "Remove the previously defined alias 'll'."),
            ],
            "theme": [
                ("theme", "Display the currently active terminal color theme."),
                ("theme list", "List all available themes including plugin themes."),
                ("theme Dracula", "Switch active theme to Dracula."),
            ],
            "ls": [
                ("ls", "List files and directories in the current working directory."),
                ("ls -la", "List all entries including hidden files with detailed metadata."),
                ("ls -lh", "List entries in long format with human-readable file sizes."),
            ],
            "cat": [
                ("cat file.txt", "Display the entire contents of file.txt to standard output."),
                ("cat file1.txt file2.txt", "Concatenate and display multiple files sequentially."),
            ],
            "grep": [
                ("grep 'error' /var/log/syslog", "Search for lines matching 'error' in syslog."),
                ("grep -i 'warning' app.log", "Case-insensitive search for 'warning' in app.log."),
            ],
            "nano": [
                ("nano config.json", "Open config.json in the built-in graphical text editor modal."),
            ],
            "man": [
                ("man terminal", "View the full internal manual page for Wheelhouser Terminal."),
                ("man kill", "View the manual page and command usage for process termination."),
            ],
        }

        # Curated cross references
        see_also_map = {
            "kill": "ps(1), htop(1), terminal(1), signal(7)",
            "ps": "htop(1), kill(1), terminal(1)",
            "htop": "ps(1), kill(1), top(1)",
            "plugins": "terminal(1), theme(1)",
            "alias": "unalias(1), terminal(1)",
            "unalias": "alias(1), terminal(1)",
            "theme": "plugins(1), terminal(1)",
            "ls": "dir(1), vdir(1), terminal(1)",
            "cat": "less(1), head(1), tail(1)",
            "grep": "sed(1), awk(1), find(1)",
            "nano": "less(1), terminal(1)",
        }

        # Build lines conforming strictly to POSIX / man-pages(7) structure
        lines = [
            f"{header:<35}Wheelhouser Built-in Commands{header:>35}\n",
            "NAME",
            f"       {topic} - {description_text}",
            "\nSYNOPSIS",
            f"       {synopsis}",
            "\nDESCRIPTION",
            f"       {topic} is an internal command provided by Wheelhouser Terminal.",
            "       It provides unified, cross-platform functionality with consistent",
            "       behavior across Linux, Windows, and macOS operating environments.",
        ]

        if parsed_options:
            lines.append("\nOPTIONS")
            for opt, opt_desc in parsed_options:
                lines.append(f"       {opt}")
                if opt_desc:
                    lines.append(f"              {opt_desc}\n")
                else:
                    lines.append("")
        else:
            lines.extend([
                "\nOPTIONS",
                "       --help",
                "              Display usage help information and exit.\n",
                "       --version",
                "              Display version information and exit.\n",
            ])

        curated_ex = examples_map.get(topic.lower())
        lines.append("EXAMPLES")
        if curated_ex:
            for ex_cmd, ex_desc in curated_ex:
                lines.append(f"       {ex_cmd}")
                lines.append(f"              {ex_desc}\n")
        else:
            lines.append(f"       {topic}")
            lines.append(f"              Execute {topic} with default parameters.\n")

        lines.extend([
            "EXIT STATUS",
            "       0      Successful execution.",
            "",
            "       >0     An error occurred, operand was missing, or invalid arguments",
            "              were supplied.",
            "\nSEE ALSO",
            f"       {see_also_map.get(topic.lower(), 'terminal(1), help(1), man(1)')}",
            "\nAUTHOR",
            "       Wheelhouser Terminal Development Team (Wheelhouser LLC).",
        ])

        return "\n".join(lines)

    def _query_system_man(self, topic: str) -> Optional[str]:
        """Tries to query the system's native man implementation."""
        # Query section 1 (user commands) first, then general query
        for cmd in [["man", "-P", "cat", "1", topic], ["man", "-P", "cat", topic]]:
            try:
                res = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=3,
                )
                if res.returncode == 0 and res.stdout.strip():
                    cleaned = re.sub(r'.\x08', '', res.stdout)
                    cleaned = re.sub(r"\x1b\[[0-9;]*m", "", cleaned)
                    return cleaned
            except Exception:
                pass
        return None


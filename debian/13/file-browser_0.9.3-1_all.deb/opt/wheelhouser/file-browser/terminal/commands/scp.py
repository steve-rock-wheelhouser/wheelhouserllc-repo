#!/usr/bin/python3
# -*- coding: utf-8 -*-
# SCP Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of scp command.
#
# Future features may include:
# - Support for -i (identity file) parsing in help
#============================================================================================

import shutil

from command_registry import Command

COMMAND_NAME = "scp"
VERSION = "0.1.0"
DESCRIPTION = "Secure copy (remote file copy program)"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class ScpCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [[user@]host1:]file1 ... [[user@]host2:]file2\n{DESCRIPTION}\n\nOptions:\n  -P port       Port to connect to on the remote host\n  -r            Recursively copy entire directories\n  -i identity   Selects a file from which the identity (private key) is read\n  --version     output version information and exit\n  --help        display this help and exit\n\nNote: Interactive password prompts are not supported. Use SSH keys for authentication.")
            return

        # 2. Main Logic
        if not shutil.which("scp"):
            session.print_output("scp: command not found. Please ensure OpenSSH client is installed and in your PATH.")
            return

        if not args:
            session.print_output("scp: usage: scp [options] [[user@]host1:]file1 ... [[user@]host2:]file2")
            return

        # Pass through to system command
        # Note: We pass session.stdin, though scp rarely uses stdin for file content (it uses it for password if not batch mode)
        full_cmd = ["scp"] + args
        
        # run_system_command handles execution and output capture
        session.run_system_command(full_cmd, session.stdin)
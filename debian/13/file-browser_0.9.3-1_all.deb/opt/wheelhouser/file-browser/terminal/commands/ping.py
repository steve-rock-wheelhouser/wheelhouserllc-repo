#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Ping Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of ping command.
#
# Future features may include:
# - Support for interval (-i)
# - Support for packet size (-s)
#============================================================================================

import platform
import subprocess

from command_registry import Command

COMMAND_NAME = "ping"
VERSION = "0.1.0"
DESCRIPTION = "Send ICMP ECHO_REQUEST to network hosts"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class PingCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... destination\n{DESCRIPTION}\n\nOptions:\n  -c, --count=NUMBER   stop after sending NUMBER packets\n  --version            output version information and exit\n  --help               display this help and exit")
            return

        # 2. Parse Arguments & Flags
        count = 4
        destination = None
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-c" or arg == "--count":
                if i + 1 < len(args):
                    try:
                        count = int(args[i+1])
                        i += 1
                    except ValueError:
                        session.print_output(f"ping: invalid count: '{args[i+1]}'")
                        return
                else:
                    session.print_output("ping: option requires an argument")
                    return
            elif arg.startswith("--count="):
                try:
                    count = int(arg.split("=", 1)[1])
                except ValueError:
                    session.print_output(f"ping: invalid count in '{arg}'")
                    return
            elif arg.startswith("-") and arg != "-":
                pass # Ignore unknown flags
            else:
                destination = arg
            i += 1

        # 3. Main Logic
        if not destination:
            session.print_output("ping: missing host operand")
            return

        try:
            system_name = platform.system().lower()
            cmd_args = ["ping"]
            
            if system_name == "windows":
                cmd_args.extend(["-n", str(count)])
            else:
                cmd_args.extend(["-c", str(count)])
                
            cmd_args.append(destination)
            
            process = subprocess.run(
                cmd_args,
                capture_output=True,
                text=True
            )
            
            if process.stdout:
                session.print_output(process.stdout.rstrip())
            if process.stderr:
                session.print_output(process.stderr.rstrip())
                
        except Exception as e:
            session.print_output(f"ping: error: {e}")
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Rsync Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of rsync command.
#
# Future features may include:
# - Support for --exclude parsing in help
#============================================================================================

import shutil

from command_registry import Command

COMMAND_NAME = "rsync"
VERSION = "0.1.0"
DESCRIPTION = "Fast, versatile, remote (and local) file-copying tool"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class RsyncCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... SRC [SRC]... DEST\n{DESCRIPTION}\n\nOptions:\n  -a, --archive       archive mode; equals -rlptgoD (no -H,-A,-X)\n  -v, --verbose       increase verbosity\n  -z, --compress      compress file data during the transfer\n  -P                  same as --partial --progress\n  --version           output version information and exit\n  --help              display this help and exit")
            return

        # 2. Main Logic
        if not shutil.which("rsync"):
            session.print_output("rsync: command not found. Please ensure rsync is installed and in your PATH.")
            return

        if not args:
            session.print_output("rsync: usage: rsync [options] source destination")
            return

        # Pass through to system command
        # Note: We pass session.stdin to support piping if needed, though rsync usually doesn't use it for data
        full_cmd = ["rsync"] + args
        
        # run_system_command handles execution and output capture
        session.run_system_command(full_cmd, session.stdin)
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Zip/Unzip Commands for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of zip/unzip commands.
#
# Future features may include:
# - Support for password protection
# - Support for update (-u) and freshen (-f) modes
#============================================================================================

import os
import zipfile

from command_registry import Command

VERSION = "0.1.0"

class ZipCommand(Command):
    def __init__(self):
        super().__init__("zip", f"Package and compress (archive) files (v{VERSION})")

    def execute(self, session, args):
        if "--version" in args:
            session.print_output(f"zip (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output("Usage: zip [OPTION]... [zipfile] [file]...\nPackage and compress (archive) files.\n\nOptions:\n  -r, --recurse-paths  travel the directory structure recursively\n  -q, --quiet          quiet operation\n  --version            output version information and exit\n  --help               display this help and exit")
            return

        flags = set()
        clean_args = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)

        recurse = 'r' in flags or '--recurse-paths' in flags
        quiet = 'q' in flags or '--quiet' in flags

        if len(clean_args) < 2:
            session.print_output("zip: error: missing zipfile or input files")
            return

        zip_name = clean_args[0]
        if not zip_name.lower().endswith('.zip'):
            zip_name += ".zip"
            
        zip_path = session.resolve_path(zip_name)
        input_files = clean_args[1:]
        
        try:
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for input_name in input_files:
                    full_path = session.resolve_path(input_name)
                    
                    if not os.path.exists(full_path):
                        session.print_output(f"zip: warning: {input_name}: No such file or directory")
                        continue
                        
                    if os.path.isdir(full_path):
                        if recurse:
                            if not quiet:
                                session.print_output(f"  adding: {input_name}/ (stored 0%)")
                            zf.write(full_path, arcname=os.path.basename(full_path))
                            
                            for root, dirs, files in os.walk(full_path):
                                for file in files:
                                    file_path = os.path.join(root, file)
                                    arcname = os.path.relpath(file_path, os.path.dirname(full_path))
                                    if not quiet:
                                        session.print_output(f"  adding: {arcname}")
                                    zf.write(file_path, arcname=arcname)
                        else:
                            if not quiet:
                                session.print_output(f"  adding: {input_name}/ (stored 0%)")
                            zf.write(full_path, arcname=os.path.basename(full_path))
                    else:
                        if not quiet:
                            session.print_output(f"  adding: {input_name}")
                        zf.write(full_path, arcname=os.path.basename(full_path))
                        
        except Exception as e:
            session.print_output(f"zip: error: {e}")

class UnzipCommand(Command):
    def __init__(self):
        super().__init__("unzip", f"List, test and extract compressed files in a ZIP archive (v{VERSION})")

    def execute(self, session, args):
        if "--version" in args:
            session.print_output(f"unzip (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output("Usage: unzip [OPTION]... [zipfile]\nList, test and extract compressed files in a ZIP archive.\n\nOptions:\n  -l, --list           list archive files (short format)\n  -d dir               extract files into exdir\n  --version            output version information and exit\n  --help               display this help and exit")
            return

        flags = set()
        clean_args = []
        dest_dir = None
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-d":
                if i + 1 < len(args):
                    dest_dir = args[i+1]
                    i += 1
                else:
                    session.print_output("unzip: option requires an argument -- d")
                    return
            elif arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)
            i += 1

        list_mode = 'l' in flags or '--list' in flags

        if not clean_args:
            session.print_output("unzip: error: missing zipfile")
            return

        zip_name = clean_args[0]
        zip_path = session.resolve_path(zip_name)
        
        if not os.path.exists(zip_path):
             if not zip_path.lower().endswith('.zip'):
                 zip_path += ".zip"
             
             if not os.path.exists(zip_path):
                session.print_output(f"unzip: cannot find or open {zip_name}")
                return

        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                if list_mode:
                    session.print_output("Archive:  " + zip_name)
                    session.print_output("  Length      Date    Time    Name")
                    session.print_output("---------  ---------- -----   ----")
                    total_len = 0
                    file_count = 0
                    for info in zf.infolist():
                        dt = "%d-%02d-%02d %02d:%02d" % info.date_time[:5]
                        session.print_output(f"{info.file_size:9d}  {dt}   {info.filename}")
                        total_len += info.file_size
                        file_count += 1
                    session.print_output("---------                     -------")
                    session.print_output(f"{total_len:9d}                     {file_count} files")
                else:
                    extract_path = session.cwd
                    if dest_dir:
                        extract_path = session.resolve_path(dest_dir)
                        if not os.path.exists(extract_path):
                            os.makedirs(extract_path)
                    
                    session.print_output(f"Archive:  {zip_name}")
                    for info in zf.infolist():
                        session.print_output(f"  inflating: {info.filename}")
                        zf.extract(info, path=extract_path)
                        
        except zipfile.BadZipFile:
            session.print_output(f"unzip: {zip_name}: not a valid zip file")
        except Exception as e:
            session.print_output(f"unzip: error: {e}")
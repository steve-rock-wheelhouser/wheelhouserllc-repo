#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Du Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of du command.
#
# Future features may include:
# - Support for max-depth
# - Support for exclude patterns
#============================================================================================

import os

from command_registry import Command

COMMAND_NAME = "du"
VERSION = "0.1.0"
DESCRIPTION = "Estimate file space usage"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class DuCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -a, --all             write counts for all files, not just directories\n  -h, --human-readable  print sizes in human readable format (e.g., 1K 234M 2G)\n  -s, --summarize       display only a total for each argument\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        paths = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                paths.append(arg)

        human_readable = 'h' in flags or '--human-readable' in flags
        summarize = 's' in flags or '--summarize' in flags
        all_files = 'a' in flags or '--all' in flags

        if not paths:
            paths = ["."]

        def format_size(size_bytes):
            if not human_readable:
                # Default to 1K blocks, ceiling
                return str((size_bytes + 1023) // 1024)
            
            for unit in ['K', 'M', 'G', 'T', 'P']:
                if size_bytes < 1024:
                    return f"{size_bytes:.1f}{unit}"
                size_bytes /= 1024
            return f"{size_bytes:.1f}E"

        # 3. Main Logic
        for path_str in paths:
            target = session.resolve_path(path_str)
            if not os.path.exists(target):
                session.print_output(f"du: cannot access '{path_str}': No such file or directory")
                continue

            if summarize:
                total_size = 0
                if os.path.isfile(target):
                    total_size = os.path.getsize(target)
                else:
                    for root, dirs, files in os.walk(target):
                        for f in files:
                            fp = os.path.join(root, f)
                            if not os.path.islink(fp):
                                try:
                                    total_size += os.path.getsize(fp)
                                except OSError:
                                    pass
                session.print_output(f"{format_size(total_size)}\t{path_str}")
            else:
                if os.path.isfile(target):
                    session.print_output(f"{format_size(os.path.getsize(target))}\t{path_str}")
                else:
                    # Recursive calculation
                    dir_sizes = {}
                    
                    # Walk bottom-up to aggregate sizes
                    for root, dirs, files in os.walk(target, topdown=False):
                        current_size = 0
                        # Files
                        for f in files:
                            fp = os.path.join(root, f)
                            try:
                                if not os.path.islink(fp):
                                    fsize = os.path.getsize(fp)
                                    current_size += fsize
                                    if all_files:
                                        rel_path = os.path.relpath(fp, session.cwd)
                                        session.print_output(f"{format_size(fsize)}\t{rel_path}")
                            except OSError:
                                pass
                        
                        # Subdirectories
                        for d in dirs:
                            dp = os.path.join(root, d)
                            if dp in dir_sizes:
                                current_size += dir_sizes[dp]
                        
                        dir_sizes[root] = current_size
                        
                        rel_path = os.path.relpath(root, session.cwd)
                        if path_str == "." and rel_path == ".":
                            display_path = "."
                        elif rel_path == ".":
                            display_path = path_str
                        else:
                            display_path = rel_path
                            
                        session.print_output(f"{format_size(current_size)}\t{display_path}")
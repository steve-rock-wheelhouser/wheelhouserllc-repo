#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Chown Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of chown command.
# 0.1.1 - Added support for --reference=RFILE
#
# Future features may include:
# - 
#============================================================================================

import os

# pwd and grp are Unix-only modules
try:
    import pwd
    import grp
except ImportError:
    pass

from command_registry import Command

COMMAND_NAME = "chown"
VERSION = "0.1.1"
DESCRIPTION = "Change file owner and group"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class ChownCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [OWNER][:[GROUP]] FILE...\n  or:  {COMMAND_NAME} [OPTION]... --reference=RFILE FILE...\n{DESCRIPTION}\n\nOptions:\n  -R, --recursive       operate on files and directories recursively\n  --reference=RFILE     use RFILE's owner and group rather than specifying values\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Platform Check
        if os.name == 'nt':
            session.print_output("chown: not supported on Windows")
            return

        # 3. Parse Arguments & Flags
        flags = set()
        clean_args = []
        reference_file = None
        
        for arg in args:
            if arg.startswith("--reference="):
                reference_file = arg.split("=", 1)[1]
            elif arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)

        recursive = 'R' in flags or '--recursive' in flags

        uid = -1
        gid = -1

        if reference_file:
            if not clean_args:
                session.print_output("chown: missing operand")
                return
            files = clean_args
            
            try:
                ref_path = session.resolve_path(reference_file)
                st = os.stat(ref_path)
                uid = st.st_uid
                gid = st.st_gid
            except Exception as e:
                session.print_output(f"chown: failed to get attributes of '{reference_file}': {e}")
                return
        else:
            if len(clean_args) < 2:
                session.print_output("chown: missing operand")
                return

            owner_group = clean_args[0]
            files = clean_args[1:]
            
            user_str = None
            group_str = None

            if ":" in owner_group:
                parts = owner_group.split(":")
                user_str = parts[0]
                if len(parts) > 1 and parts[1]:
                    group_str = parts[1]
            else:
                user_str = owner_group

            try:
                if user_str:
                    uid = int(user_str) if user_str.isdigit() else pwd.getpwnam(user_str).pw_uid
                
                if group_str:
                    gid = int(group_str) if group_str.isdigit() else grp.getgrnam(group_str).gr_gid
            except KeyError as e:
                session.print_output(f"chown: invalid user/group: {e}")
                return
            except Exception as e:
                session.print_output(f"chown: error: {e}")
                return

        def do_chown(path):
            try:
                os.chown(path, uid, gid)
            except Exception as e:
                session.print_output(f"chown: changing ownership of '{path}': {e}")

        for filename in files:
            path = session.resolve_path(filename)
            do_chown(path)
            
            if recursive and os.path.isdir(path):
                for root, dirs, files_in_dir in os.walk(path):
                    for name in dirs + files_in_dir:
                        do_chown(os.path.join(root, name))
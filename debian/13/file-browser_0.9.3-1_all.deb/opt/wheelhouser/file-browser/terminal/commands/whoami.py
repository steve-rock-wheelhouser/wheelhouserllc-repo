#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Whoami Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of whoami command.
# 0.1.1 - Append newline delimiter to output and error messages
#
# Future features may include:
# - 
#============================================================================================

import getpass

from command_registry import Command

COMMAND_NAME = "whoami"
VERSION = "0.1.1"
DESCRIPTION = "Print effective userid"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class WhoamiCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}\n")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]...\n{DESCRIPTION}\n\nOptions:\n  --version     output version information and exit\n  --help        display this help and exit\n")
            return

        # 2. Main Logic
        if len(args) > 0 and not args[0].startswith("-"):
             session.print_output(f"whoami: extra operand '{args[0]}'\n")
             return

        try:
            user = getpass.getuser()
            session.print_output(f"{user}\n")
        except Exception as e:
            session.print_output(f"whoami: error: {e}\n")
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Date Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of date command.
# 0.1.1 - Append newline delimiter to output and error messages
#
# Future features may include:
# - Support for setting date/time (-s)
# - Support for parsing date strings (-d)
#============================================================================================

import time
import datetime

from command_registry import Command

COMMAND_NAME = "date"
VERSION = "0.1.1"
DESCRIPTION = "Print or set the system date and time"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class DateCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}\n")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [+FORMAT]\n{DESCRIPTION}\n\nOptions:\n  -u, --utc, --universal  print or set Coordinated Universal Time (UTC)\n  --version               output version information and exit\n  --help                  display this help and exit\n")
            return

        # 2. Parse Arguments & Flags
        use_utc = '-u' in args or '--utc' in args or '--universal' in args
        format_str = None
        
        for arg in args:
            if arg.startswith('+'):
                format_str = arg[1:]
                break

        # 3. Main Logic
        if use_utc:
            now = datetime.datetime.utcnow()
            tz_name = "UTC"
        else:
            now = datetime.datetime.now()
            # Determine local timezone name
            is_dst = time.localtime().tm_isdst > 0
            if time.daylight and is_dst:
                tz_name = time.tzname[1]
            else:
                tz_name = time.tzname[0]

        if format_str:
            try:
                # Python's strftime doesn't support all GNU date % sequences, but supports standard C ones
                session.print_output(now.strftime(format_str) + "\n")
            except Exception as e:
                session.print_output(f"date: invalid format: {e}\n")
        else:
            # Default format: Thu Mar  6 14:30:00 EST 2025
            # %a %b %d %H:%M:%S %Z %Y
            # Note: %Z in python strftime depends on locale setup, so we append manually if needed
            base_str = now.strftime("%a %b %d %H:%M:%S")
            year_str = now.strftime("%Y")
            # Insert spaces for single digit days if needed to match `date` exactly, but strftime usually handles padding
            # Python's %e is platform specific (linux only usually), so %d is safer
            session.print_output(f"{base_str} {tz_name} {year_str}\n")
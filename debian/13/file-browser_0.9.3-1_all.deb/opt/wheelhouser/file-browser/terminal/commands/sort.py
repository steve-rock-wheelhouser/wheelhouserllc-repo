#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Sort Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of sort command.
# 0.1.1 - Append newline delimiter to output lines and error messages
#
# Future features may include:
# - Support for sorting by keys/fields (-k)
# - Support for random sort (-R)
#============================================================================================

import os
import re

from command_registry import Command

COMMAND_NAME = "sort"
VERSION = "0.1.1"
DESCRIPTION = "Sort lines of text files"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class SortCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -r, --reverse         reverse the result of comparisons\n  -n, --numeric-sort    compare according to string numerical value\n  -f, --ignore-case     fold lower case to upper case characters\n  -u, --unique          output only the first of an equal run\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        files = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                files.append(arg)

        reverse = 'r' in flags or '--reverse' in flags
        numeric = 'n' in flags or '--numeric-sort' in flags
        ignore_case = 'f' in flags or '--ignore-case' in flags
        unique = 'u' in flags or '--unique' in flags

        # 3. Main Logic
        lines = []
        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                lines = session.stdin.splitlines()
            else:
                # Wait for stdin in a real shell, here we just return
                return
        else:
            for filename in files:
                path = session.resolve_path(filename)
                if not os.path.exists(path):
                    session.print_output(f"sort: cannot read: {filename}: No such file or directory")
                    continue
                if os.path.isdir(path):
                    session.print_output(f"sort: read failed: {filename}: Is a directory\n")
                    continue
                try:
                    with open(path, 'r', encoding='utf-8', errors='replace') as f:
                        lines.extend(f.readlines())
                except Exception as e:
                    session.print_output(f"sort: {filename}: {e}\n")

        # Remove newlines for sorting
        lines = [line.rstrip('\n\r') for line in lines]

        if unique:
            lines = list(set(lines))

        def sort_key(line):
            val = line
            if ignore_case:
                val = val.lower()
            if numeric:
                # Extract leading number if possible
                match = re.search(r"^\s*(-?\d+(\.\d+)?)", val)
                if match:
                    try:
                        return float(match.group(1))
                    except ValueError:
                        return 0.0
                return 0.0
            return val

        try:
            lines.sort(key=sort_key, reverse=reverse)
        except Exception:
            # Fallback
            lines.sort(reverse=reverse)

        for line in lines:
            session.print_output(line + "\n")
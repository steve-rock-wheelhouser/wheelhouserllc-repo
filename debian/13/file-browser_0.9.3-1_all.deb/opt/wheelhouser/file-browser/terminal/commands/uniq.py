#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Uniq Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of uniq command.
# 0.1.1 - Append newline delimiter to output lines and error messages
#
# Future features may include:
# - Support for skipping fields (-f)
# - Support for skipping chars (-s)
#============================================================================================

import os

from command_registry import Command

COMMAND_NAME = "uniq"
VERSION = "0.1.1"
DESCRIPTION = "Report or omit repeated lines"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class UniqCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [INPUT [OUTPUT]]\n{DESCRIPTION}\n\nOptions:\n  -c, --count           prefix lines by the number of occurrences\n  -d, --repeated        only print duplicate lines, one for each group\n  -u, --unique          only print unique lines\n  -i, --ignore-case     ignore differences in case when comparing\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        files = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                files.append(arg)

        show_counts = 'c' in flags or '--count' in flags
        only_duplicates = 'd' in flags or '--repeated' in flags
        only_unique = 'u' in flags or '--unique' in flags
        ignore_case = 'i' in flags or '--ignore-case' in flags

        # 3. Main Logic
        lines = []
        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                lines = session.stdin.splitlines()
            else:
                # Wait for stdin in a real shell, here we just return
                return
        else:
            # Only handle input file for now, output via redirection >
            input_file = files[0]
            path = session.resolve_path(input_file)
            if not os.path.exists(path):
                session.print_output(f"uniq: {input_file}: No such file or directory\n")
                return
            if os.path.isdir(path):
                session.print_output(f"uniq: {input_file}: Is a directory\n")
                return
            
            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    lines = f.readlines()
            except Exception as e:
                session.print_output(f"uniq: {input_file}: {e}\n")
                return

        def compare(l1, l2):
            if ignore_case:
                return l1.lower() == l2.lower()
            return l1 == l2

        def emit(line, count):
            if line is None: 
                return
            should_print = False
            if only_duplicates and count > 1: 
                should_print = True
            elif only_unique and count == 1:
                should_print = True
            elif not only_duplicates and not only_unique: 
                should_print = True
            
            if should_print:
                prefix = f"{count:>7} " if show_counts else ""
                session.print_output(f"{prefix}{line}\n")

        prev_line = None
        count = 0

        for line in lines:
            line = line.rstrip('\n\r')
            if prev_line is None:
                prev_line = line
                count = 1
                continue
            
            if compare(line, prev_line):
                count += 1
            else:
                emit(prev_line, count)
                prev_line = line
                count = 1
        
        emit(prev_line, count)
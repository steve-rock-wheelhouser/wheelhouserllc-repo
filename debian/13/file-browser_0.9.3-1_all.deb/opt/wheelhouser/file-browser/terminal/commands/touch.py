#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Touch Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of touch command.
#
# Future features may include:
# - Support for setting specific time (-t, -d)
# - Support for reference file (-r)
#============================================================================================

import os
import time

from command_registry import Command

COMMAND_NAME = "touch"
VERSION = "0.1.0"
DESCRIPTION = "Change file timestamps"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class TouchCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... FILE...\n{DESCRIPTION}\n\nOptions:\n  -a                    change only the access time\n  -c, --no-create       do not create any files\n  -m                    change only the modification time\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        files = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                files.append(arg)

        change_atime = 'a' in flags
        change_mtime = 'm' in flags
        no_create = 'c' in flags or '--no-create' in flags

        # If neither -a nor -m is specified, change both
        if not change_atime and not change_mtime:
            change_atime = True
            change_mtime = True

        # 3. Main Logic
        if not files:
            session.print_output("touch: missing file operand")
            return

        for filename in files:
            path = session.resolve_path(filename)
            
            if os.path.exists(path):
                try:
                    # Get current times if we need to preserve one of them
                    stat = os.stat(path)
                    current_time = time.time()
                    
                    atime = current_time if change_atime else stat.st_atime
                    mtime = current_time if change_mtime else stat.st_mtime
                    
                    os.utime(path, (atime, mtime))
                except Exception as e:
                    session.print_output(f"touch: setting times of '{filename}': {e}")
            else:
                if not no_create:
                    try:
                        # Create empty file
                        with open(path, 'a'):
                            os.utime(path, None)
                    except Exception as e:
                        session.print_output(f"touch: cannot touch '{filename}': {e}")
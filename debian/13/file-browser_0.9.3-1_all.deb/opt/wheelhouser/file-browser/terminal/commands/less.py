#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Less Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of less command.
#
# Future features may include:
# - Search functionality within the viewer
# - Line numbers
#============================================================================================

import os
from PySide6.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QPushButton, QHBoxLayout
from PySide6.QtGui import QFont

from command_registry import Command

COMMAND_NAME = "less"
VERSION = "0.1.0"
DESCRIPTION = "Opposite of more"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class LessDialog(QDialog):
    def __init__(self, title, content, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"less - {title}")
        self.resize(800, 600)
        self.setup_ui(content)

    def setup_ui(self, content):
        layout = QVBoxLayout(self)
        
        self.text_edit = QTextEdit()
        self.text_edit.setPlainText(content)
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Consolas", 12))
        self.text_edit.setStyleSheet("background-color: #1e1e1e; color: #ffffff; border: 1px solid #555;")
        layout.addWidget(self.text_edit)
        
        btn_layout = QHBoxLayout()
        self.btn_close = QPushButton("Quit (q)")
        self.btn_close.clicked.connect(self.accept)
        self.btn_close.setStyleSheet("background-color: #333; color: white; padding: 5px;")
        
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_close)
        layout.addLayout(btn_layout)

class LessCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [FILE]...\n{DESCRIPTION}\n\nOptions:\n  --version    output version information and exit\n  --help       display this help and exit")
            return

        # 2. Parse Arguments & Logic
        content = ""
        title = ""

        # Check for stdin first
        if hasattr(session, 'stdin') and session.stdin:
            content = session.stdin
            title = "stdin"
        
        filename = None
        for arg in args:
            if not arg.startswith("-"):
                filename = arg
                break
        
        if filename:
            path = session.resolve_path(filename)
            if os.path.exists(path):
                if os.path.isdir(path):
                    session.print_output(f"less: {filename}: Is a directory")
                    return
                try:
                    with open(path, 'r', encoding='utf-8', errors='replace') as f:
                        file_content = f.read()
                        content = file_content if not content else content + "\n" + file_content
                    if not title:
                        title = filename
                except Exception as e:
                    session.print_output(f"less: {filename}: {e}")
                    return
            else:
                session.print_output(f"less: {filename}: No such file or directory")
                return
        
        if not content and not filename:
             session.print_output("less: missing filename")
             return

        dialog = LessDialog(title, content, parent=session)
        dialog.exec()
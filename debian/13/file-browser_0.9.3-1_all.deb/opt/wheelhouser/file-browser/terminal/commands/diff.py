#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Diff Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of diff command.
#
# Future features may include:
# - Support for different diff formats (context, unified)
# - Support for ignoring whitespace
#============================================================================================

import os
import difflib

from command_registry import Command

COMMAND_NAME = "diff"
VERSION = "0.1.0"
DESCRIPTION = "Compare files line by line"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class DiffCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... FILE1 FILE2\n{DESCRIPTION}\n\nOptions:\n  --version     output version information and exit\n  --help        display this help and exit")
            return

        # 2. Parse Arguments & Flags
        files = []
        
        for arg in args:
            if not arg.startswith("-"):
                files.append(arg)

        # 3. Main Logic
        if len(files) != 2:
            session.print_output(f"{COMMAND_NAME}: missing operand after '{files[0] if files else ''}'")
            return

        file1_path = session.resolve_path(files[0])
        file2_path = session.resolve_path(files[1])

        if not os.path.exists(file1_path):
            session.print_output(f"{COMMAND_NAME}: {files[0]}: No such file or directory")
            return
        if not os.path.exists(file2_path):
            session.print_output(f"{COMMAND_NAME}: {files[1]}: No such file or directory")
            return

        try:
            with open(file1_path, 'r', encoding='utf-8', errors='replace') as f1, \
                 open(file2_path, 'r', encoding='utf-8', errors='replace') as f2:
                f1_lines = f1.readlines()
                f2_lines = f2.readlines()

            diff = difflib.unified_diff(f1_lines, f2_lines, fromfile=files[0], tofile=files[1], lineterm='')
            
            for line in diff:
                if line.startswith('+') and not line.startswith('+++'):
                    session.print_output(f"\033[32m{line}\033[0m") # Green for additions
                elif line.startswith('-') and not line.startswith('---'):
                    session.print_output(f"\033[31m{line}\033[0m") # Red for deletions
                else:
                    session.print_output(line)
        except Exception as e:
            session.print_output(f"{COMMAND_NAME}: error: {e}")
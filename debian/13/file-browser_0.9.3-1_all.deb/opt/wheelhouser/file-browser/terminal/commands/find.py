#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Find Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of find command.
# 0.1.1 - Append newline delimiter to output paths and error messages
#
# Future features may include:
# - Support for regex patterns
# - Support for size and time filters
# - Support for exec actions
#============================================================================================

import os
import fnmatch

from command_registry import Command

COMMAND_NAME = "find"
VERSION = "0.1.1"
DESCRIPTION = "Search for files in a directory hierarchy"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class FindCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [path...] [expression]\n{DESCRIPTION}\n\nOptions:\n  -name pattern  Base of file name matches shell pattern.\n  -type c        File is of type c: f (regular file), d (directory).\n  --version      output version information and exit\n  --help         display this help and exit")
            return

        # 2. Parse Arguments & Flags
        paths = []
        name_pattern = None
        type_filter = None
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-name":
                if i + 1 < len(args):
                    name_pattern = args[i+1]
                    i += 1
                else:
                    session.print_output("find: missing argument to `-name'")
                    return
            elif arg == "-type":
                if i + 1 < len(args):
                    type_filter = args[i+1]
                    i += 1
                else:
                    session.print_output("find: missing argument to `-type'")
                    return
            elif arg.startswith("-"):
                session.print_output(f"find: unknown predicate `{arg}'")
                return
            else:
                paths.append(arg)
            i += 1

        if not paths:
            paths = ["."]

        # 3. Main Logic
        for path_arg in paths:
            root_path = session.resolve_path(path_arg)
            
            if not os.path.exists(root_path):
                session.print_output(f"find: `{path_arg}': No such file or directory\n")
                continue

            # Walk the directory tree
            for root, dirs, files in os.walk(root_path):
                # Combine dirs and files to process everything
                entries = dirs + files
                # Also include the root itself if it's the first iteration
                if root == root_path:
                    entries.append("") # Empty string represents the root itself relative to root

                for name in sorted(entries):
                    if name == "":
                        full_path = root
                        display_name = os.path.basename(root)
                    else:
                        full_path = os.path.join(root, name)
                        display_name = name

                    is_dir = os.path.isdir(full_path)

                    # Apply filters
                    if type_filter:
                        if type_filter == 'f' and is_dir:
                            continue
                        if type_filter == 'd' and not is_dir:
                            continue
                    
                    if name_pattern:
                        if not fnmatch.fnmatch(display_name, name_pattern):
                            continue

                    # Calculate display path
                    if name == "":
                        # This is the root argument itself
                        session.print_output(path_arg + "\n")
                    else:
                        rel_path = os.path.relpath(full_path, root_path)
                        if path_arg.endswith(os.sep) or path_arg == "":
                            display_path = path_arg + rel_path
                        else:
                            display_path = os.path.join(path_arg, rel_path)
                        session.print_output(display_path + "\n")
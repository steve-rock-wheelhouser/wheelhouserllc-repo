#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Tree Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of tree command.
#
# Future features may include:
# - Support for displaying hidden files and directories with a flag (e.g. -a or --all)
# - Support for limiting the depth of the tree display with a flag (e.g. -L or --level)
# - Support for displaying file sizes and modification dates with flags (e.g. -s or --size, -d or --date)
# - Support for colorizing output based on file types with a flag (e.g. --color)
# - Support for sorting output by name, size, date, etc. with a flag (e.g. -S or --sort)
# - Support for following symbolic links with a flag (e.g. -l or --follow-links)
#
#============================================================================================


import os
from command_registry import Command

COMMAND_NAME = "tree"
VERSION = "0.1.0"
DESCRIPTION = "List contents of directories in a tree-like format."

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class TreeCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [PATH]...\n{DESCRIPTION}\n\nOptions:\n  -a            All files are printed. By default, hidden files are not.\n  -L level      Descend only level directories deep.\n  --version     output version information and exit\n  --help        display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        positional_args = []
        max_depth = -1 # -1 means infinite
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == '-L':
                if i + 1 < len(args):
                    try:
                        max_depth = int(args[i+1])
                        i += 1
                    except ValueError:
                        session.print_output("tree: Invalid level, must be an integer.")
                        return
                else:
                    session.print_output("tree: Missing level argument for -L.")
                    return
            elif arg.startswith("-"):
                for char in arg[1:]:
                    flags.add(char)
            else:
                positional_args.append(arg)
            i += 1

        show_all = 'a' in flags

        # 3. Main Logic
        paths = positional_args if positional_args else [session.cwd]
        
        for path in paths:
            try:
                target_path = session.resolve_path(path)
                if not os.path.exists(target_path):
                    session.print_output(f"tree: {path}: No such file or directory\n")
                    continue

                # Print root
                session.print_output(f"\033[1;34m{os.path.basename(target_path) or target_path}\033[0m\n")
                
                self.dirs = 0
                self.files = 0
                self._walk(session, target_path, "", show_all, max_depth, 0)
                session.print_output(f"\n{self.dirs} directories, {self.files} files\n")

            except Exception as e:
                session.print_output(f"tree: error: {e}\n")

    def _walk(self, session, directory, prefix, show_all, max_depth, current_depth):
        if max_depth != -1 and current_depth >= max_depth:
            return

        try:
            entries = sorted(os.listdir(directory))
        except OSError:
            return

        # Filter hidden files if -a is not present
        if not show_all:
            entries = [e for e in entries if not e.startswith('.')]
        
        count = len(entries)
        for i, entry in enumerate(entries):
            is_last = (i == count - 1)
            connector = "└── " if is_last else "├── "
            
            full_path = os.path.join(directory, entry)
            is_dir = os.path.isdir(full_path)
            
            if is_dir:
                self.dirs += 1
                color = "\033[1;34m" # Blue
            else:
                self.files += 1
                color = "\033[0m" # Default/White
                
            reset = "\033[0m"
            
            line = f"{prefix}{connector}{color}{entry}{reset}\n"
            session.print_output(line)
            
            if is_dir:
                extension = "    " if is_last else "│   "
                self._walk(session, full_path, prefix + extension, show_all, max_depth, current_depth + 1)
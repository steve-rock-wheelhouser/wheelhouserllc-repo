#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Sed Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of sed command.
#
# Future features may include:
# - Support for delete (d), print (p) commands
# - Support for address ranges
#============================================================================================

import os
import re

from command_registry import Command

COMMAND_NAME = "sed"
VERSION = "0.1.0"
DESCRIPTION = "Stream editor for filtering and transforming text"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class SedCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [script] [input_file]...\n{DESCRIPTION}\n\nOptions:\n  -i[SUFFIX], --in-place[=SUFFIX]\n                 edit files in place (makes backup if SUFFIX supplied)\n  -e script, --expression=script\n                 add the script to the commands to be executed\n  --version      output version information and exit\n  --help         display this help and exit")
            return

        # 2. Parse Arguments & Flags
        clean_args = []
        script = None
        in_place = False
        backup_suffix = ""

        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-i":
                in_place = True
            elif arg.startswith("-i"):
                in_place = True
                if len(arg) > 2:
                    backup_suffix = arg[2:]
            elif arg == "--in-place":
                in_place = True
            elif arg.startswith("--in-place="):
                in_place = True
                backup_suffix = arg.split("=", 1)[1]
            elif arg == "-e":
                if i + 1 < len(args):
                    script = args[i+1]
                    i += 1
            elif arg.startswith("-e"):
                script = arg[2:]
            elif arg.startswith("-") and arg != "-":
                 # Ignore unknown flags for now
                 pass
            else:
                clean_args.append(arg)
            i += 1
        
        if not script and clean_args:
            script = clean_args.pop(0)
        
        if not script:
             session.print_output("sed: missing script")
             return

        # Simple parser for s/find/replace/flags
        if not script.startswith("s"):
             session.print_output(f"sed: only substitution (s///) is currently supported. Script: {script}")
             return
        
        if len(script) < 2:
            session.print_output("sed: invalid script")
            return

        delimiter = script[1]
        parts = script.split(delimiter)
        
        if len(parts) < 3:
             session.print_output("sed: bad option in substitution expression")
             return
             
        pattern_str = parts[1]
        replacement = parts[2]
        sed_flags = parts[3] if len(parts) > 3 else ""
        
        global_replace = 'g' in sed_flags
        ignore_case = 'I' in sed_flags or 'i' in sed_flags
        
        re_flags = 0
        if ignore_case:
            re_flags |= re.IGNORECASE
            
        try:
            regex = re.compile(pattern_str, re_flags)
        except re.error as e:
            session.print_output(f"sed: invalid regex: {e}")
            return

        def process_content(content):
            lines = content.splitlines()
            result_lines = []
            for line in lines:
                count = 0 if global_replace else 1
                new_line = regex.sub(replacement, line, count=count)
                result_lines.append(new_line)
            return "\n".join(result_lines)

        files = clean_args
        
        # 3. Main Logic
        if not files:
            # Stdin
            if hasattr(session, 'stdin') and session.stdin:
                content = session.stdin
                output = process_content(content)
                session.print_output(output)
            return

        for filename in files:
            path = session.resolve_path(filename)
            if not os.path.exists(path):
                session.print_output(f"sed: cannot read {filename}: No such file or directory")
                continue
            
            if os.path.isdir(path):
                session.print_output(f"sed: {filename}: Is a directory")
                continue

            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
                
                new_content = process_content(content)
                
                if in_place:
                    if backup_suffix:
                        import shutil
                        shutil.copy2(path, path + backup_suffix)
                    
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                else:
                    session.print_output(new_content)
                    
            except Exception as e:
                session.print_output(f"sed: error processing {filename}: {e}")
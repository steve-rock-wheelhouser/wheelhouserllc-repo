#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Environment Variable Commands for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of env commands.
#
# Future features may include:
# - 
#============================================================================================

import re
from command_registry import Command

VERSION = "0.1.0"

class ExportCommand(Command):
    def __init__(self):
        super().__init__("export", f"Set environment variables (v{VERSION})")

    def execute(self, session, args):
        if not args:
            for k, v in sorted(session.env.items()):
                session.print_output(f"declare -x {k}=\"{v}\"")
            return

        for arg in args:
            if "=" in arg:
                key, value = arg.split("=", 1)
                
                # Remove quotes if present
                if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
                    value = value[1:-1]
                
                # Expand variables in value using session.env
                value = self._expand_value(value, session.env)
                
                session.env[key] = value
            else:
                # In a real shell, this would export a local variable. 
                # We don't have local variables distinct from env yet.
                pass

    def _expand_value(self, value, env):
        # Expand $VAR
        pattern = r'\$([a-zA-Z_][a-zA-Z0-9_]*)'
        def replace(match):
            var_name = match.group(1)
            return env.get(var_name, "")
        value = re.sub(pattern, replace, value)
        
        # Expand ${VAR}
        pattern_braces = r'\$\{([a-zA-Z_][a-zA-Z0-9_]*)\}'
        def replace_braces(match):
            var_name = match.group(1)
            return env.get(var_name, "")
        value = re.sub(pattern_braces, replace_braces, value)
        
        return value

class UnsetCommand(Command):
    def __init__(self):
        super().__init__("unset", f"Unset environment variables (v{VERSION})")

    def execute(self, session, args):
        for arg in args:
            if arg in session.env:
                del session.env[arg]

class EnvCommand(Command):
    def __init__(self):
        super().__init__("env", f"Print environment variables (v{VERSION})")

    def execute(self, session, args):
        if args:
            session.print_output("env: running commands with modified environment not yet supported")
            return
            
        for k, v in sorted(session.env.items()):
            session.print_output(f"{k}={v}")
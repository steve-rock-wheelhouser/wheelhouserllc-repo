#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Tar Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of tar command.
#
# Future features may include:
# - Support for bzip2 (-j)
# - Support for -C (change directory)
#============================================================================================

import os
import tarfile

from command_registry import Command

COMMAND_NAME = "tar"
VERSION = "0.1.0"
DESCRIPTION = "Store, list or extract files in an archive"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class TarCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION...] [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -c, --create       create a new archive\n  -x, --extract      extract files from an archive\n  -t, --list         list the contents of an archive\n  -v, --verbose      verbosely list files processed\n  -f, --file=ARCHIVE use archive file or device ARCHIVE\n  -z, --gzip         filter the archive through gzip\n  --version          output version information and exit\n  --help             display this help and exit")
            return

        # 2. Parse Arguments & Flags
        mode_op = None
        verbose = False
        gzip = False
        archive_name = None
        target_files = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg.startswith("-") and len(arg) > 1:
                # Handle bundled flags like -cvf or long flags
                if arg == "--create":
                    mode_op = 'c'
                elif arg == "--extract":
                    mode_op = 'x'
                elif arg == "--list":
                    mode_op = 't'
                elif arg == "--verbose":
                    verbose = True
                elif arg == "--gzip":
                    gzip = True
                elif arg.startswith("--file="):
                    archive_name = arg.split("=", 1)[1]
                elif arg == "--file":
                    if i + 1 < len(args):
                        archive_name = args[i+1]
                        i += 1
                    else:
                        session.print_output("tar: option '--file' requires an argument")
                        return
                else:
                    # Short flags (e.g., -cvf)
                    chars = arg[1:]
                    for idx, char in enumerate(chars):
                        if char == 'c': 
                            mode_op = 'c'
                        elif char == 'x': 
                            mode_op = 'x'
                        elif char == 't': 
                            mode_op = 't'
                        elif char == 'v': 
                            verbose = True
                        elif char == 'z': 
                            gzip = True
                        elif char == 'f':
                            if i + 1 < len(args):
                                archive_name = args[i+1]
                                i += 1
                                break 
                            else:
                                session.print_output("tar: option requires an argument -- f")
                                return
            else:
                target_files.append(arg)
            i += 1

        if not mode_op:
            session.print_output("tar: must specify one of -c, -x, -t")
            return

        if not archive_name:
            session.print_output("tar: refusing to read/write to terminal (missing -f option)")
            return

        archive_path = session.resolve_path(archive_name)
        
        # 3. Main Logic
        try:
            if mode_op == 'c':
                if not target_files:
                    session.print_output("tar: cowardly refusing to create an empty archive")
                    return
                
                tar_mode = 'w:gz' if gzip else 'w'
                with tarfile.open(archive_path, tar_mode) as tar:
                    for name in target_files:
                        full_path = session.resolve_path(name)
                        if os.path.exists(full_path):
                            if verbose:
                                session.print_output(name)
                            tar.add(full_path, arcname=os.path.basename(full_path))
                        else:
                            session.print_output(f"tar: {name}: Cannot stat: No such file or directory")
                            
            elif mode_op == 'x':
                if not os.path.exists(archive_path):
                    session.print_output(f"tar: {archive_name}: Cannot open: No such file or directory")
                    return
                
                with tarfile.open(archive_path, "r:*") as tar:
                    if verbose:
                        for member in tar.getmembers():
                            session.print_output(member.name)
                    tar.extractall(path=session.cwd)
                        
            elif mode_op == 't':
                if not os.path.exists(archive_path):
                    session.print_output(f"tar: {archive_name}: Cannot open: No such file or directory")
                    return
                    
                with tarfile.open(archive_path, "r:*") as tar:
                    for member in tar.getmembers():
                        session.print_output(member.name)

        except Exception as e:
            session.print_output(f"tar: Error: {e}")
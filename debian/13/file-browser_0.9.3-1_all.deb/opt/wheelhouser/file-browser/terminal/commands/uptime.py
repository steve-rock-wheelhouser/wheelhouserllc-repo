#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Uptime Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of uptime command.
#
# Future features may include:
# - Support for pretty printing (-p)
# - Support for start time (-s)
#============================================================================================

import platform
import datetime

from command_registry import Command

COMMAND_NAME = "uptime"
VERSION = "0.1.0"
DESCRIPTION = "Tell how long the system has been running"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class UptimeCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME}\n{DESCRIPTION}\n\nOptions:\n  --version    output version information and exit\n  --help       display this help and exit")
            return

        # 2. Main Logic
        if platform.system() == "Windows":
            try:
                import ctypes
                windll = getattr(ctypes, "windll", None)
                if not windll:
                    session.print_output("uptime: unavailable on this Windows configuration")
                    return
                tick = windll.kernel32.GetTickCount64()
                seconds = tick / 1000
                m, s = divmod(seconds, 60)
                h, m = divmod(m, 60)
                d, h = divmod(h, 24)
                
                now = datetime.datetime.now().strftime("%H:%M:%S")
                
                session.print_output(f" {now} up {int(d)} days, {int(h):02}:{int(m):02}")
            except Exception as e:
                session.print_output(f"uptime: {e}")
        else:
            # Linux/Mac usually have a native uptime command
            session.run_system_command(["uptime"])
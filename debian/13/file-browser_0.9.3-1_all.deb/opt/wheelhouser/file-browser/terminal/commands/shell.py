#!/usr/bin/python3
# -*- coding: utf-8 -*-
# TerminalWidget - A simple terminal interface for file management and command execution within the application.
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development, basic file browsing features

from command_registry import Command

VERSION = "0.1.0"

#============================================================================================
# --- Utility Commands ---
#============================================================================================
class ClearCommand(Command):
    def __init__(self):
        super().__init__("clear", "Clear the terminal screen")

    def execute(self, session, args):
        session.output_area.clear()

#============================================================================================
# --- Help and Alias Commands ---
#============================================================================================
class HelpCommand(Command):
    def __init__(self):
        super().__init__("help", "Display information about builtin commands")

    def execute(self, session, args):
        session.print_output("Available commands:\n")
        commands = sorted(session.registry.list_commands(), key=lambda c: c.name)
        for cmd in commands:
            session.print_output(f"  {cmd.name}\t\t{cmd.description}\n")

#============================================================================================
# --- Tab and Theme Commands ---
#============================================================================================
class AliasCommand(Command):
    def __init__(self):
        super().__init__("alias", "Define or display aliases")

    def execute(self, session, args):
        if not args:
            for k, v in session.aliases.items():
                session.print_output(f"alias {k}='{v}'")
            return
            
        # Handle alias name='value'
        arg_str = " ".join(args)
        if "=" in arg_str:
            name, value = arg_str.split("=", 1)
            # Remove quotes if present
            if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
                value = value[1:-1]
            session.aliases[name.strip()] = value.strip()
        else:
            name = args[0]
            if name in session.aliases:
                session.print_output(f"alias {name}='{session.aliases[name]}'")
            else:
                session.print_output(f"alias: {name}: not found")

#============================================================================================
# --- Shell Scripting Commands ---
#============================================================================================
class UnaliasCommand(Command):
    def __init__(self):
        super().__init__("unalias", "Remove alias definitions")

    def execute(self, session, args):
        if not args:
            session.print_output("unalias: usage: unalias name [name ...]")
            return
        for name in args:
            if name in session.aliases:
                del session.aliases[name]
            else:
                session.print_output(f"unalias: {name}: not found")

#============================================================================================
# --- Source Command (Execute commands from a file) ---
#============================================================================================
class SourceCommand(Command):
    def __init__(self):
        super().__init__("source", "Execute commands from a file in the current shell")

    def execute(self, session, args):
        if not args:
            session.print_output("source: filename argument required")
            return
        
        path = session.resolve_path(args[0])
        try:
            with open(path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        # Assuming session has execute_command_line
                        if hasattr(session, 'execute_command_line'):
                            session.execute_command_line(line, echo=False)
                        else:
                            session.print_output("Error: Session does not support executing command lines.")
        except Exception as e:
            session.print_output(f"source: {e}")

#============================================================================================
# --- Dot Command (Alias for source) ---
#============================================================================================
class DotCommand(SourceCommand):
    def __init__(self):
        Command.__init__(self, ".", "Execute commands from a file in the current shell")
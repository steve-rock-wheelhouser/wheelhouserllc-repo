from command_registry import Command

class PluginsCommand(Command):
    def __init__(self):
        super().__init__("plugins", "List all loaded command plugins.")

    def execute(self, session, args):
        if "--help" in args:
            session.print_output(f"Usage: {self.name}\n{self.description}\n\nOptions:\n  --help       display this help and exit\n")
            return

        pm = session.plugin_manager
        if not pm:
            session.print_output("Plugin system not initialized.\n")
            return

        if not pm.command_plugins:
            session.print_output("No command plugins loaded.\n")
            return

        session.print_output("Loaded Plugins:\n")
        for p in pm.command_plugins:
            status_color = "\033[32m" if p["status"].startswith("Loaded") else "\033[31m"
            session.print_output(f"  {p['file']} - {status_color}{p['status']}\033[0m\n")
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Free Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of free command.
#
# Future features may include:
# - Support for swap memory display
# - Support for different units (-b, -k, -m, -g)
#============================================================================================

import platform
import subprocess
import re

from command_registry import Command

COMMAND_NAME = "free"
VERSION = "0.1.0"
DESCRIPTION = "Display amount of free and used memory in the system"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class FreeCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]...\n{DESCRIPTION}\n\nOptions:\n  -h, --human    show output in human-readable format\n  --version      output version information and exit\n  --help         display this help and exit")
            return

        # 2. Parse Arguments & Flags
        human_readable = '-h' in args or '--human' in args

        # 3. Main Logic
        system_name = platform.system().lower()
        
        if system_name == "windows":
            self._free_windows(session, human_readable)
        elif system_name == "darwin":
            self._free_macos(session, human_readable)
        else:
            # Linux usually has 'free' installed
            self._free_linux(session, args)

    def _format_bytes(self, size, human):
        if not human:
            return str(size // 1024) # Default to KB
        
        for unit in ['B', 'Ki', 'Mi', 'Gi', 'Ti']:
            if size < 1024.0:
                return f"{size:.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}Pi"

    def _free_windows(self, session, human):
        try:
            # Get memory info via WMIC
            cmd = ["wmic", "OS", "get", "FreePhysicalMemory,TotalVisibleMemorySize", "/Value"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                session.print_output(f"free: error retrieving memory info: {result.stderr}")
                return

            total_kb = 0
            free_kb = 0
            
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line: 
                    continue
                if "=" in line:
                    key, val = line.split("=", 1)
                    if key == "TotalVisibleMemorySize":
                        total_kb = int(val)
                    elif key == "FreePhysicalMemory":
                        free_kb = int(val)
            
            total_bytes = total_kb * 1024
            free_bytes = free_kb * 1024
            used_bytes = total_bytes - free_bytes
            
            # Header
            session.print_output(f"{'':<10} {'total':>10} {'used':>10} {'free':>10}")
            
            # Mem line
            t_str = self._format_bytes(total_bytes, human)
            u_str = self._format_bytes(used_bytes, human)
            f_str = self._format_bytes(free_bytes, human)
            
            session.print_output(f"{'Mem:':<10} {t_str:>10} {u_str:>10} {f_str:>10}")
            
        except Exception as e:
            session.print_output(f"free: error: {e}")

    def _free_macos(self, session, human):
        try:
            # vm_stat returns pages (usually 4096 bytes)
            cmd = ["vm_stat"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                session.print_output(f"free: error: {result.stderr}")
                return

            page_size = 4096 # Default
            pages_free = 0
            
            for line in result.stdout.splitlines():
                if "page size of" in line:
                    match = re.search(r"page size of (\d+) bytes", line)
                    if match:
                        page_size = int(match.group(1))
                    continue
                
                if ":" in line:
                    key, val = line.split(":", 1)
                    val = int(val.strip().replace(".", ""))
                    if key == "Pages free": 
                        pages_free = val

            # To get total physical RAM on mac: sysctl hw.memsize
            total_bytes = 0
            try:
                sysctl = subprocess.run(["sysctl", "hw.memsize"], capture_output=True, text=True)
                if sysctl.returncode == 0:
                    match = re.search(r"hw.memsize: (\d+)", sysctl.stdout)
                    if match:
                        total_bytes = int(match.group(1))
            except Exception:
                pass

            free_bytes = pages_free * page_size
            used_bytes = total_bytes - free_bytes
            
            # Header
            session.print_output(f"{'':<10} {'total':>10} {'used':>10} {'free':>10}")
            
            t_str = self._format_bytes(total_bytes, human)
            u_str = self._format_bytes(used_bytes, human)
            f_str = self._format_bytes(free_bytes, human)
            
            session.print_output(f"{'Mem:':<10} {t_str:>10} {u_str:>10} {f_str:>10}")

        except Exception as e:
            session.print_output(f"free: error: {e}")

    def _free_linux(self, session, args):
        try:
            cmd = ["free"]
            # Pass through flags that make sense
            for arg in args:
                if arg.startswith("-"):
                    cmd.append(arg)
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.stdout:
                session.print_output(result.stdout.rstrip())
            if result.stderr:
                session.print_output(result.stderr.rstrip())
        except FileNotFoundError:
            session.print_output("free: command not found")
        except Exception as e:
            session.print_output(f"free: error: {e}")
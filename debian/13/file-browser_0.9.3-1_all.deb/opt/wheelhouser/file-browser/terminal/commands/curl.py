#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Curl Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of curl command.
#
# Future features may include:
# - Support for POST data (-d)
# - Support for headers (-H)
#============================================================================================

import os
import requests

from command_registry import Command

COMMAND_NAME = "curl"
VERSION = "0.1.0"
DESCRIPTION = "Transfer a URL"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class CurlCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [options...] <url>\n{DESCRIPTION}\n\nOptions:\n  -O, --remote-name   Write output to a file named as the remote file\n  -o, --output <file> Write to file instead of stdout\n  -I, --head          Show document info only\n  -X, --request <cmd> Specify request command to use\n  --version           output version information and exit\n  --help              display this help and exit")
            return

        # 2. Parse Arguments & Flags
        url = None
        output_file = None
        use_remote_name = False
        method = "GET"
        head_only = False
        
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "-O" or arg == "--remote-name":
                use_remote_name = True
            elif arg == "-o" or arg == "--output":
                if i + 1 < len(args):
                    output_file = args[i+1]
                    i += 1
                else:
                    session.print_output("curl: option requires an argument -- o")
                    return
            elif arg == "-I" or arg == "--head":
                head_only = True
                method = "HEAD"
            elif arg == "-X" or arg == "--request":
                if i + 1 < len(args):
                    method = args[i+1]
                    i += 1
                else:
                    session.print_output("curl: option requires an argument -- X")
                    return
            elif arg.startswith("-") and arg != "-":
                pass # Ignore unknown flags for now
            else:
                url = arg
            i += 1
            
        if not url:
            session.print_output("curl: no URL specified!")
            return
            
        if not url.startswith("http"):
            url = "http://" + url
            
        # 3. Main Logic
        try:
            response = requests.request(method, url, stream=True)
            
            if head_only:
                for k, v in response.headers.items():
                    session.print_output(f"{k}: {v}")
                return
                
            if output_file or use_remote_name:
                if use_remote_name:
                    output_file = os.path.basename(url.split("?")[0])
                    if not output_file:
                        output_file = "index.html"
                
                path = session.resolve_path(output_file)
                with open(path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
            else:
                # Print to stdout
                content_type = response.headers.get('content-type', '')
                if 'text' in content_type or 'json' in content_type:
                    session.print_output(response.text)
                else:
                    session.print_output(f"Binary output ({len(response.content)} bytes) not displayed. Use -o to save to file.")
                    
        except Exception as e:
            session.print_output(f"curl: {e}")
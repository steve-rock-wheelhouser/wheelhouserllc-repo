#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Df Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of df command.
#
# Future features may include:
# - Support for inode usage (-i)
# - Support for filesystem type (-T)
#============================================================================================

import os
import shutil

from command_registry import Command

COMMAND_NAME = "df"
VERSION = "0.1.0"
DESCRIPTION = "Report file system disk space usage"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class DfCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -h, --human-readable  print sizes in powers of 1024 (e.g., 1023M)\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        paths = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                paths.append(arg)

        human_readable = 'h' in flags or '--human-readable' in flags

        def format_size(size_bytes):
            if not human_readable:
                # Default to 1K blocks
                return str(size_bytes // 1024)
            
            for unit in ['B', 'K', 'M', 'G', 'T', 'P']:
                if size_bytes < 1024:
                    return f"{size_bytes:.1f}{unit}"
                size_bytes /= 1024
            return f"{size_bytes:.1f}E"

        # 3. Main Logic
        targets = []
        if not paths:
            # Try to find all roots
            if os.name == 'nt':
                try:
                    import string
                    from ctypes import windll
                    drives = []
                    bitmask = windll.kernel32.GetLogicalDrives()
                    for letter in string.ascii_uppercase:
                        if bitmask & 1:
                            drives.append(f"{letter}:\\")
                        bitmask >>= 1
                    targets = drives
                except Exception:
                    targets = [session.cwd]
            else:
                # Linux/Mac: Just show root /
                targets = ['/']
        else:
            targets = [session.resolve_path(p) for p in paths]

        # Header
        size_label = "Size" if human_readable else "1K-blocks"
        header = f"{'Filesystem':<20} {size_label:>10} {'Used':>10} {'Avail':>10} {'Use%':>6} {'Mounted on'}"
        session.print_output(header)

        for target in targets:
            try:
                if not os.path.exists(target):
                    session.print_output(f"df: {target}: No such file or directory")
                    continue
                    
                usage = shutil.disk_usage(target)
                
                fs_name = target
                if os.name == 'nt':
                    drive, _ = os.path.splitdrive(target)
                    if drive: 
                        fs_name = drive
                
                total = format_size(usage.total)
                used = format_size(usage.used)
                free = format_size(usage.free)
                percent = int((usage.used / usage.total) * 100) if usage.total > 0 else 0
                
                line = f"{fs_name:<20} {total:>10} {used:>10} {free:>10} {percent:>5}% {target}"
                session.print_output(line)
            except Exception as e:
                session.print_output(f"df: {target}: {e}")
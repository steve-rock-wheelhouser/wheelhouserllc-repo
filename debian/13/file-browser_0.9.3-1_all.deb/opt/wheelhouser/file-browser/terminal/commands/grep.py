#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Grep Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of grep command.
# 0.1.1 - Fix missing newline in match output and suppress ANSI colors when piped in capture mode
#
# Future features may include:
# - Support for recursive search (-r)
# - Support for context lines (-A, -B, -C)
#============================================================================================

import os
import re

from command_registry import Command

COMMAND_NAME = "grep"
VERSION = "0.1.1"
DESCRIPTION = "Print lines that match patterns"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class GrepCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... PATTERNS [FILE]...\n{DESCRIPTION}\n\nOptions:\n  -i, --ignore-case  ignore case distinctions\n  -v, --invert-match select non-matching lines\n  -n, --line-number  print line number with output lines\n  -c, --count        print only a count of selected lines per file\n  --version          output version information and exit\n  --help             display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        clean_args = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)

        ignore_case = 'i' in flags or '--ignore-case' in flags
        invert_match = 'v' in flags or '--invert-match' in flags
        line_number = 'n' in flags or '--line-number' in flags
        count_only = 'c' in flags or '--count' in flags

        if not clean_args:
            session.print_output("grep: usage: grep [OPTION]... PATTERNS [FILE]...")
            return

        pattern_str = clean_args[0]
        files = clean_args[1:]

        try:
            re_flags = re.IGNORECASE if ignore_case else 0
            pattern = re.compile(pattern_str, re_flags)
        except re.error as e:
            session.print_output(f"grep: invalid regular expression: {e}\n")
            return

        def process_lines(lines, source_name, print_name=False):
            match_count = 0
            is_capture = getattr(session, '_capture_mode', False)
            for i, line in enumerate(lines):
                line = line.rstrip('\n\r')
                matched = bool(pattern.search(line))
                
                if invert_match:
                    matched = not matched

                if matched:
                    match_count += 1
                    if not count_only:
                        output = []
                        if print_name:
                            output.append(f"\033[35m{source_name}\033[0m:" if not is_capture else f"{source_name}:")
                        if line_number:
                            output.append(f"\033[32m{i+1}\033[0m:" if not is_capture else f"{i+1}:")
                        
                        if not invert_match:
                            # Highlight match in interactive mode; plain text in pipeline capture mode
                            if is_capture:
                                output.append(line)
                            else:
                                highlighted_line = pattern.sub(lambda m: f"\033[1;31m{m.group(0)}\033[0m", line)
                                output.append(highlighted_line)
                        else:
                            output.append(line)
                            
                        session.print_output("".join(output) + "\n")

            if count_only:
                prefix = f"{source_name}:" if print_name else ""
                session.print_output(f"{prefix}{match_count}\n")

        # 3. Main Logic
        if not files:
            if hasattr(session, 'stdin') and session.stdin:
                lines = session.stdin.splitlines()
                process_lines(lines, "(standard input)", print_name=False)
            else:
                # In a real shell, grep waits for stdin. Here we just return.
                pass
            return

        print_filenames = len(files) > 1

        for filename in files:
            if filename == "-":
                if hasattr(session, 'stdin') and session.stdin:
                    lines = session.stdin.splitlines()
                    process_lines(lines, "(standard input)", print_name=print_filenames)
                continue

            path = session.resolve_path(filename)
            if not os.path.exists(path):
                session.print_output(f"grep: {filename}: No such file or directory\n")
                continue
            if os.path.isdir(path):
                session.print_output(f"grep: {filename}: Is a directory\n")
                continue

            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f:
                    process_lines(f, filename, print_name=print_filenames)
            except Exception as e:
                session.print_output(f"grep: {filename}: {e}\n")
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Ln Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of ln command.
#
# Future features may include:
# - Support for backup (-b)
# - Support for logical/physical (-L, -P)
#============================================================================================

import os

from command_registry import Command

COMMAND_NAME = "ln"
VERSION = "0.1.0"
DESCRIPTION = "Make links between files"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class LnCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... TARGET LINK_NAME\n{DESCRIPTION}\n\nOptions:\n  -s, --symbolic        make symbolic links instead of hard links\n  -f, --force           remove existing destination files\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        clean_args = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)

        symbolic = 's' in flags or '--symbolic' in flags
        force = 'f' in flags or '--force' in flags

        if not clean_args:
            session.print_output("ln: missing file operand")
            return

        target = clean_args[0]
        link_name = clean_args[1] if len(clean_args) > 1 else os.path.basename(target)

        # Resolve paths
        # Note: For symlinks, the target is often stored as-is (relative), but we need absolute for checking existence if hard link
        # However, os.symlink(target, link_name) uses target string literally.
        
        link_path = session.resolve_path(link_name)
        
        # If link_name is a directory, put the link inside it
        if os.path.isdir(link_path):
            link_path = os.path.join(link_path, os.path.basename(target))

        if os.path.exists(link_path) or os.path.islink(link_path):
            if force:
                try:
                    os.remove(link_path)
                except Exception as e:
                    session.print_output(f"ln: cannot remove '{link_name}': {e}")
                    return
            else:
                session.print_output(f"ln: failed to create link '{link_name}': File exists")
                return

        try:
            if symbolic:
                # For symlinks, we usually want to keep the target path as provided by user 
                # if it's relative, so the link works relative to its location.
                # But os.symlink(src, dst) creates a link at dst pointing to src.
                os.symlink(target, link_path)
            else:
                # Hard links require the source to exist and be resolved
                target_path = session.resolve_path(target)
                if not os.path.exists(target_path):
                    session.print_output(f"ln: failed to access '{target}': No such file or directory")
                    return
                os.link(target_path, link_path)
                
        except OSError as e:
            if os.name == 'nt' and symbolic:
                session.print_output(f"ln: failed to create symbolic link '{link_name}': {e}\n(Note: On Windows, Developer Mode must be enabled or run as Administrator)")
            else:
                session.print_output(f"ln: failed to create link '{link_name}': {e}")
        except Exception as e:
            session.print_output(f"ln: error: {e}")
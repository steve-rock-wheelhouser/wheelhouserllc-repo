#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Ps Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of ps command.
#
# Future features may include:
# - Support for filtering by user or PID
# - Support for custom output formats
#============================================================================================

import platform
import subprocess

from command_registry import Command

COMMAND_NAME = "ps"
VERSION = "0.1.0"
DESCRIPTION = "Report a snapshot of the current processes"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class PsCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]...\n{DESCRIPTION}\n\nOptions:\n  --version     output version information and exit\n  --help        display this help and exit")
            return

        # 2. Parse Arguments & Flags
        # Currently ps command does not support complex cross-platform filtering flags in this version.
        # It defaults to listing all processes.
        
        # 3. Main Logic
        system_name = platform.system().lower()
        try:
            cmd_args = []
            
            if system_name == "windows":
                cmd_args = ["tasklist"]
            else:
                # Use standard POSIX syntax for all processes
                cmd_args = ["ps", "-ef"]
            
            # If user provided extra args, we could try to pass them, but they are highly OS specific.
            # For now, we ignore them to ensure stability, or we could append them if we wanted to allow raw access.
            # Given the goal of a unified shell, we stick to the default view for 0.1.0.
            
            process = subprocess.run(
                cmd_args,
                capture_output=True,
                text=True
            )
            
            if process.stdout:
                # On Windows tasklist output can be messy with encoding sometimes, but Python handles it well usually.
                session.print_output(process.stdout.rstrip())
            
            if process.stderr:
                session.print_output(process.stderr.rstrip())
                
        except FileNotFoundError:
            session.print_output(f"ps: required system utility ('{'tasklist' if system_name == 'windows' else 'ps'}') not found.")
        except Exception as e:
            session.print_output(f"ps: error: {e}")
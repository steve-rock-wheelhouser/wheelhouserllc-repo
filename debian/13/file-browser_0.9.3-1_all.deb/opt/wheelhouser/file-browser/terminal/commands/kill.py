#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Kill Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of kill command.
#
# Future features may include:
# - Support for specific signals (-s)
# - Interactive mode
#============================================================================================

import platform
import subprocess

from command_registry import Command

COMMAND_NAME = "kill"
VERSION = "0.1.0"
DESCRIPTION = "Terminate processes by PID or name"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class KillCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... PID|NAME...\n{DESCRIPTION}\n\nOptions:\n  -f, -9, --force       forcefully terminate the process\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        force = False
        targets = []
        
        for arg in args:
            if arg == "-f" or arg == "--force" or arg == "-9":
                force = True
            elif arg.startswith("-") and arg != "-":
                pass # Ignore other flags for now
            else:
                targets.append(arg)

        # 3. Main Logic
        if not targets:
            session.print_output("kill: missing operand")
            return

        system_name = platform.system().lower()

        for target in targets:
            try:
                cmd_args = []
                is_pid = target.isdigit()

                if system_name == "windows":
                    cmd_args = ["taskkill"]
                    if force:
                        cmd_args.append("/F")
                    
                    if is_pid:
                        cmd_args.extend(["/PID", target])
                    else:
                        cmd_args.extend(["/IM", target])
                        # On Windows, names usually need .exe extension for taskkill /IM
                        if not target.lower().endswith(".exe"):
                             cmd_args[-1] += ".exe"
                else:
                    # Unix/Linux/macOS
                    if is_pid:
                        cmd_args = ["kill"]
                        if force:
                            cmd_args.append("-9")
                        cmd_args.append(target)
                    else:
                        cmd_args = ["pkill"]
                        if force:
                            cmd_args.append("-9")
                        cmd_args.append(target)

                process = subprocess.run(cmd_args, capture_output=True, text=True)
                
                if process.stdout:
                    session.print_output(process.stdout.rstrip())
                if process.stderr:
                    session.print_output(process.stderr.rstrip())

            except Exception as e:
                session.print_output(f"kill: error processing '{target}': {e}")
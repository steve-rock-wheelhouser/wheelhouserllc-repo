#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Chmod Command for Wheelhouser Terminal
# Author: Wheelhouser Team
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development and release of chmod command.
#
# Future features may include:
# - Support for full symbolic mode parsing (u+x,go-w)
# - Support for --reference=RFILE
#============================================================================================

import os
import stat

from command_registry import Command

COMMAND_NAME = "chmod"
VERSION = "0.1.0"
DESCRIPTION = "Change file mode bits"

#============================================================================================
# --- Command Implementation ---
#============================================================================================
class ChmodCommand(Command):
    def __init__(self):
        super().__init__(COMMAND_NAME, f"{DESCRIPTION} (v{VERSION})")

    def execute(self, session, args):
        # 1. Handle Standard Flags
        if "--version" in args:
            session.print_output(f"{COMMAND_NAME} (Wheelhouser Terminal) {VERSION}")
            return

        if "--help" in args:
            session.print_output(f"Usage: {COMMAND_NAME} [OPTION]... MODE[,MODE]... FILE...\n{DESCRIPTION}\n\nOptions:\n  -R, --recursive       change files and directories recursively\n  --version             output version information and exit\n  --help                display this help and exit")
            return

        # 2. Parse Arguments & Flags
        flags = set()
        clean_args = []
        
        for arg in args:
            if arg.startswith("-") and arg != "-":
                if arg.startswith("--"):
                    flags.add(arg)
                else:
                    for char in arg[1:]:
                        flags.add(char)
            else:
                clean_args.append(arg)

        recursive = 'R' in flags or '--recursive' in flags

        if len(clean_args) < 2:
            session.print_output("chmod: missing operand")
            return

        mode_str = clean_args[0]
        files = clean_args[1:]

        # Parse Mode
        is_octal = False
        octal_mode = 0
        symbolic_ops = []

        if mode_str.isdigit():
            is_octal = True
            try:
                octal_mode = int(mode_str, 8)
            except ValueError:
                session.print_output(f"chmod: invalid mode: '{mode_str}'")
                return
        else:
            # Basic symbolic parsing: +x, -w, etc. (applies to all)
            # Does not yet support complex scopes like u+x,g-w
            ops = mode_str.split(',')
            for op in ops:
                if '+' in op:
                    parts = op.split('+')
                    symbolic_ops.append(('+', parts[1]))
                elif '-' in op:
                    parts = op.split('-')
                    symbolic_ops.append(('-', parts[1]))
                elif '=' in op:
                    parts = op.split('=')
                    symbolic_ops.append(('=', parts[1]))

        def do_chmod(path):
            try:
                if is_octal:
                    os.chmod(path, octal_mode)
                else:
                    st = os.stat(path)
                    current_mode = stat.S_IMODE(st.st_mode)
                    new_mode = current_mode
                    
                    for op, perms in symbolic_ops:
                        bits = 0
                        if 'r' in perms: 
                            bits |= stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH
                        if 'w' in perms: 
                            bits |= stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH
                        if 'x' in perms: 
                            bits |= stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
                        
                        if op == '+':
                            new_mode |= bits
                        elif op == '-':
                            new_mode &= ~bits
                        elif op == '=':
                            # Simple implementation: set bits, clear others? 
                            # For now, treat = like + but clearing unspecified is complex without scope
                            new_mode = bits
                            
                    os.chmod(path, new_mode)
            except Exception as e:
                session.print_output(f"chmod: changing permissions of '{path}': {e}")

        for filename in files:
            path = session.resolve_path(filename)
            if os.path.exists(path):
                do_chmod(path)
                if recursive and os.path.isdir(path):
                    for root, dirs, files_in_dir in os.walk(path):
                        for name in dirs + files_in_dir:
                            do_chmod(os.path.join(root, name))
            else:
                session.print_output(f"chmod: cannot access '{filename}': No such file or directory")
import os
import sys
import subprocess
from platformdirs import user_data_dir

# Must match APP_NAME and APP_AUTHOR in terminal.py
APP_NAME = "Terminal"
APP_AUTHOR = "WheelhouserLLC"

def open_plugins_folder():
    # Get the data directory
    # Windows: C:\Users\<User>\AppData\Local\WheelhouserLLC\Terminal
    data_dir = user_data_dir(APP_NAME, APP_AUTHOR)
    plugins_dir = os.path.join(data_dir, "plugins")
    
    # Create if it doesn't exist
    fonts_dir = os.path.join(plugins_dir, "fonts")
    themes_dir = os.path.join(plugins_dir, "themes")
    commands_dir = os.path.join(plugins_dir, "commands")
    
    try:
        os.makedirs(plugins_dir, exist_ok=True)
        os.makedirs(fonts_dir, exist_ok=True)
        os.makedirs(themes_dir, exist_ok=True)
        os.makedirs(commands_dir, exist_ok=True)
        print(f"[OK] Created/Verified: {plugins_dir}")
        print(f"[OK] Created/Verified: {fonts_dir}")
        print(f"[OK] Created/Verified: {themes_dir}")
        print(f"[OK] Created/Verified: {commands_dir}")
    except Exception as e:
        print(f"[ERROR] Could not create directories: {e}")
    
    print(f"\nOpening: {plugins_dir}")
    
    # Open in file explorer
    try:
        if sys.platform == 'win32':
            os.startfile(plugins_dir)
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', plugins_dir])
        else:
            subprocess.Popen(['xdg-open', plugins_dir])
    except Exception as e:
        print(f"[ERROR] Could not open folder: {e}")

if __name__ == "__main__":
    open_plugins_folder()
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# This is the client library for connecting to the Wheelhouser AI Orchestrator via WebSockets. It handles
#
#
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
#
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# python.exe -m pip install --upgrade pip
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial version
# 0.2.0 - Added automatic reconnection and heartbeat
# 0.3.0 - Added message queue for sending commands from GUI apps
# 0.4.0 - Improved error handling and logging
# 0.5.0 - Added HTTPS support


import asyncio
import json
import threading
import queue
import websockets
import requests  # type: ignore
import ssl
import urllib3

# Suppress insecure request warnings for local development (since we use self-signed certs)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WheelhouserClient:
    """
    A reusable client for connecting to the Wheelhouser AI Orchestrator via WebSockets.
    Handles automatic reconnection, heartbeats, and command receiving.
    """
    def __init__(self, app_name, host="localhost", port=7800, secure=True):
        self.app_name = app_name
        self.secure = secure
        self.protocol_ws = "wss" if secure else "ws"
        self.protocol_http = "https" if secure else "http"
        self.uri = f"{self.protocol_ws}://{host}:{port}/ws/{app_name}"
        self.api_url = f"{self.protocol_http}://{host}:{port}"
        self.websocket = None
        self.connected = False
        self.callback = None
        self.loop = None
        self.thread = None
        self.running = False
        self.send_queue = queue.Queue()
        self.on_connect = None
        self.on_disconnect = None

    def send_message(self, data):
        """Queues a message to be sent to the Orchestrator."""
        self.send_queue.put(data)

    def set_command_callback(self, callback):
        """Sets the function to call when a command is received from the Orchestrator."""
        self.callback = callback

    def start(self):
        """Starts the connection loop in a background thread."""
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()

    def stop(self):
        """Stops the client connection."""
        self.running = False
        # The loop will eventually exit on next connection attempt or timeout

    def _run_loop(self):
        """Internal method to run the asyncio loop."""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._connect_forever())

    async def _connect_forever(self):
        """Main connection logic with retry."""
        ssl_context = None
        if self.secure:
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

        while self.running:
            try:
                print(f"[{self.app_name}] Connecting to {self.uri}...")
                async with websockets.connect(self.uri, ssl=ssl_context) as websocket:
                    self.websocket = websocket
                    self.connected = True
                    print(f"[{self.app_name}] Connected to Orchestrator.")
                    if self.on_connect:
                        self.on_connect()
                    
                    # Start Heartbeat Task
                    heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                    sender_task = asyncio.create_task(self._sender_loop())
                    
                    try:
                        async for message in websocket:
                            if not self.running:
                                break
                            data = json.loads(message)
                            if self.callback:
                                # Call callback (usually triggers a signal in GUI apps)
                                self.callback(data)
                    except websockets.ConnectionClosed:
                        print(f"[{self.app_name}] Connection lost.")
                    finally:
                        self.connected = False
                        if self.on_disconnect:
                            self.on_disconnect()
                        heartbeat_task.cancel()
                        sender_task.cancel()
            except Exception as e:
                print(f"[{self.app_name}] Connection failed: {e}. Retrying in 5s...")
                await asyncio.sleep(5)

    async def _heartbeat_loop(self):
        """Sends a heartbeat every 10 seconds."""
        while self.running:
            try:
                if self.websocket:
                    await self.websocket.send(json.dumps({"type": "heartbeat"}))
                await asyncio.sleep(10)
            except Exception:
                break

    async def _sender_loop(self):
        """Sends messages from the queue."""
        while self.running and self.connected:
            try:
                while not self.send_queue.empty():
                    msg = self.send_queue.get_nowait()
                    if self.websocket:
                        await self.websocket.send(json.dumps(msg))
                await asyncio.sleep(0.1)
            except Exception:
                break

    def resolve(self, user_input, current_state=None):
        """
        Sends user input to the Orchestrator for intent resolution via HTTP.
        Returns the JSON response containing the command pipeline.
        """
        if current_state is None:
            current_state = {}
        
        # Ensure app_name is in the state so the Orchestrator loads the right manifest
        current_state["app_name"] = self.app_name

        payload = {
            "user_input": user_input,
            "current_state": current_state
        }

        try:
            response = requests.post(f"{self.api_url}/resolve", json=payload, timeout=120, verify=not self.secure)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"[{self.app_name}] Resolution failed: {e}")
            return {"error": str(e), "pipeline": [], "response_text": "Connection error."}
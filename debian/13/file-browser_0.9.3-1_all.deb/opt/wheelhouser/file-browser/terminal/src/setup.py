from setuptools import setup, find_packages  # type: ignore

setup(
    name="wheelhouser-terminal",
    version="0.31.0",
    packages=find_packages(include=['commands', 'commands.*']),
    py_modules=[
        "main",
        "terminal",
        "command_registry",
        "plugin_manager",
        "theme_manager",
        "update_manager"
    ],
    install_requires=[
        "PySide6"
    ]
)

"""Backward compatibility shim exposing TerminalWidget, TerminalMainWindow, and main from src/main.py."""
import sys
import os

# Ensure package root and src are in sys.path
_src_dir = os.path.dirname(os.path.abspath(__file__))
_repo_root = os.path.dirname(_src_dir)
for _p in (_src_dir, _repo_root):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from .main import TerminalWidget, TerminalMainWindow, main
except ImportError:
    from main import TerminalWidget, TerminalMainWindow, main  # type: ignore

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]

if __name__ == "__main__":
    main()

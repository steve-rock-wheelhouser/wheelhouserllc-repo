import os
import sys
import json
import logging
import importlib.util
from PySide6.QtGui import QFontDatabase
from platformdirs import user_data_dir

class PluginManager:
    """
    Manages loading of built-in and plugin-based themes, fonts, and commands.
    """
    def __init__(self, app_name, app_author, built_in_themes):
        self.themes = built_in_themes.copy()
        self.custom_fonts = []
        self.command_plugins = []
        self.plugin_dir = os.path.join(user_data_dir(app_name, app_author), "plugins")
        self.ensure_directories()

    def ensure_directories(self):
        """Creates the plugin directory structure and populates default examples if they don't exist."""
        try:
            themes_dir = os.path.join(self.plugin_dir, "themes")
            fonts_dir = os.path.join(self.plugin_dir, "fonts")
            commands_dir = os.path.join(self.plugin_dir, "commands")
            os.makedirs(themes_dir, exist_ok=True)
            os.makedirs(fonts_dir, exist_ok=True)
            os.makedirs(commands_dir, exist_ok=True)

            # 1. Default theme example (Dracula)
            dracula_path = os.path.join(themes_dir, "dracula.json")
            if not os.path.exists(dracula_path):
                dracula_theme = {
                    "name": "Dracula",
                    "bg": "#282a36",
                    "fg": "#f8f8f2",
                    "ansi": [
                        "#21222c", "#ff5555", "#50fa7b", "#f1fa8c",
                        "#bd93f9", "#ff79c6", "#8be9fd", "#f8f8f2",
                        "#6272a4", "#ff5555", "#50fa7b", "#f1fa8c",
                        "#bd93f9", "#ff79c6", "#8be9fd", "#ffffff"
                    ]
                }
                with open(dracula_path, "w", encoding="utf-8") as f:
                    json.dump(dracula_theme, f, indent=4)
                logging.info(f"Created default theme plugin: {dracula_path}")

            # 2. Default font example
            font_readme = os.path.join(fonts_dir, "README.txt")
            if not os.path.exists(font_readme):
                with open(font_readme, "w", encoding="utf-8") as f:
                    f.write("Place custom TrueType (.ttf) or OpenType (.otf) font files in this folder.\n"
                            "They will be automatically loaded into Wheelhouser Terminal's Font Family preferences.\n")

            has_fonts = any(f.lower().endswith((".ttf", ".otf")) for f in os.listdir(fonts_dir))
            if not has_fonts:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                for candidate in [
                    os.path.join(os.path.dirname(base_dir), "assets", "fonts", "AnonymousPro", "AnonymousPro-Regular.ttf"),
                    os.path.join(base_dir, "assets", "fonts", "AnonymousPro", "AnonymousPro-Regular.ttf"),
                    os.path.join(os.path.dirname(os.path.dirname(base_dir)), "terminal", "assets", "fonts", "AnonymousPro", "AnonymousPro-Regular.ttf")
                ]:
                    if os.path.exists(candidate):
                        import shutil
                        shutil.copy2(candidate, os.path.join(fonts_dir, "AnonymousPro-Regular.ttf"))
                        logging.info(f"Copied example font to: {fonts_dir}")
                        break

            # 3. Default command examples (Python plugin + Shell script plugin)
            hello_cmd_path = os.path.join(commands_dir, "hello.py")
            if not os.path.exists(hello_cmd_path):
                hello_code = '''"""Example Python command plugin for Wheelhouser Terminal."""
from command_registry import Command

class HelloCommand(Command):
    """A sample command plugin that prints a greeting."""
    def __init__(self):
        super().__init__("hello", "Sample plugin: prints a greeting")

    def execute(self, session, args):
        target = " ".join(args) if args else "Wheelhouser user"
        session.print_output(f"\\033[1;36mHello, {target}! This command was loaded from your plugins folder.\\033[0m")

def register(registry):
    registry.register(HelloCommand())
'''
                with open(hello_cmd_path, "w", encoding="utf-8") as f:
                    f.write(hello_code)
                logging.info(f"Created default python command plugin: {hello_cmd_path}")

            sample_sh_path = os.path.join(commands_dir, "sample.sh")
            if not os.path.exists(sample_sh_path):
                sample_sh_code = '''#!/bin/bash
# Example script plugin for Wheelhouser Terminal
# Any executable script in this directory is registered as a terminal command.
echo "Hello from sample script plugin! Arguments: $@"
'''
                with open(sample_sh_path, "w", encoding="utf-8") as f:
                    f.write(sample_sh_code)
                try:
                    os.chmod(sample_sh_path, 0o755)
                except Exception:
                    pass
                logging.info(f"Created default script plugin: {sample_sh_path}")

        except Exception as e:
            logging.error(f"Could not create plugin directories or examples: {e}")

    def load_plugins(self):
        """Loads custom fonts, themes, and commands from the plugin directory."""
        self._load_fonts()
        self._load_themes()
        self._load_command_plugins()
        self._load_script_plugins()

    def load_fonts_from_dir(self, fonts_dir):
        if not os.path.exists(fonts_dir):
            return
        
        for root, _, files in os.walk(fonts_dir):
            for f in files:
                if f.lower().endswith((".ttf", ".otf")):
                    path = os.path.join(root, f)
                    idx = QFontDatabase.addApplicationFont(path)
                    if idx != -1:
                        families = QFontDatabase.applicationFontFamilies(idx)
                        for family in families:
                            if family not in self.custom_fonts:
                                self.custom_fonts.append(family)
                                logging.info(f"Loaded custom font: {family}")
                    else:
                        logging.warning(f"Failed to load font: {path}")

    def _load_fonts(self):
        fonts_dir = os.path.join(self.plugin_dir, "fonts")
        self.load_fonts_from_dir(fonts_dir)

    def _load_themes(self):
        themes_dir = os.path.join(self.plugin_dir, "themes")
        if not os.path.exists(themes_dir):
            return

        for f in os.listdir(themes_dir):
            if f.lower().endswith(".json"):
                try:
                    path = os.path.join(themes_dir, f)
                    with open(path, 'r', encoding='utf-8') as file:
                        data = json.load(file)
                        
                        # Basic validation
                        if "bg" in data and "fg" in data and "ansi" in data:
                            name = data.get("name", os.path.splitext(f)[0])
                            self.themes[name] = data
                            logging.info(f"Loaded custom theme: {name}")
                        else:
                            logging.warning(f"Invalid theme format in {f}")
                except Exception as e:
                    logging.error(f"Error loading theme {f}: {e}")

    def _load_command_plugins(self):
        commands_dir = os.path.join(self.plugin_dir, "commands")
        if not os.path.exists(commands_dir):
            return

        for f in os.listdir(commands_dir):
            if f.endswith(".py"):
                path = os.path.join(commands_dir, f)
                try:
                    spec = importlib.util.spec_from_file_location(f[:-3], path)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        if hasattr(module, "register"):
                            self.command_plugins.append({
                                "file": f,
                                "register": module.register,
                                "status": "Loaded"
                            })
                            logging.info(f"Loaded command plugin: {f}")
                        else:
                            logging.warning(f"Plugin {f} has no 'register' function.")
                except Exception as e:
                    logging.error(f"Failed to load plugin {f}: {e}")
                    self.command_plugins.append({
                        "file": f,
                        "register": None,
                        "status": f"Error: {e}"
                    })

    def _load_script_plugins(self):
        commands_dir = os.path.join(self.plugin_dir, "commands")
        if not os.path.exists(commands_dir):
            return

        supported_exts = {'.sh', '.bat', '.ps1', '.cmd'}
        
        for f in os.listdir(commands_dir):
            name, ext = os.path.splitext(f)
            if ext.lower() in supported_exts:
                path = os.path.join(commands_dir, f)
                
                # Create a closure to capture path and name
                def register_func(registry, cmd_name=name, cmd_path=path, cmd_ext=ext.lower()):
                    class ScriptCommand:
                        def __init__(self):
                            self.name = cmd_name
                            self.description = f"Script Plugin: {os.path.basename(cmd_path)}"
                        
                        def execute(self, session, args):
                            tokens = [cmd_path] + args
                            # On Linux/macOS, explicitly invoke bash for .sh files to avoid permission issues
                            if sys.platform != "win32" and cmd_ext == ".sh":
                                tokens = ["bash", cmd_path] + args
                            session.run_system_command(tokens)

                    registry.register(ScriptCommand())

                self.command_plugins.append({
                    "file": f,
                    "register": register_func,
                    "status": "Loaded (Script)"
                })
                logging.info(f"Loaded script plugin: {f}")

    def register_commands(self, registry):
        for plugin in self.command_plugins:
            try:
                if plugin["register"]:
                    plugin["register"](registry)
            except Exception as e:
                logging.error(f"Error registering plugin commands: {e}")

    def get_theme(self, name):
        return self.themes.get(name)

    def get_theme_names(self):
        return list(self.themes.keys())

    def get_custom_fonts(self):
        return self.custom_fonts
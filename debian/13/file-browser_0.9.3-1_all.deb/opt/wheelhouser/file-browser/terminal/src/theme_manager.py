r"""
c:\Users\floyd\Git\terminal\theme_manager.py
"""
import os
import json
import logging
from PySide6.QtGui import QFontDatabase
from platformdirs import user_data_dir

class ThemeManager:
    """
    Manages loading of built-in and plugin-based themes and fonts.
    """
    def __init__(self, app_name, app_author, built_in_themes):
        self.themes = built_in_themes.copy()
        self.custom_fonts = []
        self.plugin_dir = os.path.join(user_data_dir(app_name, app_author), "plugins")
        self.ensure_directories()

    def ensure_directories(self):
        """Creates the plugin directory structure if it doesn't exist."""
        try:
            os.makedirs(os.path.join(self.plugin_dir, "themes"), exist_ok=True)
            os.makedirs(os.path.join(self.plugin_dir, "fonts"), exist_ok=True)
        except Exception as e:
            logging.error(f"Could not create plugin directories: {e}")

    def load_plugins(self):
        """Loads custom fonts and themes from the plugin directory."""
        self._load_fonts()
        self._load_themes()

    def load_fonts_from_dir(self, fonts_dir):
        if not os.path.exists(fonts_dir):
            return
        
        for root, _, files in os.walk(fonts_dir):
            for f in files:
                if f.lower().endswith((".ttf", ".otf")):
                    path = os.path.join(root, f)
                    idx = QFontDatabase.addApplicationFont(path)
                    if idx != -1:
                        families = QFontDatabase.applicationFontFamilies(idx)
                        for family in families:
                            if family not in self.custom_fonts:
                                self.custom_fonts.append(family)
                                logging.info(f"Loaded custom font: {family}")
                    else:
                        logging.warning(f"Failed to load font: {path}")

    def _load_fonts(self):
        fonts_dir = os.path.join(self.plugin_dir, "fonts")
        self.load_fonts_from_dir(fonts_dir)

    def _load_themes(self):
        themes_dir = os.path.join(self.plugin_dir, "themes")
        if not os.path.exists(themes_dir):
            return

        for f in os.listdir(themes_dir):
            if f.lower().endswith(".json"):
                try:
                    path = os.path.join(themes_dir, f)
                    with open(path, 'r', encoding='utf-8') as file:
                        data = json.load(file)
                        
                        # Basic validation
                        if "bg" in data and "fg" in data and "ansi" in data:
                            name = data.get("name", os.path.splitext(f)[0])
                            self.themes[name] = data
                            logging.info(f"Loaded custom theme: {name}")
                        else:
                            logging.warning(f"Invalid theme format in {f}")
                except Exception as e:
                    logging.error(f"Error loading theme {f}: {e}")

    def get_theme(self, name):
        return self.themes.get(name)

    def get_theme_names(self):
        return list(self.themes.keys())

    def get_custom_fonts(self):
        return self.custom_fonts

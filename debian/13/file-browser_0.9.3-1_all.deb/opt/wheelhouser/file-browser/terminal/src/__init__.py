import sys
import os

# --- CRITICAL FIX ---
# Add this directory to sys.path so that submodules (like commands/*.py) 
# can perform absolute imports of sibling modules (like 'import command_registry')
# This resolves the "ModuleNotFoundError" without rewriting all command files.
package_dir = os.path.dirname(os.path.abspath(__file__))
if package_dir not in sys.path:
    sys.path.insert(0, package_dir)

# Expose the main widget for easy import
# Usage: from terminal import TerminalWidget
try:
    from .main import TerminalWidget, TerminalMainWindow, main
except (ImportError, Exception):
    try:
        from main import TerminalWidget, TerminalMainWindow, main  # type: ignore
    except (ImportError, Exception):
        TerminalWidget = None  # type: ignore
        TerminalMainWindow = None  # type: ignore
        main = None  # type: ignore

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]

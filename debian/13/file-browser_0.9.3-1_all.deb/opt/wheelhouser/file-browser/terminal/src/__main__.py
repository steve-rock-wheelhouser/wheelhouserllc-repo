import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
for p in (current_dir, parent_dir):
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    from main import main
except ImportError:
    try:
        from src.main import main
    except ImportError:
        from terminal.src.main import main  # type: ignore

if __name__ == "__main__":
    main()
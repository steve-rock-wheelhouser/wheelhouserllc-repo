from typing import List, Optional, Any, Dict

class Command:
    """Base class for all terminal commands."""
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description

    def execute(self, session: Any, args: List[str]) -> None:
        raise NotImplementedError

class CommandRegistry:
    """Registry to manage available commands."""
    def __init__(self):
        self._commands: Dict[str, Any] = {}

    def register(self, command: Any) -> None:
        self._commands[command.name] = command

    def get_command(self, name: str) -> Optional[Any]:
        return self._commands.get(name)

    def list_commands(self) -> List[Any]:
        return list(self._commands.values())
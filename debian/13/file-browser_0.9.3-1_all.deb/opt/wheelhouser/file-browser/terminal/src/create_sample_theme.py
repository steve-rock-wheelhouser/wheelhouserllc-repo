import os
import json
from platformdirs import user_data_dir

# Must match APP_NAME and APP_AUTHOR in terminal.py
APP_NAME = "Terminal"
APP_AUTHOR = "WheelhouserLLC"

def create_sample_theme():
    # 1. Determine the directory
    # On Windows: C:\Users\<User>\AppData\Local\WheelhouserLLC\Terminal\plugins\themes
    base_dir = user_data_dir(APP_NAME, APP_AUTHOR)
    themes_dir = os.path.join(base_dir, "plugins", "themes")
    
    # 2. Ensure directory exists
    os.makedirs(themes_dir, exist_ok=True)
    
    # 3. Define the theme (Dracula)
    dracula_theme = {
        "name": "Dracula",
        "bg": "#282a36",
        "fg": "#f8f8f2",
        "ansi": [
            "#21222c", # Black
            "#ff5555", # Red
            "#50fa7b", # Green
            "#f1fa8c", # Yellow
            "#bd93f9", # Blue
            "#ff79c6", # Magenta
            "#8be9fd", # Cyan
            "#f8f8f2", # White
            "#6272a4", # Bright Black
            "#ff5555", # Bright Red
            "#50fa7b", # Bright Green
            "#f1fa8c", # Bright Yellow
            "#bd93f9", # Bright Blue
            "#ff79c6", # Bright Magenta
            "#8be9fd", # Bright Cyan
            "#ffffff"  # Bright White
        ]
    }
    
    # 4. Write the file
    file_path = os.path.join(themes_dir, "dracula.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(dracula_theme, f, indent=4)
        
    print(f"Successfully created theme file at:\n{file_path}")
    print("\nRestart the Terminal app, and look for 'Dracula' in the Hamburger -> Theme menu.")

if __name__ == "__main__":
    create_sample_theme()
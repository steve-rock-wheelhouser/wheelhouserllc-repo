"""Compatibility shim exposing TerminalWidget and main entrypoint for embedded terminal integration."""
import sys
import os

_dir = os.path.dirname(os.path.abspath(__file__))
_src = os.path.join(_dir, "src")
for _p in (_dir, _src):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from .src.main import TerminalWidget, TerminalMainWindow, main
except (ImportError, Exception):
    try:
        from src.main import TerminalWidget, TerminalMainWindow, main  # type: ignore
    except (ImportError, Exception):
        TerminalWidget = None  # type: ignore
        TerminalMainWindow = None  # type: ignore
        main = None  # type: ignore

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]

if __name__ == "__main__":
    if callable(main):
        main()

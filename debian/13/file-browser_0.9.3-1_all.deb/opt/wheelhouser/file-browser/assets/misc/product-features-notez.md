# Notez - Feature Highlights

**Notez** is a professional, vector-based note-taking application designed for creative professionals and students. Built with a sleek dark-themed interface, it offers a distraction-free environment for sketching, writing, and organizing ideas.

## 🎨 Powerful Drawing Tools
*   **Vector Precision**: Every stroke is stored as a vector object, ensuring your notes look crisp at any zoom level and can be manipulated individually.
*   **Versatile Pen Tool**:
    *   **Custom Colors**: Choose any color from a full spectrum palette. Your custom colors are saved automatically for your next session.
    *   **Adjustable Width**: Fine-tune your line thickness with a touch-friendly slider (1px - 20px).
    *   **Line Styles**: Switch between Solid, Dashed, Dotted, and Dash-Dot lines for diagrams and technical drawings.
*   **Smart Eraser**: Quickly remove mistakes by dragging over strokes. The eraser intelligently detects and removes entire vector paths.

## ✂️ Advanced Selection & Editing
*   **Lasso Tool**: Draw a loop around any set of notes to select them instantly.
*   **Move & Arrange**: Drag selected items anywhere on the canvas.
*   **Batch Editing**: Change the color, width, or style of multiple selected items at once.
*   **Easy Selection**: Click anywhere within a drawing's bounding box to select it—no need to trace the exact line.
*   **Object Deletion**: Double-click any object while using the Lasso tool to bring up a quick "Delete Object" button, or use the Delete key for selected groups.

## 📝 Note Management
*   **Unlimited Notes**: Create as many separate note pages as you need.
*   **Auto-Save**: Never lose your work. Notez saves your changes instantly as you draw and persists them across application restarts.
*   **Rename & Organize**: Double-click note names in the sidebar to rename them for better organization.
*   **Safe Deletion**: Includes a confirmation dialog to prevent accidental deletion of entire notes.

## ↩️ Workflow & Usability
*   **Undo / Redo System**: Full support for Undo (Ctrl+Z) and Redo (Ctrl+Y), allowing you to experiment fearlessly. Dedicated toolbar buttons are included for tablet users.
*   **Touch-Optimized UI**: Buttons, sliders, and inputs are sized 20% larger to ensure comfortable use with fingers or styluses on touchscreens.
*   **Dark Mode**: A custom-engineered dark theme reduces eye strain during late-night study or design sessions.

## 📤 Export & Sharing
*   **Smart PNG Export**: Export your notes to high-quality PNG images.
*   **Auto-Naming**: The export filename defaults to your note's name.
*   **Directory Memory**: The app remembers your last save location, streamlining your workflow.
*   **Intelligent Cropping**: The export function automatically detects the bounds of your drawing, ensuring no wasted empty space in the final image.

***

### Technical Specifications
*   **Platform**: Windows, Linux, macOS (Python/PySide6 based).
*   **Storage**: JSON-based local storage in the user's AppData directory.
*   **Graphics Engine**: Hardware-accelerated QGraphicsScene for smooth performance with complex drawings.
<p align="center">
  <img src="assets/banner.svg" alt="Wheelhouser Git Tools Banner" width="100%" />
</p>

# Wheelhouser Git Tools - Enterprise Cross-Platform Automation Suite

[![Wheelhouser LLC](https://img.shields.io/badge/Enterprise-Wheelhouser%20LLC-blue)](https://wheelhouser.com)
[![Version](https://img.shields.io/badge/version-1.5.0-emerald.svg)](.release_version)
[![Cross-Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20%7C%20Windows-purple.svg)](README.md)
[![License](https://img.shields.io/badge/license-GPL--3.0-blue.svg)](LICENSE)

A unified, enterprise-grade Git workflow and automation suite developed for **Wheelhouser LLC**. Provides standardized, cross-platform implementations of `push`, `pull`, and management CLI tooling across Linux, macOS, and Windows.

---

## 🎯 Purpose & Open-Source Decoupling

In legacy setups, individual repositories maintained local copies of `push.sh`, `pull.sh`, `push.ps1`, and `pull.ps1` in their root directories. When publishing repositories as open-source, shipping these internal scripts creates repository clutter and exposes internal development patterns.

**Wheelhouser Git Tools** centralizes all push/pull automation into a single, installable developer environment:
1. **Centralized Maintenance**: A single repository to maintain, audit, and improve workflow scripts.
2. **System-Wide Accessibility**: Commands (`push`, `pull`, `push.sh`, `pull.sh`, `push.ps1`, `pull.ps1`) are available globally from any repository on your machine.
3. **Open-Source Cleanliness**: Enables stripping local scripts from open-source repositories via `git-tools clean-repo`.
4. **Automated Security**: Built-in pre-commit credential leak protection preventing accidental commits of `.key`, `.pem`, `.p12`, `.env`, or private keys.
5. **Clean Public-Ready Architecture**: All build, packaging, and installer scripts are isolated into designated `build-linux/`, `build-mac/`, and `build-msix/` directories. The repository root contains zero build scripts and zero sensitive credentials, allowing it to transition seamlessly to a public open-source repository without hiding or scrubbing code.

---

## 🚀 Quickstart & Installation

Wheelhouser Git Tools supports one-command installation across all major developer platforms.

### Linux & macOS

Run the native installation script from `build-linux/`:

```bash
# User-level installation (installs to ~/.local/bin and configures Git aliases)
./build-linux/install.sh

# Or system-wide installation (requires root / sudo)
sudo ./build-linux/install.sh --system
```

Alternatively, use the `git-tools` CLI directly:
```bash
python3 src/git-tools install
```

### Windows (PowerShell & CMD)

Open PowerShell and execute the installer from `build-msix/`:

```powershell
# From the repository root in PowerShell:
.\build-msix\install.ps1
```

This will:
1. Copy all command shims (`push.ps1`, `pull.ps1`, `push.cmd`, `pull.cmd`, `push.sh`, `pull.sh`, `git-tools.cmd`) to your user bin directory (`%LOCALAPPDATA%\Programs\git-tools\bin` or `~/bin`).
2. Permanently register the installation directory in your Windows User `PATH`.
3. Configure global Git aliases (`git push-repo` and `git pull-repo`).
4. Enable immediate command execution across PowerShell, Command Prompt (CMD), Git Bash, and Windows Terminal.

---

## 💻 Daily Usage

Once installed, you can run `push` and `pull` from **any** Git repository on your system.

### 1. Pushing Changes (`push`)

```bash
# Interactive prompt for commit message
push

# Direct commit message
push "feat(auth): add MFA support"

# Flag format
push -m "fix(styles): resolve header padding on mobile"

# Safe force-push (verifies remote ref has not moved)
push --force-with-lease "refactor: simplify data pipeline"

# Force push
push --force "hotfix: overwrite remote branch"

# Bypass pre-commit secret audit (if intentionally committing an example .env.example)
push --allow-sensitive -m "docs: add environment sample"
```

#### Windows PowerShell:
```powershell
push "feat: implement native windows tray icon"
push -ForceWithLease "refactor: update build configs"
```

### 2. Pulling Updates (`pull`)

```bash
# Fetch and pull with fast-forward priority; prompts to stash uncommitted changes
pull

# Automatically stash uncommitted changes and pop them after pull
pull --autostash

# Pull with rebase
pull --rebase

# Force sync (hard reset to origin/<branch> and clean untracked files)
pull --force
```

#### Windows PowerShell:
```powershell
pull
pull -AutoStash
pull -Rebase
pull -Force
```

### 3. Bi-Directional Synchronization (`sync`)

Performs an atomic bi-directional sync: autostashes and pulls remote changes, audits modified files for credentials, stages all changes, and pushes with automatic upstream branch tracking.

```bash
# Full bi-directional sync with commit prompt
sync

# Sync with explicit commit message
sync "feat(api): connect telemetry endpoint"
sync -m "fix(cli): resolve flag parsing"

# Force push during sync (or force-with-lease)
sync --force-with-lease "refactor: optimize database query"
```

#### Windows PowerShell:
```powershell
sync "feat: update telemetry client"
```

### 4. Safe Commit Rollback (`undo`)

Safely rolls back the most recent commit (`git reset --soft HEAD~1`), preserving all modified and added files safely staged in your working tree:

```bash
# Soft undo: rollback commit, keep all file modifications staged
undo

# Hard undo: permanently discard the last commit and its file modifications
undo --hard -y
```

#### Windows PowerShell:
```powershell
undo
undo -Hard -Yes
```

### 5. Terminal Commit Topology (`graph`)

Renders a compact, colorized visual ASCII graph of the entire repository history across all branches:

```bash
# View complete commit topology
git-tools graph

# View last 10 commits on topology graph
git-tools graph -n 10
```

### 6. Multi-Repository Fleet Management (`fleet-status` & `fleet-pull`)

Provides high-level workspace visibility and bulk operations across dozens of Git repositories:

```bash
# Instant workspace dashboard: shows branch, clean/dirty state, ahead/behind delta, and last commit
git-tools fleet-status ~/Projects

# Bulk synchronize all repositories across your workspace with autostash rebase
git-tools fleet-pull ~/Projects
```

### 7. Branch Hygiene (`prune-branches`)

Safely prunes local branches that have already been merged into `main` or `master`, while automatically protecting critical branches (`main`, `master`, `dev`, `release*`):

```bash
# Preview branches that would be deleted
git-tools prune-branches --dry-run

# Prune merged branches
git-tools prune-branches
```

### 8. Credential & Secret Audit (`scan-secrets`)

Comprehensive pre-flight security scanner auditing working tree and git commit history for private keys, AWS tokens, GitHub PATs, and sensitive file extensions:

```bash
# Scan current repository
git-tools scan-secrets

# Scan working tree only (skipping history)
git-tools scan-secrets --no-history

# Scan deep into commit history
git-tools scan-secrets --depth 50
```

### 9. Git Command Aliases

Git global aliases are automatically configured upon installation:
```bash
git push-repo "chore: update documentation"
git pull-repo
git sync-repo "feat: ship update"
git undo-commit
```

### 10. Repository Initialization (`init`)

Standardizes new Git repositories with default `main` branch, Wheelhouser Rule 13 local overrides (`*.local.sh`, `.local/`), language-tailored `.gitignore`, and initial commit:

```bash
# Initialize current directory with default main branch
git-tools init

# Initialize a new project directory with remote origin and Python gitignore preset
git-tools init my-new-app --branch main --remote git@github.com:wheelhouser/my-new-app.git --type python
```

### 11. Intelligent Branch Merging & Conflict Diagnostics (`merge` & `conflicts`)

Safe, verifiable merge workflows with pre-merge test execution (Rule 9), non-destructive conflict simulation via `git merge-tree`, and automated branch pruning:

```bash
# Simulate merge cleanly without touching working tree or staging index
git-tools merge feature-auth --dry-run

# Squash merge with custom commit message and automatic branch pruning
git-tools merge feature-auth --strategy squash -m "feat: implement OAuth2 authentication" --prune

# Fast-forward only merge for upstream synchronization
git-tools merge origin/main --strategy ff

# Scan working tree for unresolved merge conflicts
git-tools conflicts
```

### 12. Wheelhouser Standard Project Scaffolding & Compliance (`scaffold` & `audit-compliance`)

Instantiate canonical project structures adhering to all 13 rules of the Canonical Wheelhouser Development Policy (`AGENTS.md`), including test runners, packaging specs, security templates, and bug tracking hierarchies:

```bash
# Scaffold a brand new Python desktop or CLI application
git-tools scaffold audio-mixer --type python --license gpl

# Retrofit an existing repository to canonical standards without overwriting existing code
git-tools scaffold --existing

# Inspect repository compliance against all 13 canonical development rules
git-tools audit-compliance
```

---

## 📦 Packaging & Orchestra Automated Builds

All packaging logic is encapsulated in `build-*` directories, conforming to Orchestra multi-platform build automation:

### Linux Packaging (`build-linux/`)
```bash
# Build native RPM package (Fedora, Rocky Linux, AlmaLinux)
./build-linux/build_rpm.sh

# Build native DEB package (Debian 13, Ubuntu 24.04/26.04 LTS)
./build-linux/build_deb.sh
```
Outputs are routed to `build-linux/Output/` and `dist/`.

### macOS Packaging (`build-mac/`)
```bash
# Build macOS distribution and DMG installer
./build-mac/build_mac.sh -a all
```
Outputs `.dmg` installer packages to `build-mac/Output/` and `dist/`.

### Windows MSIX Packaging (`build-msix/`)
```powershell
# Build Windows MSIX sideload packages
powershell -ExecutionPolicy Bypass -File .\build-msix\build_msix.ps1
```
Outputs `.msix` packages directly to `build-msix\`.

---

## 🧹 Migrating & Cleaning Open-Source Repositories

Use the built-in audit and cleaning tools to inspect and strip legacy scripts from repositories intended for open-source:

```bash
# Audit a workspace directory to see which repos contain legacy scripts
git-tools audit-repos ~/Projects

# Preview which files would be removed from a specific repository (dry-run)
git-tools clean-repo /path/to/my-repo --dry-run

# Remove legacy scripts and stage changes in git
git-tools clean-repo /path/to/my-repo

# Clean all child repositories under a parent directory
git-tools clean-repo ~/Projects --all
```

---

## 🛡️ Pre-Commit Security Checks

Before staging and committing, both `push.sh` and `push.ps1` perform an automatic scan of untracked and modified files for sensitive files:
- Private keys (`.key`, `.pem`, `id_rsa`, `id_ed25519`)
- Certificates and PKCS stores (`.p12`, `.pfx`, `.pkcs12`, `.asc`)
- Environment secret files (`.env`, `.env.local`, `.env.production`)

If sensitive files are detected, the push aborts immediately with a clear report, safeguarding Wheelhouser repositories from accidental credential leaks.

---

## 📁 Repository Layout

```text
git-tools/
├── .release_version          # Application semantic release version
├── AGENTS.md                 # Wheelhouser Version Bump & Changelog Policy
├── LICENSE                   # Wheelhouser LLC Proprietary License
├── README.md                 # Complete documentation
├── pyrightconfig.json        # Python language server extra paths config
├── assets/                   # Branding and marketing assets (.gitkeep)
├── bug-reports/              # QA ticketing and issue tracking system
├── epics/                    # Architectural specs and design walk-throughs
├── build-linux/              # Linux native packaging & desktop integration
│   ├── com.wheelhouser.git-tools.desktop       # XDG Desktop entry for GNOME / desktop environments
│   ├── com.wheelhouser.git-tools.metainfo.xml  # AppStream metadata for GNOME Software
│   ├── git-tools.spec        # RPM spec file
│   ├── build.sh              # Master Linux builder (RPM, DEB, and Desktop launcher)
│   ├── build_desktop.sh      # Linux desktop launcher builder & deployer
│   ├── build_rpm.sh          # RPM builder for Rocky / Fedora / Alma
│   ├── build_deb.sh          # DEB builder for Debian / Ubuntu
│   ├── install.sh            # Linux installer (installs shims, desktop entry & icons)
│   └── uninstall.sh          # Linux uninstaller (cleans shims, desktop entry & icons)
├── build-mac/                # macOS DMG packaging suite
│   ├── build_mac.sh          # macOS builder & DMG packager
│   └── build.sh              # macOS build runner wrapper
├── build-msix/               # Windows MSIX packaging suite
│   ├── AppxManifest.xml      # MSIX application manifest
│   ├── build_msix.ps1        # Windows MSIX packaging script
│   ├── build_msix.bat        # Windows batch wrapper
│   ├── install.ps1           # Windows installer
│   └── uninstall.ps1         # Windows uninstaller
├── src/
│   ├── push.sh               # Canonical POSIX Bash push script
│   ├── pull.sh               # Canonical POSIX Bash pull script
│   ├── sync.sh               # Canonical POSIX Bash bi-directional sync script
│   ├── undo.sh               # Canonical POSIX Bash safe commit undo script
│   ├── push.ps1              # Canonical Windows PowerShell push script
│   ├── pull.ps1              # Canonical Windows PowerShell pull script
│   ├── sync.ps1              # Canonical Windows PowerShell sync script
│   ├── undo.ps1              # Canonical Windows PowerShell undo script
│   ├── push.cmd              # Windows Command Prompt push wrapper
│   ├── pull.cmd              # Windows Command Prompt pull wrapper
│   ├── sync.cmd              # Windows Command Prompt sync wrapper
│   ├── undo.cmd              # Windows Command Prompt undo wrapper
│   ├── main.py               # Standardized Python entry point (python3 src/main.py)
│   ├── main.sh               # Standardized Shell entry point (./src/main.sh)
│   ├── git-tools             # Executable CLI launcher
│   ├── git-tools-launcher    # Interactive terminal dashboard launcher
│   ├── git-tools.cmd         # Windows CLI wrapper
│   └── git_tools/            # Python CLI package
│       ├── __init__.py
│       ├── version.py        # Version constant & changelog entry
│       ├── installer.py      # Cross-platform installation and shim logic
│       ├── cleaner.py        # Open-source repo audit & cleaner engine
│       ├── branch.py         # Merged branch hygiene & protection logic
│       ├── fleet.py          # Multi-repository workspace dashboard & bulk pull
│       ├── security.py       # Standalone credential & leak audit scanner
│       └── cli.py            # Command-line interface router
└── tests/                    # Automated integration & unit test suite
    ├── test_push_pull.sh     # Bash integration test harness
    └── test_cli.py           # Python CLI unit tests
```

---

## 📜 Version Change Log

- **1.3.0** (2026-09-29):
  - Released as free and open-source software under the GNU General Public License v3.0 (`GPL-3.0-or-later`).
  - Added visual branch topology inspector (`git-tools branches`) and one-touch branch switching/creation (`git-tools switch [-c]`) with interactive dashboard integration (`[b] Branches`).
  - Added configurable default projects root (`~/Projects/`) on Linux/macOS and `%USERPROFILE%\Projects` on Windows with self-healing fallback to home directory (`~/`) upon failure or path deletion.
  - Enabled non-blocking `<ESC>` keypress interception in commit prompts that cancels cleanly without leaking raw escape characters (`^[`) to the terminal.
  - Rendered commit message prompts directly to `/dev/tty` so prompts are never swallowed in subshell captures.
  - Packaged Python `git_tools/` module directory alongside CLI binary shims into `~/.local/bin/` with multi-path import fallbacks.
  - Expanded pre-flight security scanner rules (KeePass `.kdbx`, SSH DSA/ECDSA keys, Slack incoming webhooks, Slack tokens) and added dedicated `.SH PRE-COMMIT SECURITY & CREDENTIAL SCANNING` section to `man/git-tools.8`.
  - Added comprehensive GNOME Software Center AppStream metainfo with store hero banner (`1920x1080`) and feature showcase screenshots.

- **1.2.0** (2026-09-29):
  - Added persistent projects root configuration (`~/.config/git-tools/config.json`) defaulting to `~/Projects/` on Linux/macOS and user profile on Windows.
  - Added interactive project navigator with real-time `Up` and `Down` arrow key selection and Git branch/sync status previews.
  - Standardized pop-up terminal application name to `git-tools` (replacing `git-tools-launcher`).
  - Added `git-tools config` and `git-tools dashboard` commands to CLI and manual pages.

- **1.1.4** (2026-09-29):
  - Automated build script version resolution to inherit `VERSION` directly from `src/main.py`.
  - Added native system manual page (`man/git-tools.8`) installed across Linux/macOS and packaged in RPM and Debian archives.
  - Added pre-build metafile linters (`desktop-file-validate`, `appstreamcli validate --pedantic`, and `groff` syntax checks) and `rpmlint` post-validation.
  - Generated native multi-resolution Windows (`icon.ico`) and macOS (`icon.icns`) assets.

- **1.1.3** (2026-09-29):
  - Eliminated duplicate desktop launcher icons by removing redundant `com.wheelhouser.git-tools.desktop` symlinks in applications and dock favorites.
  - Standardized on a single launcher entry (`git-tools.desktop`) in line with the `auto-updates` template.
  - Pruned orphaned launchers from GNOME dock favorites (`org.gnome.shell favorite-apps`) on uninstallation.
  - Set `DO_INSTALL=false` by default in `build_desktop.sh` to ensure package builds do not pollute local user directories.

- **1.1.2** (2026-09-29):
  - Standardized desktop launcher, icon packaging, and AppStream metadata modeled after `auto-updates`.
  - Separated non-RDNN desktop launcher and icon (`git-tools`, `git-tools.desktop`, `git-tools.svg`) from RDNN Software Center integration (`com.wheelhouser.git-tools`).
  - Added desktop validation via `desktop-file-utils` and dual-icon scalable assets.

- **1.1.1** (2026-09-29):
  - Added dedicated Linux desktop launcher builder (`build-linux/build_desktop.sh`) and master build runner (`build-linux/build.sh`).
  - Integrated automated desktop launcher packaging into RPM build pipeline (`build-linux/build_rpm.sh`).
  - Added direct Desktop launcher deployment (`~/Desktop/com.wheelhouser.git-tools.desktop`) with GNOME metadata trust.
  - Hardened unit test sandbox isolation to protect local user desktop environments.

- **1.1.0** (2026-09-29):
  - Added standard `src/main.py` and `src/main.sh` application entry points.
  - Implemented strict Wheelhouser LLC version synchronization across all primary entry points (`src/git_tools/version.py`, `src/push.sh`, `src/pull.sh`, `src/sync.sh`, `src/undo.sh`, `src/push.ps1`, `src/pull.ps1`, `src/sync.ps1`, `src/undo.ps1`).
  - Added XDG desktop entry (`build-linux/com.wheelhouser.git-tools.desktop`) and AppStream metainfo (`build-linux/com.wheelhouser.git-tools.metainfo.xml`) for GNOME Software and Settings integration.
  - Introduced `git-tools-launcher` interactive terminal dashboard for the desktop application grid.
  - Updated RPM, Debian, and MSIX manifests to 1.1.0.
  - Archived architectural epic documentation in `epics/2026-09-29-git-automation-suite-expansion-and-desktop-integration/`.

- **1.0.1** (2026-09-29):
  - Multi-platform packaging validation and repository synchronization.

- **1.0.0** (2026-09-29):
  - Initial centralized release for cross-platform Git automation suite.


---

## 🖥️ GNOME Software & Desktop Integration

Wheelhouser Git Tools includes complete freedesktop.org XDG Desktop Entry and AppStream Metainfo specifications:
- **GNOME Software**: Discovered and managed natively. Displays rich product descriptions, developer information (Wheelhouser LLC), version numbers, and one-click uninstallation.
- **GNOME Settings (`Settings -> Apps`)**: Fully indexed as an installed application, showing permissions, storage usage, and system registration.
- **Interactive Terminal Launcher**: Launching "Git Tools" from the desktop application grid launches an interactive status dashboard providing quick actions for fleet monitoring, security scans, commit topology, and branch hygiene.

---

## 🧪 Testing

Run the automated test suite to verify script functionality and security safeguards:

```bash
# Run bash integration tests (creates isolated temporary git repos)
bash tests/test_push_pull.sh

# Run Python CLI tests
python3 -m unittest discover -s tests
```

---

## 📄 License & Compliance

Released as free and open-source software under the [GNU General Public License v3.0 (GPL-3.0-or-later)](file:///home/studio/Projects/git-tools/LICENSE).
Copyright © 2026 Wheelhouser LLC. All rights reserved.
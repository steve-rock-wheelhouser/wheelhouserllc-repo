<#
.SYNOPSIS
    Wheelhouser Git Tools - sync.ps1
.DESCRIPTION
    Unified bi-directional Git synchronization:
    1. Safely pulls incoming remote changes with autostash rebase.
    2. Runs pre-flight security scan and stages changes.
    3. Commits and pushes to remote with automatic upstream tracking.
.PARAMETER Message
    Commit message to apply to outgoing changes.
.PARAMETER Force
    Force push to remote branch.
.PARAMETER ForceWithLease
    Safer force push verifying remote ref has not diverged.
.PARAMETER AllowSensitive
    Bypass pre-commit security audit for sensitive files.
.PARAMETER Help
    Displays command reference.
.PARAMETER Version
    Displays version information.
#>

# Version Change Log:
# 1.3.0 - Released as GPLv3. Added push cancellation handling and dynamic version inheritance.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.1 - Initial release of unified bi-directional sync automation for PowerShell.

[CmdletBinding()]
param(
    [Parameter(Position = 0, Mandatory = $false)]
    [string]$Message,

    [switch]$Force,
    [switch]$ForceWithLease,
    [switch]$AllowSensitive,
    [switch]$Help,
    [switch]$Version
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainPy = Join-Path $ScriptDir "main.py"
$VERSION = "1.6.0"
if (Test-Path $MainPy) {
    $match = Select-String -Path $MainPy -Pattern '^VERSION\s*=\s*["'']([^"'']+)["'']'
    if ($match -and $match.Matches.Groups.Count -gt 1) {
        $VERSION = $match.Matches.Groups[1].Value
    }
}
$APP_VERSION = $VERSION

if ($Help) {
    Write-Host "Wheelhouser Git Tools - Unified Sync Automation (v$APP_VERSION)" -ForegroundColor Cyan
    Write-Host "`nUsage: sync [options] [commit message]" -ForegroundColor Yellow
    Write-Host "       sync.ps1 [options] [commit message]`n" -ForegroundColor Yellow
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -Message <msg>      Specify commit message for outgoing changes."
    Write-Host "  -Force              Force push to remote branch."
    Write-Host "  -ForceWithLease     Safer force push verifying remote ref has not diverged."
    Write-Host "  -AllowSensitive     Bypass pre-commit security audit for sensitive files."
    Write-Host "  -Help               Show this documentation."
    Write-Host "  -Version            Show script version."
    exit 0
}

if ($Version) {
    Write-Host "sync (Wheelhouser Git Tools) v$APP_VERSION"
    exit 0
}

$ErrorActionPreference = "Stop"

# Locate sibling pull and push scripts
$ScriptDir = $PSScriptRoot
$PullScript = Join-Path $ScriptDir "pull.ps1"
$PushScript = Join-Path $ScriptDir "push.ps1"

if (-not (Test-Path $PullScript) -or -not (Test-Path $PushScript)) {
    Write-Host "❌ Error: Required pull.ps1 and push.ps1 could not be located." -ForegroundColor Red
    exit 1
}

# Step 1: Pull incoming changes
Write-Host "==================================================================" -ForegroundColor DarkCyan
Write-Host "🔄 [1/2] Pulling incoming updates from remote..." -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor DarkCyan

& $PullScript -AutoStash

# Step 2: Push local changes
Write-Host "==================================================================" -ForegroundColor DarkCyan
Write-Host "🔄 [2/2] Staging, inspecting, and pushing local changes..." -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor DarkCyan

$pushArgs = @()
if ($Message) { $pushArgs += "-Message"; $pushArgs += $Message }
if ($Force) { $pushArgs += "-Force" }
if ($ForceWithLease) { $pushArgs += "-ForceWithLease" }
if ($AllowSensitive) { $pushArgs += "-AllowSensitive" }

& $PushScript @pushArgs

Write-Host "==================================================================" -ForegroundColor DarkGreen
Write-Host "✅ [SUCCESS] Repository is in full sync with remote!" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor DarkGreen

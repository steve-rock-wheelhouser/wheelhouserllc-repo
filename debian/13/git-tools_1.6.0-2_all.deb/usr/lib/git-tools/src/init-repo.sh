#!/usr/bin/env bash
# ==============================================================================
# src/init-repo.sh - Wheelhouser Git Tools Repository Initializer
# Version: 1.6.0
#
# Version Change Log:
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Initial implementation of repository initialization shim.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="$(command -v python3 || command -v python || true)"

if [ -z "${PYTHON_BIN}" ]; then
    echo "❌ Error: Python 3 is required to run git-tools init." >&2
    exit 1
fi

exec "${PYTHON_BIN}" "${SCRIPT_DIR}/main.py" init "$@"

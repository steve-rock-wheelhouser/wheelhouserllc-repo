#!/usr/bin/env bash
#
# Wheelhouser Git Tools - main.sh
# Version: 1.6.0
#
# Primary Shell Entry Point for Wheelhouser Git Tools cross-platform suite.
#
# Version Change Log:
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs.
# 1.3.0 - Released as GPLv3. Added projects root fallback, ESC commit abort, and AppStream store hero banner.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Eliminate duplicate desktop launcher in applications and dock favorites.
# 1.1.2 - Standardize desktop launcher, icon packaging, and AppStream metadata modeled after auto-updates.
# 1.1.1 - Add Linux desktop launcher builder (build_desktop.sh), master build runner (build.sh), and sandbox isolation.
# 1.1.0 - Add standard src/main.sh entry point with command router and version synchronization.
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.0.0}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Command Line Interface (v${VERSION})

Usage: ./src/main.sh <command> [options]
       ./src/main.sh [options]

Core Commands:
  push [options] [msg]    Stage, security scan, commit, and push branch
  pull [options]          Pull remote branch with autostash and rebase
  sync [options] [msg]    Bi-directional sync (pull incoming, stage, commit, push)
  undo [--hard]           Undo most recent commit (soft by default)
  graph [options]         Visual topology graph with branch lanes and commit hashes
  fleet [options]         Multi-repository workspace scanner and bulk sync
  security [path]         Standalone sensitive credential and secret scanner
  branch [options]        Clean up merged local branches with safety protections
  clean-repo [path]       Remove local push/pull scripts for open-source publishing
  purge-history <path>    Permanently excise file/folder from Git history and GC packfiles
  install [options]       Install global CLI shims and desktop metadata
  uninstall [options]     Remove global CLI shims and desktop integration

Options:
  -v, --version           Show application version
  -h, --help              Show this documentation

EOF
}

if [[ $# -eq 0 ]]; then
    show_help
    exit 0
fi

case "$1" in
    -v|--version|version)
        echo "Wheelhouser Git Tools v${VERSION}"
        exit 0
        ;;
    -h|--help|help)
        show_help
        exit 0
        ;;
    push)
        shift
        exec "${SCRIPT_DIR}/push.sh" "$@"
        ;;
    pull)
        shift
        exec "${SCRIPT_DIR}/pull.sh" "$@"
        ;;
    sync|git-sync)
        shift
        exec "${SCRIPT_DIR}/sync.sh" "$@"
        ;;
    undo)
        shift
        exec "${SCRIPT_DIR}/undo.sh" "$@"
        ;;
    *)
        # Delegate to Python CLI
        exec /usr/bin/env python3 "${SCRIPT_DIR}/main.py" "$@"
        ;;
esac

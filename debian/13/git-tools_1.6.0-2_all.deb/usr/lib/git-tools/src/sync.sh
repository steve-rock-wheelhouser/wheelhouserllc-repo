#!/usr/bin/env bash
#
# Wheelhouser Git Tools - sync.sh
# Version: 1.6.0
#
# Unified bi-directional Git synchronization:
# 1. Safely pulls incoming remote changes with autostash rebase.
# 2. Runs pre-flight security scan and stages changes.
# 3. Commits and pushes to remote with automatic upstream tracking.
#
# Version Change Log:
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs.
# 1.3.0 - Released as GPLv3. Added push abort error handling and dynamic version resolution.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.1 - Initial release of unified bi-directional sync automation.
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.6.0}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Unified Sync Automation (v${VERSION})

Usage: sync [options] [commit message]
       ./sync.sh [options] [commit message]

Options:
  -m, --message <msg>   Specify commit message for outgoing changes.
  -f, --force           Force push to remote branch (git push --force).
  --force-with-lease    Safer force push verifying remote ref has not diverged.
  --allow-sensitive     Bypass pre-commit security audit for sensitive files.
  -h, --help            Show this help documentation.
  -v, --version         Show script version.

Examples:
  sync
  sync "feat: ship new feature updates"
  sync -m "fix: resolve edge case"
EOF
}

# Locate sibling pull and push scripts
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PULL_CMD=""
PUSH_CMD=""

if [ -f "${SCRIPT_DIR}/pull.sh" ] && [ -x "${SCRIPT_DIR}/pull.sh" ]; then
    PULL_CMD="${SCRIPT_DIR}/pull.sh"
elif command -v pull >/dev/null 2>&1; then
    PULL_CMD="pull"
elif command -v pull.sh >/dev/null 2>&1; then
    PULL_CMD="pull.sh"
fi

if [ -f "${SCRIPT_DIR}/push.sh" ] && [ -x "${SCRIPT_DIR}/push.sh" ]; then
    PUSH_CMD="${SCRIPT_DIR}/push.sh"
elif command -v push >/dev/null 2>&1; then
    PUSH_CMD="push"
elif command -v push.sh >/dev/null 2>&1; then
    PUSH_CMD="push.sh"
fi

if [ -z "$PULL_CMD" ] || [ -z "$PUSH_CMD" ]; then
    echo "❌ Error: Required pull and push runners could not be located." >&2
    exit 1
fi

# Ensure inside a git repository
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "❌ Error: Current directory is not inside a Git repository." >&2
    exit 1
fi

# Check for help flag
for arg in "$@"; do
    if [ "$arg" = "-h" ] || [ "$arg" = "--help" ]; then
        show_help
        exit 0
    elif [ "$arg" = "-v" ] || [ "$arg" = "--version" ]; then
        echo "sync (Wheelhouser Git Tools) v${VERSION}"
        exit 0
    fi
done

CURRENT_REPO=$(basename "$(git rev-parse --show-toplevel)")
CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || git rev-parse --short HEAD)

echo "=================================================================="
echo "🔄 Synchronizing Repository: ${CURRENT_REPO} (${CURRENT_BRANCH})"
echo "=================================================================="

# Step 1: Pull incoming changes
echo "==> [1/2] Pulling incoming updates from remote..."
"$PULL_CMD" --autostash

# Step 2: Push local changes
echo "==> [2/2] Staging, inspecting, and pushing local changes..."
if ! "$PUSH_CMD" "$@"; then
    echo "⚠️ Synchronization aborted." >&2
    exit 130
fi

echo "=================================================================="
echo "✅ [SUCCESS] Repository '${CURRENT_REPO}' is in full sync with remote!"
echo "=================================================================="

"""Wheelhouser Git Tools - Standard Project Scaffolding & Compliance Audit Module.

Automates the instantiation of Canonical Wheelhouser Development Policy (AGENTS.md)
structures across repositories:
- Full canonical directory layout (tests, bug-reports, build-linux, security, assets, src, epics)
- Pre-build test gates and Rule 9 test runners (smoke, unit, end-to-end)
- Packaging specs and metadata with version synchronization
- Compliance scorecard generator checking all 13 canonical development rules
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .init_repo import GITIGNORE_TEMPLATES

OK_MARK = "[OK]" if sys.platform == "win32" else "✔"
FAIL_MARK = "[FAIL]" if sys.platform == "win32" else "❌"
WARN_MARK = "[WARN]" if sys.platform == "win32" else "⚠️"

CANONICAL_AGENTS_POLICY = """# Mandatory Canonical Wheelhouser LLC Development Policy 2026-09-30

## Core Principle
Never make source code modifications without an explicit version increment and a clear, descriptive changelog entry.

## Rules for Every Code Modification
Whenever making ANY code changes, refactors, bug fixes, or new features in this repository:

1. **Automated Version & Build Control (Single Source of Truth)**:
   - Primary application entry points (`src/main.py`, `src/main.sh`, `src/main.c`, `src/main.ps1`, etc.) serve as the single source of truth for `APP_VERSION` / `VERSION`. Never manually hardcode version increments across downstream scripts or packaging manifests.
   - When updating `VERSION = "X.Y.Z"` and adding the corresponding changelog entry (`# X.Y.Z - <description>`) in the primary entry point, run `build-linux/sync_version.py` or any build runner (`build.sh`, `build_rpm.sh`, `build_deb.sh`, `build_mac.sh`, `build_msix.ps1`).
   - The build automation automatically propagates and guarantees parity across manifests, specs, and trackers.

2. **Add Header Changelog Entry**:
   - Add a numbered version entry to the top docstring / changelog comment section of the modified script(s):
     `# X.Y.Z - Clear explanation of the fix or feature.`

3. **Zero Unversioned Code Changes**:
   - No silent or untracked changes. Every edit must be tied to a documented version increment.

4. **Commit Changes**:
   - Commit changes with a clear and descriptive commit message using `./push.ps1` or `./push.sh` (or `git-tools push`).

5. **Cross-Platform Consistency**:
   - Wheelhouser LLC applications and developer tools are cross-platform and cross-architecture (Windows, macOS, Linux). Ensure that source code, CLI parameters, and metadata are consistent across platforms.

6. **Packaging and Installation Integrity**:
   - Ensure native platform installers maintain clean isolation, idempotency, and strict validation of system paths.

7. **Windows Packaging Standard**:
   - When building Windows desktop packages, applications are packaged strictly as MSIX. Inno Setup (`.iss` / `.exe`) and WiX MSI installers are deprecated and no longer supported.

8. **Epic and Architectural Documentation Archival**:
   - Always archive the `implementation_plan.md` and `walkthrough.md` into `epics/YYYY-MM-DD-<epic-name>/` and commit them to the repository for every epic, feature, or major architectural modification.

9. **Automated Testing Standards**:
   - All projects must have a `<project_name>/tests/` directory with a master test runner (`tests/run_tests.sh`).
   - Three standardized tiers: Smoke Testing (`tests/smoke/`), Unit Testing (`tests/unit/`), End-to-End (`tests/end-to-end/`).
   - All tests must pass before any build steps can be taken.
   - All new features and bug fixes must have automated tests.

10. **Bug Report and Tracking Standards**:
    - Dedicated `<project_name>/bug-reports/` directory with 5-level structure:
      `<type>/<os>/<distro>/<version>/<arch>/<YYYYMMDD_HHMMSS_<slug>.md>`
    - Categories: `installation`, `run-time`, `security`, `marketing`.

11. **Security Audits**:
    - All versions must have security audits before release, documented in `security/<VERSION>_sec_audit.md`.

12. **Security Patching**:
    - All security issues must be patched before the next release and documented in `bug-reports/security/`.

13. **Project Hygiene & Open-Source Decoupling**:
    - Wheelhouser public repositories must remain decoupled from internal corporate infrastructure.
    - Developer overrides (`*.local.sh`, `.local/`) are permanently excluded via `.gitignore`.
"""

TEMPLATE_SEC_AUDIT = """# Security Audit Report: {project_name} v{version}

## Executive Summary
- **Project**: `{project_name}`
- **Version**: `{version}`
- **Audit Date**: `2026-09-30`
- **Auditor / Evaluator**: `Wheelhouser Security Operations`
- **Target Git Commit**: `HEAD`
- **Overall Status**: `PASSED`

---

## 1. Automated Secret & Credential Scanning
Pre-flight scan for hardcoded credentials, private keys, cloud tokens, and sensitive files using `git-tools scan-secrets`.

| Check | Tool / Command | Findings | Status |
| :--- | :--- | :--- | :--- |
| Sensitive Files (.env, .pem, .key) | `git-tools scan-secrets` | 0 detected | PASSED |
| Token / Password Regex Scan | `git-tools scan-secrets` | 0 detected | PASSED |
| Working Tree Cleanliness | `git status --porcelain` | Clean | PASSED |

---

## 2. Dependency & Supply Chain Verification
Inspection of external dependencies, libraries, and submodules for known CVEs.

| Dependency | Required Version | Installed Version | Advisory Status |
| :--- | :--- | :--- | :--- |
| Python Runtime / Stdlib | >= 3.10 | Standard | Clean |

---

## 3. Filesystem Permissions & Least Privilege Audit
Validation of platform install scripts, desktop launchers, and binary execution privileges.

| Component | Target Location | Perms | Least Privilege Verification | Status |
| :--- | :--- | :--- | :--- | :--- |
| Executable Shims | `~/.local/bin` | `0755` | No SUID/SGID bits set | PASSED |
| Configuration | `~/.config/{project_name}/` | `0700` | User-isolated read/write | PASSED |

---

## 4. Cross-Platform Binary Hardening & Packaging
- **Linux Packaging**: RPM spec file permissions standard (`%defattr(-,root,root,-)`).
- **Windows Packaging**: MSIX Manifest configured with standard capabilities.

---

## 5. Security Defects & Remediation (Rule 12)
| Ticket ID | Severity | Problem Description | Resolution / Commit | Status |
| :--- | :--- | :--- | :--- | :--- |
| *(None)* | -- | No open security vulnerabilities reported | -- | PASSED |

---

## 6. Final Certification & Sign-Off
- [x] All automated secret scanning completed with zero defects.
- [x] All automated regression and unit tests passed.
- [x] Pre-build automated test gate enforcement validated (Rule 9).
- [x] No unpatched security issues remain open (Rule 12).

**Sign-off**: `CERTIFIED FOR RELEASE`
**Date**: `2026-09-30`
"""

GPL_LICENSE_HEADER = """                    GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.
"""

MIT_LICENSE = """MIT License

Copyright (c) 2026 Wheelhouser LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

PROPRIETARY_LICENSE = """Proprietary License

Copyright (c) 2026 Wheelhouser LLC. All rights reserved.
Unauthorized copying of this software, via any medium, is strictly prohibited.
Proprietary and confidential.
"""


def _run_git(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    """Helper to run git commands."""
    env = os.environ.copy()
    if "GIT_AUTHOR_NAME" not in env:
        env["GIT_AUTHOR_NAME"] = "Wheelhouser Engineering"
    if "GIT_AUTHOR_EMAIL" not in env:
        env["GIT_AUTHOR_EMAIL"] = "developer@wheelhouser.com"
    if "GIT_COMMITTER_NAME" not in env:
        env["GIT_COMMITTER_NAME"] = "Wheelhouser Engineering"
    if "GIT_COMMITTER_EMAIL" not in env:
        env["GIT_COMMITTER_EMAIL"] = "developer@wheelhouser.com"

    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        env=env,
        check=False,
    )


def scaffold_project(
    target_dir: Path | str,
    project_name: str,
    project_type: str = "python",
    license_type: str = "gpl",
    dry_run: bool = False,
    existing: bool = False,
) -> Tuple[bool, List[str], List[str]]:
    """Scaffold a new or existing repository to Canonical Wheelhouser Development Policy compliance.

    Args:
        target_dir: Target directory path.
        project_name: Project name slug.
        project_type: 'python', 'shell', or 'c'.
        license_type: 'gpl', 'mit', or 'proprietary'.
        dry_run: If True, preview files without writing.
        existing: If True, retrofit without overwriting existing files.

    Returns:
        (success, created_files, warnings)
    """
    root = Path(target_dir).resolve()
    if not existing:
        root = root / project_name if root.name != project_name else root

    created_files: List[str] = []
    warnings: List[str] = []

    # Map license
    if license_type.lower() == "mit":
        license_text = MIT_LICENSE
    elif license_type.lower() == "proprietary":
        license_text = PROPRIETARY_LICENSE
    else:
        license_text = GPL_LICENSE_HEADER

    # Choose gitignore template
    gi_tpl = GITIGNORE_TEMPLATES.get(project_type.lower(), GITIGNORE_TEMPLATES["generic"])

    # Determine files to scaffold
    files_map: Dict[str, Tuple[str, bool]] = {}  # rel_path -> (content, is_executable)

    # 1. Root policy & documentation
    files_map["AGENTS.md"] = (CANONICAL_AGENTS_POLICY, False)
    files_map["LICENSE"] = (license_text, False)
    files_map["README.md"] = (
        f"# {project_name}\n\n"
        f"{project_name} is an enterprise application developed by Wheelhouser LLC.\n"
        f"Built in full compliance with the Canonical Wheelhouser Development Policy (`AGENTS.md`).\n\n"
        f"## Automated Testing (Rule 9)\n"
        f"```bash\n"
        f"./tests/run_tests.sh\n"
        f"```\n\n"
        f"## Linux Build & Packaging\n"
        f"```bash\n"
        f"build-linux/build_rpm.sh\n"
        f"```\n",
        False,
    )
    files_map[".release_version"] = ("0.1.0\n", False)
    files_map[".gitignore"] = (gi_tpl, False)

    # 2. Assets
    desktop_content = (
        f"[Desktop Entry]\n"
        f"Type=Application\n"
        f"Name={project_name}\n"
        f"Comment=Wheelhouser {project_name} Application\n"
        f"Exec={project_name}\n"
        f"Icon=com.wheelhouser.{project_name}\n"
        f"Categories=Utility;Development;\n"
        f"Terminal=true\n"
    )
    files_map[f"assets/{project_name}.desktop"] = (desktop_content, False)

    # 3. Build Linux
    spec_content = (
        f"Name:           {project_name}\n"
        f"Version:        0.1.0\n"
        f"%define         release_number 1\n"
        f"Release:        %{{release_number}}%{{?dist}}\n"
        f"Summary:        Wheelhouser {project_name} application\n"
        f"License:        GPLv3+\n"
        f"URL:            https://wheelhouser.com\n"
        f"BuildArch:      noarch\n\n"
        f"%description\n"
        f"Wheelhouser {project_name} application built to canonical standards.\n\n"
        f"%prep\n\n"
        f"%build\n\n"
        f"%install\n"
        f"mkdir -p %{{buildroot}}%{{_bindir}}\n"
        f"install -m 0755 %{{_builddir}}/src/* %{{buildroot}}%{{_bindir}}/ 2>/dev/null || true\n\n"
        f"%files\n"
        f"%{{_bindir}}/*\n\n"
        f"%changelog\n"
        f"* Wed Sep 30 2026 Wheelhouser Engineering <developer@wheelhouser.com> - 0.1.0-1\n"
        f"- Initial repository scaffolding.\n"
    )
    files_map[f"build-linux/{project_name}.spec"] = (spec_content, False)

    metainfo_content = (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<component type="desktop-application">\n'
        f"  <id>com.wheelhouser.{project_name}</id>\n"
        f"  <name>{project_name}</name>\n"
        f"  <summary>Wheelhouser {project_name} application</summary>\n"
        f"  <metadata_license>CC0-1.0</metadata_license>\n"
        f"  <project_license>GPL-3.0-or-later</project_license>\n"
        f"  <description>\n"
        f"    <p>Wheelhouser {project_name} application.</p>\n"
        f"  </description>\n"
        f"  <releases>\n"
        f'    <release version="0.1.0" date="2026-09-30">\n'
        f"      <description>\n"
        f"        <p>Release 0.1.0: Initial release.</p>\n"
        f"      </description>\n"
        f"    </release>\n"
        f"  </releases>\n"
        f"</component>\n"
    )
    files_map[f"build-linux/com.wheelhouser.{project_name}.metainfo.xml"] = (metainfo_content, False)

    sync_ver_script = (
        '#!/usr/bin/env python3\n"""Automated Version and Manifest Synchronization."""\n'
        "import re, sys\nfrom pathlib import Path\n\n"
        "def sync():\n"
        "    root = Path(__file__).resolve().parent.parent\n"
        '    main_file = root / "src" / "main.py"\n'
        "    if not main_file.exists():\n"
        '        main_file = root / "src" / "main.sh"\n'
        "    if not main_file.exists():\n"
        "        return 0\n"
        "    txt = main_file.read_text(encoding='utf-8')\n"
        "    m = re.search(r'VERSION\\s*=\\s*[\"\\\']([^\"\\\']+)[\"\\\']', txt)\n"
        "    if m:\n"
        "        ver = m.group(1)\n"
        "        (root / '.release_version').write_text(f'{ver}\\n', encoding='utf-8')\n"
        "    return 0\n\n"
        "if __name__ == '__main__':\n"
        "    sys.exit(sync())\n"
    )
    files_map["build-linux/sync_version.py"] = (sync_ver_script, True)

    build_rpm_script = (
        f"#!/usr/bin/env bash\n"
        f"set -euo pipefail\n"
        f'SCRIPT_DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"\n'
        f'REPO_ROOT="$(cd "${{SCRIPT_DIR}}/.." && pwd)"\n'
        f'cd "${{REPO_ROOT}}"\n\n'
        f'echo "==> [Gate 1] Running pre-build automated tests (AGENTS.md Rule 9)..."\n'
        f'if [ -x "${{REPO_ROOT}}/tests/run_tests.sh" ]; then\n'
        f'    "${{REPO_ROOT}}/tests/run_tests.sh"\n'
        f"fi\n"
        f'echo "  {OK_MARK} Pre-build test gate PASSED."\n'
        f'echo "==> Building RPM package for {project_name}..."\n'
    )
    files_map["build-linux/build_rpm.sh"] = (build_rpm_script, True)

    # 4. Bug Reports hierarchy
    files_map["bug-reports/README.md"] = (
        "# Bug Reports Hierarchy (AGENTS.md Rule 10)\n\n"
        "Standard 5-level directory structure:\n"
        "`bug-reports/<type>/<os>/<distro>/<version>/<arch>/<ticket_id>.md`\n",
        False,
    )
    files_map["bug-reports/installation/linux/all/all/all/.gitkeep"] = ("", False)
    files_map["bug-reports/run-time/linux/all/all/all/.gitkeep"] = ("", False)
    files_map["bug-reports/security/linux/all/all/all/.gitkeep"] = ("", False)
    files_map["bug-reports/marketing/linux/all/all/all/.gitkeep"] = ("", False)

    # 5. Security templates and baseline
    files_map["security/TEMPLATE_sec_audit.md"] = (
        TEMPLATE_SEC_AUDIT.format(project_name=project_name, version="<VERSION>"),
        False,
    )
    files_map["security/0.1.0_sec_audit.md"] = (
        TEMPLATE_SEC_AUDIT.format(project_name=project_name, version="0.1.0"),
        False,
    )

    # 6. Tests structure
    run_tests_sh = (
        "#!/usr/bin/env bash\n"
        "# ==============================================================================\n"
        "# tests/run_tests.sh - Master Test Runner (AGENTS.md Rule 9)\n"
        "# ==============================================================================\n"
        "set -euo pipefail\n\n"
        'SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"\n'
        'REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"\n'
        'cd "${REPO_ROOT}"\n\n'
        'echo "==> [1/2] Running Smoke Tests..."\n'
        'if [ -d "tests/smoke" ]; then\n'
        '    if [ -f "tests/smoke/test_smoke.py" ]; then\n'
        "        python3 -m unittest discover tests/smoke -v\n"
        '    elif [ -f "tests/smoke/test_smoke.sh" ]; then\n'
        "        bash tests/smoke/test_smoke.sh\n"
        "    fi\n"
        "fi\n\n"
        'echo "==> [2/2] Running Unit Tests..."\n'
        'if [ -d "tests/unit" ]; then\n'
        '    if [ -f "tests/unit/test_core.py" ]; then\n'
        "        python3 -m unittest discover tests/unit -v\n"
        '    elif [ -f "tests/unit/test_core.sh" ]; then\n'
        "        bash tests/unit/test_core.sh\n"
        "    fi\n"
        "fi\n\n"
        'echo "✅ All Automated Tests Passed Successfully! Build Gate Cleared."\n'
    )
    files_map["tests/run_tests.sh"] = (run_tests_sh, True)
    files_map["tests/end-to-end/.gitkeep"] = ("", False)

    if project_type.lower() == "python":
        smoke_py = (
            "import unittest\nfrom pathlib import Path\nimport sys\n\n"
            "REPO_ROOT = Path(__file__).resolve().parent.parent.parent\n"
            'sys.path.insert(0, str(REPO_ROOT / "src"))\n\n'
            "class TestSmoke(unittest.TestCase):\n"
            "    def test_version_parity(self):\n"
            "        rel_file = REPO_ROOT / '.release_version'\n"
            "        self.assertTrue(rel_file.exists())\n"
            "        rel_ver = rel_file.read_text(encoding='utf-8').strip()\n"
            "        import main\n"
            "        self.assertEqual(rel_ver, main.VERSION)\n"
            "        self.assertEqual(main.VERSION, main.APP_VERSION)\n\n"
            "if __name__ == '__main__':\n"
            "    unittest.main()\n"
        )
        files_map["tests/smoke/test_smoke.py"] = (smoke_py, False)

        unit_py = (
            "import unittest\nfrom pathlib import Path\nimport sys\n\n"
            "REPO_ROOT = Path(__file__).resolve().parent.parent.parent\n"
            'sys.path.insert(0, str(REPO_ROOT / "src"))\n\n'
            "class TestCore(unittest.TestCase):\n"
            "    def test_initialization(self):\n"
            "        import main\n"
            "        self.assertEqual(main.main(), 0)\n\n"
            "if __name__ == '__main__':\n"
            "    unittest.main()\n"
        )
        files_map["tests/unit/test_core.py"] = (unit_py, False)

        main_py = (
            f'#!/usr/bin/env python3\n"""Wheelhouser {project_name} - Main Entry Point.\n\n'
            f"Version Change Log:\n"
            f"# 0.1.0 - Initial repository scaffolding.\n"
            f'"""\n\n'
            f"from __future__ import annotations\nimport sys\n\n"
            f'VERSION = "0.1.0"\n'
            f'APP_VERSION = "0.1.0"\n'
            f'__version__ = "0.1.0"\n\n'
            f"def main() -> int:\n"
            f'    print(f"Hello from {project_name} v{{VERSION}}!")\n'
            f"    return 0\n\n"
            f'if __name__ == "__main__":\n'
            f"    sys.exit(main())\n"
        )
        files_map["src/main.py"] = (main_py, True)

    elif project_type.lower() == "shell":
        smoke_sh = (
            "#!/usr/bin/env bash\nset -euo pipefail\n"
            'REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"\n'
            '[ -f "${REPO_ROOT}/.release_version" ]\n'
            '[ -x "${REPO_ROOT}/src/main.sh" ]\n'
        )
        files_map["tests/smoke/test_smoke.sh"] = (smoke_sh, True)

        unit_sh = (
            "#!/usr/bin/env bash\nset -euo pipefail\n"
            'REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"\n'
            'OUTPUT="$("${REPO_ROOT}/src/main.sh")"\n'
            '[[ "${OUTPUT}" =~ "Hello from" ]]\n'
        )
        files_map["tests/unit/test_core.sh"] = (unit_sh, True)

        main_sh = (
            f"#!/usr/bin/env bash\n"
            f"# ==============================================================================\n"
            f"# src/main.sh - {project_name} Entry Point\n"
            f"# Version: 0.1.0\n#\n"
            f"# Version Change Log:\n"
            f"# 0.1.0 - Initial repository scaffolding.\n"
            f"# ==============================================================================\n"
            f"set -euo pipefail\n\n"
            f'VERSION="0.1.0"\n'
            f'echo "Hello from {project_name} v${{VERSION}}!"\n'
        )
        files_map["src/main.sh"] = (main_sh, True)

    else:  # c
        smoke_sh = (
            "#!/usr/bin/env bash\nset -euo pipefail\n"
            'REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"\n'
            '[ -f "${REPO_ROOT}/.release_version" ]\n'
        )
        files_map["tests/smoke/test_smoke.sh"] = (smoke_sh, True)

        unit_sh = (
            "#!/usr/bin/env bash\nset -euo pipefail\nexit 0\n"
        )
        files_map["tests/unit/test_core.sh"] = (unit_sh, True)

        main_c = (
            f'/* Wheelhouser {project_name} */\n'
            f'#include <stdio.h>\n'
            f'#define VERSION "0.1.0"\n\n'
            f'int main(void) {{\n'
            f'    printf("Hello from {project_name} v%s\\n", VERSION);\n'
            f'    return 0;\n'
            f'}}\n'
        )
        files_map["src/main.c"] = (main_c, False)
        makefile = (
            f"CC ?= gcc\nCFLAGS ?= -Wall -Wextra -O2\n\n"
            f"all:\n\t$(CC) $(CFLAGS) -o src/{project_name} src/main.c\n\n"
            f"clean:\n\trm -f src/{project_name}\n"
        )
        files_map["Makefile"] = (makefile, False)

    # 7. Epics directory
    files_map["epics/.gitkeep"] = ("", False)

    # Perform creation or dry run
    if dry_run:
        for rel_path in files_map:
            fpath = root / rel_path
            if existing and fpath.exists():
                continue
            created_files.append(str(fpath))
        return True, created_files, []

    root.mkdir(parents=True, exist_ok=True)

    for rel_path, (content, is_exe) in files_map.items():
        fpath = root / rel_path
        if existing and fpath.exists():
            # If gitignore, ensure Rule 13 overrides
            if rel_path == ".gitignore":
                cur_text = fpath.read_text(encoding="utf-8")
                missing = []
                if "*.local.sh" not in cur_text:
                    missing.append("*.local.sh")
                if ".local/" not in cur_text:
                    missing.append(".local/")
                if missing:
                    with fpath.open("a", encoding="utf-8") as gf:
                        gf.write("\n# Wheelhouser Rule 13 - Local developer overrides\n" + "\n".join(missing) + "\n")
            continue

        fpath.parent.mkdir(parents=True, exist_ok=True)
        fpath.write_text(content, encoding="utf-8")
        if is_exe and sys.platform != "win32":
            fpath.chmod(fpath.stat().st_mode | 0o755)
        created_files.append(str(fpath))

    # Initialize Git repository if new project and not already a Git repo
    if not existing and not (root / ".git").is_dir():
        _run_git(["git", "init", "-b", "main"], cwd=root)
        _run_git(["git", "add", "."], cwd=root)
        _run_git(["git", "commit", "-m", f"chore: initial repository scaffolding for {project_name}"], cwd=root)

    return True, created_files, warnings


@dataclass
class RuleCheckResult:
    rule_id: int
    rule_name: str
    status: str  # "PASS", "WARN", "FAIL"
    details: str


@dataclass
class ComplianceReport:
    repo_path: Path
    checks: List[RuleCheckResult]

    @property
    def passed_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "PASS")

    @property
    def total_count(self) -> int:
        return len(self.checks)

    @property
    def percentage(self) -> float:
        return (self.passed_count / self.total_count) * 100.0 if self.total_count else 0.0

    def format_scorecard(self) -> str:
        lines = [
            "=" * 78,
            f"    CANONICAL WHEELHOUSER COMPLIANCE SCORECARD: {self.repo_path.name}",
            "=" * 78,
            f"{'RULE':<7} {'STATUS':<8} {'POLICY NAME':<34} {'DETAILS'}",
            "-" * 78,
        ]

        for c in self.checks:
            mark = OK_MARK if c.status == "PASS" else (WARN_MARK if c.status == "WARN" else FAIL_MARK)
            lines.append(f"Rule {c.rule_id:2d}  {mark} {c.status:<5} {c.rule_name:<34} {c.details}")

        lines.append("-" * 78)
        lines.append(f"Compliance Score: {self.passed_count}/{self.total_count} ({self.percentage:.1f}%)")
        lines.append("=" * 78)
        return "\n".join(lines)


def audit_compliance(repo_path: Path | str) -> ComplianceReport:
    """Evaluate a repository against the 13 Canonical Wheelhouser Development Policy rules."""
    root = Path(repo_path).resolve()
    checks: List[RuleCheckResult] = []

    # Rule 1: Automated Version & Build Control (Single Source of Truth)
    # Check src/main.* for VERSION and .release_version
    r1_pass = False
    r1_detail = "Missing VERSION definition or .release_version tracker."
    main_py = root / "src" / "main.py"
    main_sh = root / "src" / "main.sh"
    rel_ver = root / ".release_version"
    sync_py = root / "build-linux" / "sync_version.py"

    entry_has_ver = False
    if main_py.exists():
        content = main_py.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"^VERSION\s*=", content, re.MULTILINE):
            entry_has_ver = True
    elif main_sh.exists():
        content = main_sh.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"^(#\s*Version:|VERSION=)", content, re.MULTILINE):
            entry_has_ver = True

    if entry_has_ver and rel_ver.exists():
        r1_pass = True
        r1_detail = f"Verified single source of truth in src/main.* ({rel_ver.read_text(encoding='utf-8').strip()})."
    checks.append(RuleCheckResult(1, "Automated Version Control", "PASS" if r1_pass else "FAIL", r1_detail))

    # Rule 2: Header Changelog Entry
    r2_pass = False
    r2_detail = "No changelog entry matching '# X.Y.Z -' found in primary entry point."
    for p in (main_py, main_sh):
        if p.exists():
            c = p.read_text(encoding="utf-8", errors="ignore")
            if re.search(r"^#\s*[0-9]+\.[0-9]+\.[0-9]+\s*-", c, re.MULTILINE):
                r2_pass = True
                r2_detail = "Changelog entry present in entry point header."
                break
    checks.append(RuleCheckResult(2, "Header Changelog Entry", "PASS" if r2_pass else "FAIL", r2_detail))

    # Rule 3: Zero Unversioned Code Changes
    r3_pass = False
    r3_detail = "Not a git repository or untracked changes."
    if (root / ".git").is_dir():
        r3_pass = True
        r3_detail = "Git repository tracking enabled."
    checks.append(RuleCheckResult(3, "Zero Unversioned Changes", "PASS" if r3_pass else "FAIL", r3_detail))

    # Rule 4: Commit Changes
    r4_pass = False
    r4_detail = "No standard commit script (push.sh / push.ps1)."
    if (root / "src" / "push.sh").exists() or (root / "push.sh").exists():
        r4_pass = True
        r4_detail = "Push / commit automation shims present."
    checks.append(RuleCheckResult(4, "Commit Automation", "PASS" if r4_pass else "WARN", r4_detail))

    # Rule 5: Cross-Platform Consistency
    r5_pass = False
    r5_detail = "Single-platform scripts only."
    has_posix = any((root / "src").glob("*.sh")) or (root / "build-linux").exists()
    has_win = any((root / "src").glob("*.ps1")) or (root / "build-msix").exists()
    if has_posix and (has_win or (root / "src" / "main.py").exists()):
        r5_pass = True
        r5_detail = "Cross-platform POSIX and Windows components validated."
    checks.append(RuleCheckResult(5, "Cross-Platform Consistency", "PASS" if r5_pass else "WARN", r5_detail))

    # Rule 6: Packaging & Installation Integrity
    r6_pass = False
    r6_detail = "Missing build-linux/install.sh or packaging manifests."
    if (root / "build-linux" / "install.sh").exists() or any((root / "build-linux").glob("*.spec")):
        r6_pass = True
        r6_detail = "Packaging and installer scripts present."
    checks.append(RuleCheckResult(6, "Packaging & Installation", "PASS" if r6_pass else "WARN", r6_detail))

    # Rule 7: Windows Packaging Standard
    r7_pass = True
    r7_detail = "Compliant with MSIX packaging standard."
    # Check for forbidden legacy installer scripts
    iss_files = list(root.glob("**/*.iss"))
    if iss_files:
        r7_pass = False
        r7_detail = f"Deprecated Inno Setup scripts found: {iss_files[0].name}"
    checks.append(RuleCheckResult(7, "Windows Packaging Standard", "PASS" if r7_pass else "FAIL", r7_detail))

    # Rule 8: Epic Documentation Archival
    r8_pass = False
    r8_detail = "Missing epics/ directory."
    if (root / "epics").is_dir():
        r8_pass = True
        r8_detail = "epics/ directory present and maintained."
    checks.append(RuleCheckResult(8, "Epic Archival Standard", "PASS" if r8_pass else "FAIL", r8_detail))

    # Rule 9: Automated Testing Standards
    r9_pass = False
    r9_detail = "Missing tests/run_tests.sh or test tiers."
    run_tests_sh = root / "tests" / "run_tests.sh"
    if run_tests_sh.exists() and (root / "tests" / "smoke").is_dir() and (root / "tests" / "unit").is_dir():
        r9_pass = True
        r9_detail = "Master test runner tests/run_tests.sh with smoke & unit tiers."
    checks.append(RuleCheckResult(9, "Automated Testing Standard", "PASS" if r9_pass else "FAIL", r9_detail))

    # Rule 10: Bug Report & Tracking Standards
    r10_pass = False
    r10_detail = "Missing bug-reports/ directory with 5-level structure."
    bug_dir = root / "bug-reports"
    if (
        bug_dir.is_dir()
        and (bug_dir / "installation").is_dir()
        and (bug_dir / "run-time").is_dir()
        and (bug_dir / "security").is_dir()
    ):
        r10_pass = True
        r10_detail = "bug-reports/ 5-level tracking structure verified."
    checks.append(RuleCheckResult(10, "Bug Report Hierarchy", "PASS" if r10_pass else "FAIL", r10_detail))

    # Rule 11: Security Audits
    r11_pass = False
    r11_detail = "Missing security audit documents."
    sec_dir = root / "security"
    if sec_dir.is_dir() and any(sec_dir.glob("*_sec_audit.md")):
        r11_pass = True
        r11_detail = f"Security audit reports verified in security/."
    checks.append(RuleCheckResult(11, "Security Audits", "PASS" if r11_pass else "FAIL", r11_detail))

    # Rule 12: Security Patching
    r12_pass = True
    r12_detail = "No open security defects detected."
    sec_bugs_dir = root / "bug-reports" / "security"
    if sec_bugs_dir.is_dir():
        for bf in sec_bugs_dir.glob("**/*.md"):
            try:
                b_text = bf.read_text(encoding="utf-8", errors="ignore")
                if 'status: "open"' in b_text:
                    r12_pass = False
                    r12_detail = f"Open security defect: {bf.name}"
                    break
            except Exception:
                pass
    checks.append(RuleCheckResult(12, "Security Patching Integrity", "PASS" if r12_pass else "FAIL", r12_detail))

    # Rule 13: Project Hygiene & Open-Source Decoupling
    r13_pass = True
    r13_detail = "Rule 13 local overrides (*.local.sh, .local/) configured."
    gi_file = root / ".gitignore"
    if gi_file.exists():
        gi_txt = gi_file.read_text(encoding="utf-8", errors="ignore")
        if "*.local.sh" not in gi_txt or ".local/" not in gi_txt:
            r13_pass = False
            r13_detail = ".gitignore missing *.local.sh or .local/ overrides."
    else:
        r13_pass = False
        r13_detail = "Missing .gitignore file."

    # Check for corporate private paths
    if r13_pass:
        for p in (root / "src", root / "build-linux"):
            if p.is_dir():
                for sf in p.glob("**/*"):
                    if sf.is_file() and sf.suffix in (".py", ".sh", ".spec"):
                        try:
                            if sf.name not in ("scaffold.py",):
                                stxt = sf.read_text(encoding="utf-8", errors="ignore")
                                if "wheelhouserllc-repo" in stxt:
                                    r13_pass = False
                                    r13_detail = f"Private corporate path found in {sf.name}"
                                    break
                        except Exception:
                            pass
    checks.append(RuleCheckResult(13, "Project Hygiene & Decoupling", "PASS" if r13_pass else "FAIL", r13_detail))

    return ComplianceReport(repo_path=root, checks=checks)

"""Wheelhouser Git Tools Version Information.

Dynamically inherits VERSION from src/main.py as the single source of truth.

Version Change Log:
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge, and canonical project scaffolding.
"""

from __future__ import annotations

import re
from pathlib import Path


def _resolve_version() -> str:
    try:
        main_py = Path(__file__).resolve().parent.parent / "main.py"
        if main_py.exists():
            match = re.search(r"^VERSION\s*=\s*['\"]([^'\"]+)['\"]", main_py.read_text(encoding="utf-8"), re.MULTILINE)
            if match:
                return match.group(1)
    except Exception:
        pass
    return "1.6.0"


__version__ = _resolve_version()
VERSION = __version__
APP_VERSION = __version__

"""Wheelhouser Git Tools - Unified Command Line Interface.

Provides a unified cross-platform CLI for managing git-tools installations,
running push/pull/sync/undo automations, viewing graph topology, auditing workspace
fleets, cleaning repositories, and scanning for credential leaks.
"""

from __future__ import annotations

import argparse
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import List, Optional

from .branch import (
    list_repository_branches,
    prune_merged_branches,
    render_branches_dashboard,
    switch_repository_branch,
)
from .build import run_build
from .cleaner import audit_repository, clean_repository, scan_workspace
from .fleet import pull_fleet, render_fleet_dashboard, scan_fleet
from .config import (
    get_config_path,
    get_current_project,
    get_default_projects_root,
    get_projects_root,
    list_projects,
    load_config,
    set_current_project,
    set_projects_root,
)
from .dashboard import interactive_dashboard
from .installer import (
    get_default_install_dir,
    get_source_scripts_dir,
    install_tools,
    is_dir_in_path,
    uninstall_tools,
)
from .security import scan_commit_history, scan_working_tree
from .init_repo import init_repository
from .merger import detect_conflicts, execute_merge, format_conflicts_report, simulate_merge
from .purge import find_matching_commits, format_bytes, get_repo_objects_size, purge_path
from .scaffold import audit_compliance, scaffold_project
from .version import __version__


def get_current_repo_root() -> Optional[Path]:
    """Find the root of the current Git repository, if applicable."""
    try:
        res = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode == 0:
            return Path(res.stdout.strip())
    except Exception:
        pass
    return None


def cmd_install(args: argparse.Namespace) -> int:
    target_dir = Path(args.dir).resolve() if args.dir else None
    print(f"==> Installing Wheelhouser Git Tools (v{__version__})...")

    success, items, warnings = install_tools(
        target_dir=target_dir,
        system_wide=args.system,
        setup_git_aliases=not args.no_git_aliases,
    )

    if items:
        print("\nSuccessfully installed:")
        for item in items:
            print(f"  + {item}")

    if warnings:
        print("\nWarnings / Notes:")
        for warn in warnings:
            print(f"  ! {warn}")

    if success:
        print("\nInstallation completed successfully!")
        return 0
    else:
        print("\nInstallation encountered errors.")
        return 1


def cmd_uninstall(args: argparse.Namespace) -> int:
    target_dir = Path(args.dir).resolve() if args.dir else None
    print("==> Uninstalling Wheelhouser Git Tools...")

    success, items, warnings = uninstall_tools(
        target_dir=target_dir,
        system_wide=args.system,
        remove_git_aliases=not args.keep_git_aliases,
    )

    if items:
        print("\nRemoved items:")
        for item in items:
            print(f"  - {item}")

    if warnings:
        print("\nWarnings:")
        for warn in warnings:
            print(f"  ! {warn}")

    print("\nUninstallation complete.")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    install_dir = get_default_install_dir()
    in_path = is_dir_in_path(install_dir)

    print("==================================================================")
    print(f"           WHEELHOUSER GIT TOOLS v{__version__} - STATUS")
    print("==================================================================")
    print(f"Operating System:     {platform.system()} ({platform.machine()})")
    print(f"Default Bin Path:     {install_dir}")
    print(f"Bin Path in PATH:     {'Yes' if in_path else 'No (Action required: add to PATH)'}")

    # Check Git alias status
    push_alias = subprocess.run(["git", "config", "--global", "alias.push-repo"], capture_output=True, text=True).stdout.strip()
    pull_alias = subprocess.run(["git", "config", "--global", "alias.pull-repo"], capture_output=True, text=True).stdout.strip()
    sync_alias = subprocess.run(["git", "config", "--global", "alias.sync-repo"], capture_output=True, text=True).stdout.strip()
    undo_alias = subprocess.run(["git", "config", "--global", "alias.undo-commit"], capture_output=True, text=True).stdout.strip()
    print(f"Git alias 'push-repo':    {push_alias if push_alias else 'Not set'}")
    print(f"Git alias 'pull-repo':    {pull_alias if pull_alias else 'Not set'}")
    print(f"Git alias 'sync-repo':    {sync_alias if sync_alias else 'Not set'}")
    print(f"Git alias 'undo-commit':  {undo_alias if undo_alias else 'Not set'}")

    # Check persistent configuration
    cfg = load_config()
    print(f"Projects Root:        {cfg.get('projects_root')}")
    print(f"Current Project:      {cfg.get('current_project') or '(None selected)'}")

    # Check current repo
    repo = get_current_repo_root()
    if repo:
        print(f"\nCurrent Git Repository: {repo}")
        legacy = audit_repository(repo)
        if legacy:
            print(f"Legacy scripts found:   {', '.join(legacy)}")
            print("  -> Use 'git-tools clean-repo .' to remove before open-sourcing.")
        else:
            print("Legacy scripts found:   None (Clean repository!)")
    else:
        print("\nCurrent Directory:      Not inside a Git repository")

    return 0


def cmd_dashboard(args: argparse.Namespace) -> int:
    return interactive_dashboard()


def cmd_config(args: argparse.Namespace) -> int:
    if getattr(args, "root", None):
        new_root = set_projects_root(args.root)
        print(f"✔ Projects root set to: {new_root}")
    if getattr(args, "project", None):
        set_current_project(args.project)
        print(f"✔ Current project set to: {args.project}")

    cfg = load_config()
    print("==================================================================")
    print("        WHEELHOUSER GIT TOOLS - PERSISTENT CONFIGURATION")
    print("==================================================================")
    print(f"Config File:      {get_config_path()}")
    print(f"Projects Root:    {cfg.get('projects_root')}")
    print(f"Current Project:  {cfg.get('current_project') or '(None selected)'}")
    print("==================================================================")
    return 0


def cmd_push(args: argparse.Namespace, extra_args: List[str]) -> int:
    src_dir = get_source_scripts_dir()
    if os.name == "nt":
        script = src_dir / "push.ps1"
        cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] + extra_args
    else:
        script = src_dir / "push.sh"
        cmd = [str(script)] + extra_args

    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except Exception as e:
        print(f"❌ Failed to execute push runner: {e}", file=sys.stderr)
        return 1


def cmd_pull(args: argparse.Namespace, extra_args: List[str]) -> int:
    src_dir = get_source_scripts_dir()
    if os.name == "nt":
        script = src_dir / "pull.ps1"
        cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] + extra_args
    else:
        script = src_dir / "pull.sh"
        cmd = [str(script)] + extra_args

    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except Exception as e:
        print(f"❌ Failed to execute pull runner: {e}", file=sys.stderr)
        return 1


def cmd_sync(args: argparse.Namespace, extra_args: List[str]) -> int:
    src_dir = get_source_scripts_dir()
    if os.name == "nt":
        script = src_dir / "sync.ps1"
        cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] + extra_args
    else:
        script = src_dir / "sync.sh"
        cmd = [str(script)] + extra_args

    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except Exception as e:
        print(f"❌ Failed to execute sync runner: {e}", file=sys.stderr)
        return 1


def cmd_undo(args: argparse.Namespace, extra_args: List[str]) -> int:
    src_dir = get_source_scripts_dir()
    if os.name == "nt":
        script = src_dir / "undo.ps1"
        cmd = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)] + extra_args
    else:
        script = src_dir / "undo.sh"
        cmd = [str(script)] + extra_args

    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except Exception as e:
        print(f"❌ Failed to execute undo runner: {e}", file=sys.stderr)
        return 1


def cmd_graph(args: argparse.Namespace) -> int:
    repo = get_current_repo_root()
    if not repo:
        print("❌ Error: Current directory is not inside a Git repository.", file=sys.stderr)
        return 1

    cmd = ["git", "-C", str(repo), "log", "--graph", "--all", "--decorate", "--oneline", "--color"]
    if args.count:
        cmd.extend(["-n", str(args.count)])

    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except Exception as e:
        print(f"❌ Failed to display git graph: {e}", file=sys.stderr)
        return 1


def cmd_fleet_status(args: argparse.Namespace) -> int:
    base_dir = Path(args.path).resolve()
    if not base_dir.is_dir():
        print(f"❌ Error: '{base_dir}' is not a directory.", file=sys.stderr)
        return 1

    fleet = scan_fleet(base_dir)
    print(render_fleet_dashboard(fleet))
    return 0


def cmd_fleet_pull(args: argparse.Namespace) -> int:
    base_dir = Path(args.path).resolve()
    if not base_dir.is_dir():
        print(f"❌ Error: '{base_dir}' is not a directory.", file=sys.stderr)
        return 1

    print(f"==> Initiating Fleet Pull across repositories under '{base_dir}'...\n")
    results = pull_fleet(base_dir)

    success_count = sum(1 for _, ok, _ in results if ok)
    fail_count = len(results) - success_count

    print("\n" + "=" * 60)
    print(f"Fleet Pull Summary: {success_count} succeeded, {fail_count} failed ({len(results)} total)")
    print("=" * 60)

    for name, ok, output in results:
        status_icon = "✅" if ok else "❌"
        first_line = output.splitlines()[0] if output else "Up to date"
        print(f" {status_icon} {name:<22}: {first_line}")

    return 0 if fail_count == 0 else 1


def cmd_prune_branches(args: argparse.Namespace) -> int:
    repo = get_current_repo_root()
    if not repo:
        print("❌ Error: Current directory is not inside a Git repository.", file=sys.stderr)
        return 1

    dry_run = args.dry_run
    prefix = "[DRY RUN] " if dry_run else ""
    print(f"==> {prefix}Pruning merged local branches in '{repo.name}'...")

    pruned, errors = prune_merged_branches(repo, dry_run=dry_run)

    if pruned:
        action = "Would delete" if dry_run else "Deleted"
        print(f"✅ {action} {len(pruned)} merged branch(es):")
        for b in pruned:
            print(f"  - {b}")
    else:
        print("ℹ️ No merged branches eligible for pruning. Protected and active branches preserved.")

    if errors:
        for err in errors:
            print(f"  ❌ {err}", file=sys.stderr)
        return 1

    return 0


def cmd_branches(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve()
    if (target_path / ".git").exists():
        repo = target_path
    else:
        repo = get_current_repo_root()

    if not repo:
        print(f"❌ Error: '{target_path}' is not inside a Git repository.", file=sys.stderr)
        return 1

    branches = list_repository_branches(repo)
    print(render_branches_dashboard(branches, repo.name))
    return 0


def cmd_switch(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve()
    if (target_path / ".git").exists():
        repo = target_path
    else:
        repo = get_current_repo_root()

    if not repo:
        print(f"❌ Error: '{target_path}' is not inside a Git repository.", file=sys.stderr)
        return 1

    success, msg = switch_repository_branch(repo, args.branch, create=args.create)
    if success:
        print(f"✔ {msg}")
        return 0
    else:
        print(f"❌ {msg}", file=sys.stderr)
        return 1


def cmd_scan_secrets(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve()
    if (target_path / ".git").exists():
        repo = target_path
    else:
        repo = get_current_repo_root()

    if not repo:
        print(f"❌ Error: '{target_path}' is not inside a Git repository.", file=sys.stderr)
        return 1

    print(f"==> Scanning repository '{repo.name}' for sensitive files and credentials...\n")

    working_tree_findings = scan_working_tree(repo)
    historical_findings = scan_commit_history(repo, depth=args.depth) if not args.no_history else []

    all_findings = working_tree_findings + historical_findings

    if not all_findings:
        print("✅ Pre-flight Security Scan: 0 issues found! No exposed secrets detected.")
        return 0

    print(f"⚠️ Security Scan detected {len(all_findings)} potential issue(s):\n")
    for f in all_findings:
        sev_color = "\033[31m" if f.severity == "CRITICAL" else "\033[33m"
        reset = "\033[0m"
        line_info = f":{f.line_number}" if f.line_number else ""
        print(f"  {sev_color}[{f.severity}]{reset} {f.rule_name}")
        print(f"     File:    {f.file_path}{line_info}")
        print(f"     Snippet: {f.matched_snippet}\n")

    return 1 if any(f.severity == "CRITICAL" for f in all_findings) else 0


def cmd_audit_repos(args: argparse.Namespace) -> int:
    target = Path(args.path).resolve()
    print(f"==> Auditing repositories under '{target}' for legacy push/pull scripts...\n")

    results = scan_workspace(target)
    if not results:
        print("✅ No repositories found with legacy push/pull scripts. All clean!")
        return 0

    print(f"Found {len(results)} repository/repositories with legacy scripts:\n")
    for repo_path, files in results.items():
        print(f"  📁 {repo_path.name} ({repo_path})")
        for f in files:
            print(f"     - {f}")
    print(f"\n💡 To strip scripts from a repo before open-sourcing:")
    print(f"   git-tools clean-repo <path-to-repo>")
    return 0


def cmd_clean_repo(args: argparse.Namespace) -> int:
    target = Path(args.path).resolve()
    dry_run = args.dry_run

    if args.all:
        results = scan_workspace(target)
        if not results:
            print("✅ No repositories found with legacy scripts.")
            return 0
        print(f"==> {'[DRY RUN] ' if dry_run else ''}Cleaning legacy scripts from {len(results)} repositories...")
        for rpath in results:
            rem, errs = clean_repository(rpath, dry_run=dry_run)
            print(f"  📁 {rpath.name}: removed {', '.join(rem) if rem else 'none'}")
            if errs:
                for e in errs:
                    print(f"     ❌ {e}")
        return 0

    if not target.is_dir():
        print(f"❌ Error: '{target}' is not a directory.", file=sys.stderr)
        return 1

    rem, errs = clean_repository(target, dry_run=dry_run)
    prefix = "[DRY RUN] " if dry_run else ""
    if rem:
        print(f"==> {prefix}Successfully removed legacy scripts from '{target.name}':")
        for f in rem:
            print(f"  - {f}")
    else:
        print(f"==> No legacy scripts found in '{target.name}'.")

    if errs:
        for e in errs:
            print(f"  ❌ Error: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_build(args: argparse.Namespace) -> int:
    return run_build(
        project=args.project,
        build_only=not getattr(args, "stage", False),
        platform_filter=args.platform,
        force=args.force,
        dry_run=args.dry_run,
        limit=args.limit,
        skip_tests=args.no_tests,
    )


def cmd_init(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve()
    print(f"==> Initializing Git repository in '{target_path}'...")
    initial_commit = not getattr(args, "no_initial_commit", False)
    if hasattr(args, "initial_commit") and args.initial_commit is not None:
        initial_commit = args.initial_commit

    success, msg = init_repository(
        target_path=target_path,
        branch=args.branch,
        remote_url=args.remote,
        project_type=args.type,
        initial_commit=initial_commit,
        commit_message=args.message,
    )

    if success:
        print(f"  ✔ {msg}")
        return 0
    else:
        print(f"  ❌ {msg}", file=sys.stderr)
        return 1


def cmd_merge(args: argparse.Namespace) -> int:
    repo_dir = get_current_repo_root() or Path.cwd()
    if not (repo_dir / ".git").is_dir():
        print(f"❌ Error: '{repo_dir}' is not a Git repository.", file=sys.stderr)
        return 1

    if args.dry_run:
        print(f"==> Simulating merge: {args.branch} -> current branch...")
        is_clean, conflicts, msg = simulate_merge(repo_dir=repo_dir, source_branch=args.branch)
        if is_clean:
            print(f"    Analyzing tree differences via git merge-tree...")
            print(f"    Result: Clean merge! No conflicting files detected.")
            return 0
        else:
            print(f"❌ Merge Conflict Simulation:")
            print(f"   {msg}", file=sys.stderr)
            return 1

    run_tests = not getattr(args, "no_test_gate", False)
    success, msg = execute_merge(
        repo_dir=repo_dir,
        source_branch=args.branch,
        strategy=args.strategy,
        message=args.message,
        prune=args.prune,
        run_tests=run_tests,
    )

    if success:
        print(f"✔ {msg}")
        return 0
    else:
        print(f"❌ Merge failed: {msg}", file=sys.stderr)
        return 1


def cmd_conflicts(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve() if getattr(args, "path", None) else (get_current_repo_root() or Path.cwd())
    if not (target_path / ".git").is_dir():
        print(f"❌ Error: '{target_path}' is not a Git repository.", file=sys.stderr)
        return 1

    conflicts = detect_conflicts(target_path)
    report = format_conflicts_report(target_path, conflicts)
    print(report)
    return 0 if not conflicts else 1


def cmd_scaffold(args: argparse.Namespace) -> int:
    target_dir = Path.cwd()
    project_name = args.project_name

    if args.existing:
        if not project_name:
            project_name = target_dir.name
        print(f"==> Retrofitting existing repository '{project_name}' for Wheelhouser compliance...")
    else:
        if not project_name:
            print("❌ Error: project-name argument is required when scaffolding a new project.", file=sys.stderr)
            return 1
        print(f"==> Generating Wheelhouser Canonical Project Scaffolding for '{project_name}'...")

    success, created, warnings = scaffold_project(
        target_dir=target_dir,
        project_name=project_name,
        project_type=args.type,
        license_type=args.license,
        dry_run=args.dry_run,
        existing=args.existing,
    )

    prefix = "[DRY RUN] " if args.dry_run else ""
    if success:
        for f in created:
            print(f"  ✔ {prefix}Created: {f}")
        for w in warnings:
            print(f"  ⚠️ {w}")
        if not args.dry_run:
            print(f"🎉 Project '{project_name}' successfully scaffolded and ready for development!")
        return 0
    else:
        print(f"❌ Scaffolding failed.", file=sys.stderr)
        return 1


def cmd_audit_compliance(args: argparse.Namespace) -> int:
    target_path = Path(args.path).resolve() if getattr(args, "path", None) else (get_current_repo_root() or Path.cwd())
    report = audit_compliance(target_path)
    print(report.format_scorecard())
    has_fail = any(c.status == "FAIL" for c in report.checks)
    return 1 if has_fail else 0


def cmd_purge_history(args: argparse.Namespace) -> int:
    repo_dir = get_current_repo_root() or Path.cwd()
    if not (repo_dir / ".git").is_dir():
        print(f"❌ Error: '{repo_dir}' is not a Git repository.", file=sys.stderr)
        return 1

    target_path = args.path.strip().strip("/")
    if not target_path:
        print("❌ Error: Target path cannot be empty.", file=sys.stderr)
        return 1

    print(f"==> Scanning commit history of '{repo_dir.name}' for path '{target_path}'...")
    commits = find_matching_commits(repo_dir, target_path)
    if not commits:
        print(f"ℹ️  No historical commits found touching '{target_path}'. Nothing to purge.")
        return 0

    print(f"⚠️  Found {len(commits)} historical commit(s) touching '{target_path}':")
    for sha, msg in commits[:10]:
        print(f"   • {sha} {msg}")
    if len(commits) > 10:
        print(f"   ... and {len(commits) - 10} more commit(s)")

    if args.dry_run:
        print(f"\n[DRY RUN] Purge would rewrite all {len(commits)} commits and run packfile garbage collection.")
        return 0

    if not args.yes:
        print(f"\n⚠️  CRITICAL WARNING:")
        print(f"   This operation will permanently rewrite Git history across ALL local branches")
        print(f"   to excise '{target_path}'. All affected commit SHAs will change.")
        print(f"   To publish changes, a remote force push (git push --force) will be required.\n")
        try:
            confirm = input(f"Are you sure you want to permanently purge '{target_path}' from history? [y/N]: ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            print("\n🚫 Operation cancelled by user.")
            return 130
        if confirm not in ("y", "yes"):
            print("🚫 Operation cancelled by user.")
            return 130

    print(f"\n==> Rewriting repository history and expunging '{target_path}'...")
    success, msg, before, after = purge_path(
        repo_path=repo_dir,
        target_path=target_path,
        push_remote=args.push,
        remote_name=args.remote,
    )

    if success:
        print(f"\n✔ {msg}")
        if not args.push:
            print("\n💡 Next step: To push the cleaned history to GitHub / remote, run:")
            print(f"   git push origin --force --all")
            print(f"   git push origin --force --tags")
        return 0
    else:
        print(f"\n❌ Error during history purge:\n{msg}", file=sys.stderr)
        return 1



def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog="git-tools",
        description=f"Wheelhouser Git Tools v{__version__} - Cross-Platform Git Automation Suite",
    )
    parser.add_argument("-v", "--version", action="version", version=f"git-tools v{__version__}")

    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # install
    p_inst = subparsers.add_parser("install", help="Install global push, pull, sync, undo shims and configure Git aliases")
    p_inst.add_argument("--dir", help="Custom installation target directory")
    p_inst.add_argument("--system", action="store_true", help="Install system-wide (e.g. /usr/local/bin)")
    p_inst.add_argument("--no-git-aliases", action="store_true", help="Do not configure Git global aliases")

    # uninstall
    p_uninst = subparsers.add_parser("uninstall", help="Remove global push, pull, sync, undo shims and Git aliases")
    p_uninst.add_argument("--dir", help="Custom installation directory to clean")
    p_uninst.add_argument("--system", action="store_true", help="Uninstall from system-wide directory")
    p_uninst.add_argument("--keep-git-aliases", action="store_true", help="Do not unset Git global aliases")

    # status
    subparsers.add_parser("status", help="Check installation status, PATH, and repository environment")

    # push
    subparsers.add_parser("push", help="Run push automation on current repository")

    # pull
    subparsers.add_parser("pull", help="Run pull automation on current repository")

    # sync
    subparsers.add_parser("sync", help="Run bi-directional pull & push sync automation")

    # undo
    subparsers.add_parser("undo", help="Safely undo the most recent commit, keeping working changes")

    # graph
    p_graph = subparsers.add_parser("graph", help="Display visual color commit topology graph")
    p_graph.add_argument("-n", "--count", type=int, help="Limit number of commits shown")

    # fleet-status
    p_fstat = subparsers.add_parser("fleet-status", help="Display status dashboard across multiple Git repositories")
    p_fstat.add_argument("path", nargs="?", default=".", help="Base directory to search for Git repositories (default: .)")

    # fleet-pull
    p_fpull = subparsers.add_parser("fleet-pull", help="Pull incoming updates across multiple Git repositories")
    p_fpull.add_argument("path", nargs="?", default=".", help="Base directory to search for Git repositories (default: .)")

    # prune-branches
    p_prune = subparsers.add_parser("prune-branches", help="Safely delete local branches merged into main/master")
    p_prune.add_argument("--dry-run", action="store_true", help="Preview branches that would be deleted without deleting")

    # scan-secrets
    p_sec = subparsers.add_parser("scan-secrets", help="Scan repository for leaked credentials, private keys, and tokens")
    p_sec.add_argument("path", nargs="?", default=".", help="Repository directory to scan (default: current repository)")
    p_sec.add_argument("--no-history", action="store_true", help="Scan only working tree, skipping git commit history")
    p_sec.add_argument("--depth", type=int, default=15, help="Number of recent commits to inspect (default: 15)")

    # audit-repos
    p_audit = subparsers.add_parser("audit-repos", help="Scan directory for repos containing legacy push/pull scripts")
    p_audit.add_argument("path", nargs="?", default=".", help="Directory to scan (default: current directory)")

    # clean-repo
    p_clean = subparsers.add_parser("clean-repo", help="Remove legacy push/pull scripts from an open-source repository")
    p_clean.add_argument("path", nargs="?", default=".", help="Repository path to clean (default: current directory)")
    p_clean.add_argument("--all", action="store_true", help="Clean all child repositories under path")
    p_clean.add_argument("--dry-run", action="store_true", help="Simulate removal without deleting files")

    # branches
    p_br = subparsers.add_parser("branches", aliases=["branch"], help="Display all local and remote branches with commit previews")
    p_br.add_argument("path", nargs="?", default=".", help="Repository path (default: current directory)")

    # switch
    p_sw = subparsers.add_parser("switch", aliases=["checkout"], help="Switch or create branches in the repository")
    p_sw.add_argument("branch", help="Target branch name")
    p_sw.add_argument("-c", "--create", action="store_true", help="Create new branch if it does not exist")
    p_sw.add_argument("--path", default=".", help="Repository path (default: current directory)")

    # dashboard / launcher
    subparsers.add_parser("dashboard", aliases=["launcher"], help="Open interactive terminal dashboard and project navigator")

    # config
    p_cfg = subparsers.add_parser("config", help="Manage persistent projects root and current project settings")
    p_cfg.add_argument("--root", help="Set the main projects root directory (e.g. ~/Projects)")
    p_cfg.add_argument("--project", help="Set active current project name")

    # build
    p_bld = subparsers.add_parser("build", help="Trigger cross-platform build orchestration via Orchestra")
    p_bld.add_argument("project", nargs="?", default=None, help="Target project to build (defaults to current repository)")
    p_bld.add_argument("--stage", action="store_true", help="Stage packages and run Fleet QA instead of build-only")
    p_bld.add_argument("--platform", choices=["all", "linux", "macos", "windows"], default="all", help="Filter target platform (default: all)")
    p_bld.add_argument("--force", action="store_true", help="Force rebuild even if version already exists")
    p_bld.add_argument("--dry-run", action="store_true", help="Run in check / dry-run mode")
    p_bld.add_argument("--limit", help="Limit execution to specific host or VM (e.g. rockylinux10, fedora44)")
    p_bld.add_argument("--no-tests", action="store_true", help="Skip pre-build automated test gate")

    # init
    p_init = subparsers.add_parser("init", help="Initialize a directory as a canonical Git repository")
    p_init.add_argument("path", nargs="?", default=".", help="Target directory (default: current directory)")
    p_init.add_argument("-b", "--branch", default="main", help="Default initial branch name (default: main)")
    p_init.add_argument("-r", "--remote", help="Configure remote origin URL immediately")
    p_init.add_argument("-t", "--type", choices=["python", "c", "bash", "web", "generic"], default="generic", help="Preset .gitignore template")
    p_init.add_argument("--initial-commit", dest="initial_commit", action="store_true", default=True, help="Create initial commit (default: True)")
    p_init.add_argument("--no-initial-commit", dest="initial_commit", action="store_false", help="Do not create initial commit")
    p_init.add_argument("-m", "--message", default="chore: initial repository structure", help="Initial commit message")

    # merge
    p_mrg = subparsers.add_parser("merge", help="Safely merge a branch with strategy options and conflict simulation")
    p_mrg.add_argument("branch", help="Source branch to merge into current active branch")
    p_mrg.add_argument("-s", "--strategy", choices=["ff", "squash", "rebase", "no-ff"], default="squash", help="Merge strategy (default: squash)")
    p_mrg.add_argument("-m", "--message", help="Custom commit message for squash or merge commit")
    p_mrg.add_argument("-d", "--dry-run", action="store_true", help="Simulate merge cleanly using git merge-tree without applying changes")
    p_mrg.add_argument("-p", "--prune", action="store_true", help="Automatically delete source branch if merge succeeds")
    p_mrg.add_argument("--no-test-gate", action="store_true", help="Bypass pre-merge test execution")

    # conflicts
    p_cfl = subparsers.add_parser("conflicts", help="Detect active Git conflict markers across working tree")
    p_cfl.add_argument("path", nargs="?", default=".", help="Repository directory to scan (default: current repository)")

    # scaffold
    p_scaf = subparsers.add_parser("scaffold", help="Generate or retrofit a canonical Wheelhouser project")
    p_scaf.add_argument("project_name", nargs="?", default=None, help="Name of the application or tool")
    p_scaf.add_argument("-t", "--type", choices=["python", "shell", "c"], default="python", help="Project language/framework runtime (default: python)")
    p_scaf.add_argument("-l", "--license", choices=["gpl", "mit", "proprietary"], default="gpl", help="License template (default: gpl)")
    p_scaf.add_argument("--existing", action="store_true", help="Retrofit an existing repository without overwriting existing code")
    p_scaf.add_argument("--dry-run", action="store_true", help="Preview files that would be created without writing them")

    # audit-compliance
    p_audc = subparsers.add_parser("audit-compliance", help="Inspect repository compliance against the 13 canonical rules")
    p_audc.add_argument("path", nargs="?", default=".", help="Repository directory to inspect (default: current repository)")

    # purge-history (alias: purge)
    p_prg = subparsers.add_parser("purge-history", aliases=["purge"], help="Permanently excise files or directories from Git history")
    p_prg.add_argument("path", help="Relative path of file or directory to purge across all commits")
    p_prg.add_argument("-y", "--yes", action="store_true", help="Confirm rewrite without interactive confirmation prompt")
    p_prg.add_argument("--push", action="store_true", help="Automatically force-push cleaned branches and tags to remote origin")
    p_prg.add_argument("--remote", default="origin", help="Target remote name when using --push (default: origin)")
    p_prg.add_argument("-d", "--dry-run", action="store_true", help="Simulate scan and list affected commits without rewriting")

    # If push, pull, sync, or undo, split known args to allow passing arbitrary flags/commit messages
    if len(argv) > 0 and argv[0] in ("push", "pull", "sync", "undo"):
        subcmd = argv[0]
        extra_args = argv[1:]
        if subcmd == "push":
            return cmd_push(argparse.Namespace(), extra_args)
        elif subcmd == "pull":
            return cmd_pull(argparse.Namespace(), extra_args)
        elif subcmd == "sync":
            return cmd_sync(argparse.Namespace(), extra_args)
        elif subcmd == "undo":
            return cmd_undo(argparse.Namespace(), extra_args)

    # When executed without arguments:
    if len(argv) == 0:
        if sys.stdin.isatty():
            return cmd_dashboard(argparse.Namespace())
        elif sys.platform == "darwin":
            from .dashboard import launch_in_macos_terminal
            if launch_in_macos_terminal():
                return 0

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    if args.command in ("dashboard", "launcher"):
        return cmd_dashboard(args)
    elif args.command == "config":
        return cmd_config(args)
    elif args.command == "install":
        return cmd_install(args)
    elif args.command == "uninstall":
        return cmd_uninstall(args)
    elif args.command == "status":
        return cmd_status(args)
    elif args.command == "graph":
        return cmd_graph(args)
    elif args.command in ("branches", "branch"):
        return cmd_branches(args)
    elif args.command in ("switch", "checkout"):
        return cmd_switch(args)
    elif args.command == "fleet-status":
        return cmd_fleet_status(args)
    elif args.command == "fleet-pull":
        return cmd_fleet_pull(args)
    elif args.command == "prune-branches":
        return cmd_prune_branches(args)
    elif args.command == "scan-secrets":
        return cmd_scan_secrets(args)
    elif args.command == "audit-repos":
        return cmd_audit_repos(args)
    elif args.command == "clean-repo":
        return cmd_clean_repo(args)
    elif args.command == "build":
        return cmd_build(args)
    elif args.command == "init":
        return cmd_init(args)
    elif args.command == "merge":
        return cmd_merge(args)
    elif args.command == "conflicts":
        return cmd_conflicts(args)
    elif args.command == "scaffold":
        return cmd_scaffold(args)
    elif args.command == "audit-compliance":
        return cmd_audit_compliance(args)
    elif args.command in ("purge-history", "purge"):
        return cmd_purge_history(args)

    return 0


if __name__ == "__main__":
    sys.exit(main())

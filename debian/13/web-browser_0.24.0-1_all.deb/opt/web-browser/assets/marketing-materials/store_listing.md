# Web-Browser from Wheelhouser - Microsoft Store Listing Materials

---

## 1. Short Description (Search & Summary)
> **Character Limit: ~100-200 characters**

Fast, privacy-focused desktop web browser powered by Chromium and Qt WebEngine with integrated ad blocking, native media streaming, and modern dark theme.

---

## 2. Full Store Description
> **Partner Center Store Listing: Description Field**

Experience the web with speed, clarity, and uncompromising privacy. **Web-Browser from Wheelhouser** delivers a modern, lightweight, and responsive browsing experience powered by Chromium and Qt WebEngine. Designed with efficiency and user control at its core, Web-Browser removes distractions, speeds up page loads with integrated ad and tracker blocking, and integrates natively with Windows 10 and Windows 11.

Whether you are managing complex web applications, researching across dozens of tabs, or streaming high-definition multimedia, Web-Browser provides the performance, stability, and clean aesthetic you expect from modern software.

### Key Highlights:

* **High-Performance Chromium Engine:** Powered by Qt WebEngine and modern Chromium architecture, delivering cutting-edge web standard compliance, fast JavaScript execution, and smooth graphics acceleration.
* **Built-in Ad & Tracker Blocker:** Block invasive advertisements, third-party analytics scripts, and intrusive banners out of the box for a faster, cleaner, and more private web.
* **Native Multimedia Streaming Server:** Built-in HTTP 206 partial content streaming engine for local video and audio playback, enabling seamless playback and instant seek performance.
* **Modern Dark & Light UI:** Sleek, distraction-free user interface designed to feel right at home on Windows 11 and Windows 10, complete with high-contrast form controls and custom themes.
* **Effortless Tab & Session Management:** Multi-tab workspace with instant search, pinned tabs, and persistent session recovery.
* **Privacy by Design:** Zero tracking, zero telemetry collection, and local data persistence. Your browsing history, downloads, and bookmarks stay strictly on your device.
* **Universal Windows Shell Integration:** Native taskbar grouping, unplated crisp high-DPI icons, and full support for Windows notifications and desktop shortcuts.

---

## 3. Product Features (Store Feature Bullets)
> **Partner Center Store Listing: Features Field (One per bullet)**

* Fast, modern web browsing powered by Chromium and Qt WebEngine
* Built-in ad blocker and privacy tracker prevention
* Native media streaming server with HTTP 206 byte-range seek support
* Clean, modern interface with Dark Mode and Light Mode support
* Multi-tab management with persistent session restoration
* Comprehensive bookmark management and fast history search
* Zero data tracking, zero third-party telemetry, 100% private
* Optimized for Windows 11 and Windows 10 with crisp high-DPI visuals

---

## 4. What's New in this Version (Release Notes - v0.14.1)
> **Partner Center Store Listing: What's new in this version Field**

### What's New in Version 0.14.1:

* **Windows Shell & AUMID Standardization:** Standardized unversioned AppUserModelID (AUMID) for seamless Windows taskbar grouping, smooth shortcut migration, and persistent notification handling across app updates.
* **High-DPI Icon Suite:** Added native unplated transparent icon scaling across all Windows 10 & Windows 11 taskbar, desktop, and Start Menu target sizes.
* **Media Streaming Engine Enhancements:** Optimized local HTTP byte-range streaming server for smoother video playback and instant seeking.
* **Form & UI Rendering Improvements:** Enhanced dark theme form control rendering (radio buttons, checkboxes, and Fluent UI controls) across modern web apps and portals.
* **Ad Blocker Performance:** Improved host matching efficiency and network request filtering for lower memory usage and faster page loads.
* **Security & Platform Updates:** Built with the latest security patches, Python runtime optimizations, and Qt WebEngine binaries.

---

## 5. Search Keywords / Tags
> **Partner Center Store Listing: Search Terms (Up to 7 terms, max 30 chars each)**

1. web browser
2. chromium browser
3. ad blocker browser
4. private browser
5. fast web browser
6. media browser
7. wheelhouser browser

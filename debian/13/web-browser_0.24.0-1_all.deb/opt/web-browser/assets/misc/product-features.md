Web Browser - Feature Highlights

Web Browser is a professional, privacy-centric web browsing application designed for power users and students. Built with a sleek dark-themed interface, it offers a distraction-free environment for focused research and web navigation. 
+2

🌐 Navigation & Tab Management

Persistent Sessions: The app remembers your open tabs, the current active tab, and even your specific zoom levels every time you restart. 
+1

Smart Tab Bar: Tabs display website favicons and automatically shrink to fit your window as you open more, ensuring a clean workspace.

Intuitive Controls:


Navigation: Dedicated Back, Forward, and Reload buttons with custom icons. 

Zoom Reset: A "100%" button to instantly return the page to its default scale.


New Tab: Integrated "Add Tab" button located directly on the tab bar for quick access. 

🛡️ Privacy & Customization

Local-First Philosophy: Your history, search settings, and disk cache are stored locally using a named QWebEngineProfile to ensure your data never leaves your machine. 
+1


Search Engine Freedom: Choose your preferred search engine; your choice is saved and persists across sessions. 


Bookmark Management: A dedicated sidebar to "Add" or "Delete" bookmarks, with a persistent min/max state so your layout stays exactly how you left it. 
+1

History Log: A built-in history feature allows you to view and manage a log of your visited URLs.

📥 Media & Downloads
Smart Image Saving: Right-click to "Save image as." The browser automatically detects the source file type and sets the correct extension in the save dialog. 


Clipboard Integration: Copy images directly from the web to paste into other applications seamlessly. 

Download Management: Files are automatically routed to your system's default Downloads folder, and the app remembers your last "Save to" directory for manual exports.

🎨 Workflow & Usability
Modern Aesthetics:

Pill-style URL Bar: A highly rounded, compact search bar integrated into the main theme.


Dark Mode: A custom CSS injection ensures even web view scrollbars match the dark-themed interface. 


Compact UI: Reduced padding on the main window edges for a more professional, space-efficient feel. 

Fullscreen Mode: Use F11 to toggle an immersive fullscreen experience for the active tab.


Tooltips: Every toolbar button includes a descriptive tooltip to help you navigate the interface. 

Technical Specifications
Platform: Windows, Linux, macOS (Python/PySide6 & QWebEngine based).


Storage: Named QWebEngineProfile for persistent local storage, disk cache, and cookies in the user's AppData directory. 


Graphics Engine: Hardware-accelerated rendering for smooth web performance and high-quality image handling.
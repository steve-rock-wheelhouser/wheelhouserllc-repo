#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Update Manager for Wheelhouser Applications
# Handles checking for updates, notifying users, and directing them to the update source.
# update_manager.py
# Copyright (C) 2026 Wheelhouser LLC

import sys
import os
import requests
import logging
import re
import platform
from PySide6.QtCore import QThread, Signal

class UpdateCheckThread(QThread):
    # Signal signature: latest_version, platform_url, release_notes
    update_available = Signal(str, str, str)
    up_to_date = Signal()
    error = Signal(str)

    def __init__(self, current_version, version_url=None, app_slug=None):
        super().__init__()
        self.current_version = current_version
        self.version_url = version_url or "https://wheelhouser.com/updates/web-browser/version.json"
        self.app_slug = app_slug

    def run(self):
        try:
            response = requests.get(self.version_url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                
                # Check if data is a multi-app unified manifest or app-specific manifest
                if self.app_slug and isinstance(data, dict) and self.app_slug in data:
                    app_entry = data[self.app_slug]
                else:
                    app_entry = data

                # Determine platform key and architecture
                if sys.platform == "win32":
                    platform_key = "windows"
                    platform_data = app_entry.get(platform_key, {}) if isinstance(app_entry, dict) else {}
                elif sys.platform == "darwin":
                    machine = platform.machine().lower()
                    mac_arch = "arm64" if ("arm" in machine or "aarch64" in machine) else "x86_64"
                    platform_key = f"macos_{mac_arch}"
                    legacy_key = f"macos {'apple-silicon' if mac_arch == 'arm64' else 'intel'}"
                    platform_data = (
                        app_entry.get(platform_key)
                        or app_entry.get(legacy_key)
                        or app_entry.get("macos")
                        or {}
                    ) if isinstance(app_entry, dict) else {}
                else:
                    platform_key = "linux"
                    platform_data = app_entry.get(platform_key, {}) if isinstance(app_entry, dict) else {}
                
                latest_version = str(
                    platform_data.get("latest_version", 
                    platform_data.get("version", 
                    app_entry.get("version", "0.0.0")))
                ).strip()
                
                target_url = platform_data.get(
                    "url", 
                    app_entry.get("fallback_url", "https://wheelhouser.com")
                )
                
                release_notes = platform_data.get("release_notes", app_entry.get("release_notes", ""))
                
                def parse_version(v):
                    normalized_parts = []
                    for segment in str(v).strip().split("."):
                        match = re.match(r"^(\d+)", segment.strip())
                        normalized_parts.append(int(match.group(1)) if match else 0)
                    while normalized_parts and normalized_parts[-1] == 0:
                        normalized_parts.pop()
                    return tuple(normalized_parts)

                def compare_versions(left, right):
                    left_parts = list(parse_version(left))
                    right_parts = list(parse_version(right))
                    max_length = max(len(left_parts), len(right_parts))
                    left_parts.extend([0] * (max_length - len(left_parts)))
                    right_parts.extend([0] * (max_length - len(right_parts)))
                    return tuple(left_parts), tuple(right_parts)
                
                current_version = str(self.current_version).strip()
                latest_parts, current_parts = compare_versions(latest_version, current_version)

                logging.info(
                    "Update check: current_version=%s latest_version=%s target_url=%s",
                    current_version,
                    latest_version,
                    target_url,
                )

                if latest_parts > current_parts:
                    self.update_available.emit(latest_version, target_url, release_notes)
                else:
                    self.up_to_date.emit()
            else:
                self.error.emit(f"Server returned HTTP {response.status_code}")
                
        except requests.RequestException as e:
            self.error.emit(f"Network error: {str(e)}")
        except Exception as e:
            self.error.emit(f"Parsing error: {str(e)}")
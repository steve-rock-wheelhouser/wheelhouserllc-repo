import os
import sys
import subprocess
import shutil
import threading
import socket
import socketserver
import logging
import json
import html
import glob
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote_plus
from urllib.request import url2pathname

logger = logging.getLogger(__name__)

ALLOWED_MEDIA_EXTS = (
    '.mp4', '.m4v', '.mov', '.mkv', '.avi', '.wmv', '.flv', '.ts', '.webm',
    '.m4a', '.mp3', '.wav', '.flac', '.ogg', '.aac', '.wma'
)

NATIVE_MEDIA_EXTS = (
    '.mp4', '.m4v', '.mov', '.webm',
    '.m4a', '.mp3', '.wav', '.flac', '.ogg', '.aac'
)

AUDIO_EXTS = (
    '.mp3', '.wav', '.flac', '.ogg', '.aac', '.wma', '.m4a'
)


def is_audio_media(path_or_url):
    if not path_or_url:
        return False
    lower = str(path_or_url).lower().split('?')[0].split('#')[0]
    ext = os.path.splitext(lower)[1]
    if ext in AUDIO_EXTS:
        return True
    mime = MEDIA_MIME_TYPES.get(ext, "")
    return mime.startswith("audio/")

MEDIA_MIME_TYPES = {
    '.mp4': 'video/mp4',
    '.m4v': 'video/mp4',
    '.mov': 'video/quicktime',
    '.webm': 'video/webm',
    '.mkv': 'video/x-matroska',
    '.avi': 'video/x-msvideo',
    '.wmv': 'video/x-ms-wmv',
    '.flv': 'video/x-flv',
    '.ts': 'video/mp2t',
    '.m4a': 'audio/mp4',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.flac': 'audio/flac',
    '.ogg': 'audio/ogg',
    '.aac': 'audio/aac',
    '.wma': 'audio/x-ms-wma',
}


def find_ffmpeg():
    exe_names = ["ffmpeg.exe", "ffmpeg"] if sys.platform != "win32" else ["ffmpeg.exe"]
    base_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    src_dir = os.path.dirname(os.path.abspath(__file__))
    exe_dir = os.path.dirname(sys.executable)

    # 1. Bundled / app-relative paths take precedence for self-contained packages
    bundled_dirs = [
        exe_dir,
        base_dir,
        src_dir,
        os.path.join(exe_dir, "..", "Resources"),
        os.path.join(exe_dir, "..", "Frameworks"),
        os.path.join(base_dir, "assets", "ffmpeg", "bin"),
        os.path.join(base_dir, "assets", "ffmpeg", "ffmpeg-master-latest-win64-gpl-shared", "bin"),
        os.path.join(exe_dir, "Scripts"),
    ]
    for b_dir in bundled_dirs:
        for name in exe_names:
            c = os.path.normpath(os.path.join(b_dir, name))
            if os.path.isfile(c) and (sys.platform == "win32" or os.access(c, os.X_OK)):
                return c

    # 2. PATH lookup
    path = shutil.which("ffmpeg")
    if path and os.path.isfile(path):
        return path

    # 3. Known system locations
    candidates = []
    if sys.platform == "win32":
        candidates.extend([
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-7.1-full_build\bin\ffmpeg.exe"),
            r"C:\ffmpeg\bin\ffmpeg.exe",
            r"C:\Program Files\ffmpeg\bin\ffmpeg.exe"
        ])
        candidates.extend(glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Programs\Python\Python*\Lib\site-packages\static_ffmpeg\**\ffmpeg.exe"), recursive=True))
        candidates.extend(glob.glob(os.path.expandvars(r"%APPDATA%\Python\Python*\site-packages\static_ffmpeg\**\ffmpeg.exe"), recursive=True))
    elif sys.platform == "darwin":
        candidates.extend([
            "/usr/local/bin/ffmpeg",
            "/opt/homebrew/bin/ffmpeg",
            "/opt/local/bin/ffmpeg",
            os.path.expanduser("~/bin/ffmpeg"),
            "/Applications/ffmpeg"
        ])
        candidates.extend(glob.glob(os.path.expanduser("~/Library/Python/*/lib/python/site-packages/static_ffmpeg/**/ffmpeg"), recursive=True))
        candidates.extend(glob.glob(os.path.expanduser("~/.local/share/static_ffmpeg/**/ffmpeg"), recursive=True))
    else:
        candidates.extend([
            "/usr/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/snap/bin/ffmpeg",
            os.path.expanduser("~/bin/ffmpeg"),
            os.path.expanduser("~/.local/bin/ffmpeg")
        ])
        candidates.extend(glob.glob(os.path.expanduser("~/.local/lib/python*/site-packages/static_ffmpeg/**/ffmpeg"), recursive=True))
    for c in candidates:
        if c and os.path.isfile(c) and (sys.platform == "win32" or os.access(c, os.X_OK)):
            return c
    return None


def find_ffprobe():
    exe_names = ["ffprobe.exe", "ffprobe"] if sys.platform != "win32" else ["ffprobe.exe"]
    base_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    src_dir = os.path.dirname(os.path.abspath(__file__))
    exe_dir = os.path.dirname(sys.executable)

    # 1. Bundled / app-relative paths take precedence for self-contained packages
    bundled_dirs = [
        exe_dir,
        base_dir,
        src_dir,
        os.path.join(exe_dir, "..", "Resources"),
        os.path.join(exe_dir, "..", "Frameworks"),
        os.path.join(base_dir, "assets", "ffmpeg", "bin"),
        os.path.join(base_dir, "assets", "ffmpeg", "ffmpeg-master-latest-win64-gpl-shared", "bin"),
        os.path.join(exe_dir, "Scripts"),
    ]
    for b_dir in bundled_dirs:
        for name in exe_names:
            c = os.path.normpath(os.path.join(b_dir, name))
            if os.path.isfile(c) and (sys.platform == "win32" or os.access(c, os.X_OK)):
                return c

    # 2. PATH lookup
    path = shutil.which("ffprobe")
    if path and os.path.isfile(path):
        return path

    # 3. Known system locations
    candidates = []
    if sys.platform == "win32":
        candidates.extend([
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffprobe.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-7.1-full_build\bin\ffprobe.exe"),
            r"C:\ffmpeg\bin\ffprobe.exe",
            r"C:\Program Files\ffmpeg\bin\ffprobe.exe"
        ])
        candidates.extend(glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Programs\Python\Python*\Lib\site-packages\static_ffmpeg\**\ffprobe.exe"), recursive=True))
        candidates.extend(glob.glob(os.path.expandvars(r"%APPDATA%\Python\Python*\site-packages\static_ffmpeg\**\ffprobe.exe"), recursive=True))
    elif sys.platform == "darwin":
        candidates.extend([
            "/usr/local/bin/ffprobe",
            "/opt/homebrew/bin/ffprobe",
            "/opt/local/bin/ffprobe",
            os.path.expanduser("~/bin/ffprobe"),
            "/Applications/ffprobe"
        ])
        candidates.extend(glob.glob(os.path.expanduser("~/Library/Python/*/lib/python/site-packages/static_ffmpeg/**/ffprobe"), recursive=True))
        candidates.extend(glob.glob(os.path.expanduser("~/.local/share/static_ffmpeg/**/ffprobe"), recursive=True))
    else:
        candidates.extend([
            "/usr/bin/ffprobe",
            "/usr/local/bin/ffprobe",
            "/snap/bin/ffprobe",
            os.path.expanduser("~/bin/ffprobe"),
            os.path.expanduser("~/.local/bin/ffprobe")
        ])
        candidates.extend(glob.glob(os.path.expanduser("~/.local/lib/python*/site-packages/static_ffmpeg/**/ffprobe"), recursive=True))
    for c in candidates:
        if c and os.path.isfile(c) and (sys.platform == "win32" or os.access(c, os.X_OK)):
            return c
    return None


def has_video_stream(file_path):
    if not file_path or not os.path.isfile(file_path):
        return not is_audio_media(file_path)
    if is_audio_media(file_path):
        return False
    probe = find_ffprobe()
    if not probe:
        return True
    try:
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        cmd = [
            probe,
            "-v", "error",
            "-show_entries", "stream=codec_type",
            "-of", "json",
            file_path
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=3, creationflags=creationflags)
        if res.returncode == 0:
            data = json.loads(res.stdout)
            types = [s.get("codec_type") for s in data.get("streams", [])]
            return "video" in types
    except Exception:
        pass
    return True


def get_media_duration(file_path):
    probe = find_ffprobe()
    if not probe:
        return 0
    try:
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        cmd = [
            probe,
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "json",
            file_path
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=3, creationflags=creationflags)
        if res.returncode == 0:
            data = json.loads(res.stdout)
            return float(data.get("format", {}).get("duration", 0))
    except Exception:
        pass
    return 0


class MediaStreamHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def server_bind(self):
        # Override to bypass socket.getfqdn(host) which triggers blocking
        # reverse DNS / mDNS resolution (mdns_hostbyaddr) on macOS and Linux.
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = str(host)
        self.server_port = port


class MediaStreamHandler(BaseHTTPRequestHandler):
    def address_string(self):
        # Bypass socket.getfqdn(host) to prevent per-request reverse DNS lookups
        return self.client_address[0]

    def is_authorized_origin(self):
        # Allow requests to /stream, /favicon.ico and direct browser navigation
        parsed = urlparse(self.path)
        if parsed.path in ("/stream", "/favicon.ico"):
            return True
        origin = self.headers.get("Origin")
        referer = self.headers.get("Referer")
        if not origin and not referer:
            return True
        allowed_hosts = ("127.0.0.1", "localhost")
        if origin:
            parsed_origin = urlparse(origin)
            if parsed_origin.hostname not in allowed_hosts:
                return False
        if referer:
            parsed_ref = urlparse(referer)
            if parsed_ref.hostname not in allowed_hosts:
                return False
        return True

    def resolve_local_path(self, target_url):
        target_url_unquoted = unquote(target_url)
        if "%" in target_url_unquoted:
            target_url_unquoted = unquote(target_url_unquoted)

        # Strip query and fragment if present
        clean_url = target_url_unquoted.split("?")[0].split("#")[0]

        if clean_url.startswith("file://"):
            local_p = url2pathname(urlparse(clean_url).path)
            if sys.platform == "win32":
                local_p = local_p.replace("/", "\\")
                while local_p.startswith("\\\\"):
                    local_p = local_p[1:]
                if len(local_p) >= 3 and local_p[0] == '\\' and local_p[2] == ':':
                    local_p = local_p[1:]
            return local_p
        elif (len(clean_url) >= 2 and clean_url[1] == ":") or clean_url.startswith("/") or clean_url.startswith("\\"):
            local_p = clean_url
            if sys.platform == "win32":
                local_p = local_p.replace("/", "\\")
            return local_p
        elif os.path.exists(clean_url):
            return os.path.abspath(clean_url)
        return None

    def do_HEAD(self):
        if not self.is_authorized_origin():
            self.send_error(403, "Forbidden")
            return
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path == "/stream":
            target_url = query.get("url", [None])[0]
            if not target_url:
                self.send_error(400, "Missing url parameter")
                return
            is_remote = target_url.startswith("http://") or target_url.startswith("https://")
            local_path = self.resolve_local_path(target_url) if not is_remote else None
            input_source = local_path if (local_path and os.path.isfile(local_path)) else (target_url if is_remote else None)
            if input_source:
                self.send_response(200)
                self.send_header("Content-Type", "video/webm")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_OPTIONS(self):
        if not self.is_authorized_origin():
            self.send_error(403, "Forbidden")
            return
        self.send_response(200)
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()

    def do_GET(self):
        if not self.is_authorized_origin():
            self.send_error(403, "Forbidden")
            return

        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        if parsed.path == "/player":
            target_url = query.get("url", [None])[0]
            if not target_url:
                self.send_error(400, "Missing url parameter")
                return

            local_path = self.resolve_local_path(target_url)
            duration = 0
            filename = target_url
            mime_type = "video/mp4"
            ext = ""
            if local_path and os.path.exists(local_path):
                lower = local_path.lower().split('?')[0].split('#')[0]
                if not any(lower.endswith(e) for e in ALLOWED_MEDIA_EXTS):
                    self.send_error(403, "Forbidden: Invalid file type")
                    return
                ext = os.path.splitext(lower)[1]
                mime_type = MEDIA_MIME_TYPES.get(ext, "video/mp4")
                filename = os.path.basename(local_path) or local_path
                duration = get_media_duration(local_path)
            else:
                lower = target_url.lower().split('?')[0].split('#')[0]
                ext = os.path.splitext(lower)[1]
                mime_type = MEDIA_MIME_TYPES.get(ext, "video/mp4")

            ffmpeg_path = find_ffmpeg()
            is_audio = is_audio_media(local_path if (local_path and os.path.isfile(local_path)) else target_url)

            if is_audio:
                source_mime_type = "audio/webm" if ffmpeg_path else mime_type
                format_badge = "MP3 Audio" if ext == ".mp3" else ("WAV Audio" if ext == ".wav" else (f"{ext.lstrip('.').upper()} Audio" if ext else "Audio Track"))
                badge_text = "Web-Browser Audio Player"
                icon = "🎵"
            else:
                source_mime_type = "video/webm" if ffmpeg_path else mime_type
                format_badge = f"{ext.lstrip('.').upper()} Video" if ext else "Video"
                badge_text = "Web-Browser Media Player"
                icon = "🎬"

            has_ffmpeg_js = "true" if ffmpeg_path else "false"
            is_audio_js = "true" if is_audio else "false"
            container_audio_class = " audio-mode" if is_audio else ""

            parent_url = ""
            if local_path:
                parent_dir = os.path.dirname(local_path)
                if parent_dir:
                    if sys.platform == "win32":
                        parent_url = "file:///" + parent_dir.replace("\\", "/")
                    else:
                        parent_url = "file://" + parent_dir

            stream_url = f"/stream?url={quote_plus(target_url)}"
            escaped_filename = html.escape(filename)

            audio_visualizer_html = """
        <div class="audio-visualizer-container paused" id="audioVisualizer">
            <div class="audio-ambient-glow"></div>
            <div class="audio-card">
                <div class="vinyl-disc" id="vinylDisc" title="Click to Play / Pause">
                    <div class="vinyl-groove-1"></div>
                    <div class="vinyl-groove-2"></div>
                    <div class="vinyl-center">
                        <span class="vinyl-icon">{icon}</span>
                    </div>
                </div>
                <div class="audio-info">
                    <div class="audio-title" title="{escaped_filename}">{escaped_filename}</div>
                    <div class="audio-badge-row">
                        <span class="audio-pill">{format_badge}</span>
                        <span class="audio-status" id="audioStatusText">Ready</span>
                    </div>
                </div>
                <div class="audio-equalizer" id="audioEqualizer">
                    <div class="eq-bar bar-1"></div>
                    <div class="eq-bar bar-2"></div>
                    <div class="eq-bar bar-3"></div>
                    <div class="eq-bar bar-4"></div>
                    <div class="eq-bar bar-5"></div>
                    <div class="eq-bar bar-6"></div>
                    <div class="eq-bar bar-7"></div>
                    <div class="eq-bar bar-8"></div>
                    <div class="eq-bar bar-9"></div>
                    <div class="eq-bar bar-10"></div>
                    <div class="eq-bar bar-11"></div>
                    <div class="eq-bar bar-12"></div>
                </div>
            </div>
        </div>
""".format(icon=icon, escaped_filename=escaped_filename, format_badge=format_badge) if is_audio else ""

            html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{escaped_filename}</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; user-select: none; }}
        body {{
            background-color: #000;
            color: #f3f4f6;
            font-family: "Segoe UI", -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }}
        .player-container {{
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
            position: relative;
            cursor: default;
        }}
        .player-container.idle {{
            cursor: none;
        }}
        .player-container.audio-mode {{
            background: radial-gradient(circle at center, #1e1b4b 0%, #0f172a 50%, #030712 100%);
        }}
        .player-container.audio-mode video {{
            position: absolute;
            width: 1px;
            height: 1px;
            opacity: 0;
            pointer-events: none;
        }}
        .audio-visualizer-container {{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 5;
            position: relative;
        }}
        .audio-ambient-glow {{
            position: absolute;
            width: 340px;
            height: 340px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(99, 102, 241, 0.28) 0%, rgba(37, 99, 235, 0.15) 50%, transparent 75%);
            filter: blur(45px);
            pointer-events: none;
            animation: pulseGlow 4s ease-in-out infinite alternate;
        }}
        @keyframes pulseGlow {{
            0% {{ transform: scale(0.9); opacity: 0.55; }}
            100% {{ transform: scale(1.15); opacity: 1; }}
        }}
        .audio-card {{
            background: rgba(17, 24, 39, 0.65);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 28px;
            padding: 36px 44px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.8), 0 0 40px rgba(59, 130, 246, 0.15);
            max-width: 480px;
            width: 90vw;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }}
        .audio-card:hover {{
            box-shadow: 0 30px 70px -15px rgba(0, 0, 0, 0.9), 0 0 50px rgba(99, 102, 241, 0.25);
        }}
        .vinyl-disc {{
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: radial-gradient(circle, #1e293b 0%, #0f172a 40%, #1e293b 50%, #0f172a 75%, #1e1b4b 100%);
            border: 4px solid rgba(255, 255, 255, 0.16);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7), inset 0 0 15px rgba(0, 0, 0, 0.8);
            position: relative;
            cursor: pointer;
            animation: spinVinyl 10s linear infinite;
            animation-play-state: paused;
            transition: transform 0.2s ease;
        }}
        .audio-visualizer-container.playing .vinyl-disc {{
            animation-play-state: running;
        }}
        .vinyl-disc:hover {{
            transform: scale(1.04);
        }}
        .vinyl-disc:active {{
            transform: scale(0.96);
        }}
        @keyframes spinVinyl {{
            from {{ transform: rotate(0deg); }}
            to {{ transform: rotate(360deg); }}
        }}
        .vinyl-groove-1, .vinyl-groove-2 {{
            position: absolute;
            border-radius: 50%;
            border: 1px dashed rgba(255, 255, 255, 0.08);
            pointer-events: none;
        }}
        .vinyl-groove-1 {{ width: 110px; height: 110px; }}
        .vinyl-groove-2 {{ width: 75px; height: 75px; }}
        .vinyl-center {{
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2563eb, #7c3aed);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.5);
        }}
        .vinyl-icon {{
            font-size: 24px;
            user-select: none;
        }}
        .audio-info {{
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            width: 100%;
        }}
        .audio-title {{
            font-size: 17px;
            font-weight: 700;
            color: #f8fafc;
            text-align: center;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            letter-spacing: -0.2px;
        }}
        .audio-badge-row {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .audio-pill {{
            font-size: 11px;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 9999px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: #fff;
            letter-spacing: 0.5px;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.4);
        }}
        .audio-status {{
            font-size: 12px;
            color: #94a3b8;
            font-weight: 500;
        }}
        .audio-equalizer {{
            display: flex;
            align-items: flex-end;
            justify-content: center;
            gap: 4px;
            height: 36px;
            padding-top: 6px;
        }}
        .eq-bar {{
            width: 4px;
            border-radius: 2px;
            background: linear-gradient(to top, #3b82f6, #a855f7);
            height: 4px;
            transition: height 0.15s ease;
        }}
        .audio-visualizer-container.playing .eq-bar {{
            animation: eqBounce 1.1s ease-in-out infinite alternate;
        }}
        .audio-visualizer-container.paused .eq-bar {{
            animation-play-state: paused;
            height: 4px !important;
        }}
        @keyframes eqBounce {{
            0% {{ height: 4px; }}
            100% {{ height: 32px; }}
        }}
        .bar-1 {{ animation-delay: 0.05s !important; }}
        .bar-2 {{ animation-delay: 0.25s !important; }}
        .bar-3 {{ animation-delay: 0.45s !important; }}
        .bar-4 {{ animation-delay: 0.15s !important; }}
        .bar-5 {{ animation-delay: 0.35s !important; }}
        .bar-6 {{ animation-delay: 0.55s !important; }}
        .bar-7 {{ animation-delay: 0.1s !important; }}
        .bar-8 {{ animation-delay: 0.3s !important; }}
        .bar-9 {{ animation-delay: 0.5s !important; }}
        .bar-10 {{ animation-delay: 0.2s !important; }}
        .bar-11 {{ animation-delay: 0.4s !important; }}
        .bar-12 {{ animation-delay: 0.15s !important; }}
        .player-container.audio-mode .header,
        .player-container.audio-mode .controls-container {{
            opacity: 1 !important;
            pointer-events: auto !important;
        }}
        video {{
            width: 100%;
            height: 100%;
            max-width: 100%;
            max-height: 100%;
            outline: none;
            background: #000;
        }}
        .header {{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            padding: 16px 24px;
            background: linear-gradient(to bottom, rgba(0,0,0,0.85), rgba(0,0,0,0));
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 10;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }}
        .header.hidden, .controls-container.hidden {{
            opacity: 0;
            pointer-events: none !important;
        }}
        .header-left {{
            display: flex;
            align-items: center;
            gap: 12px;
            max-width: 80%;
            pointer-events: auto;
        }}
        .back-btn {{
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #f1f5f9;
            padding: 5px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.15s ease, border-color 0.15s ease;
        }}
        .back-btn:hover {{
            background: rgba(255, 255, 255, 0.25);
            border-color: rgba(255, 255, 255, 0.4);
        }}
        .back-btn svg {{
            width: 16px;
            height: 16px;
            fill: currentColor;
        }}
        .title {{
            font-size: 15px;
            font-weight: 600;
            color: #e2e8f0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-shadow: 0 1px 3px rgba(0,0,0,0.8);
        }}
        .badge {{
            font-size: 11px;
            padding: 4px 10px;
            border-radius: 4px;
            background: #2563eb;
            color: #fff;
            font-weight: 600;
            box-shadow: 0 2px 4px rgba(0,0,0,0.4);
        }}
        .controls-container {{
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 20px 24px 16px 24px;
            background: linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.6) 60%, rgba(0,0,0,0) 100%);
            display: flex;
            flex-direction: column;
            gap: 8px;
            z-index: 10;
            transition: opacity 0.3s ease;
        }}
        .progress-area {{
            position: relative;
            width: 100%;
            height: 16px;
            display: flex;
            align-items: center;
            cursor: pointer;
        }}
        .progress-bar-bg {{
            width: 100%;
            height: 5px;
            background: rgba(255, 255, 255, 0.25);
            border-radius: 3px;
            position: relative;
            transition: height 0.15s ease;
        }}
        .progress-area:hover .progress-bar-bg, .progress-area.scrubbing .progress-bar-bg {{
            height: 8px;
        }}
        .progress-bar-played {{
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 0%;
            background: #2563eb;
            border-radius: 3px;
            pointer-events: none;
        }}
        .progress-thumb {{
            position: absolute;
            top: 50%;
            right: -6px;
            transform: translateY(-50%) scale(0);
            width: 14px;
            height: 14px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 0 6px rgba(0,0,0,0.6);
            transition: transform 0.15s ease;
            pointer-events: none;
        }}
        .progress-area:hover .progress-thumb, .progress-area.scrubbing .progress-thumb {{
            transform: translateY(-50%) scale(1);
        }}
        .tooltip {{
            position: absolute;
            bottom: 24px;
            transform: translateX(-50%);
            background: rgba(18, 18, 18, 0.9);
            color: #fff;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
            pointer-events: none;
            display: none;
            white-space: nowrap;
            box-shadow: 0 2px 6px rgba(0,0,0,0.5);
        }}
        .controls-row {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
        }}
        .controls-left, .controls-right {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .btn {{
            background: transparent;
            border: none;
            color: #e2e8f0;
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.15s ease, color 0.15s ease, transform 0.1s ease;
        }}
        .btn:hover {{
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
        }}
        .btn:active {{
            transform: scale(0.92);
        }}
        .btn svg {{
            width: 20px;
            height: 20px;
            fill: currentColor;
        }}
        .time-display {{
            font-size: 13px;
            font-weight: 500;
            color: #cbd5e1;
            margin-left: 4px;
            letter-spacing: 0.5px;
        }}
        .volume-container {{
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .volume-slider {{
            -webkit-appearance: none;
            appearance: none;
            width: 70px;
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 2px;
            outline: none;
            cursor: pointer;
            transition: width 0.2s ease;
        }}
        .volume-slider::-webkit-slider-thumb {{
            -webkit-appearance: none;
            appearance: none;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #fff;
            cursor: pointer;
            box-shadow: 0 0 4px rgba(0,0,0,0.5);
        }}
    </style>
</head>
<body>
    <div class="player-container{container_audio_class}" id="playerContainer">
        {audio_visualizer_html}
        <video id="videoPlayer" playsinline>
            <source src="{stream_url}" type="{source_mime_type}">
            Your browser does not support playing this media stream.
        </video>
        
        <div class="header" id="headerBar">
            <div class="header-left">
                <button class="back-btn" id="playerBackBtn" title="Back to Folder">
                    <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                    <span>Back</span>
                </button>
                <div class="title">{icon} {escaped_filename}</div>
            </div>
            <div class="badge">{badge_text}</div>
        </div>

        <div class="controls-container" id="controlsBar">
            <div class="progress-area" id="progressArea">
                <div class="tooltip" id="timeTooltip">00:00</div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-played" id="progressBarPlayed">
                        <div class="progress-thumb"></div>
                    </div>
                </div>
            </div>
            
            <div class="controls-row">
                <div class="controls-left">
                    <button class="btn" id="playBtn" title="Play / Pause (Space)">
                        <svg id="playIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                        <svg id="pauseIcon" viewBox="0 0 24 24" style="display:none;"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                    </button>
                    <button class="btn" id="seekBackBtn" title="Rewind 10s (Left Arrow)">
                        <svg viewBox="0 0 24 24"><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8zm-1.1 11h-.8v-3.3h-.9v-.7h1.7V16zm3.6-2.2c0 .8-.5 1.2-1.2 1.2s-1.2-.4-1.2-1.2v-1.6c0-.8.5-1.2 1.2-1.2s1.2.4 1.2 1.2v1.6zm-.8 0v-1.6c0-.4-.1-.6-.4-.6s-.4.2-.4.6v1.6c0 .4.1.6.4.6s.4-.2.4-.6z"/></svg>
                    </button>
                    <button class="btn" id="seekFwdBtn" title="Forward 10s (Right Arrow)">
                        <svg viewBox="0 0 24 24"><path d="M12 5V1l5 5-5 5V7c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6h2c0 4.42-3.58 8-8 8s-8-3.58-8-8 3.58-8 8-8zm-1.1 11h-.8v-3.3h-.9v-.7h1.7V16zm3.6-2.2c0 .8-.5 1.2-1.2 1.2s-1.2-.4-1.2-1.2v-1.6c0-.8.5-1.2 1.2-1.2s1.2.4 1.2 1.2v1.6zm-.8 0v-1.6c0-.4-.1-.6-.4-.6s-.4.2-.4.6v1.6c0 .4.1.6.4.6s.4-.2.4-.6z"/></svg>
                    </button>
                    <div class="volume-container">
                        <button class="btn" id="muteBtn" title="Mute / Unmute (M)">
                            <svg id="volHighIcon" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                            <svg id="volMuteIcon" viewBox="0 0 24 24" style="display:none;"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>
                        </button>
                        <input type="range" class="volume-slider" id="volSlider" min="0" max="1" step="0.05" value="1">
                    </div>
                    <div class="time-display" id="timeDisplay">00:00 / 00:00</div>
                </div>
                <div class="controls-right">
                    <button class="btn" id="fsBtn" title="Toggle Fullscreen (F)">
                        <svg id="fsEnterIcon" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
                        <svg id="fsExitIcon" viewBox="0 0 24 24" style="display:none;"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const container = document.getElementById('playerContainer');
        const video = document.getElementById('videoPlayer');
        const header = document.getElementById('headerBar');
        const playerBackBtn = document.getElementById('playerBackBtn');
        const controls = document.getElementById('controlsBar');
        const playBtn = document.getElementById('playBtn');
        const playIcon = document.getElementById('playIcon');
        const pauseIcon = document.getElementById('pauseIcon');
        const seekBackBtn = document.getElementById('seekBackBtn');
        const seekFwdBtn = document.getElementById('seekFwdBtn');
        const muteBtn = document.getElementById('muteBtn');
        const volHighIcon = document.getElementById('volHighIcon');
        const volMuteIcon = document.getElementById('volMuteIcon');
        const volSlider = document.getElementById('volSlider');
        const timeDisplay = document.getElementById('timeDisplay');
        const progressArea = document.getElementById('progressArea');
        const progressBarPlayed = document.getElementById('progressBarPlayed');
        const timeTooltip = document.getElementById('timeTooltip');
        const fsBtn = document.getElementById('fsBtn');
        const fsEnterIcon = document.getElementById('fsEnterIcon');
        const fsExitIcon = document.getElementById('fsExitIcon');

        const isAudio = {is_audio_js};
        const audioVisualizer = document.getElementById('audioVisualizer');
        const vinylDisc = document.getElementById('vinylDisc');
        const audioStatusText = document.getElementById('audioStatusText');

        if (vinylDisc) {{
            vinylDisc.addEventListener('click', (e) => {{
                e.stopPropagation();
                togglePlay();
            }});
        }}

        const totalDuration = {duration};
        const baseUrl = "{stream_url}";
        const parentUrl = "{parent_url}";
        const hasFfmpeg = {has_ffmpeg_js};
        let currentOffset = 0;
        let isScrubbing = false;
        let isUserPaused = false;
        let hideTimer;

        if (playerBackBtn) {{
            playerBackBtn.addEventListener('click', (e) => {{
                e.stopPropagation();
                if (window.history.length > 1) {{
                    window.history.back();
                }} else if (parentUrl) {{
                    window.location.href = parentUrl;
                }}
            }});
        }}

        function formatTime(sec) {{
            if (isNaN(sec) || sec < 0) sec = 0;
            const s = Math.floor(sec);
            const m = Math.floor(s / 60);
            const h = Math.floor(m / 60);
            const displaySec = (s % 60).toString().padStart(2, '0');
            const displayMin = (m % 60).toString().padStart(2, '0');
            if (h > 0) {{
                return h + ':' + displayMin + ':' + displaySec;
            }}
            return displayMin + ':' + displaySec;
        }}

        function updateProgress() {{
            const currentTotalTime = currentOffset + (video.currentTime || 0);
            const effectiveDuration = totalDuration > 0 ? totalDuration : (video.duration || currentTotalTime || 1);
            const percent = Math.min(100, Math.max(0, (currentTotalTime / effectiveDuration) * 100));
            progressBarPlayed.style.width = percent + '%';
            timeDisplay.innerText = formatTime(currentTotalTime) + ' / ' + formatTime(totalDuration);
            if (totalDuration > 0 && currentTotalTime >= totalDuration && !video.paused && !isUserPaused) {{
                video.pause();
                isUserPaused = true;
                playIcon.style.display = 'block';
                pauseIcon.style.display = 'none';
                showControls();
            }}
        }}

        function seekTo(targetSeconds) {{
            if (targetSeconds < 0) targetSeconds = 0;
            if (totalDuration > 0 && targetSeconds > totalDuration) targetSeconds = totalDuration;
            const shouldPlay = !isUserPaused && !video.paused && !video.ended;
            if (hasFfmpeg) {{
                currentOffset = targetSeconds;
                video.src = baseUrl + "&start=" + encodeURIComponent(targetSeconds);
                video.load();
                if (shouldPlay) {{
                    video.play().catch(() => {{}});
                }}
            }} else {{
                video.currentTime = targetSeconds;
                if (shouldPlay) {{
                    video.play().catch(() => {{}});
                }}
            }}
            updateProgress();
        }}

        function getScrubTimeFromEvent(e) {{
            const rect = progressArea.getBoundingClientRect();
            const pos = Math.min(Math.max(0, e.clientX - rect.left), rect.width);
            const percent = pos / rect.width;
            const effectiveDuration = totalDuration > 0 ? totalDuration : (video.duration || 1);
            return {{ time: percent * effectiveDuration, percent: percent * 100, x: pos }};
        }}

        progressArea.addEventListener('mousemove', (e) => {{
            const {{ time, x }} = getScrubTimeFromEvent(e);
            timeTooltip.style.display = 'block';
            timeTooltip.style.left = x + 'px';
            timeTooltip.innerText = formatTime(time);
        }});

        progressArea.addEventListener('mouseleave', () => {{
            if (!isScrubbing) timeTooltip.style.display = 'none';
        }});

        progressArea.addEventListener('mousedown', (e) => {{
            isScrubbing = true;
            progressArea.classList.add('scrubbing');
            const {{ time }} = getScrubTimeFromEvent(e);
            seekTo(time);
        }});

        document.addEventListener('mousemove', (e) => {{
            if (isScrubbing) {{
                const {{ time, x }} = getScrubTimeFromEvent(e);
                timeTooltip.style.display = 'block';
                timeTooltip.style.left = x + 'px';
                timeTooltip.innerText = formatTime(time);
                seekTo(time);
            }}
        }});

        document.addEventListener('mouseup', () => {{
            if (isScrubbing) {{
                isScrubbing = false;
                progressArea.classList.remove('scrubbing');
                timeTooltip.style.display = 'none';
            }}
        }});

        function togglePlay() {{
            const isAtEnd = video.ended || (totalDuration > 0 && (currentOffset + (video.currentTime || 0)) >= totalDuration);
            if (video.paused || isAtEnd) {{
                if (isAtEnd) {{
                    seekTo(0);
                }}
                isUserPaused = false;
                video.play().catch(() => {{}});
            }} else {{
                isUserPaused = true;
                video.pause();
            }}
        }}

        playBtn.addEventListener('click', (e) => {{
            e.stopPropagation();
            togglePlay();
        }});
        video.addEventListener('click', (e) => {{
            e.stopPropagation();
            togglePlay();
        }});
        video.addEventListener('dblclick', toggleFullscreen);

        video.addEventListener('play', () => {{
            isUserPaused = false;
            playIcon.style.display = 'none';
            pauseIcon.style.display = 'block';
            if (audioVisualizer) {{
                audioVisualizer.classList.remove('paused');
                audioVisualizer.classList.add('playing');
            }}
            if (audioStatusText) {{
                audioStatusText.innerText = 'Playing';
            }}
            resetControlsTimer();
        }});

        video.addEventListener('pause', () => {{
            playIcon.style.display = 'block';
            pauseIcon.style.display = 'none';
            if (audioVisualizer) {{
                audioVisualizer.classList.remove('playing');
                audioVisualizer.classList.add('paused');
            }}
            if (audioStatusText) {{
                audioStatusText.innerText = 'Paused';
            }}
            showControls();
        }});

        video.addEventListener('ended', () => {{
            isUserPaused = true;
            playIcon.style.display = 'block';
            pauseIcon.style.display = 'none';
            if (audioVisualizer) {{
                audioVisualizer.classList.remove('playing');
                audioVisualizer.classList.add('paused');
            }}
            if (audioStatusText) {{
                audioStatusText.innerText = 'Ended';
            }}
            showControls();
            updateProgress();
        }});

        seekBackBtn.addEventListener('click', (e) => {{
            e.stopPropagation();
            seekTo((currentOffset + (video.currentTime || 0)) - 10);
        }});

        seekFwdBtn.addEventListener('click', (e) => {{
            e.stopPropagation();
            seekTo((currentOffset + (video.currentTime || 0)) + 10);
        }});

        volSlider.addEventListener('input', (e) => {{
            video.volume = parseFloat(e.target.value);
            video.muted = (video.volume === 0);
            updateVolumeUI();
        }});

        function updateVolumeUI() {{
            if (video.muted || video.volume === 0) {{
                volHighIcon.style.display = 'none';
                volMuteIcon.style.display = 'block';
            }} else {{
                volHighIcon.style.display = 'block';
                volMuteIcon.style.display = 'none';
            }}
        }}

        muteBtn.addEventListener('click', () => {{
            video.muted = !video.muted;
            if (!video.muted && video.volume === 0) {{
                video.volume = 0.5;
                volSlider.value = 0.5;
            }}
            updateVolumeUI();
        }});

        function toggleFullscreen() {{
            if (!document.fullscreenElement) {{
                container.requestFullscreen().catch(() => {{}});
            }} else {{
                document.exitFullscreen().catch(() => {{}});
            }}
        }}

        fsBtn.addEventListener('click', toggleFullscreen);
        document.addEventListener('fullscreenchange', () => {{
            if (document.fullscreenElement) {{
                fsEnterIcon.style.display = 'none';
                fsExitIcon.style.display = 'block';
            }} else {{
                fsEnterIcon.style.display = 'block';
                fsExitIcon.style.display = 'none';
            }}
        }});

        function showControls() {{
            header.classList.remove('hidden');
            controls.classList.remove('hidden');
            container.classList.remove('idle');
            clearTimeout(hideTimer);
        }}

        function resetControlsTimer() {{
            showControls();
            hideTimer = setTimeout(() => {{
                if (!video.paused && !isScrubbing && !isAudio) {{
                    header.classList.add('hidden');
                    controls.classList.add('hidden');
                    container.classList.add('idle');
                }}
            }}, 2500);
        }}

        container.addEventListener('mousemove', resetControlsTimer);

        // Periodically update progress bar and time label
        video.addEventListener('timeupdate', updateProgress);
        setInterval(updateProgress, 250);

        function tryPlay() {{
            if (isUserPaused || video.ended) return;
            const p = video.play();
            if (p !== undefined) {{
                p.catch(() => {{}});
            }}
        }}

        video.addEventListener('loadedmetadata', () => {{ if (!isUserPaused) tryPlay(); }});
        video.addEventListener('loadeddata', () => {{ if (!isUserPaused) tryPlay(); }});
        video.addEventListener('canplay', () => {{ if (!isUserPaused) tryPlay(); }});
        window.addEventListener('DOMContentLoaded', () => {{
            updateProgress();
            if (!isUserPaused) tryPlay();
        }});
        setTimeout(() => {{ if (!isUserPaused) tryPlay(); }}, 100);
        setTimeout(() => {{ if (!isUserPaused) tryPlay(); }}, 300);
        setTimeout(() => {{ if (!isUserPaused) tryPlay(); }}, 800);

        window.addEventListener('keydown', (e) => {{
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            switch(e.code) {{
                case 'Space':
                case 'KeyK':
                    e.preventDefault();
                    togglePlay();
                    break;
                case 'ArrowLeft':
                case 'KeyJ':
                    e.preventDefault();
                    seekTo((currentOffset + video.currentTime) - 10);
                    break;
                case 'ArrowRight':
                case 'KeyL':
                    e.preventDefault();
                    seekTo((currentOffset + video.currentTime) + 10);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    video.volume = Math.min(1.0, video.volume + 0.1);
                    volSlider.value = video.volume;
                    updateVolumeUI();
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    video.volume = Math.max(0.0, video.volume - 0.1);
                    volSlider.value = video.volume;
                    updateVolumeUI();
                    break;
                case 'KeyM':
                    e.preventDefault();
                    video.muted = !video.muted;
                    updateVolumeUI();
                    break;
                case 'KeyF':
                    e.preventDefault();
                    toggleFullscreen();
                    break;
            }}
        }});
    </script>
</body>
</html>
"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html_doc.encode("utf-8"))
            return

        elif parsed.path == "/stream":
            target_url = query.get("url", [None])[0]
            if not target_url:
                self.send_error(400, "Missing url parameter")
                return

            local_path = self.resolve_local_path(target_url)
            start_time = float(query.get("start", [0])[0])

            if local_path:
                lower = local_path.lower().split('?')[0].split('#')[0]
                ext = os.path.splitext(lower)[1]
                if not any(lower.endswith(e) for e in ALLOWED_MEDIA_EXTS):
                    self.send_error(403, "Forbidden: Invalid file type")
                    return
                if not os.path.exists(local_path) or not os.path.isfile(local_path):
                    self.send_error(404, f"File not found: {local_path}")
                    return

                ffmpeg_path = find_ffmpeg()

                if not ffmpeg_path:
                    # Serve directly via HTTP 206 Partial Content (Byte-Range requests)
                    file_size = os.path.getsize(local_path)
                    mime_type = MEDIA_MIME_TYPES.get(ext, "video/mp4")
                    range_header = self.headers.get("Range")
                    if range_header:
                        import re
                        range_match = re.match(r"bytes=(\d+)-(\d*)", range_header)
                        if range_match:
                            start = int(range_match.group(1))
                            end = int(range_match.group(2)) if range_match.group(2) else file_size - 1
                            end = min(end, file_size - 1)
                            length = max(0, end - start + 1)

                            self.send_response(206)
                            self.send_header("Content-Type", mime_type)
                            self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
                            self.send_header("Content-Length", str(length))
                            self.send_header("Accept-Ranges", "bytes")
                            self.send_header("Access-Control-Allow-Origin", "*")
                            self.send_header("Cache-Control", "public, max-age=3600")
                            self.end_headers()

                            with open(local_path, "rb") as f:
                                f.seek(start)
                                remaining = length
                                while remaining > 0:
                                    chunk_size = min(65536, remaining)
                                    chunk = f.read(chunk_size)
                                    if not chunk:
                                        break
                                    try:
                                        self.wfile.write(chunk)
                                        remaining -= len(chunk)
                                    except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                                        break
                            return

                    # Full file stream
                    self.send_response(200)
                    self.send_header("Content-Type", mime_type)
                    self.send_header("Content-Length", str(file_size))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "public, max-age=3600")
                    self.end_headers()

                    with open(local_path, "rb") as f:
                        while True:
                            chunk = f.read(65536)
                            if not chunk:
                                break
                            try:
                                self.wfile.write(chunk)
                            except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                                break
                    return

                is_remote = target_url.startswith("http://") or target_url.startswith("https://")
                input_source = local_path if (local_path and os.path.isfile(local_path)) else (target_url if is_remote else None)

                if ffmpeg_path and input_source:
                    is_audio = is_audio_media(local_path if (local_path and os.path.isfile(local_path)) else input_source)
                    if is_audio:
                        ffmpeg_cmd = [ffmpeg_path, "-nostdin"]
                        if start_time > 0:
                            ffmpeg_cmd.extend(["-ss", str(start_time)])
                        ffmpeg_cmd.extend([
                            "-i", input_source,
                            "-vn",
                            "-c:a", "libvorbis",
                            "-b:a", "192k",
                            "-f", "webm",
                            "-cluster_size_limit", "2M",
                            "-cluster_time_limit", "5100",
                            "-flush_packets", "1",
                            "pipe:1"
                        ])
                        content_type = "audio/webm"
                    else:
                        ffmpeg_cmd = [ffmpeg_path]
                        if start_time > 0:
                            ffmpeg_cmd.extend(["-ss", str(start_time)])
                        ffmpeg_cmd.extend([
                            "-i", input_source,
                            "-map", "0:v:0",
                            "-map", "0:a?",
                            "-c:v", "libvpx",
                            "-b:v", "2M",
                            "-crf", "18",
                            "-g", "15",
                            "-quality", "realtime",
                            "-cpu-used", "8",
                            "-threads", "4",
                            "-c:a", "libvorbis",
                            "-b:a", "128k",
                            "-f", "webm",
                            "-cluster_size_limit", "2M",
                            "-cluster_time_limit", "5100",
                            "-flush_packets", "1",
                            "pipe:1"
                        ])
                        content_type = "video/webm"

                    proc = None
                    try:
                        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
                        proc = subprocess.Popen(
                            ffmpeg_cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL,
                            bufsize=65536,
                            creationflags=creationflags
                        )

                        self.send_response(200)
                        self.send_header("Content-Type", content_type)
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Cache-Control", "no-cache")
                        self.end_headers()

                        while True:
                            chunk = proc.stdout.read(8192)
                            if not chunk:
                                break
                            try:
                                self.wfile.write(chunk)
                                self.wfile.flush()
                            except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                                break
                    except Exception as e:
                        logger.debug(f"Media stream error for {target_url}: {e}")
                    finally:
                        if proc:
                            try:
                                proc.stdout.close()
                                proc.kill()
                            except Exception:
                                pass
                    return
            else:
                is_remote = target_url.startswith("http://") or target_url.startswith("https://")
                ffmpeg_path = find_ffmpeg()
                if is_remote and ffmpeg_path:
                    is_audio = is_audio_media(target_url)
                    ffmpeg_cmd = [
                        ffmpeg_path,
                        "-nostdin",
                        "-user_agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                        "-reconnect", "1",
                        "-reconnect_streamed", "1",
                        "-reconnect_delay_max", "5",
                    ]
                    if start_time > 0:
                        ffmpeg_cmd.extend(["-ss", str(start_time)])
                    if is_audio:
                        ffmpeg_cmd.extend([
                            "-i", target_url,
                            "-vn",
                            "-c:a", "libvorbis",
                            "-b:a", "192k",
                            "-f", "webm",
                            "-cluster_size_limit", "2M",
                            "-cluster_time_limit", "5100",
                            "-flush_packets", "1",
                            "pipe:1"
                        ])
                        content_type = "audio/webm"
                    else:
                        ffmpeg_cmd.extend([
                            "-i", target_url,
                            "-map", "0:v:0",
                            "-map", "0:a?",
                            "-c:v", "libvpx",
                            "-b:v", "2M",
                            "-crf", "18",
                            "-g", "15",
                            "-quality", "realtime",
                            "-cpu-used", "8",
                            "-threads", "4",
                            "-c:a", "libvorbis",
                            "-b:a", "128k",
                            "-f", "webm",
                            "-cluster_size_limit", "2M",
                            "-cluster_time_limit", "5100",
                            "-flush_packets", "1",
                            "pipe:1"
                        ])
                        content_type = "video/webm"
                    proc = None
                    try:
                        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
                        proc = subprocess.Popen(
                            ffmpeg_cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL,
                            bufsize=65536,
                            creationflags=creationflags
                        )
                        self.send_response(200)
                        self.send_header("Content-Type", content_type)
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.send_header("Cache-Control", "no-cache")
                        self.end_headers()
                        while True:
                            chunk = proc.stdout.read(8192)
                            if not chunk:
                                break
                            try:
                                self.wfile.write(chunk)
                                self.wfile.flush()
                            except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                                break
                    except Exception as e:
                        logger.debug(f"Remote stream error for {target_url}: {e}")
                    finally:
                        if proc:
                            try:
                                proc.stdout.close()
                                proc.kill()
                            except Exception:
                                pass
                    return
                self.send_error(404)
        else:
            self.send_error(404)

    def log_message(self, format, *args):
        # Silence default HTTP server console noise
        pass


class MediaStreamServer:
    def __init__(self, port=28754):
        self.port = port
        self.server = None
        self.thread = None
        self.running = False

    def find_open_port(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", self.port))
                return self.port
        except OSError:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", 0))
                return s.getsockname()[1]

    def start(self):
        self.port = self.find_open_port()
        try:
            self.server = MediaStreamHTTPServer(("127.0.0.1", self.port), MediaStreamHandler)
            self.running = True
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
            logger.info(f"Media stream proxy started on 127.0.0.1:{self.port}")
        except Exception as e:
            logger.error(f"Failed to start media stream proxy: {e}")

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.running = False

    def get_polyfill_js(self):
        has_ffmpeg_js = "true" if find_ffmpeg() else "false"
        return f"""
(function() {{
    const hasFfmpeg = {has_ffmpeg_js};
    if (!hasFfmpeg) return;

    // Do NOT run polyfill on the embedded player page or streamer loopback server
    if (window.location.pathname === '/player' || window.location.port === '{self.port}') {{
        return;
    }}

    function polyfillVideo(v, rawSrc) {{
        if (!v || v.dataset.polyfilled) return;
        var fullSrc = rawSrc;
        try {{
            fullSrc = new URL(rawSrc, window.location.href).href;
        }} catch(e) {{}}
        if (!fullSrc || fullSrc.indexOf('127.0.0.1:{self.port}') !== -1) return;

        v.dataset.polyfilled = 'true';
        var streamUrl = 'http://127.0.0.1:{self.port}/stream?url=' + encodeURIComponent(fullSrc);
        
        var sources = v.querySelectorAll('source');
        sources.forEach(function(s) {{ s.remove(); }});

        v.muted = true;
        v.defaultMuted = true;
        v.setAttribute('muted', '');
        v.playsInline = true;
        v.setAttribute('playsinline', '');

        v.addEventListener('pause', function() {{
            if (!v.ended) {{
                v.dataset.userPaused = 'true';
            }}
        }});
        v.addEventListener('play', function() {{
            delete v.dataset.userPaused;
        }});
        v.addEventListener('playing', function() {{
            v.dataset.hasStarted = 'true';
            v.dataset.isPlaying = 'true';
        }});

        var attemptPlay = function() {{
            if (v.dataset.userPaused) return;
            if (v.autoplay || !v.paused) {{
                v.muted = true;
                try {{
                    var p = v.play();
                    if (p && p.catch) {{
                        p.catch(function(e) {{}});
                    }}
                }} catch(e) {{}}
            }}
        }};

        v.addEventListener('loadeddata', attemptPlay);
        v.addEventListener('canplay', attemptPlay);
        v.addEventListener('canplaythrough', attemptPlay);

        if (!v.dataset.hasEndedListener) {{
            v.dataset.hasEndedListener = 'true';
            v.addEventListener('ended', function() {{
                if (v.loop) {{
                    v.src = streamUrl;
                    v.load();
                    attemptPlay();
                }}
            }});
        }}

        if (!v.dataset.hasStreamErrListener) {{
            v.dataset.hasStreamErrListener = 'true';
            v.addEventListener('error', function() {{
                if (v.dataset.polyfilled && !v.dataset.retryStream) {{
                    v.dataset.retryStream = '1';
                    setTimeout(function() {{
                        v.src = streamUrl;
                        v.load();
                        attemptPlay();
                    }}, 1000);
                }}
            }});
        }}

        v.src = streamUrl;
        v.load();
        attemptPlay();
    }}

    function checkVideoElement(v) {{
        if (v.dataset.userPaused) return;

        if (v.dataset.polyfilled) {{
            if (v.autoplay && v.paused && !v.ended && !v.dataset.hasStarted && v.readyState >= 1) {{
                v.muted = true;
                try {{
                    var p = v.play();
                    if (p && p.catch) p.catch(function(e) {{}});
                }} catch(e) {{}}
            }}
            return;
        }}

        var src = v.currentSrc || v.src;
        if (!src) {{
            var s = v.querySelector('source');
            if (s) src = s.src || s.getAttribute('src');
        }}
        if (!src) return;

        var lower = src.toLowerCase().split('?')[0].split('#')[0];
        var isMp4OrMov = lower.endsWith('.mp4') || lower.endsWith('.m4v') || lower.endsWith('.mov') || lower.endsWith('.mkv') || lower.endsWith('.avi');
        var isMarqueeHero = (window.location.hostname.indexOf('marquee-magic.com') !== -1) || (src.indexOf('design_click_poof.mp4') !== -1);

        if (!v.dataset.hasErrListener) {{
            v.dataset.hasErrListener = 'true';
            v.addEventListener('error', function() {{
                polyfillVideo(v, src);
            }});
            var sources = v.querySelectorAll('source');
            sources.forEach(function(s) {{
                s.addEventListener('error', function() {{
                    polyfillVideo(v, s.src || s.getAttribute('src') || src);
                }});
            }});
        }}

        var can = v.canPlayType ? v.canPlayType('video/mp4; codecs="avc1.42E01E"') : '';
        var cannotPlay = (can !== 'probably' && can !== 'maybe');

        if (v.error || v.networkState === 3) {{
            polyfillVideo(v, src);
        }} else if (isMp4OrMov && (cannotPlay || isMarqueeHero)) {{
            polyfillVideo(v, src);
        }} else if (isMp4OrMov && v.autoplay && v.paused && !v.ended && v.readyState === 0) {{
            polyfillVideo(v, src);
        }} else if (isMp4OrMov && v.autoplay && v.paused && !v.ended && !v.dataset.hasStarted && v.readyState >= 1) {{
            v.muted = true;
            v.play().catch(function(e) {{}});
        }}
    }}

    function scanAllVideos() {{
        var videos = document.querySelectorAll('video');
        videos.forEach(checkVideoElement);
    }}

    function unblockAutoplay() {{
        document.querySelectorAll('video[data-polyfilled]').forEach(function(v) {{
            if (v.paused && !v.dataset.userPaused && !v.ended && v.autoplay && !v.dataset.hasStarted) {{
                v.muted = true;
                try {{
                    v.play().catch(function(e) {{}});
                }} catch(e) {{}}
            }}
        }});
    }}
    document.addEventListener('click', unblockAutoplay, {{ passive: true }});
    document.addEventListener('keydown', unblockAutoplay, {{ passive: true }});

    if (document.readyState === 'loading') {{
        document.addEventListener('DOMContentLoaded', scanAllVideos);
    }} else {{
        scanAllVideos();
    }}
    setInterval(scanAllVideos, 800);

    try {{
        var observer = new MutationObserver(function() {{
            scanAllVideos();
        }});
        var targetNode = document.body || document.documentElement;
        if (targetNode) {{
            observer.observe(targetNode, {{ childList: true, subtree: true }});
        }} else {{
            document.addEventListener('DOMContentLoaded', function() {{
                var bodyNode = document.body || document.documentElement;
                if (bodyNode) {{
                    observer.observe(bodyNode, {{ childList: true, subtree: true }});
                }}
            }});
        }}
    }} catch(e) {{}}
}})();
"""


#!/usr/bin/python3
# -*- coding: utf-8 -*-
# WAI Assistant UI and Integration Module
# Provides a drop-in GUI and manager for the Wheelhouser AI Orchestrator.
# Copyright (C) 2026 Wheelhouser LLC
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import json
import uuid
import logging
import html
from typing import Optional, Callable, Dict, Any, List

from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QTextEdit,
    QCheckBox,
    QLineEdit,
    QPushButton,
    QHBoxLayout,
    QWidget,
)
from PySide6.QtCore import Qt, QObject, Signal, QThread

try:
    from src.wheelhouser_client import WheelhouserClient
except (ModuleNotFoundError, ImportError):
    try:
        from wheelhouser_client import WheelhouserClient
    except (ModuleNotFoundError, ImportError):
        WheelhouserClient = None  # type: ignore


class WAIWorker(QThread):
    """Background worker to handle WAI requests without freezing the UI."""
    finished = Signal(dict)
    error = Signal(str)

    def __init__(self, client: Any, text: str, state: Dict[str, Any]):
        super().__init__()
        self.client = client
        self.text = text
        self.state = state

    def run(self):
        try:
            if not self.client:
                raise RuntimeError("Wheelhouser AI client is not available.")
            response = self.client.resolve(self.text, self.state)
            self.finished.emit(response)
        except Exception as e:
            self.error.emit(str(e))


class WAIDialog(QDialog):
    """Chat dialog interface for the Wheelhouser AI Browser Assistant."""

    def __init__(
        self,
        client: Any,
        get_context_cb: Callable[..., Dict[str, Any]],
        execute_pipeline_cb: Callable[[List[Dict[str, Any]]], None],
        parent: Optional[QWidget] = None,
    ):
        super().__init__(parent)
        self.client = client
        self.get_context_cb = get_context_cb
        self.execute_pipeline_cb = execute_pipeline_cb
        self.session_id = str(uuid.uuid4())
        self.worker: Optional[WAIWorker] = None

        self.setWindowTitle("Wheelhouser AI - Web Browser")
        self.resize(440, 620)
        self.setup_ui()

    def setup_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #e0e0e0;
            }
            QTextEdit {
                background-color: #252526;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 6px;
                padding: 8px;
                font-size: 13px;
            }
            QCheckBox {
                color: #b0b0b0;
                font-size: 12px;
                spacing: 6px;
            }
            QLineEdit {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #007acc;
            }
            QPushButton {
                background-color: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 600;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #094771;
            }
            QPushButton:disabled {
                background-color: #333333;
                color: #666666;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)

        self.chk_include_text = QCheckBox("Include Page Context")
        self.chk_include_text.setToolTip(
            "Send the current web page URL, title, and selected text to Wheelhouser AI for context."
        )
        self.chk_include_text.setChecked(True)
        layout.addWidget(self.chk_include_text)

        input_layout = QHBoxLayout()
        input_layout.setSpacing(8)

        self.btn_clear = QPushButton("🗑️")
        self.btn_clear.setFixedSize(36, 36)
        self.btn_clear.setToolTip("Clear Chat History")
        self.btn_clear.setStyleSheet(
            "background-color: #2d2d2d; border: 1px solid #444; border-radius: 6px;"
        )
        self.btn_clear.clicked.connect(self.request_clear)

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Ask a question, open a site, or search the web...")
        self.input_field.returnPressed.connect(self.send_message)

        self.send_btn = QPushButton("Send")
        self.send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_btn.clicked.connect(self.send_message)

        input_layout.addWidget(self.btn_clear)
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)

        self.append_message(
            "WAI",
            "Hello! I am your Wheelhouser AI browser assistant. You can ask me to navigate to websites, search the web, bookmark pages, or summarize content from the current tab. How can I help you today?",
        )

    def send_message(self):
        text = self.input_field.text().strip()
        if not text:
            return

        self.append_message("You", text)
        self.input_field.clear()

        # Lock UI inputs during processing, but keep window responsive
        self.input_field.setEnabled(False)
        self.send_btn.setEnabled(False)
        self.btn_clear.setEnabled(False)

        self.start_request(text)

    def start_request(self, text: str, retry: bool = False):
        try:
            # Gather context on main thread
            current_state = self.get_context_cb(
                include_text=self.chk_include_text.isChecked()
            )
            current_state["session_id"] = self.session_id

            state_dump = json.dumps(current_state)
            logging.info(f"Sending WAI request: {text}")
            logging.info(f"Context payload size: {len(state_dump)} chars.")

            self.worker = WAIWorker(self.client, text, current_state)
            self.worker.finished.connect(
                lambda resp: self.handle_response(resp, text, retry)
            )
            self.worker.error.connect(self.handle_error)
            self.worker.start()
        except Exception as e:
            self.handle_error(str(e))

    def handle_response(self, response: Dict[str, Any], text: str, retry: bool):
        is_token_error = False
        try:
            response_text = response.get("response_text", "Done.")

            # Catch token/quota limits returned from the Orchestrator
            is_token_error = any(
                phrase in response_text.lower()
                for phrase in ["exceed context window", "token limit", "quota"]
            )

            if is_token_error:
                if not retry:
                    self.append_message(
                        "System",
                        "Context limit reached. Automatically rotating session and retrying...",
                    )
                    self.session_id = str(uuid.uuid4())
                    self.start_request(text, retry=True)
                    return
                else:
                    self.append_message(
                        "System",
                        "Error: The server rejected the request again. The Wheelhouser AI Orchestrator may be out of quota or its prompt is too large.",
                    )
                    self.unlock_ui()
                    return

            self.append_message("WAI", response_text)
            logging.info(f"WAI Response: {response_text}")

            if "pipeline" in response and self.execute_pipeline_cb:
                self.execute_pipeline_cb(response["pipeline"])

        except Exception as e:
            self.append_message("System", f"Error processing response: {str(e)}")
        finally:
            if not is_token_error:
                self.unlock_ui()

    def handle_error(self, error_msg: str):
        self.append_message("System", f"Error: {error_msg}")
        self.unlock_ui()

    def unlock_ui(self):
        self.input_field.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.btn_clear.setEnabled(True)
        self.input_field.setFocus()

    def append_message(self, sender: str, text: str):
        if sender == "WAI":
            color = "#38bdf8"
        elif sender == "You":
            color = "#4ade80"
        elif sender == "System":
            color = "#f87171"
        else:
            color = "#e2e8f0"

        safe_text = html.escape(text).replace("\n", "<br>")
        self.chat_display.append(
            f"<div style='margin-bottom: 8px;'><b style='color:{color};'>{sender}:</b> {safe_text}</div>"
        )
        sb = self.chat_display.verticalScrollBar()
        sb.setValue(sb.maximum())

    def request_clear(self):
        """Manually requested clear from user. No arguments, strictly manual."""
        self.session_id = str(uuid.uuid4())
        self.chat_display.clear()
        self.append_message(
            "WAI",
            "Hello! I am your Wheelhouser AI browser assistant. You can ask me to navigate to websites, search the web, bookmark pages, or summarize content from the current tab. How can I help you today?",
        )


class WAIAssistantManager(QObject):
    """Manager class to encapsulate the client and the dialog UI."""
    connectionChanged = Signal(bool)

    def __init__(
        self,
        app_name: str,
        parent_widget: Any,
        get_context_cb: Callable[..., Dict[str, Any]],
        execute_pipeline_cb: Callable[[List[Dict[str, Any]]], None],
    ):
        super().__init__(parent_widget)
        self.app_name = app_name
        self.execute_pipeline_cb = execute_pipeline_cb
        self.client = WheelhouserClient(app_name) if WheelhouserClient else None
        if self.client:
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.set_command_callback(self._on_command_received)
            self.client.start()

        self.dialog = (
            WAIDialog(
                client=self.client,
                get_context_cb=get_context_cb,
                execute_pipeline_cb=execute_pipeline_cb,
                parent=parent_widget,
            )
            if self.client
            else None
        )

    def _on_command_received(self, data: Any):
        """Processes incoming commands pushed by the Wheelhouser AI Orchestrator."""
        if not isinstance(data, dict):
            return {"status": "ignored"}
        cmd = data.get("command") or data
        if self.execute_pipeline_cb:
            if isinstance(cmd, list):
                self.execute_pipeline_cb(cmd)
            elif isinstance(cmd, dict):
                self.execute_pipeline_cb([cmd])
            elif isinstance(cmd, str):
                self.execute_pipeline_cb([{"action": cmd, "intent": cmd, "parameters": {}}])
        return {"status": "success"}

    def _on_connect(self):
        self.connectionChanged.emit(True)

    def _on_disconnect(self):
        self.connectionChanged.emit(False)

    def open_dialog(self, force: bool = False) -> bool:
        """Opens the chat dialog. If force is True, opens even if not currently connected."""
        if not force and (not self.client or not self.client.connected):
            return False

        if self.dialog:
            self.dialog.show()
            self.dialog.raise_()
            self.dialog.activateWindow()
            return True
        return False

    def stop(self):
        if self.client:
            self.client.stop()
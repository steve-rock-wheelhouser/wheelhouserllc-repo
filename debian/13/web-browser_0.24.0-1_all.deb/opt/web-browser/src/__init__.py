"""
Web-Browser source package.
"""

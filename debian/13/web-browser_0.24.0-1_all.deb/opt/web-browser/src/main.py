#!/usr/bin/python3
# -*- coding: utf-8 -*-  # noqa: UP009
# Web-Browser by Wheelhouser LLC
# Features include the Wheelhouser dark mode.
# Built with Python and PySide6.
#
#
# Copyright (C) 2026 Wheelhouser LLC
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python3.13 -m venv .venv
# .venv\Scripts\Activate.ps1
# python.exe -m pip install --upgrade pip
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
# ===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development, basic search and UI
# 0.1.1 - Added support for multiple tabs.
# 0.1.2 - Set tab styling the same as file-browser and terminal.
# 0.1.3 - Move "Add Tab" button to the tab bar just like file-browser and terminal.
# 0.1.4 - Added navigation buttons (Back, Forward, Reload) and implemented "New Tab" button in the tab bar.
# 0.1.5 - Updated navigation buttons to use icons (back.png, forward.png, reload.png).
# 0.1.6 - Make My Notes sidebar the Bookmarks, change the buttons to "Add Bookmark" and "Delete Bookmark".  Add a new button to "Set Homepage".
# 0.1.7 - Fixed bug where homepage setting was ignored on startup.
# 0.1.8 - Move the hamburger menu to the left of the About button.
# 0.1.9 - Add tooltips to all toolbar buttons.
# 0.1.10 - Add session persistence to remember open tabs between sessions.
# 0.1.11 - Make the Bookmark sidebar min/max state persist between sessions.
# 0.1.12 - Fixed issue where web view scrollbars were not dark themed by injecting CSS.
# 0.1.13 - Reduce the padding of the main window on left, right, and bottom to create a more compact feel.
# 0.1.14 - Make the current active tab persest between sessions.
# 0.1.15 - Updated the Icon to the new Web-Browser icon.
# 0.1.16 - If I close the right most tab, the new right most tab must become active.  This is a common behavior in web browsers that users expect.
# 0.1.17 - Make the width of the About button narrower.  It's taking up too much space right not.
# 0.1.18 - Make search engine settings persist between sessions.  This is a common feature in web browsers that users expect.
# 0.1.19 - Enable Local Storage and Disk Cache to ensure search engine settings (like DuckDuckGo) persist between sessions.
# 0.1.20 - Implement a named QWebEngineProfile to guarantee settings persistence across sessions.
# 0.1.21 - Add the ability to copy images from the web and download files in general.  This is a common feature in web browsers that users expect.
# 0.1.22 - "Save Image" must detect the source file type and add the correct extension. This should be included in the save dialog as the default file type.
# 0.1.23 - "Copy Image" does not appear to copy the image to the clipboard in a way that allows it to be pasted elsewhere.
# 0.1.24 - Improve "Save Image" to detect source file type and use it as the default filter in the save dialog.
# 0.1.25 - Make the Save to directory persistent across sessions and default to the last used directory.
# 0.1.26 - Update the drop down menu from "Save Image" to "Save image as".
# 0.1.27 - Make the hamburger menu items the same size as the rest of the toolbar buttons.  The current size is too small and hard to click.
# 0.1.28 - Have tabs display the favicon of the website if available.  This is a common feature in web browsers that users expect.
# 0.1.29 - Have tabs shrink in size (to a realistic minimum) if too many tabs are open.
# 0.1.30 - Reduce the padding of the search bar to create a more compact feel.  This is especially important on smaller screens.
# 0.1.31 - Increase the border radius of the search bar to create a more rounded, pill-like appearance.
# 0.1.32 - Move URL bar styling to the main theme to ensure the rounded border radius is correctly applied.
# 0.1.33 - Force rounded corners on the URL bar by applying the stylesheet directly to the widget.
# 0.1.34 - Use the zoom 100% button to reset the zoom level of the current page to 100%.  This is a common feature in web browsers that users expect.
# 0.1.35 - Use the downloads button to open the user's default downloads folder.  This is a common feature in web browsers that users expect.
# 0.1.36 - Add the search-engine.png icon to the Search Engine menu item in the hamburger menu.  This will make it easier for users to find and recognize the search engine settings.
# 0.1.37 - Make the zoom level persistent across sessions.  This is a common feature in web browsers that users expect.
# 0.1.38 - Have files that are to be downloaded, download to the user's default downloads folder instead of the current working directory.  This is a common feature in web browsers that users expect.
# 0.1.39 - Fix download directory persistence by resetting the settings key to ensure it defaults to the system Downloads folder.
# 0.1.40 - Apply F11 fullscreen mode TOGGLE to the current active tab.
# 0.1.41 - Update About dialog to Horizontally center the logo and highlight privacy features.
# 0.1.42 - Make the About dialog responsive to fit the contents fully.
# 0.1.43 - Add a "History" feature that logs visited URLs and allows the user to view them in a dialog.
# 0.1.44 - Apply history.png icon to the History button in the hamburger menu.
# 0.1.45 - Standardize project structure to Wheelhouser layout, fix module imports and asset path resolution, and clean up template references.
# 0.1.46 - Clean up tab and WebEnginePage teardown in closeEvent/close_tab to eliminate profile release warnings on exit; suppress external website JavaScript console noise.
# 0.1.47 - Add menu settings to toggle disk caching (Disk vs Memory) and clear browsing cache on demand, with persistence.
# 0.1.48 - Configure web engine settings for smooth video/media playback and autoplay without user gesture requirements.
# 0.1.49 - Implement automatic in-browser media stream polyfill to transcode and play MP4/H.264 HTML5 videos seamlessly.
# 0.1.50 - Implement persistent favicon disk caching and session tab icon restoration for instant tab loading without network re-fetching.
# 0.1.51 - Display cached favicons to the left of bookmark names in the sidebar with live icon updates.
# 0.1.52 - Upgrade About dialog with standard Wheelhouser in-app updater, download progress bar, installer launcher, and cohesive Blue theme.
# 0.1.53 - Add Chromium turbo flags, 1GB cache sizing, kinetic scroll animations, lazy tab loading, and built-in ad/tracker blocking interceptor.
# 0.1.54 - Add shortcut bookmark button with custom book icon to the right side of the URL bar.
# 0.1.55 - Add dynamic URL bar bookmark action state, visual feedback popup on bookmarking, and automatic disabled state when already bookmarked.
# 0.1.56 - Fix session restore tab duplication and pending URL persistence by blocking signals during batch tab restoration and preserving lazy URLs.
# 0.1.57 - Ensure seamless 1-to-1 session tab preservation without creating extraneous tabs on launch.
# 0.1.58 - Fix URL bar navigation and query resolution, add URL Go button, and integrate sleek page load progress bar.
# 0.1.59 - Prevent closeEvent teardown from wiping session data and guard session persistence across restarts.
# 0.1.60 - Add folder favicon icon and clean folder naming for file:/// local directory bookmarks.
# 0.1.61 - Make unbookmarked URL bar bookmark icon vibrant blue to stand out, and fix all icons_path variable references.
# 0.1.62 - Apply application and bookmark Segoe UI font family and dark styling to local file:/// browser directory listings.
# 0.1.63 - Escape CSS double braces for QListWidget style sheet and fix startup style sheet syntax.
# 0.1.64 - Enlarge folder bookmark favicon by 30% and add Ctrl+/Ctrl-/Ctrl+0 keyboard and wheel zoom support.
# 0.1.65 - Set dark canvas background color by default on WebEnginePage and views to eliminate white flash on tab switch/load.
# 0.1.66 - Update Back and Forward navigation buttons to vibrant modern blue.
# 0.1.67 - Add Web/File browsing mode toggle button with auto-prepend and enable Copy File in right-click context menus.
# 0.1.68 - Fix video playback by converting local paths for ffmpeg, removing reconnect flags on files, and routing to dedicated HTML5 player.
# 0.1.69 - Add ENABLE_LICENSING flag and hide the Activate button by default.
# 0.1.70 - Fix startup and video navigation crash by safely deferring player URL redirection to next Qt event loop tick.
# 0.1.71 - Set blue Back and Forward icons in right-click context menu and enlarge Bookmark button as a dedicated toolbar button.
# 0.1.72 - Strip 'Index of' prefix from directory headers and tab titles, and add bookmark reordering (drag-and-drop, Move Up/Down buttons, and context menu).
# 0.1.73 - Update reload and hamburger icons to match vibrant royal blue button aesthetic.
# 0.1.74 - Match Reload and Hamburger icon proportions and stroke weights to Back, Forward, and Mode buttons.
# 0.1.75 - Re-render Reload and Hamburger vector icons with smooth gradient squircle and eliminate raster banding.
# 0.1.76 - Seamlessly unify reload circular arc and arrowhead path to eliminate overhang.
# 0.1.77 - Enlarge Reload icon arrowhead by 20% for optimal visual balance.
# 0.1.78 - Make application OS-aware: adapt file paths, file browsing placeholders, zoom shortcuts (Cmd on macOS, Ctrl on Win/Linux), and modifier labels.
# 0.1.79 - Fix ecdsa import and HAS_ECDSA definition in main.py.
# 0.1.80 - Add type ignore annotation and install ecdsa package to resolve static analyzer import warning.
# 0.1.81 - Add Google, Bing, DuckDuckGo, and Yahoo favicons to Search Engine submenu.
# 0.1.82 - Scale search engine favicons down by 20% and add clear active indicator in Search Engine menu.
# 0.1.83 - Fix Zoom Out (Ctrl -) shortcut by removing duplicate QShortcut binding ambiguity and applying ApplicationShortcut context.
# 0.1.84 - Set home directory (~) as default file browsing root, replace [parent directory] with full parent path, and inject clean modern upright SVG file/dir icons.
# 0.1.85 - Update file browser folder icons to match bookmark gold theme and add rich IDE-style extension favicons (.py, .html, .css, .js, .csv, .json, .md, .pdf, media, archives).
# 0.1.86 - Dynamically update tab favicons on URL changes and page transitions between websites and local files.
# 0.1.87 - Render matching IDE file extension favicons (.py, .html, .css, .js, .csv, .json, .md, .pdf, media, archives) for individual files opened in Tabs.
# 0.1.88 - Add save.png and copy.png icons to right-click context menu and implement Examine Source tab opening.
# 0.1.89 - Fix right-click crash by preventing WebAction double invocation, remove unstable createWindow override, and restore stable session and tab history handling.
# 0.1.90 - Remove View Page Source from context submenu and apply matching 64x64 Examine Source icon.
# 0.1.91 - Apply rounded borders (border-radius: 8px) and matching item radii to menus and submenus across the application.
# 0.1.92 - Seamlessly route all local and remote media file clicks, navigations, and downloads to the integrated media player.
# 0.1.93 - Implement HTTP 206 Partial Content (Byte-Range requests) and native streaming for instant, seekable media playback.
# 0.1.94 - Optimize real-time WebM transcoding pipeline with cluster flushing and keyframe indexing for instant video playback in QtWebEngine.
# 0.1.95 - Navigate directory media file clicks directly to media streamer player with immediate autoplay on first open.
# 0.1.96 - Revert updater to check wheelhouser.com and link to Microsoft Store for Store compliance.
# 0.1.97 - Harden security: restrict JS clipboard access, escape player titles, and enforce media extension and CORS controls on local streaming server.
# 0.1.98 - Implement custom media player UI with accurate full-duration timeline scrubber, time tooltip, and smooth playback controls.
# 0.1.99 - Enable intelligent fallback in Back navigation and player Back button to restore parent directory navigation when history is empty.
# 0.1.100 - Set DuckDuckGo as default search engine and reorder search engines menu (DuckDuckGo, Google, Yahoo, Bing).
# 0.1.101 - Synchronize Windows YubiKey hardware signing scripts with video-stitcher and preserve third-party vendor signatures.
# 0.1.102 - Add background startup update check and highlight About button with red badge when a new version is available.
# 0.1.103 - Fix main window container layout attachment in BrowserWindow initialization.
# 0.1.104 - Update push.ps1 script to handle already-committed changes and push automatically.
# 0.1.105 - Enforce strict Python 3.13 requirement in Windows build scripts and packaging tooling.
# 0.1.106 - Bundle only required assets (icons) and restrict code signing strictly to the application executable.
# 0.1.107 - Strip unreferenced asset files (.icns, .svg, 1080x1080 art) and bundle only the 23 active runtime icons.
# 0.1.108 - Implement Linux build system, PyInstaller spec, desktop/metainfo integration, and Fedora 44 RPM packaging.
# 0.1.109 - Add automated GPG signing and publishing to steve-rock-wheelhouser/fedora-repo in build_rpm.sh.
# 0.1.110 - Consolidate Linux desktop launcher strictly to com.wheelhouser.web-browser.desktop.
# 0.1.111 - Switch Linux RPM packaging to native DNF dependencies for lightweight package.
# 0.1.112 - Configure reverse-DNS application name, desktopFileName, and StartupWMClass for proper Wayland/X11 dock icon grouping.
# 0.1.113 - Add AppStream screenshots (1-4.png) to Linux metainfo.xml.
# 0.1.114 - Implement platform-specific update UI messages, tooltips, and buttons for Linux DNF, Windows Store, and macOS.
# 0.1.115 - Redesign About dialog layout with clean spacing, wider card geometry, and decluttered update notification.
# 0.1.116 - Separate Linux update command snippet and repository link into dedicated styled widgets to prevent text overlapping.
# 0.1.117 - Update Author display in About dialog to steve.rock@wheelhouser.com.
# 0.1.118 - Fix About button text clipping by increasing button width and adjusting badge padding.
# 0.1.119 - Fix About dialog natural layout sizing, eliminate PySide disconnect warning, and ensure About button reliably highlights red when update is available.
# 0.1.120 - Add copy to clipboard button with icon for Fedora upgrade command in About dialog.
# 0.1.121 - Add support for macos_arm64 and macos_x86_64 architecture targets in update manager.
# 0.1.122 - Enhance pull.sh to automatically handle branch divergence with rebase and autostash.
# 0.1.123 - Configure setup.iss for silent install compatibility, clean uninstaller registry keys, and MS Store guidelines.
# 0.1.124 - Lock Windows AppUserModelID to static WheelhouserLLC.Web-Browser.0.1.44 to preserve taskbar pinning across all version updates.
# 0.1.125 - Initialize application name and desktop file name before QApplication and suppress duplicate portal registration warning.
# 0.1.126 - Configure macOS build system, PyInstaller spec, codesigning, notarization, and bash 3.2 compatibility.
# 0.1.127 - Fix macOS Intel launch crash by pinning cryptography<=44.0.2 with universal OpenSSL binaries and isolating DYLD_LIBRARY_PATH.
# 0.1.128 - Prevent .bin extension from being appended to DMG and binary downloads by prioritizing file extension over generic octet-stream MIME type.
# 0.1.129 - Fix setup.iss silent installer configuration, remove bogus .exe registry file associations, and set admin privileges and clean uninstaller.
# 0.1.131 - Add interactive GUI file picker dialog to microsoft_store_pre-check.ps1.
# 0.1.132 - Add interactive quick-select installer menu and TopMost file picker to microsoft_store_pre-check.ps1.
# 0.1.133 - Align setup.iss and manifest versions with Partner Center package validation.
# 0.1.134 - Fix MS Store package validation: enforce PrivilegesRequired=admin for Machine HKLM registry registration, remove .exe ProgID, and update pre-check harness.
# 0.1.135 - Enforce strict HKLM Machine-context validation in microsoft_store_pre-check.ps1 to prevent false passes on HKCU user installs.
# 0.1.136 - Add automatic UAC self-elevation to microsoft_store_pre-check.ps1 for unattended execution.
# 0.1.137 - Save Microsoft Store pre-check results to build-windows/microsoft_store_pre-check.log and mirror output to caller terminal.
# 0.1.138 - Align setup.iss with proven Store-compliant configuration from silent_setup.iss (user privileges, clean ARP name, and silent icon checks).
# 0.1.139 - Refactor microsoft_store_pre-check.ps1 parameter to -SkipUninstall switch adhering to PowerShell best practices.
# 0.1.140 - Implement Windows MSIX package build pipeline in build-msix with automated layout assembly, AppxManifest, asset integration, and YubiKey code signing.
# 0.1.141 - Implement WiX Toolset Windows MSI installer build pipeline in build-msi with automated payload harvesting, HKLM perMachine registration, and code signing.
# 0.1.142 - Fix MSI shortcut WorkingDirectory and target binding, add Desktop icon, and automate legacy Inno Setup removal.
# 0.1.143 - Fix PySide6 QtWidgets DLL packaging by installing PyInstaller into .venv and rebuilding distribution binaries.
# 0.1.144 - Use assets/icons/icon.ico for MSI installer and shortcuts, and place Start Menu shortcut in top-level Programs directory.
# 0.1.145 - Eliminate conflicting ICU DLLs and register DLL search directories on Windows to guarantee clean PySide6 QtWidgets loading.
# 0.1.146 - Explicitly bundle icon.ico in INSTALLDIR payload and configure elevated install privileges on MSI package.
# 0.1.147 - Add custom WiX UI Banner and Dialog bitmaps, sync APP_VERSION constant, and bundle application branding.
# 0.1.148 - Refactor WiX Banner bitmap layout to prevent text overlap and ensure crisp typography in MSI wizard.
# 0.1.149 - Implement automatic legacy AppData folder cleanup and Taskbar pinned shortcut migration to Program Files in MSI installer.
# 0.1.150 - Enforce Wheelhouser LLC YubiKey EV certificate signing for MSI installer package and add sign_msi helper.
# 0.1.151 - Fix Windows SDK SignTool path resolution in sign_msi.bat and add sign_msi.ps1 for PowerShell.
# 0.1.152 - Add automated Smart Card and Certificate Propagation service startup to MSI signing workflow.
# 0.1.153 - Ensure all payload application binaries (Web-Browser.exe) and MSI package are signed with YubiKey EV certificate.
# 0.1.154 - Standardize MSI build and signing toolchain on modern PowerShell scripts and remove legacy batch wrappers.
# 0.1.155 - Ensure timestamping URL is explicitly propagated to payload signing pass in sign_msi.ps1.
# 0.1.156 - Unify end-to-end payload signing, MSI compilation, package signing, and verification into a single build_msi.ps1 command.
# 0.1.157 - Integrate Microsoft Store Win32 Pre-Check Certification harness into MSI build and publishing pipeline.
# 0.1.158 - Fix PowerShell parameter splatting in sign_msi.ps1 to prevent empty string argument parsing errors.
# 0.1.159 - Add ARPINSTALLLOCATION to MSI package and route clean overwrite pre-check report log to build-msi/.
# 0.1.160 - Refactor MSI log parsing patterns in microsoft_store_pre-check.ps1 to prevent parser ambiguities.
# 0.1.161 - Standardize subexpression formatting and explicit block braces in microsoft_store_pre-check.ps1.
# 0.1.162 - Add run_wack.ps1 utility in build-msi/ for automated and interactive Windows App Certification Kit testing.
# 0.1.163 - Remove unused repoRoot variable and enhance GUI fallback in run_wack.ps1.
# 0.1.164 - Automatically target latest MSI and copy path to clipboard for instant pasting in run_wack.ps1.
# 0.1.165 - Ensure latest MSI is silently installed before launching WACK Desktop App certification suite.
# 0.1.166 - Condition desktop shortcut creation in MSI package to ensure 100% compliance with Microsoft Store silent install policy.
# 0.1.167 - Fix ARPINSTALLLOCATION mapping to INSTALLDIR in Product.wxs and add fallback install directory validation in pre-check.
# 0.1.168 - Fix start menu and desktop shortcut creation and prevent legacy migration script from deleting new shortcuts.
# 0.1.169 - Suppress WiX shortcut ICE validation rules in light.exe and set HKCU keypaths in Product.wxs.
# 0.1.170 - Ensure PyInstaller automatically recompiles updated source code into dist before MSI packaging.
# 0.1.171 - Remove hardcoded SkipPyInstaller flag from sign_msi.ps1 so builds always compile updated application binaries.
# 0.1.172 - Resolve IDE warnings and static diagnostics for logging, exception handling, and import styling.
# 0.1.173 - Remove unused legacy Nuitka requirements file.
# 0.11.0 - Restore media streaming server on startup, polyfill script injection, Chromium flags, and background update checking.
# 0.11.1 - Implement HTTP 206 Partial Content Byte-Range streaming and native media playback for video and audio files without external FFmpeg dependency.
# 0.11.2 - Add local FFmpeg/FFprobe binary discovery and live WebM transcoding pipeline for seamless in-browser media playback.
# 0.13.0 - Standardize package-relative imports with fallback in main.py to eliminate IDE diagnostics and ensure seamless module resolution.
# 0.13.1 - Fix radio button and checkbox indicators in dark theme UI and web forms (Partner Center / Fluent UI) with dedicated indicator styles, standard User-Agent, and clean Chromium flags.
# 0.13.2 - Enhance web form radio button and checkbox interaction with capturing event delegation, input z-index elevation, and React prototype change event dispatching.
# 0.13.3 - Enable verbose debugging mode, live JS console message streaming to terminal, and click diagnostics for web form inspection.
# 0.13.4 - Add universal Angular Formly, Bootstrap, and HTML5 dynamic radio indicator state styles and detailed DOM inspection logging.
# 0.13.5 - Add dynamic radial gradient dot styling for Angular Formly input[type=radio]:checked and auto-clear on unselected options.
# 0.13.6 - Add comprehensive radio control computed style and DOM inspector for Angular Formly diagnosis.
# 0.13.7 - Explicitly set appearance: none with dimensions and border on input[type=radio] and input[type=checkbox] to ensure Chromium renders custom high-contrast indicators.
# 0.13.8 - Whitelist Microsoft/cloud hosts in ad blocker, clean Chromium flags, enable clipboard/window permissions, and add reactive radio group synchronizer.
# 0.13.9 - Optimize AdBlockInterceptor host matching using tuple argument in endswith().
# 0.13.10 - Add network and script fetch diagnostic hooks at DocumentCreation to isolate micro-frontend bundle fetch failures.
# 0.13.11 - Add high-contrast 5px bordered visual selection styling and direct data-checked label state synchronizer.
# 0.13.12 - Add detailed stylesheet rule extraction and container tree diagnostic inspector for Partner Center radio controls.
# 0.13.13 - Add span::before outer ring and span::after inner white dot styling with strict data-checked group synchronization.
# 0.13.14 - Align Fluent UI radio indicator styling using box-shadow inset dot and clean previous selection state on radio group switch.
# 0.13.15 - Remove synthetic JS click interceptor to allow native browser radio event propagation with pure CSS Fluent UI inset indicators.
# 0.13.16 - Add complete DOM tree and computed style dump for all radio options in group to isolate visual rendering container.
# 0.13.17 - Synchronize HTML checked attribute in native change event handler to update attribute-based CSS selectors across SSR micro-frontends.
# 0.13.18 - Enforce strict sibling checked attribute cleanup on radio change and prioritize :not(:checked) CSS override.
# 0.13.19 - Clean up form control styling to standard accent-color and remove complex site-specific DOM overrides.
# 0.14.0 - Start version 0.14.0 development cycle.
# 0.14.1 - Standardize Windows AppUserModelID (AUMID) to unversioned WheelhouserLLC.Web-Browser to resolve legacy version coupling.
# 0.14.2 - Add "Add Desktop Shortcut" functionality and buttons in the Hamburger menu and About dialog for cross-platform desktop shortcut creation.
# 0.14.3 - Implement tab right-click context menu with Bookmark This Tab, Bookmark All Open Tabs, Open Bookmark submenu, Reload, Duplicate Tab, Copy URL, New Tab, and Close Tab.
# 0.14.4 - Refine tab context menu placing Open Bookmark first, remove bulk bookmarking, set 22px menu icon proxy style, and synchronize shared open/close/new company icons matching Text-Editor.
# 0.14.5 - Create custom zoom-in and zoom-out icons matching the Zoom 100% squircle styling and attach them to Hamburger menu actions.
# 0.14.6 - Enable default EV code signing and certificate identity in MSIX build process to allow local sideloading and installation.
# 0.14.7 - Fix Microsoft Store submission validation by setting primary MSIX package to MS Store Publisher Identity (CN=6FCF7B44-0B45-4833-982F-DC64E2D684EC) and generating signed Sideload package alongside it.
# 0.14.8 - Fix desktop shortcut creation in Windows by distinguishing Python Store packages from native MSIX and dynamically resolving PackageFamilyName.
# 0.14.9 - Ensure robust dynamic MSIX PackageFamilyName resolution for desktop shortcut creation across all user installation modes.
# 0.14.10 - Consolidate standalone compilation and MSIX packaging under build-msix/, deprecate Inno Setup exe and WiX MSI installers, and remove build-windows/ and build-msi/.
# 0.15.0 - Open source release under GNU General Public License v3.0 (GPL-3.0) with repository sanitization and public GitHub documentation.
# 0.15.0-2 - Packaging release: Add python3-pyside6.qtsvg and python3-pyside6.qtsvgwidgets control dependencies on Debian/Ubuntu and update RPM spec to ensure QSvgRenderer loads cleanly.
# 0.15.1 - Fix dark mode window border on AlmaLinux/Rocky Linux by setting Qt.ColorScheme.Dark and dark QPalette; eliminate libEGL/Mesa Zink warnings and WebGL blocklisting by auto-routing to software rasterization when DRI render node is absent and passing --ignore-gpu-blocklist in Chromium flags.
# 0.15.2 - Honor desktop GNOME button-layout (single close button) and window geometry for rounded corners on Rocky/AlmaLinux; add headless offscreen smoke test auto-exit and clean signal/thread teardown to prevent hanging or aborting during automated fleet QA.
# 0.16.1 - Resolve open defects BUG-20260926_153343, BUG-20260926_152822, and BUG-20260926_152915:
#          - Set default homepage to DuckDuckGo (https://duckduckgo.com) upon initial installation and empty sessions.
#          - Fix video playback on marquee-magic.com and web pages by restricting media streaming polyfill to local media files requiring transcoding, preventing hijack of remote HTTP/HTTPS video elements, and scoping VaapiVideoDecoder Chromium flag strictly to Linux.
#          - Fix full-screen toggle on macOS by binding standard macOS shortcuts (Ctrl+Cmd+F / Meta+Ctrl+F), F11, ApplicationShortcut context, keyPressEvent delegation in BrowserView, and handling web-initiated fullScreenRequested events.
# 0.16.2 - Resolve open defects:
#          - Fix F11 / Fullscreen shortcut ambiguity and conflict causing F11 not to toggle on Linux (BUG-20260926_182533, BUG-20260926_182056).
#          - Standardize macOS full-screen toggle to Safari emulation using Fn+F (Ctrl+Cmd+F) with key delegation (BUG-20260926_180644).
#          - Persist user main window geometry, position, size, and maximized state across sessions for all operating systems with offscreen CI guards (BUG-20260926_181901).
#          - Fix website media playback for https://marquee-magic.com and remote video streaming on macOS by adding static_ffmpeg path discovery, remote stream transcoding, permissive loopback origin, and intelligent client polyfill (BUG-20260926_180834).
#          - Ensure running application instances are cleanly terminated before package installation and enforce exact candidate package version verification in QA harness (BUG-20260926_181157, BUG-20260926_181420).
# 0.17.0 - Resolve open defects BUG-20260926_201212, BUG-20260926_202210, BUG-20260926_202344, and BUG-20260926_202613:
#          - Fix window geometry persistence across sessions on Linux and Windows by removing unconditional resize(800, 600) in __init__, setting _is_initializing guards during startup, and only saving geometry when the window is fully initialized and visible.
#          - Fix window decoration plugin loading on Debian/Ubuntu by removing bundled EL10 plugins from Debian package and scoping QCoreApplication.addLibraryPath for /opt/web-browser/plugins strictly to RHEL-family distributions when system plugins are absent.
#          - Fix media streaming player across all Linux distros by implementing direct HTTP 206 Partial Content byte-range streaming for all native media formats without requiring system FFmpeg, with dynamic MIME type negotiation and native HTML5 video time seeking.
#          - Fix macOS Intel (x86_64) automatic installation in QA fleet harness and Staging Hub copyable install commands to ensure the .app bundle is installed to /Applications/.
# 0.17.2 - Resolve open defects BUG-20260927_133312, BUG-20260927_132754, and BUG-20260927_132606:
#          - Fix NSS -8018 root certificate failure on Debian 13 by auto-sanitizing conflicting duplicate root cert module entries in ~/.pki/nssdb/pkcs11.txt.
#          - Fix video capture context provider bind failure on AlmaLinux 10 and Rocky Linux 10 by disabling VideoCaptureServiceInProcess, video capture GPU memory buffers, and GPU memory buffer video frames.
#          - Fix SharedImageManager non-existent mailbox errors during video playback on Linux by disabling GPU video frame buffers and forcing llvmpipe driver fallback when DRI render node is absent.
#          - Set Chromium log-level to 3 (FATAL) in release mode to suppress internal non-fatal diagnostics and error noise from polluting stderr and journal logs.
# 0.17.3 - Resolve open defect BUG-20260926_203228:
#          - Fix video playback failure on https://marquee-magic.com and web pages on Intel macOS (x86_64) by allowing running insecure content and disabling mixed-content auto-upgrade and private network request blocking for the local media streaming loopback proxy.
#          - Enhance media streaming polyfill to hook loadeddata, canplay, and canplaythrough events to avoid power-saving AbortError interruptions during initial media load, set muted and playsinline attributes to satisfy strict autoplay policies, and retry playback when polyfilled media reaches readyState >= 2.
# 0.17.4 - Resolve open defect BUG-20260927_184838:
#          - Fix video playback failure on https://marquee-magic.com on Intel macOS (x86_64) by bundling universal FFmpeg and FFprobe binaries directly into Web-Browser.app Contents/MacOS/.
#          - Add standalone application bundle and app-relative binary discovery in media_streamer find_ffmpeg() and find_ffprobe() across macOS, Linux, and Windows.
#          - Eliminate main-thread reverse-DNS (mdns_hostbyaddr) stalls during startup by overriding server_bind() in MediaStreamHTTPServer and address_string() in MediaStreamHandler.
#          - Enhance in-browser media stream polyfill with DOM MutationObserver, user interaction autoplay unblocking, stream error auto-retry, and browser User-Agent forwarding in FFmpeg pipeline.
# 0.18.0 - Enterprise Golden Build:
#          - Establish unified golden release candidate baseline across Linux (Rocky 10, AlmaLinux 10, Fedora 44, Debian 13, Ubuntu 26.04 LTS), macOS, and Windows 11.
#          - Guard Wayland decoration plugin loading with explicit x86_64 architecture checks to ensure architecture stability.
#          - Cleanly synchronize version metadata across all enterprise packaging manifests.
# 0.18.1 - Resolve open defect BUG-20260930_180300:
#          - Fix Qt6 private API conflict on Fedora 44/45 by scoping bundled EL10 Wayland decoration plugin strictly to RHEL family (%if 0%{?rhel}) in RPM spec.
#          - Rely on native qt6-qtwayland-adwaita-decoration package on Fedora to eliminate libQt6Gui.so.6(Qt_PRIVATE_API) dependency lock.
# 0.19.0 - Implement cross-platform Refresh (F5) keyboard shortcuts, tab Periodic Refresh, and align repository with CANONICAL_AGENTS.md:
#          - Add standard keyboard shortcuts for Reload (F5, Ctrl+R on Windows/Linux; Cmd+R, F5 on macOS) and Hard Reload bypassing cache (Ctrl+Shift+R, Ctrl+F5, Shift+F5 on Windows/Linux; Cmd+Shift+R, Cmd+Option+R on macOS).
#          - Implement BrowserView keyPressEvent delegation to ensure Chromium WebEngine views never swallow refresh shortcuts.
#          - Implement configurable tab Periodic Refresh / Auto-Reload with selectable intervals (Off, 10s, 30s, 1m, 2m, 5m, 15m, 30m, custom) accessible via tab context menu and reload button context menu.
#          - Unthrottle background tab timers via Chromium flags (--disable-background-timer-throttling, --disable-renderer-backgrounding, --disable-backgrounding-occluded-windows) so page-level meta-refreshes and JavaScript dashboard timers run reliably in background tabs.
#          - Add recurring background update check timer (every 4 hours).
#          - Align repository with CANONICAL_AGENTS.md: update AGENTS.md, remove forbidden publish.sh and redundant root build_deb.sh, clean up broken symlinks, create build-linux/sync_version.py, install.sh, uninstall.sh, build.sh, and comprehensive automated test suite in tests/.
# 0.19.1 - Cross-platform compilation & packaging resilience:
#          - Add graceful fallback for platformdirs user_data_dir across Linux distros when platformdirs is not installed in the system Python environment.
#          - Fix Windows PowerShell compile.ps1 NativeCommandError by temporarily relaxing ErrorActionPreference around PyInstaller execution, and make Web-Browser.spec paths dynamic and relative.
#          - Handle Apple Developer Program agreement expiration gracefully during macOS notarization preflight, creating Developer ID signed distribution DMGs.
# 0.19.2 - Multi-distro Linux packaging and test gate resilience:
#          - Make websockets dependency optional with graceful fallback in wheelhouser_client.py, preventing startup crashes when building/running without websockets.
#          - Guard optional module imports (license_manager, wai_assistant, update_manager, media_streamer) against sub-dependency failures in headless build environments.
#          - Guard automated test suites (test_smoke.py, test_shortcuts.py, test_periodic_refresh.py, test_browser_lifecycle.py) to skip UI tests gracefully when PySide6 is not installed on packaging nodes.
#          - Add build resilience regression tests in tests/unit/test_build_resilience.py.
# 0.19.3 - Resolve runtime defects BUG-20261001_185932 and BUG-20261001_190149:
#          - Fix media player playback stalling on initial load by ensuring FFmpeg live WebM transcoding starts immediately at start_time == 0 instead of falling back to raw MP4 when FFmpeg is available.
#          - Fix Fn+F5 / F5 / Refresh shortcut handling across all platforms by installing application-level and focusProxy child event filters, supporting Qt.Key.Key_Refresh multimedia keys, and ensuring Chromium WebEngine child widgets never swallow reload shortcuts.
# 0.19.4 - Resolve open defect BUG-20261001_204540:
#          - Fix Gatekeeper malware verification blocker on macOS 15 Intel (x86_64) by standardizing PySide6 embedded framework bundle structures and eliminating unsealed loose files.
#          - Prevent runtime signature invalidation by locking framework Versions directory permissions (chmod 555) against rogue QtWebEngine / Rosetta runtime mutations.
#          - Add automated DMG installation suite (install.sh, Install Web-Browser.command, README.txt) inside distribution DMGs for one-click installation and automatic Gatekeeper quarantine stripping.
#          - Add early macOS startup quarantine self-clearing logic to ensure seamless subsequent launches.
# 0.20.0 - Resolve embedded media player pause responsiveness and infinite loop defect:
#          - Fix media player pause button responsiveness by preventing polyfill scripts and autoplay observers from overriding user-initiated pauses.
#          - Terminate infinite constant looping on video completion by adding dedicated ended event handling and stopping playback when reaching media duration.
#          - Exclude internal streamer endpoints and embedded player pages from polyfill script injection.
#          - Honor user pause states during timeline scrubbing and prevent unexpected playback resumption.
# 0.21.0 - Support in-browser playback for .mp3 and .wav audio files with dedicated audio visualizer and stream handling:
#          - Add native audio stream transcoding via FFmpeg (-vn, -c:a libvorbis, audio/webm) avoiding invalid video stream mappings.
#          - Support HTTP 206 Partial Content byte-range fallback for MP3 and WAV when FFmpeg is not installed.
#          - Introduce rich in-browser audio player visualizer with vinyl disc artwork, animated equalizer bars, and format badges.
#          - Enable seamless scrubbing, volume control, keyboard shortcuts, and duration detection for audio files.
# 0.21.1 - Fix WheelhouserClient NoneType attribute errors in _heartbeat_loop and _sender_loop, guard websockets None import, and add URL encoding and persistent session pooling.
# 0.21.2 - Support opening CLI URL arguments on startup (sys.argv), implement dynamic AI Assistant enablement via --ai/--enable-ai flag and WAI_ENABLE_AI environment variable, and route incoming WAI open_url and focus commands.
# 0.22.0 - Completely remove commercial licensing system (license_manager, reset_license, PaymentDialog, and activation mechanisms) making all browser features fully unlocked.
# 0.23.0 - Resolve Google Account login security warnings by aligning User-Agent with client hints, whitelisting Google services in ad blocker, enforcing secure HTTPS content, removing global fetch injection, and adding popup window support.
# 0.24.0 - Hide Wheelhouser AI Assistant option from hamburger menu and enforce production release gating behind the ENABLE_AI flag.
#
# ===========================================================================================
# --- Imports ---
# ===========================================================================================
import os
import sys
import platform
import subprocess
import re
from typing import Any, Optional, Dict, List, Callable

# Early initialization of display and graphics flags BEFORE QtWebEngine is loaded
is_smoke_mode = (
    os.environ.get("QT_QPA_PLATFORM") == "offscreen"
    or "--smoke-test" in sys.argv
    or "--test-init" in sys.argv
)

if sys.platform.startswith("linux"):
    # Fix NSS certificate database conflict on Linux if pkcs11.txt contains duplicate/conflicting root cert module directives
    try:
        _nss_pkcs11 = os.path.expanduser("~/.pki/nssdb/pkcs11.txt")
        if os.path.isfile(_nss_pkcs11):
            with open(_nss_pkcs11, "r", encoding="utf-8", errors="ignore") as _f:
                _nss_content = _f.read()
            if "libnssckbi.so" in _nss_content or "Mozilla Root Certs" in _nss_content:
                _cleaned_lines = []
                _skip = False
                for _line in _nss_content.splitlines(keepends=True):
                    if "Mozilla Root Certs" in _line or "libnssckbi.so" in _line:
                        _skip = True
                        continue
                    if _skip and _line.strip().startswith("NSS="):
                        _skip = False
                        continue
                    if not _skip:
                        _cleaned_lines.append(_line)
                with open(_nss_pkcs11, "w", encoding="utf-8") as _f:
                    _f.writelines(_cleaned_lines)
    except Exception:
        pass

    if is_smoke_mode:
        os.environ.setdefault("LIBGL_ALWAYS_SOFTWARE", "1")
        os.environ.setdefault("GALLIUM_DRIVER", "llvmpipe")
        os.environ.setdefault("MESA_LOADER_DRIVER_OVERRIDE", "llvmpipe")
        os.environ.setdefault("QT_QUICK_BACKEND", "software")
    elif "LIBGL_ALWAYS_SOFTWARE" not in os.environ:
        has_render_node = False
        try:
            import glob

            render_nodes = glob.glob("/dev/dri/renderD*")
            if any(os.access(node, os.R_OK | os.W_OK) for node in render_nodes):
                has_render_node = True
        except Exception:
            pass

        if not has_render_node:
            os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"
            os.environ.setdefault("GALLIUM_DRIVER", "llvmpipe")
            os.environ.setdefault("MESA_LOADER_DRIVER_OVERRIDE", "llvmpipe")

    if "QT_WAYLAND_DECORATION" not in os.environ:
        os.environ["QT_WAYLAND_DECORATION"] = "adwaita"

_base_chromium_flags = [
    "--autoplay-policy=no-user-gesture-required",
    "--disable-features=TranslateUI,OptimizationHints,VideoCaptureServiceInProcess,BlockInsecurePrivateNetworkRequests,AutoupgradeMixedContent,Prefetch,SpeculationRules,Prerender2,SpeculationRulesPrefetchWithSubresources",
    "--disable-blink-features=SpeculationRules,Prerender2",
    "--disable-video-capture-use-gpu-memory-buffer",
    "--disable-gpu-memory-buffer-video-frames",
    "--disable-background-timer-throttling",
    "--disable-renderer-backgrounding",
    "--disable-backgrounding-occluded-windows",
    "--num-raster-threads=4",
    "--disk-cache-size=1073741824",
    "--media-cache-size=536870912",
]

# Suppress internal Chromium non-fatal diagnostic error noise from polluting user terminals/stderr
if "--verbose" not in sys.argv and "--debug" not in sys.argv:
    _base_chromium_flags.append("--log-level=3")

_base_chromium_flags.append("--enable-features=ParallelDownloading")


if is_smoke_mode or os.environ.get("LIBGL_ALWAYS_SOFTWARE") == "1":
    _base_chromium_flags.append("--disable-gpu")
    _base_chromium_flags.append("--no-sandbox")
else:
    _existing_flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    if "--disable-gpu" in _existing_flags:
        _base_chromium_flags.append("--disable-gpu")

os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = " ".join(_base_chromium_flags)

if sys.platform == "win32":
    # Ensure PySide6, shiboken6, and internal DLL directories are registered with Windows loader
    _app_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    for _sub in [
        "",
        "PySide6",
        "shiboken6",
        "_internal",
        "_internal\\PySide6",
        "_internal\\shiboken6",
    ]:
        _cand = os.path.normpath(os.path.join(_app_dir, _sub))
        if os.path.isdir(_cand):
            try:
                os.add_dll_directory(_cand)
            except (AttributeError, OSError):
                pass
            if _cand not in os.environ.get("PATH", ""):
                os.environ["PATH"] = f"{_cand};" + os.environ.get("PATH", "")

if sys.platform == "darwin":
    # Defensively strip any lingering Gatekeeper quarantine from own bundle on macOS
    try:
        _exec_path = os.path.abspath(sys.argv[0])
        if ".app" in _exec_path:
            _app_bundle = _exec_path[: _exec_path.find(".app") + 4]
            if os.path.isdir(_app_bundle):
                subprocess.run(
                    ["xattr", "-d", "com.apple.quarantine", _app_bundle],
                    capture_output=True,
                    timeout=2,
                    check=False,
                )
    except Exception:
        pass

import ctypes
import json
import logging
import mimetypes

logger = logging.getLogger("web-browser")

try:
    from platformdirs import user_data_dir
except ImportError:
    def user_data_dir(appname: str, appauthor: str | None = None) -> str:
        if sys.platform == "win32":
            base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~/AppData/Local")
        elif sys.platform == "darwin":
            base = os.path.expanduser("~/Library/Application Support")
        else:
            base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
        return os.path.join(base, appname)
from PySide6.QtCore import (
    QByteArray,
    QCoreApplication,
    QEvent,
    QLoggingCategory,
    QMimeData,
    QPoint,
    QRectF,
    QSettings,
    QSize,
    QStandardPaths,
    Qt,
    QThread,
    QTimer,
    QUrl,
)
from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QColor,
    QCursor,
    QDesktopServices,
    QGuiApplication,
    QIcon,
    QImage,
    QKeySequence,
    QPainter,
    QPalette,
    QPixmap,
    QShortcut,
)
try:
    from PySide6.QtSvg import QSvgRenderer

    HAS_QT_SVG = True
except ImportError:
    HAS_QT_SVG = False
    QSvgRenderer = None  # type: ignore
from PySide6.QtWebEngineCore import (
    QWebEnginePage,
    QWebEngineProfile,
    QWebEngineScript,
    QWebEngineSettings,
    QWebEngineUrlRequestInfo,
    QWebEngineUrlRequestInterceptor,
)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QBoxLayout,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLayout,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QProxyStyle,
    QPushButton,
    QStyle,
    QTabBar,
    QTabWidget,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

logger = logging.getLogger("web-browser")

# Ensure the directory containing this script (src) is in sys.path
_src_dir = os.path.dirname(os.path.abspath(__file__))
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

try:
    from src.wai_assistant import WAIAssistantManager  # type: ignore
except (ModuleNotFoundError, ImportError):
    try:
        from wai_assistant import WAIAssistantManager  # type: ignore
    except (ModuleNotFoundError, ImportError):
        WAIAssistantManager: Any = None  # type: ignore

try:
    from src.update_manager import UpdateCheckThread  # type: ignore
except (ModuleNotFoundError, ImportError):
    try:
        from update_manager import UpdateCheckThread  # type: ignore
    except (ModuleNotFoundError, ImportError):
        UpdateCheckThread: Any = None  # type: ignore

try:
    from src.media_streamer import MediaStreamServer  # type: ignore
except (ModuleNotFoundError, ImportError):
    try:
        from media_streamer import MediaStreamServer  # type: ignore
    except (ModuleNotFoundError, ImportError):
        MediaStreamServer: Any = None  # type: ignore


def launch_installer(file_path):
    """Cross-platform installer launcher"""
    if not file_path or not os.path.exists(file_path):
        return False
    import subprocess

    try:
        if sys.platform == "win32":
            os.startfile(file_path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", file_path])
        else:
            subprocess.Popen(["xdg-open", file_path])
        return True
    except OSError as exc:
        logger.error(f"Failed to launch installer: {exc}")
        return False


# Base directory for writable runtime data (e.g. adblocker cache, history)
DATA_DIR = QStandardPaths.writableLocation(
    QStandardPaths.StandardLocation.AppDataLocation
)
os.makedirs(DATA_DIR, exist_ok=True)


def resource_path(relative_path):
    """Get absolute path to resource, works for dev, PyInstaller, and Nuitka"""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
        target = os.path.join(base_path, relative_path)
        if os.path.exists(target):
            return target

    if hasattr(sys, "_MEIPASS"):
        target = os.path.join(sys._MEIPASS, relative_path)
        if os.path.exists(target):
            return target

    if "py2app" in sys.argv:
        target = os.path.join(
            os.path.dirname(sys.executable), "..", "Resources", relative_path
        )
        if os.path.exists(target):
            return target

    src_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.dirname(src_dir)

    target_root = os.path.join(root_dir, relative_path)
    if os.path.exists(target_root):
        return target_root

    target_src = os.path.join(src_dir, relative_path)
    if os.path.exists(target_src):
        return target_src

    return target_root


ICONS_PATH = resource_path(os.path.join("assets", "icons"))


def create_desktop_shortcut(parent=None):
    """Creates a desktop shortcut for Web-Browser across Windows, macOS, and Linux."""
    try:
        app_name = APP_NAME
        desktop_dir = ""

        if sys.platform == "win32":
            user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
            onedrive_desktop = os.path.join(user_profile, "OneDrive", "Desktop")
            if os.path.exists(onedrive_desktop):
                desktop_dir = onedrive_desktop
            else:
                desktop_dir = os.path.join(user_profile, "Desktop")

            shortcut_path = os.path.join(desktop_dir, f"{app_name}.lnk")
            icon_ico = resource_path(os.path.join("assets", "icons", "icon.ico"))
            if not os.path.exists(icon_ico):
                icon_ico = resource_path(os.path.join("assets", "windows", "icon.ico"))

            is_frozen = getattr(sys, "frozen", False) or (
                not sys.executable.lower().endswith("python.exe")
                and not sys.executable.lower().endswith("pythonw.exe")
            )
            
            is_msix = False
            msix_pfn = ""
            try:
                import ctypes
                from ctypes import wintypes
                buf_len = wintypes.UINT(256)
                buf = ctypes.create_unicode_buffer(256)
                if ctypes.windll.kernel32.GetCurrentPackageFamilyName(ctypes.byref(buf_len), buf) == 0:
                    if "web-browser" in buf.value.lower() or "webbrowser" in buf.value.lower() or "wheelhouser" in buf.value.lower():
                        is_msix = True
                        msix_pfn = buf.value
            except Exception:
                pass

            if not is_msix and is_frozen and "windowsapps" in sys.executable.lower() and ("web-browser" in sys.executable.lower() or "webbrowser" in sys.executable.lower()):
                is_msix = True
                try:
                    parts = sys.executable.split(os.sep)
                    for part in parts:
                        if "__" in part and ("web-browser" in part.lower() or "webbrowser" in part.lower()):
                            tokens = part.split("__")
                            name_prefix = tokens[0].rsplit("_", 2)[0] if "_" in tokens[0] else tokens[0]
                            pub_id = tokens[1]
                            msix_pfn = f"{name_prefix}_{pub_id}"
                except Exception:
                    pass

            if is_msix:
                if not msix_pfn:
                    msix_pfn = "WheelhouserLLC.Web-BrowserfromWheelhouser_2sq2b2t7jg2f6"
                target_exe = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "explorer.exe")
                arguments = f"shell:AppsFolder\\{msix_pfn}!WebBrowser"
                working_dir = os.path.dirname(sys.executable)
            elif is_frozen:
                target_exe = sys.executable
                arguments = ""
                working_dir = os.path.dirname(sys.executable)
            else:
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                working_dir = os.path.dirname(os.path.dirname(script_path))
                py_bin = sys.executable.replace("python.exe", "pythonw.exe")
                if not os.path.exists(py_bin):
                    py_bin = sys.executable
                target_exe = os.environ.get("COMSPEC", "C:\\Windows\\System32\\cmd.exe")
                arguments = f'/c start "" "{py_bin}" "{script_path}"'

            ps_content = f'''$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut("{shortcut_path}")
$s.TargetPath = "{target_exe}"
$s.Arguments = '{arguments}'
$s.WorkingDirectory = "{working_dir}"
$s.Description = "{app_name} by {COMPANY_NAME}"
if (Test-Path "{icon_ico}") {{
    $s.IconLocation = "{icon_ico},0"
}}
$s.Save()
'''
            temp_ps1 = os.path.join(os.environ.get("TEMP", "."), f"create_shortcut_{os.getpid()}.ps1")
            with open(temp_ps1, "w", encoding="utf-8") as f:
                f.write(ps_content)

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", temp_ps1],
                check=True,
                creationflags=creationflags,
            )
            try:
                os.remove(temp_ps1)
            except Exception:
                pass

        elif sys.platform == "darwin":
            desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            if getattr(sys, "frozen", False):
                app_bundle = os.path.abspath(os.path.join(os.path.dirname(sys.executable), "..", ".."))
                if app_bundle.endswith(".app"):
                    dest_app = os.path.join(desktop_dir, os.path.basename(app_bundle))
                    if os.path.exists(dest_app):
                        os.remove(dest_app)
                    os.symlink(app_bundle, dest_app)
            else:
                command_file = os.path.join(desktop_dir, f"{app_name}.command")
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                with open(command_file, "w", encoding="utf-8") as f:
                    f.write(f'#!/bin/bash\ncd "{os.path.dirname(os.path.dirname(script_path))}"\n"{sys.executable}" "{script_path}"\n')
                os.chmod(command_file, 0o755)

        else:  # Linux
            desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            desktop_file = os.path.join(desktop_dir, "com.wheelhouser.web-browser.desktop")
            icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
            if getattr(sys, "frozen", False):
                exec_cmd = f'"{sys.executable}"'
            else:
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                exec_cmd = f'"{sys.executable}" "{script_path}"'

            content = f"""[Desktop Entry]
Type=Application
Name={app_name}
Comment={app_name} by {COMPANY_NAME}
Exec={exec_cmd}
Icon={icon_path}
Terminal=false
Categories=Network;WebBrowser;
StartupWMClass=com.wheelhouser.web-browser
"""
            with open(desktop_file, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(desktop_file, 0o755)

        if parent:
            QMessageBox.information(
                parent,
                "Desktop Shortcut",
                "Desktop icon created successfully on your Desktop!",
            )
        return True
    except Exception as e:
        logger.error(f"Failed to create desktop shortcut: {e}")
        if parent:
            QMessageBox.warning(
                parent,
                "Desktop Shortcut",
                f"Failed to create desktop icon: {e}",
            )
        return False


class LargeIconProxyStyle(QProxyStyle):
    """Proxy style to enforce refined icon sizes in QMenu (e.g. 22x22)."""

    def pixelMetric(self, metric, option=None, widget=None):
        if metric == QStyle.PixelMetric.PM_SmallIconSize:
            return 22
        return super().pixelMetric(metric, option, widget)


FILE_EXTENSION_SVGS = {
    "py": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#3776ab"/><path d="M11.5 5.5c-2.5 0-3.5.8-3.5 2v1.5h4v.5h-5.5C4.5 9.5 4 10.8 4 12.8s.7 2.2 2 2.2h1.5v-1.8c0-1.2 1-2.2 2.2-2.2h3.8c1 0 1.5-.7 1.5-1.5V7.5c0-1.2-1-2-3-2zm-1.2 1.2c.4 0 .8.4.8.8s-.4.8-.8.8-.8-.4-.8-.8.4-.8.8-.8zm2.2 11.8c2.5 0 3.5-.8 3.5-2V15h-4v-.5h5.5c2 0 2.5-1.3 2.5-3.3s-.7-2.2-2-2.2h-1.5v1.8c0 1.2-1 2.2-2.2 2.2h-3.8c-1 0-1.5.7-1.5 1.5v2c0 1.2 1 2 3 2zm1.2-1.2c-.4 0-.8-.4-.8-.8s.4-.8.8-.8.8.4.8.8-.4.8-.8.8z" fill="#ffd43b"/></svg>',
    "html": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#e44d26"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">&lt;/&gt;</text></svg>',
    "css": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#264de4"/><text x="12" y="17" font-family="sans-serif" font-weight="900" font-size="14" fill="#ffffff" text-anchor="middle">#</text></svg>',
    "js": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#f7df1e"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="11" fill="#000000" text-anchor="middle">JS</text></svg>',
    "ts": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#3178c6"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">TS</text></svg>',
    "csv": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#107c41"/><path d="M6 6h12v12H6z" fill="none" stroke="#ffffff" stroke-width="1.5"/><line x1="12" y1="6" x2="12" y2="18" stroke="#ffffff" stroke-width="1.5"/><line x1="6" y1="12" x2="18" y2="12" stroke="#ffffff" stroke-width="1.5"/></svg>',
    "json": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#f59e0b"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="#000000" text-anchor="middle">{ }</text></svg>',
    "yaml": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#8b5cf6"/><circle cx="8" cy="8" r="2" fill="#ffffff"/><circle cx="16" cy="16" r="2" fill="#ffffff"/><line x1="8" y1="10" x2="8" y2="18" stroke="#ffffff" stroke-width="1.5"/><line x1="16" y1="6" x2="16" y2="14" stroke="#ffffff" stroke-width="1.5"/></svg>',
    "md": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#0284c7"/><path d="M5 15V9l3 3 3-3v6M17 12l-2 3-2-3M15 9v6" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    "txt": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>',
    "pdf": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#ef4444"/><text x="12" y="15" font-family="sans-serif" font-weight="900" font-size="8" fill="#ffffff" text-anchor="middle">PDF</text></svg>',
    "image": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#c084fc" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    "video": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#22d3ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
    "audio": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#f43f5e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    "archive": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#eab308" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    "exe": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>',
    "code": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    "generic": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
}

_FILE_ICON_CACHE = {}


def get_file_extension_qicon(ext_or_path):
    if not ext_or_path:
        key = "generic"
    else:
        ext = ext_or_path.lower().split("?")[0].split("#")[0]
        if "." in ext:
            ext = ext.rsplit(".", 1)[-1]

        if ext in ("py", "pyw", "ipynb"):
            key = "py"
        elif ext in ("html", "htm", "xhtml"):
            key = "html"
        elif ext in ("css", "scss", "sass", "less"):
            key = "css"
        elif ext in ("js", "jsx", "mjs", "cjs"):
            key = "js"
        elif ext in ("ts", "tsx"):
            key = "ts"
        elif ext in ("csv", "tsv", "xlsx", "xls", "ods"):
            key = "csv"
        elif ext in ("json", "jsonc", "json5"):
            key = "json"
        elif ext in ("yaml", "yml", "toml", "ini", "cfg", "conf", "env"):
            key = "yaml"
        elif ext in ("md", "markdown", "rst"):
            key = "md"
        elif ext in ("txt", "log", "rtf", "out"):
            key = "txt"
        elif ext == "pdf":
            key = "pdf"
        elif ext in (
            "png",
            "jpg",
            "jpeg",
            "gif",
            "svg",
            "webp",
            "bmp",
            "ico",
            "tiff",
            "avif",
        ):
            key = "image"
        elif ext in ("mp4", "mov", "mkv", "avi", "wmv", "webm", "flv", "ts", "m4v"):
            key = "video"
        elif ext in ("mp3", "wav", "flac", "aac", "ogg", "m4a", "wma"):
            key = "audio"
        elif ext in ("zip", "rar", "7z", "tar", "gz", "bz2", "xz"):
            key = "archive"
        elif ext in ("exe", "msi", "bat", "cmd", "ps1", "sh", "bin", "dll"):
            key = "exe"
        elif ext in ("c", "cpp", "h", "hpp", "rs", "go", "java", "cs"):
            key = "code"
        else:
            key = "generic"

    if key in _FILE_ICON_CACHE:
        return _FILE_ICON_CACHE[key]

    if not HAS_QT_SVG or QSvgRenderer is None:
        return QIcon()

    try:
        svg_data = FILE_EXTENSION_SVGS.get(key, FILE_EXTENSION_SVGS["generic"])
        renderer = QSvgRenderer(QByteArray(svg_data.encode("utf-8")))
        img = QImage(32, 32, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(Qt.GlobalColor.transparent)
        painter = QPainter(img)
        renderer.render(painter, QRectF(0, 0, 32, 32))
        painter.end()
        icon = QIcon(QPixmap.fromImage(img))
        _FILE_ICON_CACHE[key] = icon
        return icon
    except (ValueError, TypeError, RuntimeError, OSError):
        return QIcon()


# ===========================================================================================
# --- Web-Browser Application with Dark Theme ---
# ===========================================================================================
APP_NAME = "Web-Browser"
APP_AUTHOR = "WheelhouserLLC"
APP_VERSION = "0.24.0"
VERSION = "0.24.0"
DEFAULT_HOMEPAGE = "https://duckduckgo.com"
COMPANY_NAME = "Wheelhouser LLC"
WEBSITE_URL = "https://wheelhouser.com"
ENABLE_AI = False  # Set to False to disable AI features for Store release
if "--ai" in sys.argv or "--enable-ai" in sys.argv or os.environ.get("WAI_ENABLE_AI", "").lower() in ("1", "true", "yes"):
    ENABLE_AI = True
STORE_RELEASE = True  # Set to False to enable verbose debugging mode

# OS Awareness Constants
IS_MAC = sys.platform == "darwin"
IS_WINDOWS = sys.platform == "win32"
IS_LINUX = sys.platform.startswith("linux")

PRIMARY_MOD_NAME = "Cmd" if IS_MAC else "Ctrl"
ALT_MOD_NAME = "Option" if IS_MAC else "Alt"
PRIMARY_KEY_SEQ = "Meta" if IS_MAC else "Ctrl"

# Default File Mode root is user's home directory (~)
home_dir_clean = os.path.abspath(os.path.expanduser("~")).replace("\\", "/")
if IS_WINDOWS and len(home_dir_clean) >= 2 and home_dir_clean[1] == ":":
    DEFAULT_FILE_ROOT = f"file:///{home_dir_clean.lstrip('/')}/"
else:
    DEFAULT_FILE_ROOT = f"file://{home_dir_clean.rstrip('/')}/"

DEFAULT_FILE_PLACEHOLDER = f"Enter file path e.g. {DEFAULT_FILE_ROOT} or ~"


# ===========================================================================================
# --- Ad & Tracker Blocker Interceptor ---
# ===========================================================================================
class AdBlockInterceptor(QWebEngineUrlRequestInterceptor):
    BLOCKED_HOST_PATTERNS = (
        "doubleclick.net",
        "googlesyndication.com",
        "google-analytics.com",
        "adservice.google.com",
        "adnxs.com",
        "scorecardresearch.com",
        "criteo.com",
        "criteo.net",
        "outbrain.com",
        "taboola.com",
        "amazon-adsystem.com",
        "ads.twitter.com",
        "moatads.com",
        "serving-sys.com",
        "adsystem.com",
        "smartadserver.com",
        "bidswitch.net",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "adroll.com",
        "quantserve.com",
        "analytics.twitter.com",
        "connect.facebook.net",
        "pixel.facebook.com",
    )

    def __init__(self, enabled=True, partner_ua: bytes = b"", parent=None):
        super().__init__(parent)
        self.enabled = enabled
        self.partner_ua = partner_ua

    def interceptRequest(self, info: QWebEngineUrlRequestInfo):
        url = info.requestUrl()
        host = url.host().lower()

        # For Microsoft Partner Center, forward clean desktop Chrome User-Agent header
        if self.partner_ua and (
            host == "partner.microsoft.com" or host.endswith(".partner.microsoft.com")
        ):
            info.setHttpHeader(b"User-Agent", self.partner_ua)

        if not self.enabled:
            return

        # Never block Microsoft, Azure, Office, Identity, or CDN domains
        if host.endswith(
            (
                ".microsoft.com",
                ".azure.com",
                ".live.com",
                ".windows.net",
                ".office.com",
                ".msftauth.net",
                ".msauth.net",
                ".trafficmanager.net",
            )
        ):
            return

        # Never block Google authentication, accounts, identity, APIs, Play, or core CDN domains
        if host == "google.com" or host.endswith(
            (
                ".google.com",
                ".gstatic.com",
                ".googleapis.com",
                ".googleusercontent.com",
                ".youtube.com",
                ".googlevideo.com",
                ".gmail.com",
            )
        ) or ".google." in host:
            return

        if any(
            host == pattern or host.endswith("." + pattern)
            for pattern in self.BLOCKED_HOST_PATTERNS
        ):
            info.block(True)


class WebEnginePage(QWebEnginePage):
    """Custom WebEnginePage that intercepts and silences remote JS console noise, defaults to dark background, and seamlessly routes video files to the streaming player."""

    def __init__(self, profile, parent=None, main_window=None):
        super().__init__(profile, parent)
        self.main_window = main_window
        self.browser_view = parent
        try:
            self.fullScreenRequested.connect(self.handle_fullscreen_requested)
        except Exception:
            pass

    def handle_fullscreen_requested(self, request):
        request.accept()
        if self.main_window:
            if request.toggleOn():
                if not self.main_window.isFullScreen():
                    self.main_window.toggle_fullscreen()
            else:
                if self.main_window.isFullScreen():
                    self.main_window.toggle_fullscreen()

    def javaScriptConsoleMessage(self, level, message, lineNumber, sourceID):
        if not STORE_RELEASE:
            level_map = {
                QWebEnginePage.JavaScriptConsoleMessageLevel.InfoMessageLevel: "INFO",
                QWebEnginePage.JavaScriptConsoleMessageLevel.WarningMessageLevel: "WARN",
                QWebEnginePage.JavaScriptConsoleMessageLevel.ErrorMessageLevel: "ERROR",
            }
            lvl = level_map.get(level, "LOG")
            print(f"[JS {lvl}] {sourceID}:{lineNumber} -> {message}")
            logger.debug(f"js ({sourceID}:{lineNumber}): {message}")

    def acceptNavigationRequest(self, url, nav_type, isMainFrame):
        try:
            url_str = url.toString()
            is_local = (
                url.isLocalFile()
                or url_str.startswith("file://")
                or url_str.startswith("/")
                or (IS_WINDOWS and len(url_str) >= 2 and url_str[1] == ":")
            )
            if (
                isMainFrame
                and is_local
                and self.main_window
                and hasattr(self.main_window, "media_streamer")
                and self.main_window.media_streamer
            ):
                port = self.main_window.media_streamer.port
                lower = url_str.lower().split("?")[0].split("#")[0]
                media_exts = (
                    ".mp4",
                    ".m4v",
                    ".mov",
                    ".mkv",
                    ".avi",
                    ".wmv",
                    ".flv",
                    ".ts",
                    ".webm",
                    ".m4a",
                    ".mp3",
                    ".wav",
                    ".flac",
                    ".ogg",
                    ".aac",
                    ".wma",
                )
                if any(
                    lower.endswith(ext) for ext in media_exts
                ) and not url_str.startswith(f"http://127.0.0.1:{port}/"):
                    from urllib.parse import quote_plus

                    player_url = QUrl(
                        f"http://127.0.0.1:{port}/player?url={quote_plus(url_str)}"
                    )
                    # Safely defer setting the URL to the next event loop cycle to avoid Chromium C++ throttle recursion
                    view = getattr(self, "browser_view", None) or (getattr(self, "view", lambda: None)() or self.parent())
                    if isinstance(view, QWebEngineView):
                        QTimer.singleShot(0, lambda p=player_url, v=view: v.setUrl(p))
                    return False
        except (AttributeError, TypeError, ValueError) as e:
            logger.debug(f"Navigation request check failed: {e}")
        return super().acceptNavigationRequest(url, nav_type, isMainFrame)


class BrowserView(QWebEngineView):
    """Custom QWebEngineView supporting right-click Copy File, Save File, Examine Source, and dark canvas styling."""

    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self._pending_url = None
        self.setStyleSheet("background-color: #1e1e1e;")

    def keyPressEvent(self, event):
        key = event.key()
        mods = event.modifiers()
        is_shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        is_ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        is_meta = bool(mods & Qt.KeyboardModifier.MetaModifier)
        is_alt = bool(mods & Qt.KeyboardModifier.AltModifier)

        # F5 / Multimedia Refresh handling (Standard reload, Shift+F5 or Ctrl+F5 hard reload)
        refresh_key = getattr(Qt.Key, "Key_Refresh", 0x010000bf)
        if key in (Qt.Key.Key_F5, refresh_key):
            if self.main_window:
                if is_shift or is_ctrl:
                    self.main_window.reload_page_bypass_cache(self)
                else:
                    self.main_window.reload_page(self)
            event.accept()
            return

        # R key handling (Ctrl+R / Cmd+R standard reload, Ctrl+Shift+R / Cmd+Shift+R hard reload)
        if key == Qt.Key.Key_R:
            if IS_MAC:
                if (is_meta or is_ctrl) and is_shift:
                    if self.main_window:
                        self.main_window.reload_page_bypass_cache(self)
                    event.accept()
                    return
                elif is_meta and is_alt:
                    if self.main_window:
                        self.main_window.reload_page_bypass_cache(self)
                    event.accept()
                    return
                elif (is_meta or is_ctrl) and not is_shift and not is_alt:
                    if self.main_window:
                        self.main_window.reload_page(self)
                    event.accept()
                    return
            else:
                if is_ctrl and is_shift:
                    if self.main_window:
                        self.main_window.reload_page_bypass_cache(self)
                    event.accept()
                    return
                elif is_ctrl and not is_shift and not is_alt and not is_meta:
                    if self.main_window:
                        self.main_window.reload_page(self)
                    event.accept()
                    return

        is_f11 = (key == Qt.Key.Key_F11)
        is_mac_fs = (
            IS_MAC
            and key == Qt.Key.Key_F
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        )
        if is_f11 or is_mac_fs:
            if self.main_window:
                self.main_window.toggle_fullscreen()
                event.accept()
                return
        elif key == Qt.Key.Key_Escape and self.main_window and self.main_window.isFullScreen():
            self.main_window.exit_fullscreen()
            event.accept()
            return
        super().keyPressEvent(event)

    def open_view_source(self):
        curr_url = self.url().toString()
        if not curr_url or curr_url == "about:blank":
            return
        if not curr_url.startswith("view-source:"):
            source_url = "view-source:" + curr_url
        else:
            source_url = curr_url
        if self.main_window:
            page_title = self.title() or curr_url
            self.main_window.add_new_tab(
                QUrl(source_url), label=f"Source: {page_title}", set_current=True
            )

    def createWindow(self, type: QWebEnginePage.WebWindowType, /) -> QWebEngineView:
        """Handle window.open() and OAuth login popups by seamlessly opening a new tab."""
        if self.main_window:
            new_tab = self.main_window.add_new_tab(set_current=True)
            if new_tab:
                return new_tab
        return super().createWindow(type)

    def contextMenuEvent(self, event):
        menu = self.createStandardContextMenu()
        if not menu:
            menu = QMenu(self)
        menu.setStyle(LargeIconProxyStyle())
        menu.setStyleSheet("""
            QMenu {
                background-color: #252525;
                border: 1px solid #454545;
                border-radius: 8px;
                padding: 4px;
                color: #ffffff;
            }
            QMenu::item {
                padding: 6px 12px;
                background-color: transparent;
                border-radius: 6px;
                min-height: 24px;
                font-size: 13px;
                color: #ffffff;
            }
            QMenu::item:selected {
                background-color: #007AFF;
                color: #ffffff;
                border-radius: 6px;
            }
            QMenu::separator {
                height: 1px;
                background: #3f3f46;
                margin: 4px 8px;
            }
        """)

        # Icon paths
        back_icon_path = os.path.join(ICONS_PATH, "back.png")
        forward_icon_path = os.path.join(ICONS_PATH, "forward.png")
        reload_icon_path = os.path.join(ICONS_PATH, "reload.png")
        save_icon_path = os.path.join(ICONS_PATH, "save.png")
        copy_icon_path = os.path.join(ICONS_PATH, "copy.png")
        examine_icon_path = os.path.join(ICONS_PATH, "examine.png")

        def _clean_and_apply_icons(menu_obj):
            for act in list(menu_obj.actions()):
                if act.isSeparator():
                    continue
                txt = act.text().lower().replace("&", "").strip()

                # 1. Remove standard "View page source" or "View source" from menu and submenus
                if "view page source" in txt or "view source" in txt or txt == "source":
                    menu_obj.removeAction(act)
                    continue

                # 2. Apply matching vibrant icons
                if (txt.startswith("back") or "go back" in txt) and os.path.exists(
                    back_icon_path
                ):
                    act.setIcon(QIcon(back_icon_path))
                elif (
                    txt.startswith("forward") or "go forward" in txt
                ) and os.path.exists(forward_icon_path):
                    act.setIcon(QIcon(forward_icon_path))
                elif (
                    txt.startswith(("reload", "refresh")) or "refresh" in txt
                ) and os.path.exists(reload_icon_path):
                    act.setIcon(QIcon(reload_icon_path))
                elif "save" in txt and os.path.exists(save_icon_path):
                    act.setIcon(QIcon(save_icon_path))
                elif "copy" in txt and os.path.exists(copy_icon_path):
                    act.setIcon(QIcon(copy_icon_path))

                if act.menu():
                    act.menu().setStyle(LargeIconProxyStyle())
                    act.menu().setStyleSheet(menu.styleSheet())
                    _clean_and_apply_icons(act.menu())

        _clean_and_apply_icons(menu)

        req = self.lastContextMenuRequest()
        target_url = None
        if req and req.linkUrl() and req.linkUrl().isValid():
            target_url = req.linkUrl()
        elif self.url() and self.url().isValid():
            target_url = self.url()

        if target_url:
            url_str = target_url.toString()
            is_file = url_str.startswith("file://") or target_url.isLocalFile()
            if is_file:
                local_path = target_url.toLocalFile()
                if not local_path:
                    local_path = url_str.replace("file:///", "").replace("file://", "")
                if (
                    local_path
                    and len(local_path) >= 3
                    and local_path[0] == "/"
                    and local_path[2] == ":"
                ):
                    local_path = local_path[1:]

                if local_path and os.path.exists(local_path):
                    menu.addSeparator()
                    copy_action = QAction("Copy File", menu)
                    if os.path.exists(copy_icon_path):
                        copy_action.setIcon(QIcon(copy_icon_path))
                    copy_action.setToolTip(
                        "Copy file to clipboard for pasting in File Explorer"
                    )
                    copy_action.triggered.connect(
                        lambda _, p=local_path: self.main_window.copy_file_to_clipboard(
                            p
                        )
                    )
                    menu.addAction(copy_action)

                    copy_path_action = QAction("Copy File Path", menu)
                    if os.path.exists(copy_icon_path):
                        copy_path_action.setIcon(QIcon(copy_icon_path))
                    copy_path_action.triggered.connect(
                        lambda _, p=local_path: QApplication.clipboard().setText(p)
                    )
                    menu.addAction(copy_path_action)

                    if os.path.isfile(local_path):
                        save_file_action = QAction("Save File As...", menu)
                        if os.path.exists(save_icon_path):
                            save_file_action.setIcon(QIcon(save_icon_path))
                        save_file_action.triggered.connect(
                            lambda _, p=local_path: self.main_window.save_local_file_as(
                                p
                            )
                        )
                        menu.addAction(save_file_action)

                        open_dir_action = QAction("Open Containing Folder", menu)
                        open_dir_action.triggered.connect(
                            lambda _, p=local_path: QDesktopServices.openUrl(
                                QUrl.fromLocalFile(os.path.dirname(p))
                            )
                        )
                        menu.addAction(open_dir_action)

        # Add Examine Source action for active pages/files
        if (
            self.url()
            and self.url().isValid()
            and self.url().toString() != "about:blank"
        ):
            menu.addSeparator()
            examine_action = QAction("Examine Source", menu)
            if os.path.exists(examine_icon_path):
                examine_action.setIcon(QIcon(examine_icon_path))
            examine_action.triggered.connect(self.open_view_source)
            menu.addAction(examine_action)

        menu.exec(event.globalPos())


class HistoryDialog(QDialog):
    def __init__(self, history_data, save_callback, parent=None):
        super().__init__(parent)
        self.setWindowTitle("History")
        self.resize(600, 400)
        self.history_data = history_data
        self.save_callback = save_callback
        self.url_to_open = None
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()

        # Show newest first
        for item in reversed(self.history_data):
            title = item.get("title", "No Title")
            url = item.get("url", "")
            display_text = f"{title}\n{url}"
            list_item = QListWidgetItem(display_text)
            list_item.setData(Qt.ItemDataRole.UserRole, url)
            self.list_widget.addItem(list_item)

        self.list_widget.itemClicked.connect(self.on_item_clicked)
        layout.addWidget(self.list_widget)

        btn_clear = QPushButton("Clear History")
        btn_clear.clicked.connect(self.clear_history)
        layout.addWidget(btn_clear)

    def on_item_clicked(self, item):
        self.url_to_open = item.data(Qt.ItemDataRole.UserRole)
        self.accept()

    def clear_history(self):
        self.history_data.clear()
        self.list_widget.clear()
        if self.save_callback:
            self.save_callback()


# ============================================================================================
# --- Main Application Window ---
# ============================================================================================
class WebBrowserApp(QMainWindow):
    @staticmethod
    def _get_desktop_window_flags():
        """Align titlebar controls with desktop preferences (e.g. GNOME close-only standard)."""
        flags = (
            Qt.WindowType.Window
            | Qt.WindowType.WindowTitleHint
            | Qt.WindowType.WindowCloseButtonHint
            | Qt.WindowType.WindowSystemMenuHint
        )
        try:
            res = subprocess.run(
                ["gsettings", "get", "org.gnome.desktop.wm.preferences", "button-layout"],
                capture_output=True,
                text=True,
                timeout=1,
            )
            layout = res.stdout.strip().replace("'", "").replace('"', "")
            if "maximize" in layout:
                flags |= Qt.WindowType.WindowMaximizeButtonHint
            if "minimize" in layout:
                flags |= Qt.WindowType.WindowMinimizeButtonHint
        except Exception:
            pass
        return flags

    def __init__(self):
        self._is_initializing = True
        super().__init__()

        if sys.platform.startswith("linux"):
            self.setWindowFlags(self._get_desktop_window_flags())

        self.setMinimumSize(960, 600)

        self.log_dir = user_data_dir(APP_NAME, APP_AUTHOR)
        os.makedirs(self.log_dir, exist_ok=True)

        self.favicon_dir = os.path.join(self.log_dir, "favicon_cache")
        os.makedirs(self.favicon_dir, exist_ok=True)

        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        self.is_smoke_mode = is_smoke_mode or (os.environ.get("QT_QPA_PLATFORM") == "offscreen")
        saved_geom = self.settings.value("geometry")
        if saved_geom and not self.is_smoke_mode:
            self.restoreGeometry(saved_geom)
        else:
            self.resize(1280, 850)
        saved_state = self.settings.value("windowState")
        if saved_state and not self.is_smoke_mode:
            self.restoreState(saved_state)
        self.saved_was_maximized = self.settings.value("isMaximized", False, type=bool)

        self.sidebar_minimized = bool(self.settings.value(
            "sidebar_minimized", False, type=bool
        ))
        self.disk_cache_enabled = bool(self.settings.value(
            "disk_cache_enabled", True, type=bool
        ))
        self.ad_block_enabled = bool(self.settings.value("ad_block_enabled", True, type=bool))
        self.ai_enabled = bool(
            ENABLE_AI and self.settings.value("enable_ai", True, type=bool)
        )

        # Configure persistent storage for WebEngine to save cookies/sessions
        self.profile = QWebEngineProfile("WebBrowserProfile", self)
        self.profile.setPersistentStoragePath(os.path.join(self.log_dir, "web_profile"))
        self.profile.setCachePath(os.path.join(self.log_dir, "web_cache"))
        self.profile.setPersistentCookiesPolicy(
            QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies
        )
        self.profile.setHttpCacheMaximumSize(1024 * 1024 * 1024)  # 1 GB Cache Limit
        if self.disk_cache_enabled:
            self.profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        else:
            self.profile.setHttpCacheType(
                QWebEngineProfile.HttpCacheType.MemoryHttpCache
            )

        # Attach built-in fast ad & tracker blocker
        self.ad_block_interceptor = AdBlockInterceptor(
            enabled=self.ad_block_enabled, parent=self
        )
        self.profile.setUrlRequestInterceptor(self.ad_block_interceptor)

        # Configure WebEngine settings for media, video autoplay, and performance
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.LocalStorageEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True
        )
        # Apply default web profile settings for media, HTML5, and script capabilities
        try:
            QWebEngineProfile.defaultProfile().settings().setAttribute(
                QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False
            )
            QWebEngineProfile.defaultProfile().settings().setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True
            )
            QWebEngineProfile.defaultProfile().settings().setAttribute(
                QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True
            )
        except Exception:
            pass

        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.PluginsEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.WebGLEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.Accelerated2dCanvasEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.AutoLoadImages, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.AutoLoadIconsForPage, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.ScrollAnimatorEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled, True
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.DnsPrefetchEnabled, True
        )
        self.profile.downloadRequested.connect(self.on_download_requested)

        # Configure User-Agent: preserve native QtWebEngine string globally to match Sec-CH-UA
        # client hints (required for Google Account authentication), and compute clean header
        # exclusively forwarded to Microsoft Partner Center.
        default_ua = self.profile.httpUserAgent()
        clean_partner_ua = default_ua
        if "QtWebEngine/" in default_ua:
            import re
            clean_partner_ua = re.sub(r"\s*QtWebEngine/\S+", "", default_ua)
        if hasattr(self, "ad_block_interceptor") and self.ad_block_interceptor:
            self.ad_block_interceptor.partner_ua = clean_partner_ua.encode("utf-8")

        # Start local media streaming proxy for in-browser MP4 playback polyfill
        self.media_streamer = MediaStreamServer()
        self.media_streamer.start()

        # Defensively clear any stale Google authentication rejection cookies from prior blocked sessions
        try:
            cookie_db = os.path.join(self.log_dir, "web_profile", "Cookies")
            if os.path.isfile(cookie_db):
                import sqlite3
                _ccon = sqlite3.connect(cookie_db, timeout=2)
                try:
                    _ccon.execute("DELETE FROM cookies WHERE host_key LIKE '%google%' AND name IN ('__Host-GAPS', 'OTZ')")
                    _ccon.commit()
                finally:
                    _ccon.close()
        except Exception:
            pass

        polyfill_script = QWebEngineScript()
        polyfill_script.setSourceCode(self.media_streamer.get_polyfill_js())
        polyfill_script.setName("mp4_media_polyfill")
        polyfill_script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        polyfill_script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        self.profile.scripts().insert(polyfill_script)

        self.inject_scrollbar_style()
        self.inject_file_browser_style()
        self.inject_form_control_style()

        self.history_file = os.path.join(self.log_dir, "history.json")
        self.load_history()

        log_file = os.path.join(
            self.log_dir, f"{APP_NAME.lower().replace(' ', '_')}.log"
        )

        root_logger = logging.getLogger()
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)

        log_level = logging.WARNING if STORE_RELEASE else logging.DEBUG
        root_logger.setLevel(log_level)

        file_handler = logging.FileHandler(log_file, mode="w", encoding="utf-8")
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        )
        file_handler.setLevel(log_level)
        root_logger.addHandler(file_handler)

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
        root_logger.addHandler(console_handler)
        logger.info("Logging initialized.")

        self.setWindowTitle(APP_NAME)

        icon_png = resource_path(os.path.join("assets", "icons", "icon.png"))
        if os.path.exists(icon_png):
            self.setWindowIcon(QIcon(icon_png))

        download_path = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)
        self.last_export_dir = str(self.settings.value("last_download_dir", download_path))
        os.makedirs(self.last_export_dir, exist_ok=True)

        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(1000)
        # self.save_timer.timeout.connect(self.save_data) # Connect to actual save method

        self.setup_ui()
        # self.update_new_note_button()
        self.apply_dark_theme()
        self.load_bookmarks()

        # Instantiate the new AI Assistant Manager
        self.wai_manager: Any = None
        if ENABLE_AI and self.ai_enabled and WAIAssistantManager:
            self._init_wai_manager()

        if getattr(self, "saved_was_maximized", False) and not self.is_smoke_mode:
            self.showMaximized()
        self._is_initializing = False

    def apply_dark_theme(self):
        close_icon = resource_path(os.path.join("assets", "icons", "custom_close.png"))
        close_icon = close_icon.replace("\\", "/")
        cb_check_icon = resource_path(
            os.path.join("assets", "icons", "checkbox_check.png")
        ).replace("\\", "/")
        menu_check_icon = resource_path(
            os.path.join("assets", "icons", "menu_check.png")
        ).replace("\\", "/")
        menu_check_white_icon = resource_path(
            os.path.join("assets", "icons", "menu_check_white.png")
        ).replace("\\", "/")

        style_sheet = f"""
            QWidget {{
                background-color: #1e1e1e;
                color: #ffffff;
                font-family: "Segoe UI", "Arial", sans-serif;
                font-size: 14px;
            }}
            QPushButton {{
                background-color: #323232;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 6px;
                min-height: 20px;
            }}
            QPushButton:hover {{
                background-color: #424242;
                border: 1px solid #007AFF;
            }}
            QPushButton:checked {{
                background-color: #007AFF;
                border: 1px solid #007AFF;
            }}
            QPushButton:disabled {{
                background-color: #1e1e1e;
                color: #555;
                border: 1px solid #333;
            }}
            QRadioButton {{
                color: #ffffff;
                spacing: 8px;
                background-color: transparent;
            }}
            QRadioButton::indicator {{
                width: 16px;
                height: 16px;
                border-radius: 9px;
                border: 2px solid #71717a;
                background-color: #27272a;
            }}
            QRadioButton::indicator:hover {{
                border-color: #38bdf8;
                background-color: #3f3f46;
            }}
            QRadioButton::indicator:checked {{
                border: 2px solid #007AFF;
                background-color: qradialgradient(
                    cx: 0.5, cy: 0.5, radius: 0.45,
                    fx: 0.5, fy: 0.5,
                    stop: 0 #007AFF,
                    stop: 0.55 #007AFF,
                    stop: 0.65 #27272a,
                    stop: 1.0 #27272a
                );
            }}
            QRadioButton::indicator:checked:hover {{
                border-color: #38bdf8;
                background-color: qradialgradient(
                    cx: 0.5, cy: 0.5, radius: 0.45,
                    fx: 0.5, fy: 0.5,
                    stop: 0 #38bdf8,
                    stop: 0.55 #38bdf8,
                    stop: 0.65 #3f3f46,
                    stop: 1.0 #3f3f46
                );
            }}
            QRadioButton::indicator:disabled {{
                border-color: #444444;
                background-color: #1e1e1e;
            }}
            QCheckBox {{
                color: #ffffff;
                spacing: 8px;
                background-color: transparent;
            }}
            QCheckBox::indicator {{
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 2px solid #71717a;
                background-color: #27272a;
            }}
            QCheckBox::indicator:hover {{
                border-color: #38bdf8;
                background-color: #3f3f46;
            }}
            QCheckBox::indicator:checked {{
                border: 2px solid #007AFF;
                background-color: #007AFF;
                image: url({cb_check_icon});
            }}
            QCheckBox::indicator:checked:hover {{
                border-color: #38bdf8;
                background-color: #0284c7;
                image: url({cb_check_icon});
            }}
            QCheckBox::indicator:disabled {{
                border-color: #444444;
                background-color: #1e1e1e;
            }}
            QComboBox {{
                background-color: #323232;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 5px;
                min-height: 20px;
            }}
            QComboBox:hover {{
                border: 1px solid #007AFF;
            }}
            QComboBox QAbstractItemView {{
                background-color: #323232;
                background-color: #252525;
                border: 1px solid #555;
                selection-background-color: #444444;
                selection-color: #ffffff;
                outline: none;
                border-radius: 8px;
            }}
            QComboBox QAbstractItemView::item {{
                min-height: 25px;
            }}
            QComboBox QAbstractItemView::item:selected,
            QComboBox QAbstractItemView::item:hover {{
                background-color: #323232;
                background-color: #444444;
                border: 1px solid #007AFF;
                border-radius: 8px;
                color: #ffffff;
            }}
            QMenu {{
                background-color: #252525;
                border: 1px solid #454545;
                border-radius: 8px;
                padding: 4px;
                color: #ffffff;
            }}
            QMenu::item {{
                padding: 6px 12px;
                background-color: transparent;
                border-radius: 6px;
                color: #ffffff;
            }}
            QMenu::item:selected {{
                background-color: #007AFF;
                color: #ffffff;
                border-radius: 6px;
            }}
            QMenu::separator {{
                height: 1px;
                background: #3f3f46;
                margin: 4px 8px;
            }}
            QMenu::indicator {{
                width: 16px;
                height: 16px;
                left: 6px;
            }}
            QMenu::indicator:checked {{
                image: url({menu_check_icon});
            }}
            QMenu::indicator:checked:selected {{
                image: url({menu_check_white_icon});
            }}
            QColorDialog QPushButton {{
                min-width: 100px;
            }}
            QListWidget {{
                background-color: #252525;
                border: 1px solid #555;
                border-radius: 4px;
                font-family: "Segoe UI", "Arial", sans-serif;
                font-size: 13px;
            }}
            QListWidget::item {{
                padding: 4px;
                font-family: "Segoe UI", "Arial", sans-serif;
                font-size: 13px;
            }}
            QGroupBox {{
                border: 1px solid #1e1e1e;
                border-radius: 5px;
                margin-top: 10px;
                color: #ddd;
            }}
            QSlider {{
                min-height: 32px;
            }}
            QSlider::groove:horizontal {{
                border: 1px solid #555;
                height: 36px;
                background: #323232;
                margin: 0px;
                border-radius: 18px;
            }}
            QSlider::handle:horizontal {{
                background: #007AFF;
                border: 1px solid #007AFF;
                width: 36px;
                height: 36px;
                margin: 0px;
                border-radius: 18px;
            }}
            QPushButton#aboutButton {{
                background-color: transparent;
                border: none;
                padding: 4px 8px;
                color: #00BFFF;
            }}
            QPushButton#aboutButton:hover {{
                background-color: #444444;
                border: none;
                border-radius: 4px;
            }}
            QPushButton#aboutButton:pressed {{
                background-color: #333333;
                border: none;
            }}
            QToolTip {{
                border: none;
                background-color: black;
                color: white;
                border-radius: 4px;
                padding: 5px;
                padding: 1px;
            }}
            QTabWidget::pane {{
                border: 1px solid #555;
                background-color: #1e1e1e;
            }}
            QTabWidget > QStackedWidget {{
                background-color: #1e1e1e;
            }}
            QWebEngineView {{
                background-color: #1e1e1e;
            }}
            QTabBar::tab {{
                background: #1e1e1e;
                color: #888;
                padding: 8px 12px;
                border: 1px solid #555;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                margin-right: 2px;
                min-width: 60px;
                max-width: 220px;
            }}
            QTabBar::tab:selected {{
                background: #323232;
                color: #fff;
                border-bottom: 1px solid #323232; 
            }}
            QTabBar::tab:hover {{
                background: #252525;
            }}
            QTabBar::close-button {{
                image: url({close_icon});
                subcontrol-position: right;
                margin-right: 5px;
                padding: 2px;
                width: 12px;
                height: 12px;
                border-radius: 2px;
            }}
            QTabBar::close-button:hover {{
                background-color: #007AFF;
                border-radius: 2px;
            }}
            QScrollBar:vertical {{
                border: none;
                background: #1e1e1e;
                width: 12px;
                margin: 0px;
            }}
            QScrollBar::handle:vertical {{
                background: #333;
                min-height: 20px;
                border-radius: 6px;
                margin: 2px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: #007AFF;
            }}
            QScrollBar::add-line:vertical {{
                height: 0px;
            }}
            QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
            QScrollBar:horizontal {{
                border: none;
                background: #1e1e1e;
                height: 12px;
                margin: 0px;
            }}
            QScrollBar::handle:horizontal {{
                background: #333;
                min-width: 20px;
                border-radius: 6px;
                margin: 2px;
            }}
            QScrollBar::handle:horizontal:hover {{
                background: #007AFF;
            }}
            QScrollBar::add-line:horizontal {{
                width: 0px;
            }}
            QScrollBar::sub-line:horizontal {{
                width: 0px;
            }}
        """
        app = QApplication.instance()
        if app is not None and isinstance(app, QApplication):
            app.setStyleSheet(style_sheet)

    def inject_scrollbar_style(self):
        # Inject CSS for scrollbars into WebEngine pages
        js = """
            (function() {
                var css = `
                    ::-webkit-scrollbar { width: 12px; height: 12px; background-color: #1e1e1e; }
                    ::-webkit-scrollbar-track { background-color: #1e1e1e; }
                    ::-webkit-scrollbar-thumb { background-color: #333; border-radius: 6px; }
                    ::-webkit-scrollbar-thumb:hover { background-color: #007AFF; }
                    ::-webkit-scrollbar-corner { background-color: #1e1e1e; }
                `;
                var style = document.createElement('style');
                style.type = 'text/css';
                style.appendChild(document.createTextNode(css));
                (document.head || document.documentElement).appendChild(style);
            })();
        """
        script = QWebEngineScript()
        script.setName("scrollbar_style")
        script.setSourceCode(js)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(True)

        self.profile.scripts().insert(script)

    def inject_file_browser_style(self):
        # Configure WebEngine default fonts to match UI
        web_settings = self.profile.settings()
        web_settings.setFontFamily(
            QWebEngineSettings.FontFamily.StandardFont, "Segoe UI"
        )
        web_settings.setFontFamily(
            QWebEngineSettings.FontFamily.SansSerifFont, "Segoe UI"
        )
        web_settings.setFontFamily(QWebEngineSettings.FontFamily.FixedFont, "Segoe UI")

        stream_port = (
            self.media_streamer.port
            if hasattr(self, "media_streamer") and self.media_streamer
            else 28754
        )

        # Inject CSS into file:/// local directory listings so the file browser uses the exact same font and dark theme, removes 'Index of', custom upright vector icons, and renders full parent dir path
        js = """
            (function() {
                var isFile = (window.location.protocol === 'file:');
                if (isFile) {
                    var streamPort = __STREAM_PORT__;

                    function getParentPath() {
                        var p = decodeURIComponent(window.location.pathname);
                        p = p.replace(/\\/+$/, '');
                        var isWin = (navigator.platform && navigator.platform.indexOf('Win') !== -1) || /^[a-zA-Z]:/.test(p.replace(/^\\//, ''));
                        if (isWin) {
                            p = p.replace(/^\\//, '');
                        }
                        var lastSlash = p.lastIndexOf('/');
                        if (lastSlash === -1) {
                            return isWin ? p.replace(/\\//g, '\\\\') : p;
                        }
                        var parent = p.substring(0, lastSlash);
                        if (isWin) {
                            if (/^[a-zA-Z]:$/.test(parent)) {
                                parent += '\\\\';
                            } else {
                                parent = parent.replace(/\\//g, '\\\\');
                            }
                        } else {
                            if (!parent) parent = '/';
                        }
                        return parent;
                    }

                    function updateDirectoryListing() {
                        if (document.title && document.title.toLowerCase().startsWith('index of')) {
                            document.title = document.title.replace(/^Index of:?\\s*/i, '');
                        }
                        var h1 = document.querySelector('h1, #header');
                        if (h1 && h1.innerText && h1.innerText.toLowerCase().startsWith('index of')) {
                            h1.innerText = h1.innerText.replace(/^Index of:?\\s*/i, '');
                        }
                        var parentLink = document.getElementById('parentDirLink') || document.querySelector('a.up, #parentDirLinkBox a');
                        if (parentLink) {
                            var parentPath = getParentPath();
                            parentLink.innerText = parentPath;
                        }
                    }

                    updateDirectoryListing();
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', updateDirectoryListing);
                    }
                    setInterval(updateDirectoryListing, 100);

                    // Intercept media file clicks in directory listing to route directly to player
                    document.addEventListener('click', function(e) {
                        var a = e.target.closest('a');
                        if (!a || !a.href) return;
                        var href = a.href;
                        var lower = href.toLowerCase().split('?')[0].split('#')[0];
                        var mediaExts = ['.mp4', '.m4v', '.mov', '.mkv', '.avi', '.wmv', '.flv', '.ts', '.webm', '.m4a', '.mp3', '.wav', '.flac', '.ogg', '.aac', '.wma'];
                        if (mediaExts.some(function(ext) { return lower.endsWith(ext); })) {
                            e.preventDefault();
                            e.stopPropagation();
                            window.location.href = 'http://127.0.0.1:' + streamPort + '/player?url=' + encodeURIComponent(href);
                        }
                    }, true);
                    
                    var css = `
                        html, body, table, th, td, pre, a, span, div, h1, #header, #parentDirLinkBox {
                            font-family: "Segoe UI", "Arial", sans-serif !important;
                        }
                        body {
                            background-color: #1e1e1e !important;
                            color: #e0e0e0 !important;
                            font-size: 13px !important;
                        }
                        a {
                            color: #38bdf8 !important;
                            text-decoration: none !important;
                        }
                        a:hover {
                            color: #60a5fa !important;
                            text-decoration: underline !important;
                        }
                        a.dir {
                            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="%23fab301" stroke="%23d97706" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>') left center no-repeat !important;
                            padding-inline-start: 1.8em !important;
                            background-size: 16px 16px !important;
                        }
                        a.up, a.icon.up, #parentDirLink {
                            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%23fab301" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>') left center no-repeat !important;
                            padding-inline-start: 1.8em !important;
                            background-size: 16px 16px !important;
                            font-weight: 500 !important;
                        }
                        /* Generic File Fallback */
                        a.file {
                            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%2394a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>') left center no-repeat !important;
                            padding-inline-start: 1.8em !important;
                            background-size: 16px 16px !important;
                        }
                        /* Python files */
                        a.file[href*=".py" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%233b82f6"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23ffffff" text-anchor="middle">PY</text></svg>') !important;
                        }
                        /* HTML files */
                        a.file[href*=".html" i], a.file[href*=".htm" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%23f97316"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">&lt;/&gt;</text></svg>') !important;
                        }
                        /* CSS / SCSS files */
                        a.file[href*=".css" i], a.file[href*=".scss" i], a.file[href*=".sass" i], a.file[href*=".less" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%2306b6d4"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">#</text></svg>') !important;
                        }
                        /* JavaScript / TypeScript files */
                        a.file[href*=".js" i], a.file[href*=".mjs" i], a.file[href*=".cjs" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%23eab308"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23000000" text-anchor="middle">JS</text></svg>') !important;
                        }
                        a.file[href*=".ts" i], a.file[href*=".tsx" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%232563eb"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23ffffff" text-anchor="middle">TS</text></svg>') !important;
                        }
                        /* JSON / YAML / XML / Config files */
                        a.file[href*=".json" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%23f59e0b"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23000000" text-anchor="middle">{ }</text></svg>') !important;
                        }
                        a.file[href*=".yaml" i], a.file[href*=".yml" i], a.file[href*=".toml" i], a.file[href*=".ini" i], a.file[href*=".conf" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%23a855f7"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">CFG</text></svg>') !important;
                        }
                        a.file[href*=".xml" i], a.file[href*=".svg" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%2310b981"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">XML</text></svg>') !important;
                        }
                        /* CSV / Excel files */
                        a.file[href*=".csv" i], a.file[href*=".tsv" i], a.file[href*=".xlsx" i], a.file[href*=".xls" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%2310b981"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">CSV</text></svg>') !important;
                        }
                        /* Markdown & Text files */
                        a.file[href*=".md" i], a.file[href*=".markdown" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%236366f1"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23ffffff" text-anchor="middle">MD</text></svg>') !important;
                        }
                        a.file[href*=".txt" i], a.file[href*=".log" i], a.file[href*=".rst" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%2364748b"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="%23ffffff" text-anchor="middle">TXT</text></svg>') !important;
                        }
                        /* PDF & Documents */
                        a.file[href*=".pdf" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><rect width="22" height="22" x="1" y="1" rx="4" fill="%23ef4444"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="%23ffffff" text-anchor="middle">PDF</text></svg>') !important;
                        }
                        /* Image files */
                        a.file[href*=".png" i], a.file[href*=".jpg" i], a.file[href*=".jpeg" i], a.file[href*=".gif" i], a.file[href*=".webp" i], a.file[href*=".bmp" i], a.file[href*=".ico" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%23ec4899" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>') !important;
                        }
                        /* Video files */
                        a.file[href*=".mp4" i], a.file[href*=".mov" i], a.file[href*=".mkv" i], a.file[href*=".avi" i], a.file[href*=".wmv" i], a.file[href*=".webm" i], a.file[href*=".flv" i], a.file[href*=".ts" i], a.file[href*=".m4v" i] {
                            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%2322d3ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>') !important;
                        }
                        h1, #header {
                            color: #f3f4f6 !important;
                            font-size: 18px !important;
                            font-weight: 600 !important;
                            border-bottom: 1px solid #333 !important;
                            padding-bottom: 8px !important;
                        }
                        table {
                            color: #e0e0e0 !important;
                        }
                        th {
                            color: #9ca3af !important;
                            border-bottom: 1px solid #333 !important;
                        }
                        td {
                            border-bottom: 1px solid #262626 !important;
                            padding: 4px 8px !important;
                        }
                        tr:hover td {
                            background-color: #262626 !important;
                        }
                    `;
                    var style = document.createElement('style');
                    style.type = 'text/css';
                    style.appendChild(document.createTextNode(css));
                    (document.head || document.documentElement).appendChild(style);
                }
            })();
        """.replace("__STREAM_PORT__", str(stream_port))
        script = QWebEngineScript()
        script.setName("file_browser_style")
        script.setSourceCode(js)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(True)
        self.profile.scripts().insert(script)

    def inject_form_control_style(self):
        # Standard cross-browser HTML5 form controls accent styling
        js = """
            (function() {
                function applyFormControlFix() {
                    var css = `
                        input[type="radio"],
                        input[type="checkbox"] {
                            accent-color: #0078d4;
                        }
                    `;
                    var existing = document.getElementById('wheelhouser-form-control-fix');
                    var target = document.head || document.documentElement;
                    if (!existing && target) {
                        var style = document.createElement('style');
                        style.id = 'wheelhouser-form-control-fix';
                        style.type = 'text/css';
                        style.appendChild(document.createTextNode(css));
                        target.appendChild(style);
                    }
                }

                applyFormControlFix();
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', applyFormControlFix);
                }
            })();
        """
        script = QWebEngineScript()
        script.setName("form_control_style")
        script.setSourceCode(js)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(True)
        self.profile.scripts().insert(script)

    def setup_ui(self):
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.main_layout = QBoxLayout(QBoxLayout.Direction.LeftToRight, self.main_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        self.sidebar_container = QWidget()
        self.sidebar_layout = QBoxLayout(QBoxLayout.Direction.TopToBottom, self.sidebar_container)

        self.sidebar_label = QLabel("Bookmarks")
        self.bookmark_list = QListWidget()
        self.bookmark_list.setIconSize(QSize(16, 16))
        self.bookmark_list.itemClicked.connect(self.on_bookmark_clicked)
        self.bookmark_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.bookmark_list.customContextMenuRequested.connect(
            self.show_bookmark_context_menu
        )
        self.bookmark_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.bookmark_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.bookmark_list.model().rowsMoved.connect(
            lambda *args: self.save_bookmarks()
        )

        self.btn_add_bookmark = QPushButton("Add Bookmark")
        self.btn_add_bookmark.setToolTip("Add the current page to bookmarks")
        self.btn_add_bookmark.clicked.connect(self.add_bookmark)

        self.btn_del_bookmark = QPushButton("Delete Bookmark")
        self.btn_del_bookmark.setToolTip("Remove the selected bookmark")
        self.btn_del_bookmark.clicked.connect(self.delete_bookmark)

        # Move Up & Move Down Reorder Buttons
        bm_reorder_layout = QHBoxLayout()
        bm_reorder_layout.setSpacing(4)
        self.btn_move_bm_up = QPushButton("▲ Up")
        self.btn_move_bm_up.setToolTip(
            f"Move selected bookmark up in rank ({ALT_MOD_NAME}+Up)"
        )
        self.btn_move_bm_up.clicked.connect(self.move_bookmark_up)
        self.btn_move_bm_down = QPushButton("▼ Down")
        self.btn_move_bm_down.setToolTip(
            f"Move selected bookmark down in rank ({ALT_MOD_NAME}+Down)"
        )
        self.btn_move_bm_down.clicked.connect(self.move_bookmark_down)
        bm_reorder_layout.addWidget(self.btn_move_bm_up)
        bm_reorder_layout.addWidget(self.btn_move_bm_down)

        self.btn_set_homepage = QPushButton("Set Homepage")
        self.btn_set_homepage.setToolTip("Set the current page as the homepage")
        self.btn_set_homepage.clicked.connect(self.set_homepage)

        self.sidebar_layout.addWidget(self.sidebar_label)
        self.sidebar_layout.addWidget(self.bookmark_list)
        self.sidebar_layout.addWidget(self.btn_add_bookmark)
        self.sidebar_layout.addWidget(self.btn_del_bookmark)
        self.sidebar_layout.addLayout(bm_reorder_layout)
        self.sidebar_layout.addWidget(self.btn_set_homepage)

        self.btn_toggle_sidebar = QPushButton(
            "<" if not self.sidebar_minimized else ">"
        )
        self.btn_toggle_sidebar.setFixedWidth(16)
        self.btn_toggle_sidebar.setToolTip("Minimize/Expand Bookmarks")
        self.btn_toggle_sidebar.clicked.connect(self.toggle_sidebar)
        self.btn_toggle_sidebar.setStyleSheet("""
            QPushButton {
                background-color: #252525;
                color: #888;
                border-left: 1px solid #444;
                border-right: 1px solid #444;
                font-size: 10px;
                padding: 0px;
                min-height: 80px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #333;
                color: #007AFF;
            }
        """)

        self.content_container = QWidget()
        self.content_layout = QVBoxLayout(self.content_container)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(0)

        self.toolbar_widget = QWidget()
        self.toolbar_layout = QGridLayout(self.toolbar_widget)
        self.toolbar_layout.setContentsMargins(5, 5, 5, 5)

        self.icons_path = ICONS_PATH
        icons_path = self.icons_path
        tool_icon_size = QSize(28, 28)
        btn_square_size = 32

        transparent_btn_style = """
            QPushButton {
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 1px;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
            QPushButton:pressed {
                background-color: #007AFF;
            }
            QPushButton:checked {
                background-color: #007AFF;
                border: 1px solid #007AFF;
            }
        """

        # --- Generic Toolbar Buttons ---
        self.btn_back = QPushButton("◀")
        self.btn_back.setFixedSize(btn_square_size, btn_square_size)
        self.btn_back.setStyleSheet(transparent_btn_style)
        self.btn_back.setToolTip("Back")
        back_icon = os.path.join(icons_path, "back.png")
        if os.path.exists(back_icon):
            self.btn_back.setIcon(QIcon(back_icon))
            self.btn_back.setText("")
        self.btn_back.setIconSize(tool_icon_size)
        self.btn_back.clicked.connect(self.go_back)

        self.btn_forward = QPushButton("▶")
        self.btn_forward.setFixedSize(btn_square_size, btn_square_size)
        self.btn_forward.setStyleSheet(transparent_btn_style)
        self.btn_forward.setToolTip("Forward")
        forward_icon = os.path.join(icons_path, "forward.png")
        if os.path.exists(forward_icon):
            self.btn_forward.setIcon(QIcon(forward_icon))
            self.btn_forward.setText("")
        self.btn_forward.setIconSize(tool_icon_size)
        self.btn_forward.clicked.connect(self.go_forward)

        self.tab_periodic_timers = {}

        self.btn_reload = QPushButton("↻")
        self.btn_reload.setFixedSize(btn_square_size, btn_square_size)
        self.btn_reload.setStyleSheet(transparent_btn_style)
        reload_shortcut_text = "⌘R, F5" if IS_MAC else "F5, Ctrl+R"
        self.btn_reload.setToolTip(f"Reload ({reload_shortcut_text}) | Right-click for options")
        reload_icon = os.path.join(icons_path, "reload.png")
        if os.path.exists(reload_icon):
            self.btn_reload.setIcon(QIcon(reload_icon))
            self.btn_reload.setText("")
        self.btn_reload.setIconSize(tool_icon_size)
        self.btn_reload.clicked.connect(lambda: self.reload_page())
        self.btn_reload.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.btn_reload.customContextMenuRequested.connect(self.show_reload_context_menu)

        # Browsing Mode Toggle Button (Web vs File)
        self.browsing_mode = "web"
        self.btn_mode = QPushButton("🌐")
        self.btn_mode.setFixedSize(btn_square_size, btn_square_size)
        self.btn_mode.setStyleSheet(transparent_btn_style)
        self.btn_mode.setIconSize(tool_icon_size)
        web_icon = os.path.join(icons_path, "web.png")
        if os.path.exists(web_icon):
            self.btn_mode.setIcon(QIcon(web_icon))
            self.btn_mode.setText("")
        self.btn_mode.setToolTip("Mode: Web Browsing (Click to switch to Files)")
        self.btn_mode.clicked.connect(self.toggle_browsing_mode)

        self.btn_file = QPushButton("☰")
        self.btn_file.setFixedSize(btn_square_size, btn_square_size)
        self.btn_file.setStyleSheet(transparent_btn_style)
        self.btn_file.setToolTip("Preferences and Settings")
        file_icon = os.path.join(icons_path, "hamburger.png")
        if os.path.exists(file_icon):
            self.btn_file.setIcon(QIcon(file_icon))
            self.btn_file.setText("")
        self.btn_file.setIconSize(tool_icon_size)
        self.btn_file.clicked.connect(self.show_file_menu)

        self.btn_wai = QPushButton("✨")
        self.btn_wai.setFixedSize(btn_square_size, btn_square_size)
        self.btn_wai.setStyleSheet(transparent_btn_style)
        self.btn_wai.setToolTip("WAI Assistant (AI)")
        wai_icon = os.path.join(icons_path, "ai.png")
        if os.path.exists(wai_icon):
            self.btn_wai.setIcon(QIcon(wai_icon))
            self.btn_wai.setText("")
        self.btn_wai.setIconSize(tool_icon_size)
        # Connect to the WAI Manager instead of the local class
        self.btn_wai.clicked.connect(self.open_wai_dialog)
        if ENABLE_AI and self.ai_enabled:
            self.btn_wai.show()
            self.btn_wai.setEnabled(True)
        else:
            self.btn_wai.hide()
            self.btn_wai.setEnabled(False)

        self.btn_about = QPushButton("About")
        self.btn_about.setObjectName("aboutButton")
        self.btn_about.setToolTip("About this application")
        self.btn_about.clicked.connect(self.show_about_dialog)

        # --- URL Bar ---
        self.url_bar = QLineEdit()
        self.url_bar.setObjectName("urlBar")
        self.url_bar.setToolTip("Enter a URL or search query")
        self.url_bar.setPlaceholderText("Search or enter address")
        self.url_bar.setStyleSheet("""
            QLineEdit {
                background-color: #252525;
                border: 1px solid #555;
                border-radius: 15px;
                padding: 4px 12px;
                color: #ddd;
                font-size: 14px;
                min-height: 20px;
            }
            QLineEdit:focus {
                border: 1px solid #007AFF;
            }
        """)
        self.url_bar.returnPressed.connect(self.navigate_to_url)

        # Standalone Bookmark Button (spacious, larger, next to URL bar)
        self.btn_bookmark = QPushButton()
        self.btn_bookmark.setFixedSize(btn_square_size, btn_square_size)
        self.btn_bookmark.setStyleSheet(transparent_btn_style)
        self.btn_bookmark.setIconSize(QSize(22, 22))
        self.btn_bookmark.setToolTip("Bookmark this page")
        bookmark_blue_path = os.path.join(self.icons_path, "bookmark_blue.png")
        if os.path.exists(bookmark_blue_path):
            self.btn_bookmark.setIcon(QIcon(bookmark_blue_path))
        elif os.path.exists(os.path.join(self.icons_path, "bookmark.png")):
            self.btn_bookmark.setIcon(
                QIcon(os.path.join(self.icons_path, "bookmark.png"))
            )
        self.btn_bookmark.clicked.connect(self.add_bookmark)

        # Fullscreen Shortcuts & Action (bind cleanly without ambiguous duplicates)
        self.action_fullscreen = QAction(self)
        if IS_MAC:
            self.action_fullscreen.setShortcut(QKeySequence("Ctrl+Meta+F"))
        else:
            self.action_fullscreen.setShortcut(QKeySequence(Qt.Key.Key_F11))
        self.action_fullscreen.triggered.connect(self.toggle_fullscreen)
        self.addAction(self.action_fullscreen)

        # Esc to exit fullscreen
        self.shortcut_escape_fullscreen = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        self.shortcut_escape_fullscreen.setContext(Qt.ShortcutContext.ApplicationShortcut)
        self.shortcut_escape_fullscreen.activated.connect(self.exit_fullscreen)

        # Keyboard Zoom Shortcuts (Cmd on macOS, Ctrl on Windows/Linux)
        self.shortcuts_zoom = []
        if IS_MAC:
            zoom_in_keys = ["Meta++", "Meta+=", "Ctrl++", "Ctrl+="]
            zoom_out_keys = ["Meta+-", "Meta+_", "Ctrl+-", "Ctrl+_"]
            zoom_reset_keys = ["Meta+0", "Ctrl+0"]
        else:
            zoom_in_keys = ["Ctrl++", "Ctrl+="]
            zoom_out_keys = ["Ctrl+-", "Ctrl+_"]
            zoom_reset_keys = ["Ctrl+0"]

        for k in zoom_in_keys:
            sc = QShortcut(QKeySequence(k), self)
            sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc.activated.connect(self.zoom_in)
            self.shortcuts_zoom.append(sc)

        for k in zoom_out_keys:
            sc = QShortcut(QKeySequence(k), self)
            sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc.activated.connect(self.zoom_out)
            self.shortcuts_zoom.append(sc)

        for k in zoom_reset_keys:
            sc = QShortcut(QKeySequence(k), self)
            sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc.activated.connect(self.reset_zoom)
            self.shortcuts_zoom.append(sc)

        # Keyboard Reload / Refresh Shortcuts (Cross-platform parity)
        self.shortcuts_reload = []
        if IS_MAC:
            reload_keys = ["Meta+R", "Ctrl+R", "F5"]
            hard_reload_keys = [
                "Meta+Shift+R",
                "Ctrl+Shift+R",
                "Meta+Alt+R",
                "Shift+F5",
                "Ctrl+F5",
            ]
        else:
            reload_keys = ["F5", "Ctrl+R"]
            hard_reload_keys = ["Ctrl+F5", "Ctrl+Shift+R", "Shift+F5"]

        try:
            sc_std = QShortcut(QKeySequence(QKeySequence.StandardKey.Refresh), self)
            sc_std.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc_std.activated.connect(self.reload_page)
            self.shortcuts_reload.append(sc_std)
        except Exception:
            pass

        for k in reload_keys:
            sc = QShortcut(QKeySequence(k), self)
            sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc.activated.connect(self.reload_page)
            self.shortcuts_reload.append(sc)

        for k in hard_reload_keys:
            sc = QShortcut(QKeySequence(k), self)
            sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc.activated.connect(self.reload_page_bypass_cache)
            self.shortcuts_reload.append(sc)

        # Multimedia Refresh key shortcut
        if hasattr(Qt.Key, "Key_Refresh"):
            sc_refresh = QShortcut(QKeySequence(Qt.Key.Key_Refresh), self)
            sc_refresh.setContext(Qt.ShortcutContext.ApplicationShortcut)
            sc_refresh.activated.connect(self.reload_page)
            self.shortcuts_reload.append(sc_refresh)

        # --- Central Content Area ---
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.tabs.tabBarClicked.connect(self.on_tab_bar_clicked)
        self.tabs.setMovable(False)
        self.tabs.tabBar().setElideMode(Qt.TextElideMode.ElideRight)
        self.tabs.tabBar().setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabs.tabBar().customContextMenuRequested.connect(self.show_tab_context_menu)

        # Page Load Progress Bar
        self.page_progress_bar = QProgressBar()
        self.page_progress_bar.setFixedHeight(3)
        self.page_progress_bar.setTextVisible(False)
        self.page_progress_bar.setRange(0, 100)
        self.page_progress_bar.setValue(0)
        self.page_progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                background-color: transparent;
                height: 3px;
            }
            QProgressBar::chunk {
                background-color: #007AFF;
            }
        """)
        self.page_progress_bar.hide()

        # Add dummy "+" tab
        self.tabs.addTab(QWidget(), "+")
        self.tabs.setTabToolTip(0, "New Tab")
        self.tabs.tabBar().setTabButton(0, QTabBar.ButtonPosition.RightSide, None)

        self.restore_session()

        # Open URLs passed via CLI positional arguments upon startup
        cli_urls = [
            arg for arg in sys.argv[1:]
            if not arg.startswith("-") and not arg.endswith(".py")
            and (arg.startswith(("http://", "https://", "file://", "about:")) or ("." in arg and "/" not in arg[:2]))
        ]
        for url_arg in cli_urls:
            self.add_new_tab(QUrl(url_arg), set_current=True)

        self.content_layout.addWidget(self.toolbar_widget)
        self.content_layout.addWidget(self.page_progress_bar)
        self.content_layout.addWidget(self.tabs)

        self.main_layout.addWidget(self.sidebar_container)
        self.main_layout.addWidget(self.btn_toggle_sidebar)
        self.main_layout.addWidget(self.content_container)

        self.current_landscape = None
        self.update_adaptive_layout()

        self._pending_update_version = None
        self._pending_update_url = None
        self._pending_update_notes = None
        self.bg_update_thread = None
        QTimer.singleShot(1000, self.start_update_check)
        self.update_check_timer = QTimer(self)
        self.update_check_timer.setInterval(4 * 60 * 60 * 1000)
        self.update_check_timer.timeout.connect(self.start_update_check)
        self.update_check_timer.start()

    def start_update_check(self):
        if (
            os.environ.get("QT_QPA_PLATFORM") == "offscreen"
            or "--smoke-test" in sys.argv
            or "--test-init" in sys.argv
        ):
            return
        if self.bg_update_thread and self.bg_update_thread.isRunning():
            return
        self.bg_update_thread = UpdateCheckThread(APP_VERSION)
        self.bg_update_thread.update_available.connect(
            self.on_background_update_available
        )
        self.bg_update_thread.error.connect(self.on_background_update_error)
        self.bg_update_thread.finished.connect(self.bg_update_thread.deleteLater)
        self.bg_update_thread.start()

    def on_background_update_available(self, latest_version, target_url, release_notes):
        self._pending_update_version = latest_version
        self._pending_update_url = target_url
        self._pending_update_notes = release_notes
        self.btn_about.setStyleSheet("""
            QPushButton#aboutButton, QPushButton {
                background-color: rgba(220, 38, 38, 140);
                border: 1px solid #ef4444;
                border-radius: 4px;
                padding: 4px 6px;
                color: #ffffff;
                font-weight: bold;
            }
            QPushButton#aboutButton:hover, QPushButton:hover {
                background-color: rgba(220, 38, 38, 220);
                border: 1px solid #f87171;
            }
            QPushButton#aboutButton:pressed, QPushButton:pressed {
                background-color: rgba(185, 28, 28, 255);
            }
        """)
        if sys.platform == "win32":
            tip_text = f"Version {latest_version} is available in Microsoft Store! Click for details."
        elif sys.platform == "darwin":
            tip_text = (
                f"Version {latest_version} is available for macOS! Click for details."
            )
        else:
            tip_text = f"Version {latest_version} is available! Update with: sudo dnf upgrade web-browser"
        self.btn_about.setToolTip(tip_text)

    def on_background_update_error(self, err):
        logger.warning(f"Background update check failed: {err}")

    def on_tab_bar_clicked(self, index):
        if index == self.tabs.count() - 1:
            self.add_new_tab()

    def save_cached_icon(self, host, qicon):
        if not host or not qicon or qicon.isNull():
            return
        pixmap = qicon.pixmap(32, 32)
        if not pixmap.isNull():
            safe_host = "".join(c for c in host if c.isalnum() or c in ".-_")
            path = os.path.join(self.favicon_dir, f"{safe_host}.png")
            try:
                pixmap.save(path, "PNG")
            except OSError as e:
                logger.debug(f"Failed to save cached icon for {host}: {e}")

    def get_cached_icon(self, host):
        if not host:
            return QIcon()
        safe_host = "".join(c for c in host if c.isalnum() or c in ".-_")
        path = os.path.join(self.favicon_dir, f"{safe_host}.png")
        if os.path.exists(path):
            return QIcon(path)
        return QIcon()

    def update_tab_icon(self, browser, icon=None):
        idx = self.tabs.indexOf(browser)
        if idx == -1:
            return

        qurl = browser.url()
        if not qurl or qurl.isEmpty() or qurl.toString() == "about:blank":
            pending = getattr(browser, "_pending_url", None)
            if pending:
                qurl = pending

        url_str = qurl.toString() if qurl else ""
        if url_str.startswith("http://127.0.0.1:") and "/player" in url_str:
            from urllib.parse import parse_qs, unquote, urlparse

            query = parse_qs(urlparse(url_str).query)
            target = query.get("url", [""])[0]
            if target:
                url_str = unquote(target)
                qurl = QUrl(url_str)

        # 1. Local File or Directory
        if url_str.startswith("file://") or (qurl and qurl.isLocalFile()):
            local_path = qurl.toLocalFile() if qurl else ""
            if not local_path and url_str.startswith("file:///"):
                local_path = url_str.replace("file:///", "")
                if (
                    IS_WINDOWS
                    and len(local_path) >= 2
                    and local_path[0] == "/"
                    and local_path[2] == ":"
                ):
                    local_path = local_path.lstrip("/")

            # Check if directory or file
            is_dir = False
            if local_path and os.path.exists(local_path):
                is_dir = os.path.isdir(local_path)
            elif url_str.endswith("/") or (
                local_path and not os.path.splitext(local_path)[1]
            ):
                is_dir = True

            if is_dir:
                folder_icon_path = os.path.join(self.icons_path, "folder.png")
                if os.path.exists(folder_icon_path):
                    self.tabs.setTabIcon(idx, QIcon(folder_icon_path))
            else:
                # Specific File: Render matching file extension favicon (.py, .html, .css, .csv, .json, etc.)
                ext_icon = get_file_extension_qicon(local_path or url_str)
                if not ext_icon.isNull():
                    self.tabs.setTabIcon(idx, ext_icon)
                else:
                    file_icon_path = os.path.join(self.icons_path, "file_mode.png")
                    if os.path.exists(file_icon_path):
                        self.tabs.setTabIcon(idx, QIcon(file_icon_path))
            return

        # 2. Explicit provided non-null icon
        if icon and not icon.isNull():
            self.tabs.setTabIcon(idx, icon)
            if qurl and qurl.host():
                self.save_cached_icon(qurl.host(), icon)
                # Update matching bookmark icons in the sidebar in real time
                for i in range(self.bookmark_list.count()):
                    bm_item = self.bookmark_list.item(i)
                    bm_url = bm_item.data(Qt.ItemDataRole.UserRole)
                    if bm_url and QUrl(bm_url).host() == qurl.host():
                        bm_item.setIcon(icon)
            return

        # 3. WebEngineView's current icon
        browser_icon = browser.icon()
        if browser_icon and not browser_icon.isNull():
            self.tabs.setTabIcon(idx, browser_icon)
            if qurl and qurl.host():
                self.save_cached_icon(qurl.host(), browser_icon)
            return

        # 4. Cached favicon for domain/host
        if qurl and qurl.host():
            cached_icon = self.get_cached_icon(qurl.host())
            if not cached_icon.isNull():
                self.tabs.setTabIcon(idx, cached_icon)
                return

        # 5. Default Web icon for web pages
        if url_str.startswith(("http://", "https://")):
            web_icon_path = os.path.join(self.icons_path, "web.png")
            if os.path.exists(web_icon_path):
                self.tabs.setTabIcon(idx, QIcon(web_icon_path))
            else:
                self.tabs.setTabIcon(idx, QIcon())
        else:
            self.tabs.setTabIcon(idx, QIcon())

    def on_browser_url_changed(self, browser, qurl):
        self.update_url_bar(qurl, browser)
        self.update_tab_icon(browser)

    def on_browser_icon_changed(self, browser, icon):
        self.update_tab_icon(browser, icon)

    def add_new_tab(
        self,
        qurl=None,
        label="New Tab",
        zoom_factor=1.0,
        icon=None,
        lazy_load=False,
        set_current=True,
    ):
        if qurl is None:
            homepage = str(self.settings.value("homepage", DEFAULT_HOMEPAGE))
            qurl = QUrl(homepage)
        elif isinstance(qurl, str):
            qurl = QUrl(qurl)

        # Route direct local media URLs to streaming player
        if hasattr(self, "media_streamer") and self.media_streamer:
            url_str = qurl.toString()
            is_local = (
                qurl.isLocalFile()
                or url_str.startswith("file://")
                or url_str.startswith("/")
                or (IS_WINDOWS and len(url_str) >= 2 and url_str[1] == ":")
            )
            if is_local:
                lower = url_str.lower().split("?")[0].split("#")[0]
                media_exts = (
                    ".mp4",
                    ".m4v",
                    ".mov",
                    ".mkv",
                    ".avi",
                    ".wmv",
                    ".flv",
                    ".ts",
                    ".webm",
                    ".m4a",
                    ".mp3",
                    ".wav",
                    ".flac",
                    ".ogg",
                    ".aac",
                    ".wma",
                )
                if any(
                    lower.endswith(ext) for ext in media_exts
                ) and not url_str.startswith(
                    f"http://127.0.0.1:{self.media_streamer.port}/"
                ):
                    from urllib.parse import quote_plus

                    qurl = QUrl(
                        f"http://127.0.0.1:{self.media_streamer.port}/player?url={quote_plus(url_str)}"
                    )

        browser = BrowserView(self)
        page = WebEnginePage(self.profile, browser, main_window=self)
        browser.setPage(page)

        # 0.1.26 - Update the drop down menu from "Save Image" to "Save image as".
        action = page.action(QWebEnginePage.WebAction.DownloadImageToDisk)
        if action:
            action.setText("Save image as...")

        # Bind web actions for Reload and ReloadAndBypassCache to ensure Chromium
        # recognizes F5, Refresh, and hard-reload shortcuts directly within the web view
        act_reload = page.action(QWebEnginePage.WebAction.Reload)
        if act_reload:
            reload_seqs = [QKeySequence(Qt.Key.Key_F5), QKeySequence("Ctrl+R")]
            if hasattr(Qt.Key, "Key_Refresh"):
                reload_seqs.append(QKeySequence(Qt.Key.Key_Refresh))
            if IS_MAC:
                reload_seqs.extend([QKeySequence("Meta+R"), QKeySequence(Qt.Key.Key_F5)])
            act_reload.setShortcuts(reload_seqs)

        act_hard_reload = page.action(QWebEnginePage.WebAction.ReloadAndBypassCache)
        if act_hard_reload:
            hard_seqs = [
                QKeySequence("Ctrl+F5"),
                QKeySequence("Ctrl+Shift+R"),
                QKeySequence("Shift+F5"),
            ]
            if IS_MAC:
                hard_seqs.extend([
                    QKeySequence("Meta+Shift+R"),
                    QKeySequence("Meta+Alt+R"),
                ])
            act_hard_reload.setShortcuts(hard_seqs)

        browser.setZoomFactor(zoom_factor)
        browser.installEventFilter(self)

        if lazy_load:
            browser._pending_url = qurl
        else:
            browser._pending_url = None
            browser.setUrl(qurl)

        # Insert before dummy tab
        if label and label.lower().startswith("index of"):
            import re

            label = re.sub(r"^index of:?\s*", "", label, flags=re.IGNORECASE).strip()
            if not label and qurl:
                p = qurl.toLocalFile() or qurl.path()
                label = os.path.basename(p.rstrip("/\\")) or p

        i = self.tabs.insertTab(self.tabs.count() - 1, browser, label)
        self.update_tab_icon(browser, icon)

        if set_current:
            self.tabs.setCurrentIndex(i)

        browser.urlChanged.connect(
            lambda qurl, browser=browser: self.on_browser_url_changed(browser, qurl)
        )
        browser.titleChanged.connect(
            lambda title, browser=browser: self.on_tab_title_changed(browser, title)
        )
        browser.iconChanged.connect(
            lambda ic, browser=browser: self.on_browser_icon_changed(browser, ic)
        )
        browser.loadStarted.connect(
            lambda browser=browser: self.on_load_started(browser)
        )
        browser.loadProgress.connect(
            lambda p, browser=browser: self.on_load_progress(browser, p)
        )
        browser.loadFinished.connect(
            lambda ok, browser=browser: self.on_load_finished(browser, ok)
        )

        self.tabs.tabBar().setTabButton(self.tabs.count() - 1, QTabBar.ButtonPosition.RightSide, None)
        return browser

    def on_tab_title_changed(self, browser, title):
        idx = self.tabs.indexOf(browser)
        if idx != -1:
            clean_title = title or "New Tab"
            if clean_title.lower().startswith("index of"):
                import re

                clean_title = re.sub(
                    r"^index of:?\s*", "", clean_title, flags=re.IGNORECASE
                ).strip()
                if not clean_title and browser.url().isValid():
                    p = browser.url().toLocalFile() or browser.url().path()
                    clean_title = os.path.basename(p.rstrip("/\\")) or p
            clean_name = clean_title or "New Tab"
            self.tabs.setTabText(idx, clean_name)
            interval = self.get_tab_periodic_refresh(browser)
            if interval > 0:
                unit = f"{interval}s" if interval < 60 else f"{interval // 60}m"
                self.tabs.setTabToolTip(idx, f"{clean_name} [Periodic Refresh: {unit}]")
            else:
                self.tabs.setTabToolTip(idx, clean_name)
            self.save_session()

    def close_tab(self, index):
        if index == self.tabs.count() - 1:
            return
        if self.tabs.count() > 2:
            if index == self.tabs.count() - 2 and index == self.tabs.currentIndex():
                self.tabs.setCurrentIndex(index - 1)
            widget = self.tabs.widget(index)
            if widget:
                self.cleanup_tab_periodic_refresh(widget)
            self.tabs.removeTab(index)
            if widget and isinstance(widget, QWebEngineView):
                widget.stop()
                page = widget.page()
                widget.setPage(None)  # type: ignore
                if page:
                    page.deleteLater()
                widget.deleteLater()
            self.tabs.tabBar().setTabButton(
                self.tabs.count() - 1, QTabBar.ButtonPosition.RightSide, None
            )
            self.save_session()

    def current_tab_changed(self, index):
        if getattr(self, "is_closing", False) or getattr(self, "is_restoring", False):
            return
        if index != -1:
            browser = self.tabs.widget(index)
            if browser and isinstance(browser, BrowserView):
                pending = getattr(browser, "_pending_url", None)
                if pending:
                    browser._pending_url = None
                    browser.setUrl(pending)
                    self.url_bar.setText(pending.toString())
                else:
                    self.url_bar.setText(browser.url().toString())
            else:
                self.url_bar.clear()
            self.update_bookmark_button_state()
            self.save_session()

    def restore_session(self):
        self.is_restoring = True
        data = str(self.settings.value("session", "[]"))
        try:
            session_data = json.loads(data)
            if not session_data:
                self.add_new_tab(set_current=True)
                self.is_restoring = False
                return

            raw_idx = self.settings.value("session_active_index", 0, type=int)
            active_index = int(raw_idx) if isinstance(raw_idx, (int, str)) else 0
            if active_index < 0 or active_index >= len(session_data):
                active_index = 0

            # Block signals on tabs during batch restoration to prevent cascading currentChanged events
            self.tabs.blockSignals(True)
            for idx, item in enumerate(session_data):
                is_active = idx == active_index
                if isinstance(item, str):
                    url_str = item.strip()
                    if not url_str or url_str == "about:blank":
                        url_str = str(self.settings.value(
                            "homepage", DEFAULT_HOMEPAGE
                        ))
                    qurl = QUrl(url_str)
                    cached_icon = self.get_cached_icon(qurl.host())
                    self.add_new_tab(
                        qurl,
                        icon=cached_icon,
                        lazy_load=(not is_active),
                        set_current=False,
                    )
                elif isinstance(item, dict):
                    url_str = item.get("url", "").strip()
                    if not url_str or url_str == "about:blank":
                        url_str = str(self.settings.value(
                            "homepage", DEFAULT_HOMEPAGE
                        ))
                    url = QUrl(url_str)
                    title = item.get("title", "New Tab") or "New Tab"
                    zoom = item.get("zoom", 1.0)
                    cached_icon = self.get_cached_icon(url.host())
                    self.add_new_tab(
                        url,
                        label=title,
                        zoom_factor=zoom,
                        icon=cached_icon,
                        lazy_load=(not is_active),
                        set_current=False,
                    )

            self.tabs.blockSignals(False)
            self.is_restoring = False

            if 0 <= active_index < self.tabs.count() - 1:
                self.tabs.setCurrentIndex(active_index)
            elif self.tabs.count() > 1:
                self.tabs.setCurrentIndex(0)

            # Trigger current_tab_changed for the active tab once
            self.current_tab_changed(self.tabs.currentIndex())

        except (json.JSONDecodeError, TypeError, KeyError, OSError) as e:
            logger.error(f"Failed to restore session: {e}")
            self.is_restoring = False
            if self.tabs.count() <= 1:
                self.add_new_tab(set_current=True)

    def load_history(self):
        self.history = []
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    self.history = json.load(f)
            except (json.JSONDecodeError, OSError) as e:
                logger.debug(f"Failed to load history: {e}")

    def save_history(self):
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.history, f)
        except (TypeError, OSError) as e:
            logger.debug(f"Failed to save history: {e}")

    def log_visit(self, browser):
        url = browser.url().toString()
        title = browser.title()
        if not title:
            title = url
        self.add_to_history(title, url)

    def add_to_history(self, title, url):
        if not url or url == "about:blank":
            return
        # Simple duplicate check (last item)
        if self.history and self.history[-1]["url"] == url:
            return
        self.history.append({"title": title, "url": url})
        # Limit history size
        if len(self.history) > 1000:
            self.history = self.history[-1000:]
        self.save_history()

    def save_session(self):
        if getattr(self, "is_restoring", False):
            return
        session_data = []
        for i in range(self.tabs.count() - 1):
            widget = self.tabs.widget(i)
            if isinstance(widget, QWebEngineView):
                title = self.tabs.tabText(i)
                pending = getattr(widget, "_pending_url", None)
                url_str = pending.toString() if pending else widget.url().toString()
                if url_str and url_str != "about:blank":
                    session_data.append(
                        {
                            "url": url_str,
                            "title": title if title and title != "New Tab" else "",
                            "zoom": widget.zoomFactor(),
                        }
                    )
        if session_data:
            self.settings.setValue("session", json.dumps(session_data))
            current_idx = self.tabs.currentIndex()
            if current_idx >= self.tabs.count() - 1:
                current_idx = max(0, self.tabs.count() - 2)
            self.settings.setValue("session_active_index", current_idx)
            self.settings.sync()

    def on_load_started(self, browser):
        if browser == self.tabs.currentWidget():
            self.page_progress_bar.setValue(10)
            self.page_progress_bar.show()
        self.update_tab_icon(browser)

    def on_load_progress(self, browser, percent):
        if browser == self.tabs.currentWidget():
            self.page_progress_bar.setValue(percent)
            if percent >= 100:
                QTimer.singleShot(250, self.page_progress_bar.hide)
            else:
                self.page_progress_bar.show()

    def on_load_finished(self, browser, ok):
        if browser == self.tabs.currentWidget():
            self.page_progress_bar.setValue(100)
            QTimer.singleShot(250, self.page_progress_bar.hide)
        self.update_tab_icon(browser)
        self.log_visit(browser)
        if ok and not getattr(self, "is_restoring", False):
            self.save_session()

    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return

        if self.browsing_mode == "file":
            clean_text = text
            if clean_text == "~" or clean_text.startswith(("~/", "~\\")):
                clean_text = os.path.expanduser(clean_text)

            if not clean_text.startswith(("file://", "http://", "https://", "about:")):
                clean_path = clean_text.replace("\\", "/")
                if IS_WINDOWS and len(clean_path) >= 2 and clean_path[1] == ":":
                    url = QUrl("file:///" + clean_path)
                elif clean_path.startswith("/"):
                    url = QUrl.fromLocalFile(clean_path)
                elif os.path.exists(os.path.expanduser(clean_text)):
                    url = QUrl.fromLocalFile(
                        os.path.abspath(os.path.expanduser(clean_text))
                    )
                else:
                    home_abs = os.path.abspath(os.path.expanduser("~"))
                    joined = os.path.join(home_abs, clean_path.lstrip("/"))
                    url = QUrl.fromLocalFile(joined)
            else:
                url = QUrl(clean_text)
        else:
            clean_text = text
            if clean_text == "~" or clean_text.startswith(("~/", "~\\")):
                url = QUrl.fromLocalFile(
                    os.path.abspath(os.path.expanduser(clean_text))
                )
            elif not clean_text.startswith(
                ("http://", "https://", "file://", "about:")
            ):
                clean_path = clean_text.replace("\\", "/")
                if (IS_WINDOWS and len(clean_path) >= 2 and clean_path[1] == ":") or (
                    clean_path.startswith("/") and os.path.exists(clean_path)
                ):
                    url = QUrl.fromLocalFile(clean_path)
                elif "." in clean_text and " " not in clean_text:
                    url = QUrl("https://" + clean_text)
                else:
                    from urllib.parse import quote_plus

                    search_base = self.settings.value(
                        "search_engine", "https://duckduckgo.com/?q="
                    )
                    url = QUrl(f"{search_base}{quote_plus(clean_text)}")
            else:
                url = QUrl(clean_text)

        # Route direct media URLs to streaming player
        if hasattr(self, "media_streamer") and self.media_streamer:
            url_str = url.toString()
            lower = url_str.lower().split("?")[0].split("#")[0]
            media_exts = (
                ".mp4",
                ".m4v",
                ".mov",
                ".mkv",
                ".avi",
                ".wmv",
                ".flv",
                ".ts",
                ".webm",
                ".m4a",
                ".mp3",
                ".wav",
                ".flac",
                ".ogg",
                ".aac",
                ".wma",
            )
            if any(
                lower.endswith(ext) for ext in media_exts
            ) and not url_str.startswith(
                f"http://127.0.0.1:{self.media_streamer.port}/"
            ):
                from urllib.parse import quote_plus

                url = QUrl(
                    f"http://127.0.0.1:{self.media_streamer.port}/player?url={quote_plus(url_str)}"
                )

        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, BrowserView):
            widget._pending_url = None
            widget.setUrl(url)
            widget.setFocus()
        else:
            self.add_new_tab(url, set_current=True)

    def toggle_browsing_mode(self):
        new_mode = "file" if self.browsing_mode == "web" else "web"
        self.set_browsing_mode(new_mode, update_url_bar=True)

    def set_browsing_mode(self, mode, update_url_bar=False):
        self.browsing_mode = mode
        if mode == "file":
            file_icon = os.path.join(self.icons_path, "file_mode.png")
            if os.path.exists(file_icon):
                self.btn_mode.setIcon(QIcon(file_icon))
                self.btn_mode.setText("")
            else:
                self.btn_mode.setText("📁")
            self.btn_mode.setToolTip("Mode: File Browsing (Click to switch to Web)")
            self.url_bar.setPlaceholderText(DEFAULT_FILE_PLACEHOLDER)
            if update_url_bar:
                current_text = self.url_bar.text().strip()
                if not current_text.startswith("file://"):
                    self.url_bar.setText(DEFAULT_FILE_ROOT)
                self.url_bar.setFocus()
                self.url_bar.selectAll()
        else:
            web_icon = os.path.join(self.icons_path, "web.png")
            if os.path.exists(web_icon):
                self.btn_mode.setIcon(QIcon(web_icon))
                self.btn_mode.setText("")
            else:
                self.btn_mode.setText("🌐")
            self.btn_mode.setToolTip("Mode: Web Browsing (Click to switch to Files)")
            self.url_bar.setPlaceholderText("Search or enter address")
            if update_url_bar:
                current_text = self.url_bar.text().strip()
                if current_text.startswith("file://") or not current_text:
                    self.url_bar.setText("https://")
                self.url_bar.setFocus()
                self.url_bar.selectAll()

    def copy_file_to_clipboard(self, file_path):
        if not file_path or not os.path.exists(file_path):
            return
        mime_data = QMimeData()
        qurl = QUrl.fromLocalFile(file_path)
        mime_data.setUrls([qurl])
        mime_data.setText(file_path)
        QApplication.clipboard().setMimeData(mime_data)

        filename = os.path.basename(file_path) or file_path
        QToolTip.showText(QCursor.pos(), f"Copied '{filename}' to clipboard!", self)

    def save_local_file_as(self, file_path):
        if not file_path or not os.path.exists(file_path):
            return
        base_name = os.path.basename(file_path)
        dest, _ = QFileDialog.getSaveFileName(
            self, "Save File As", os.path.join(self.last_export_dir, base_name)
        )
        if dest:
            self.last_export_dir = os.path.dirname(dest)
            self.settings.setValue("last_download_dir", self.last_export_dir)
            import shutil

            try:
                shutil.copy2(file_path, dest)
                QToolTip.showText(
                    QCursor.pos(), f"Saved to '{os.path.basename(dest)}'!", self
                )
            except OSError as e:
                QMessageBox.warning(self, "Save Error", f"Failed to save file: {e}")

    def go_back(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            if widget.history().canGoBack():
                widget.back()
            else:
                curr_url = widget.url().toString()
                # If in media player and no history, navigate to parent folder
                if hasattr(self, "media_streamer") and self.media_streamer:
                    port = self.media_streamer.port
                    if curr_url.startswith(f"http://127.0.0.1:{port}/player"):
                        from urllib.parse import parse_qs, unquote, urlparse
                        from urllib.request import url2pathname

                        parsed = urlparse(curr_url)
                        params = parse_qs(parsed.query)
                        target_url = params.get("url", [None])[0]
                        if target_url:
                            target_unquoted = unquote(target_url)
                            if target_unquoted.startswith("file://"):
                                local_p = url2pathname(urlparse(target_unquoted).path)
                                if (
                                    sys.platform == "win32"
                                    and len(local_p) >= 3
                                    and local_p[0] == "\\"
                                    and local_p[2] == ":"
                                ):
                                    local_p = local_p[1:]
                                parent_dir = os.path.dirname(local_p)
                                if parent_dir and os.path.exists(parent_dir):
                                    widget.setUrl(QUrl.fromLocalFile(parent_dir))
                                    return
                # If viewing a file:/// URL directly and no history, go up one directory
                if curr_url.startswith("file:///"):
                    from urllib.parse import unquote, urlparse
                    from urllib.request import url2pathname

                    local_p = url2pathname(urlparse(curr_url).path)
                    if (
                        sys.platform == "win32"
                        and len(local_p) >= 3
                        and local_p[0] == "\\"
                        and local_p[2] == ":"
                    ):
                        local_p = local_p[1:]
                    parent_dir = os.path.dirname(local_p.rstrip("\\/"))
                    if parent_dir and os.path.exists(parent_dir):
                        widget.setUrl(QUrl.fromLocalFile(parent_dir))
                        return

    def go_forward(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            widget.forward()

    def reload_page(self, target_widget=None):
        widget = target_widget or self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            widget.reload()

    def reload_page_bypass_cache(self, target_widget=None):
        widget = target_widget or self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            page = widget.page()
            if page and hasattr(QWebEnginePage.WebAction, "ReloadAndBypassCache"):
                page.triggerAction(QWebEnginePage.WebAction.ReloadAndBypassCache)
            else:
                widget.reload()

    def set_tab_periodic_refresh(self, browser, interval_seconds):
        if not browser or not isinstance(browser, QWebEngineView):
            return
        self.cleanup_tab_periodic_refresh(browser)
        if interval_seconds > 0:
            timer = QTimer(self)
            timer.setInterval(interval_seconds * 1000)
            timer.timeout.connect(lambda b=browser: self._on_tab_periodic_timeout(b))
            timer.start()
            self.tab_periodic_timers[browser] = {
                "timer": timer,
                "interval": interval_seconds,
            }
            idx = self.tabs.indexOf(browser)
            if idx != -1:
                cur_tip = self.tabs.tabToolTip(idx) or ""
                clean_tip = re.sub(r"\s*\[Periodic Refresh:[^\]]+\]", "", cur_tip).strip()
                unit = f"{interval_seconds}s" if interval_seconds < 60 else f"{interval_seconds // 60}m"
                self.tabs.setTabToolTip(idx, f"{clean_tip} [Periodic Refresh: {unit}]".strip())
        else:
            idx = self.tabs.indexOf(browser)
            if idx != -1:
                cur_tip = self.tabs.tabToolTip(idx) or ""
                clean_tip = re.sub(r"\s*\[Periodic Refresh:[^\]]+\]", "", cur_tip).strip()
                self.tabs.setTabToolTip(idx, clean_tip)

    def get_tab_periodic_refresh(self, browser) -> int:
        if not browser or browser not in self.tab_periodic_timers:
            return 0
        return self.tab_periodic_timers[browser].get("interval", 0)

    def cleanup_tab_periodic_refresh(self, browser):
        timer_info = self.tab_periodic_timers.pop(browser, None)
        if timer_info:
            timer = timer_info.get("timer")
            if timer:
                try:
                    timer.stop()
                    timer.deleteLater()
                except Exception:
                    pass

    def _on_tab_periodic_timeout(self, browser):
        if self.tabs.indexOf(browser) != -1:
            try:
                browser.reload()
            except Exception as e:
                logger.debug(f"Periodic reload exception: {e}")

    def prompt_custom_periodic_refresh(self, browser):
        if not browser or not isinstance(browser, QWebEngineView):
            return
        current = self.get_tab_periodic_refresh(browser)
        val, ok = QInputDialog.getInt(
            self,
            "Custom Periodic Refresh",
            "Enter reload interval in seconds (minimum 5, 0 to disable):",
            value=current if current > 0 else 60,
            minValue=0,
            maxValue=86400,
            step=5,
        )
        if ok:
            if val < 5 and val != 0:
                val = 5
            self.set_tab_periodic_refresh(browser, val)

    def show_reload_context_menu(self, pos):
        menu = QMenu(self)
        browser = self.tabs.currentWidget()
        is_valid = bool(browser and isinstance(browser, QWebEngineView))

        reload_icon_path = resource_path(os.path.join("assets", "icons", "reload.png"))
        reload_icon = QIcon(reload_icon_path) if os.path.exists(reload_icon_path) else QIcon()

        shortcut_label = "⌘R, F5" if IS_MAC else "F5, Ctrl+R"
        hard_shortcut_label = "⌘⇧R" if IS_MAC else "Ctrl+Shift+R, Ctrl+F5"

        act_reload = menu.addAction(reload_icon, f"Reload ({shortcut_label})")
        act_reload.triggered.connect(lambda: self.reload_page(browser if is_valid else None))
        act_reload.setEnabled(is_valid)

        act_hard_reload = menu.addAction(f"Hard Reload ({hard_shortcut_label})")
        act_hard_reload.triggered.connect(lambda: self.reload_page_bypass_cache(browser if is_valid else None))
        act_hard_reload.setEnabled(is_valid)

        menu.addSeparator()

        periodic_menu = menu.addMenu("Periodic Refresh")
        if is_valid and browser:
            current_interval = self.get_tab_periodic_refresh(browser)
            intervals = [
                (0, "Off"),
                (10, "Every 10 Seconds"),
                (30, "Every 30 Seconds"),
                (60, "Every 1 Minute"),
                (120, "Every 2 Minutes"),
                (300, "Every 5 Minutes"),
                (900, "Every 15 Minutes"),
                (1800, "Every 30 Minutes"),
            ]
            for sec, label in intervals:
                act = periodic_menu.addAction(label)
                act.setCheckable(True)
                act.setChecked(current_interval == sec)
                act.triggered.connect(
                    lambda checked=False, s=sec, b=browser: self.set_tab_periodic_refresh(b, s)
                )
            periodic_menu.addSeparator()
            act_custom = periodic_menu.addAction("Custom Interval...")
            act_custom.triggered.connect(
                lambda: self.prompt_custom_periodic_refresh(browser)
            )
        else:
            periodic_menu.setEnabled(False)

        menu.exec(self.btn_reload.mapToGlobal(pos))

    def zoom_in(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            current = widget.zoomFactor()
            new_zoom = min(round(current + 0.1, 2), 3.0)
            widget.setZoomFactor(new_zoom)
            self.save_session()

    def zoom_out(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            current = widget.zoomFactor()
            new_zoom = max(round(current - 0.1, 2), 0.25)
            widget.setZoomFactor(new_zoom)
            self.save_session()

    def reset_zoom(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            widget.setZoomFactor(1.0)
            self.save_session()

    def zoom_reset(self):
        self.reset_zoom()

    def eventFilter(self, obj, event):
        if getattr(self, "is_closing", False):
            return False
        if event.type() == QEvent.Type.Wheel and (
            QApplication.keyboardModifiers()
            & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier)
        ):
            delta = event.angleDelta().y()
            if delta > 0:
                self.zoom_in()
                return True
            elif delta < 0:
                self.zoom_out()
                return True
        elif event.type() == QEvent.Type.KeyPress:
            # If a modal dialog (e.g. Save As, File Dialog) is active, preserve its default behavior
            if QApplication.activeModalWidget() is None:
                key = event.key()
                mods = event.modifiers()
                is_shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
                is_ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
                is_meta = bool(mods & Qt.KeyboardModifier.MetaModifier)
                is_alt = bool(mods & Qt.KeyboardModifier.AltModifier)

                # F5 / Multimedia Refresh key handling (Standard reload, Shift+F5 or Ctrl+F5 hard reload)
                refresh_key = getattr(Qt.Key, "Key_Refresh", 0x010000bf)
                if key in (Qt.Key.Key_F5, refresh_key):
                    if is_shift or is_ctrl:
                        self.reload_page_bypass_cache()
                    else:
                        self.reload_page()
                    return True

                # R key handling (Ctrl+R / Cmd+R standard reload, Ctrl+Shift+R / Cmd+Shift+R hard reload)
                if key == Qt.Key.Key_R:
                    if IS_MAC:
                        if (is_meta or is_ctrl) and is_shift:
                            self.reload_page_bypass_cache()
                            return True
                        elif is_meta and is_alt:
                            self.reload_page_bypass_cache()
                            return True
                        elif (is_meta or is_ctrl) and not is_shift and not is_alt:
                            self.reload_page()
                            return True
                    else:
                        if is_ctrl and is_shift:
                            self.reload_page_bypass_cache()
                            return True
                        elif is_ctrl and not is_shift and not is_alt and not is_meta:
                            self.reload_page()
                            return True

                # F11 / macOS full-screen toggle
                is_f11 = (key == Qt.Key.Key_F11)
                is_mac_fs = (
                    IS_MAC
                    and key == Qt.Key.Key_F
                    and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
                )
                if is_f11 or is_mac_fs:
                    self.toggle_fullscreen()
                    return True
                elif key == Qt.Key.Key_Escape and self.isFullScreen():
                    self.exit_fullscreen()
                    return True

        return super().eventFilter(obj, event)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            if getattr(self, "was_maximized", False):
                self.showMaximized()
            else:
                self.showNormal()
            self.toolbar_widget.show()
            self.tabs.tabBar().show()
            self.btn_toggle_sidebar.show()
            if not self.sidebar_minimized:
                self.sidebar_container.show()
        else:
            self.was_maximized = self.isMaximized()
            self.showFullScreen()
            self.toolbar_widget.hide()
            self.tabs.tabBar().hide()
            self.sidebar_container.hide()
            self.btn_toggle_sidebar.hide()

    def exit_fullscreen(self):
        if self.isFullScreen():
            self.toggle_fullscreen()

    def save_window_geometry(self):
        if getattr(self, "_is_initializing", True):
            return
        if getattr(self, "is_smoke_mode", False) or os.environ.get("QT_QPA_PLATFORM") == "offscreen":
            return
        if not self.isVisible() or self.isFullScreen():
            return
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        self.settings.setValue("isMaximized", self.isMaximized())
        self.settings.sync()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not getattr(self, "_is_initializing", True) and self.isVisible():
            self.save_window_geometry()

    def moveEvent(self, event):
        super().moveEvent(event)
        if not getattr(self, "_is_initializing", True) and self.isVisible():
            self.save_window_geometry()

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange:
            if not getattr(self, "_is_initializing", True) and self.isVisible():
                self.save_window_geometry()

    def keyPressEvent(self, event):
        key = event.key()
        mods = event.modifiers()
        is_shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        is_ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        is_meta = bool(mods & Qt.KeyboardModifier.MetaModifier)
        is_alt = bool(mods & Qt.KeyboardModifier.AltModifier)

        # F5 / Multimedia Refresh handling (Standard reload, Shift+F5 or Ctrl+F5 hard reload)
        refresh_key = getattr(Qt.Key, "Key_Refresh", 0x010000bf)
        if key in (Qt.Key.Key_F5, refresh_key):
            if is_shift or is_ctrl:
                self.reload_page_bypass_cache()
            else:
                self.reload_page()
            event.accept()
            return

        # R key handling (Ctrl+R / Cmd+R standard reload, Ctrl+Shift+R / Cmd+Shift+R hard reload)
        if key == Qt.Key.Key_R:
            if IS_MAC:
                if (is_meta or is_ctrl) and is_shift:
                    self.reload_page_bypass_cache()
                    event.accept()
                    return
                elif is_meta and is_alt:
                    self.reload_page_bypass_cache()
                    event.accept()
                    return
                elif (is_meta or is_ctrl) and not is_shift and not is_alt:
                    self.reload_page()
                    event.accept()
                    return
            else:
                if is_ctrl and is_shift:
                    self.reload_page_bypass_cache()
                    event.accept()
                    return
                elif is_ctrl and not is_shift and not is_alt and not is_meta:
                    self.reload_page()
                    event.accept()
                    return

        is_f11 = (key == Qt.Key.Key_F11)
        is_mac_fs = (
            IS_MAC
            and key == Qt.Key.Key_F
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        )
        if is_f11 or is_mac_fs:
            self.toggle_fullscreen()
            event.accept()
            return
        elif key == Qt.Key.Key_Escape and self.isFullScreen():
            self.exit_fullscreen()
            event.accept()
            return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        self.is_closing = True
        self.save_session()
        self.save_window_geometry()
        if hasattr(self, "update_check_timer") and self.update_check_timer:
            try:
                self.update_check_timer.stop()
            except Exception:
                pass
        if hasattr(self, "tab_periodic_timers"):
            for timer_info in list(self.tab_periodic_timers.values()):
                timer = timer_info.get("timer")
                if timer:
                    try:
                        timer.stop()
                    except Exception:
                        pass
            self.tab_periodic_timers.clear()
        if hasattr(self, "media_streamer") and self.media_streamer:
            self.media_streamer.stop()
        if hasattr(self, "bg_update_thread") and self.bg_update_thread:
            try:
                if self.bg_update_thread.isRunning():
                    self.bg_update_thread.quit()
                    self.bg_update_thread.wait(300)
                    if self.bg_update_thread.isRunning():
                        self.bg_update_thread.terminate()
                        self.bg_update_thread.wait(100)
            except Exception:
                pass
        # Cleanly tear down all WebEngineViews and WebEnginePages before profile destruction
        self.tabs.blockSignals(True)
        while self.tabs.count() > 0:
            widget = self.tabs.widget(0)
            self.tabs.removeTab(0)
            if widget and isinstance(widget, QWebEngineView):
                widget.stop()
                page = widget.page()
                widget.setPage(None)  # type: ignore
                if page:
                    page.deleteLater()
                widget.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        QCoreApplication.processEvents()
        super().closeEvent(event)

    def update_url_bar(self, qurl, browser=None):
        if browser == self.tabs.currentWidget():
            url_str = qurl.toString()
            if url_str.startswith("http://127.0.0.1:") and "/player" in url_str:
                from urllib.parse import parse_qs, unquote, urlparse

                query = parse_qs(urlparse(url_str).query)
                target = query.get("url", [""])[0]
                if target:
                    url_str = unquote(target)
            self.url_bar.setText(url_str)
            self.url_bar.setCursorPosition(0)
            self.update_bookmark_button_state()
            if url_str.startswith("file://") or qurl.isLocalFile():
                self.set_browsing_mode("file", update_url_bar=False)
            elif url_str and url_str != "about:blank":
                self.set_browsing_mode("web", update_url_bar=False)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.update_adaptive_layout()

    def toggle_sidebar(self):
        self.sidebar_minimized = not self.sidebar_minimized
        self.settings.setValue("sidebar_minimized", self.sidebar_minimized)
        if self.sidebar_minimized:
            self.btn_toggle_sidebar.setText(">")
        else:
            self.btn_toggle_sidebar.setText("<")
        self.update_adaptive_layout(force=True)

    def on_download_requested(self, download_item):
        suggested_filename = download_item.downloadFileName()
        mime_type = (download_item.mimeType() or "").lower()

        # Intercept media file downloads to play directly in browser
        url_str = download_item.url().toString()
        lower = url_str.lower().split("?")[0].split("#")[0]
        media_exts = (
            ".mp4",
            ".m4v",
            ".mov",
            ".mkv",
            ".avi",
            ".wmv",
            ".flv",
            ".ts",
            ".webm",
            ".m4a",
            ".mp3",
            ".wav",
            ".flac",
            ".ogg",
            ".aac",
            ".wma",
        )
        if (
            any(lower.endswith(ext) for ext in media_exts)
            and hasattr(self, "media_streamer")
            and self.media_streamer
        ):
            download_item.cancel()
            from urllib.parse import quote_plus

            player_url = QUrl(
                f"http://127.0.0.1:{self.media_streamer.port}/player?url={quote_plus(url_str)}"
            )
            widget = self.tabs.currentWidget()
            if widget and isinstance(widget, QWebEngineView):
                widget.setUrl(player_url)
            return

        # Determine dialog title
        title = "Save File"
        if mime_type.startswith("image/"):
            title = "Save Image As"
        elif mime_type.startswith("video/"):
            title = "Save Video As"
        elif mime_type.startswith("audio/"):
            title = "Save Audio As"

        # Check existing filename extension
        _base, current_ext = os.path.splitext(suggested_filename)

        # Generic/binary MIME types that shouldn't append .bin or .obj
        generic_mimes = (
            "application/octet-stream",
            "application/x-binary",
            "binary/octet-stream",
            "application/binary",
            "application/x-download",
            "application/download",
            "application/force-download",
        )

        # If no extension exists in suggested filename, try guessing from a specific MIME type
        if not current_ext and mime_type and mime_type not in generic_mimes:
            guessed_ext = mimetypes.guess_extension(mime_type)
            if guessed_ext and guessed_ext not in (".bin", ".obj"):
                if guessed_ext == ".jpe":
                    guessed_ext = ".jpg"
                suggested_filename += guessed_ext
                current_ext = guessed_ext

        filters = []

        # Specific filter based on filename extension (e.g. DMG, EXE, ZIP, etc.)
        if current_ext:
            clean_ext = current_ext.lstrip(".").lower()
            filters.append(f"{clean_ext.upper()} File (*{current_ext})")

        # Category filters
        if mime_type.startswith("image/") or (
            current_ext
            and current_ext.lower()
            in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp", ".svg")
        ):
            filters.append("Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp *.svg)")
        elif mime_type.startswith("video/") or (
            current_ext
            and current_ext.lower() in (".mp4", ".avi", ".mkv", ".mov", ".webm")
        ):
            filters.append("Videos (*.mp4 *.avi *.mkv *.mov *.webm)")
        elif mime_type.startswith("audio/") or (
            current_ext and current_ext.lower() in (".mp3", ".wav", ".ogg", ".flac")
        ):
            filters.append("Audio (*.mp3 *.wav *.ogg *.flac)")

        filters.append("All Files (*.*)")
        file_filter = ";;".join(filters)

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            title,
            os.path.join(self.last_export_dir, suggested_filename),
            file_filter,
        )

        if file_path:
            self.last_export_dir = os.path.dirname(file_path)
            self.settings.setValue("last_download_dir", self.last_export_dir)
            download_item.setDownloadDirectory(os.path.dirname(file_path))
            download_item.setDownloadFileName(os.path.basename(file_path))
            download_item.accept()

    def update_adaptive_layout(self, force=False):
        is_landscape = self.width() >= self.height()
        if not force and is_landscape == self.current_landscape:
            return
        self.current_landscape = is_landscape

        for i in range(10):
            self.toolbar_layout.setColumnStretch(i, 0)
        for i in range(3):
            self.toolbar_layout.setRowStretch(i, 0)

        self.main_layout.setDirection(QBoxLayout.Direction.LeftToRight)
        self.sidebar_layout.setDirection(QBoxLayout.Direction.TopToBottom)
        self.sidebar_label.setVisible(True)

        if self.sidebar_minimized:
            self.sidebar_container.setFixedWidth(0)
            self.sidebar_container.hide()
        else:
            self.sidebar_container.show()
            if is_landscape:
                self.sidebar_container.setFixedWidth(180)
            else:
                self.sidebar_container.setFixedWidth(135)

        if is_landscape:
            self.sidebar_container.setFixedWidth(180)
            self.sidebar_container.setMaximumHeight(16777215)

            self.toolbar_layout.addWidget(self.btn_back, 0, 0)
            self.toolbar_layout.addWidget(self.btn_forward, 0, 1)
            self.toolbar_layout.addWidget(self.btn_reload, 0, 2)
            self.toolbar_layout.addWidget(self.btn_mode, 0, 3)

            self.toolbar_layout.addWidget(self.url_bar, 0, 4)
            self.toolbar_layout.setColumnStretch(4, 1)

            self.toolbar_layout.addWidget(self.btn_bookmark, 0, 5)

            col_offset = 6

            if ENABLE_AI:
                self.toolbar_layout.addWidget(self.btn_wai, 0, col_offset)
                col_offset += 1
            self.toolbar_layout.addWidget(self.btn_file, 0, col_offset)
            self.toolbar_layout.addWidget(self.btn_about, 0, col_offset + 1)

            self.btn_about.setFixedWidth(72)
            self.btn_about.setFixedHeight(32)

            for btn in [
                self.btn_back,
                self.btn_forward,
                self.btn_reload,
                self.btn_mode,
                self.btn_bookmark,
                self.btn_file,
                self.btn_wai,
            ]:
                btn.setFixedSize(32, 32)

        else:
            self.sidebar_container.setFixedWidth(135)
            self.sidebar_container.setMaximumHeight(16777215)

            self.toolbar_layout.addWidget(self.btn_back, 0, 0)
            self.toolbar_layout.addWidget(self.btn_forward, 0, 1)
            self.toolbar_layout.addWidget(self.btn_reload, 0, 2)
            self.toolbar_layout.addWidget(self.btn_mode, 0, 3)
            if ENABLE_AI:
                self.toolbar_layout.addWidget(self.btn_wai, 0, 4)

            self.toolbar_layout.addWidget(self.url_bar, 1, 0, 1, 5)
            self.toolbar_layout.addWidget(self.btn_bookmark, 1, 5)

            col_offset = 0
            self.toolbar_layout.addWidget(self.btn_file, 2, col_offset)
            self.toolbar_layout.addWidget(self.btn_about, 2, col_offset + 1)

            self.btn_about.setFixedWidth(72)
            self.btn_about.setFixedHeight(32)

            for btn in [
                self.btn_back,
                self.btn_forward,
                self.btn_reload,
                self.btn_mode,
                self.btn_bookmark,
                self.btn_file,
                self.btn_wai,
            ]:
                btn.setFixedSize(32, 32)

    def show_file_menu(self):
        menu = QMenu(self)
        menu.setStyle(LargeIconProxyStyle())
        menu.setStyleSheet("""
            QMenu {
                background-color: #252525;
                border: 1px solid #454545;
                border-radius: 8px;
                padding: 4px;
                color: #ffffff;
            }
            QMenu::item {
                padding: 4px 8px 4px 8px;
                background-color: transparent;
                border-radius: 6px;
                min-height: 32px;
                font-size: 14px;
                color: #ffffff;
            }
            QMenu::item:selected {
                background-color: #007AFF;
                color: #ffffff;
                border-radius: 6px;
            }
            QMenu::separator {
                height: 1px;
                background: #3f3f46;
                margin: 4px 8px;
            }
            QMenu::icon {
                left: 10px;
            }
        """)

        # Generic Open Action
        import_action = QAction("Downloads", self)
        import_icon_path = resource_path(
            os.path.join("assets", "icons", "downloads.png")
        )
        if os.path.exists(import_icon_path):
            import_action.setIcon(QIcon(import_icon_path))
        import_action.triggered.connect(
            lambda: QDesktopServices.openUrl(
                QUrl.fromLocalFile(
                    QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)
                )
            )
        )
        menu.addAction(import_action)

        # Zoom Actions (OS-aware Cmd on macOS, Ctrl on Windows/Linux)
        zoom_in_action = QAction(f"Zoom In ({PRIMARY_MOD_NAME} +)", self)
        zoom_in_icon_path = resource_path(
            os.path.join("assets", "icons", "zoom-in.png")
        )
        if os.path.exists(zoom_in_icon_path):
            zoom_in_action.setIcon(QIcon(zoom_in_icon_path))
        zoom_in_action.triggered.connect(self.zoom_in)
        menu.addAction(zoom_in_action)

        zoom_out_action = QAction(f"Zoom Out ({PRIMARY_MOD_NAME} -)", self)
        zoom_out_icon_path = resource_path(
            os.path.join("assets", "icons", "zoom-out.png")
        )
        if os.path.exists(zoom_out_icon_path):
            zoom_out_action.setIcon(QIcon(zoom_out_icon_path))
        zoom_out_action.triggered.connect(self.zoom_out)
        menu.addAction(zoom_out_action)

        export_action = QAction(f"Zoom 100% ({PRIMARY_MOD_NAME} 0)", self)
        export_icon_path = resource_path(
            os.path.join("assets", "icons", "reset-zoom.png")
        )
        if os.path.exists(export_icon_path):
            export_action.setIcon(QIcon(export_icon_path))
        export_action.triggered.connect(self.reset_zoom)
        menu.addAction(export_action)

        fs_shortcut = "Fn+F" if IS_MAC else "F11"
        fs_label = "Exit Full Screen" if self.isFullScreen() else "Full Screen"
        fullscreen_menu_action = QAction(f"{fs_label} ({fs_shortcut})", self)
        fullscreen_menu_action.triggered.connect(self.toggle_fullscreen)
        menu.addAction(fullscreen_menu_action)

        history_action = QAction("History", self)
        history_icon_path = resource_path(
            os.path.join("assets", "icons", "history.png")
        )
        if os.path.exists(history_icon_path):
            history_action.setIcon(QIcon(history_icon_path))
        history_action.triggered.connect(self.show_history_dialog)
        menu.addAction(history_action)

        menu.addSeparator()

        search_menu = menu.addMenu("Search Engine")
        search_icon_path = resource_path(
            os.path.join("assets", "icons", "search-engine.png")
        )
        if os.path.exists(search_icon_path):
            search_menu.setIcon(QIcon(search_icon_path))
        search_menu.setStyle(LargeIconProxyStyle())
        search_menu.setStyleSheet(menu.styleSheet())

        engines = [
            ("DuckDuckGo", "https://duckduckgo.com/?q=", "duckduckgo.png"),
            ("Google", "https://www.google.com/search?q=", "google.png"),
            ("Yahoo", "https://search.yahoo.com/search?p=", "yahoo.png"),
            ("Bing", "https://www.bing.com/search?q=", "bing.png"),
        ]

        current_engine = self.settings.value(
            "search_engine", "https://duckduckgo.com/?q="
        )

        engine_group = QActionGroup(self)
        engine_group.setExclusive(True)

        for name, url, icon_file in engines:
            is_active = url == current_engine
            label = f"{name}  ✓" if is_active else name
            action = QAction(label, self)
            action.setCheckable(True)
            if is_active:
                action.setChecked(True)
            icon_path = resource_path(os.path.join("assets", "icons", icon_file))
            if os.path.exists(icon_path):
                action.setIcon(QIcon(icon_path))
            action.triggered.connect(lambda checked, u=url: self.set_search_engine(u))
            engine_group.addAction(action)
            search_menu.addAction(action)

        menu.addSeparator()

        cache_action = QAction("Enable Disk Cache", self)
        cache_action.setCheckable(True)
        cache_action.setChecked(self.disk_cache_enabled)
        cache_action.triggered.connect(self.toggle_disk_cache)
        menu.addAction(cache_action)

        adblock_action = QAction("Enable Ad & Tracker Blocker", self)
        adblock_action.setCheckable(True)
        adblock_action.setChecked(self.ad_block_enabled)
        adblock_action.triggered.connect(self.toggle_ad_block)
        menu.addAction(adblock_action)

        clear_cache_action = QAction("Clear Web Cache", self)
        clear_cache_action.triggered.connect(self.clear_cache)
        menu.addAction(clear_cache_action)

        if ENABLE_AI:
            ai_action = QAction("Enable Wheelhouser AI Assistant", self)
            ai_action.setCheckable(True)
            ai_action.setChecked(self.ai_enabled)
            ai_action.triggered.connect(self.toggle_ai_assistant)
            menu.addAction(ai_action)

        menu.addSeparator()

        desktop_action = QAction("Add Desktop Shortcut", self)
        desktop_icon_path = resource_path(
            os.path.join("assets", "icons", "icon.png")
        )
        if os.path.exists(desktop_icon_path):
            desktop_action.setIcon(QIcon(desktop_icon_path))
        desktop_action.triggered.connect(lambda: create_desktop_shortcut(self))
        menu.addAction(desktop_action)

        menu.exec(self.btn_file.mapToGlobal(QPoint(0, self.btn_file.height())))

    def toggle_disk_cache(self, enabled):
        self.disk_cache_enabled = enabled
        self.settings.setValue("disk_cache_enabled", enabled)
        if enabled:
            self.profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        else:
            self.profile.setHttpCacheType(
                QWebEngineProfile.HttpCacheType.MemoryHttpCache
            )

    def toggle_ad_block(self, enabled):
        self.ad_block_enabled = enabled
        self.settings.setValue("ad_block_enabled", enabled)
        if hasattr(self, "ad_block_interceptor") and self.ad_block_interceptor:
            self.ad_block_interceptor.enabled = enabled

    def clear_cache(self):
        self.profile.clearHttpCache()
        if os.path.exists(self.favicon_dir):
            for f in os.listdir(self.favicon_dir):
                try:
                    os.remove(os.path.join(self.favicon_dir, f))
                except OSError as e:
                    logger.debug(f"Failed to remove cached favicon {f}: {e}")
        QMessageBox.information(
            self,
            "Cache Cleared",
            "Local web cache and cached favicons have been successfully cleared.",
        )

    def toggle_ai_assistant(self, enabled):
        if not ENABLE_AI:
            return
        self.ai_enabled = enabled
        self.settings.setValue("enable_ai", enabled)
        if enabled:
            self._init_wai_manager()
            self.btn_wai.show()
            self.btn_wai.setEnabled(True)
        else:
            self.btn_wai.hide()
            self.btn_wai.setEnabled(False)

    def _init_wai_manager(self):
        if not hasattr(self, "wai_manager") or not self.wai_manager:
            if WAIAssistantManager:
                self.wai_manager = WAIAssistantManager(
                    app_name=APP_NAME,
                    parent_widget=self,
                    get_context_cb=self.get_wai_context,
                    execute_pipeline_cb=self.execute_wai_pipeline,
                )
                if hasattr(self, "btn_wai"):
                    self.wai_manager.connectionChanged.connect(self.btn_wai.setEnabled)

    def set_search_engine(self, url):
        self.settings.setValue("search_engine", url)

    def show_history_dialog(self):
        dlg = HistoryDialog(self.history, self.save_history, self)
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.url_to_open:
            self.add_new_tab(QUrl(dlg.url_to_open))

    # =========================================================================
    # WAI Assistant Callbacks
    # =========================================================================

    def open_wai_dialog(self):
        """Called when the WAI button is clicked in the UI."""
        if not ENABLE_AI:
            return
        if not hasattr(self, "wai_manager") or not self.wai_manager:
            self._init_wai_manager()

        if not self.wai_manager:
            QMessageBox.warning(
                self,
                "Wheelhouser AI Unavailable",
                "The Wheelhouser AI module is not available in this environment.",
            )
            return

        opened = self.wai_manager.open_dialog()
        if not opened:
            # Open forcefully so the user can interact with the chat UI while reconnecting
            opened_forced = self.wai_manager.open_dialog(force=True)
            if not opened_forced:
                QMessageBox.warning(
                    self,
                    "Connection Error",
                    "Wheelhouser AI Assistant is not connected to the orchestrator.\nPlease check that the Wheelhouser AI service is running on your system (port 7800) and try again.",
                )

    def get_wai_context(self, include_text=True):
        """Callback for WAIAssistantManager to gather rich browser state."""
        widget = self.tabs.currentWidget()
        current_url = ""
        current_title = ""
        selected_text = ""
        if widget and isinstance(widget, QWebEngineView):
            current_url = widget.url().toString()
            current_title = widget.title()
            if include_text and hasattr(widget, "selectedText"):
                try:
                    selected_text = widget.selectedText()
                except Exception:
                    selected_text = ""

        state = {
            "app_name": "Web-Browser",
            "app_mode": "web-browser",
            "current_url": current_url,
            "current_title": current_title,
            "active_tab_index": self.tabs.currentIndex(),
            "tab_count": self.tabs.count(),
            "bookmark_count": self.bookmark_list.count(),
            "active_bookmark_index": self.bookmark_list.currentRow(),
        }
        if include_text:
            if selected_text:
                state["selected_text"] = selected_text
                state["content"] = selected_text
            elif current_title or current_url:
                state["content"] = f"Page Title: {current_title}\nURL: {current_url}"
        return state

    def execute_wai_pipeline(self, pipeline: Any) -> None:
        """Callback to execute a parsed JSON pipeline from the orchestrator."""
        # Ensure execution always runs safely on the Qt main GUI thread
        app_inst = QApplication.instance()
        if app_inst and QThread.currentThread() != app_inst.thread():
            QTimer.singleShot(0, lambda: self.execute_wai_pipeline(pipeline))
            return

        pipeline_list: List[Any]
        if isinstance(pipeline, list):
            pipeline_list = pipeline
        elif isinstance(pipeline, (dict, str)):
            pipeline_list = [pipeline]
        else:
            return

        normalized_pipeline: List[Dict[str, Any]] = []
        for raw_cmd in pipeline_list:
            if isinstance(raw_cmd, str):
                normalized_pipeline.append({"action": raw_cmd, "intent": raw_cmd, "parameters": {}})
            elif isinstance(raw_cmd, dict):
                if "payload" in raw_cmd and isinstance(raw_cmd["payload"], dict) and "intent" in raw_cmd["payload"]:
                    payload = raw_cmd["payload"]
                    raw_params = payload.get("parameters")
                    params = raw_params.copy() if isinstance(raw_params, dict) else {}
                    new_cmd: Dict[str, Any] = params
                    new_cmd["action"] = payload["intent"]
                    new_cmd["parameters"] = params
                    normalized_pipeline.append(new_cmd)
                else:
                    normalized_pipeline.append(raw_cmd)

        logger.info(f"Executing pipeline with {len(normalized_pipeline)} commands")

        for cmd_dict in normalized_pipeline:
            action = str(cmd_dict.get("action") or cmd_dict.get("intent") or "")
            raw_params = cmd_dict.get("parameters")
            params: Dict[str, Any] = raw_params if isinstance(raw_params, dict) else {}

            if action == "feedback":
                self._wai_handle_feedback(cmd_dict)
            elif action in ("open_url", "navigate", "browse"):
                url = params.get("url") or cmd_dict.get("url") or params.get("target")
                if url:
                    self.add_new_tab(QUrl(str(url)), set_current=True)
            elif action == "new_tab":
                url = params.get("url") or cmd_dict.get("url") or DEFAULT_HOMEPAGE
                self.add_new_tab(QUrl(str(url)), set_current=True)
            elif action == "close_tab":
                tab_idx = params.get("tab_index")
                if isinstance(tab_idx, int) and 0 <= tab_idx < self.tabs.count():
                    self.close_tab(tab_idx)
                else:
                    self.close_tab(self.tabs.currentIndex())
            elif action == "search":
                query = params.get("query") or cmd_dict.get("query")
                if query:
                    from urllib.parse import quote_plus

                    search_base = self.settings.value(
                        "search_engine", "https://duckduckgo.com/?q="
                    )
                    search_url = f"{search_base}{quote_plus(str(query))}"
                    self.add_new_tab(QUrl(search_url), set_current=True)
            elif action == "add_bookmark":
                url = params.get("url") or cmd_dict.get("url")
                title = params.get("title") or cmd_dict.get("title")
                if url:
                    self._wai_add_bookmark(str(title) if title else "", str(url))
                else:
                    self.add_bookmark()
            elif action in ("reload", "refresh"):
                self.reload_page()
            elif action in ("go_back", "back"):
                self.go_back()
            elif action in ("go_forward", "forward"):
                self.go_forward()
            elif action == "zoom_in":
                self.zoom_in()
            elif action == "zoom_out":
                self.zoom_out()
            elif action in ("zoom_reset", "reset_zoom"):
                self.reset_zoom()
            elif action == "focus":
                self.raise_()
                self.activateWindow()
            elif action == "read_man_page":
                logger.debug("Handled read_man_page informational action.")
            else:
                logger.warning(f"Unknown or unhandled WAI action: {action}")

    def _wai_add_bookmark(self, title: str, url: str):
        if not url or url == "about:blank":
            return
        clean_title = self.clean_bookmark_title(title or url, url)
        for i in range(self.bookmark_list.count()):
            item = self.bookmark_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == url:
                self.bookmark_list.setCurrentItem(item)
                self.update_bookmark_button_state()
                return

        item = QListWidgetItem(clean_title)
        item.setData(Qt.ItemDataRole.UserRole, url)
        self.bookmark_list.addItem(item)
        self.bookmark_list.setCurrentItem(item)
        self.save_bookmarks()
        self.update_bookmark_button_state()

    # --- WAI Handlers (Internal Canvas Interactions) ---

    def _wai_handle_feedback(self, cmd):
        question = cmd.get("parameters", {}).get(
            "question", "Could you clarify what you want to modify?"
        )
        if hasattr(self, "wai_manager") and self.wai_manager.dialog:
            self.wai_manager.dialog.append_message("System", question)

    # --- Bookmarks & Homepage Logic ---
    def clean_bookmark_title(self, title, url_str):
        if not title:
            title = url_str
        import re

        if title:
            title = re.sub(r"^index of:?\s*", "", title, flags=re.IGNORECASE).strip()
        is_local = url_str.startswith(("file://", "/")) or (
            len(url_str) > 2 and url_str[1] == ":"
        )
        if is_local:
            if (
                title.startswith("file://")
                or (len(title) > 2 and title[1] == ":")
                or "/" in title
                or "\\" in title
            ):
                local_path = (
                    url_str.replace("file:///", "").replace("file://", "").rstrip("/\\")
                )
                folder_name = os.path.basename(local_path)
                return folder_name if folder_name else local_path
            return title
        return title

    def get_bookmark_icon(self, url_str, live_icon=None):
        if live_icon and not live_icon.isNull():
            return live_icon
        is_local = url_str.startswith(("file://", "/")) or (
            len(url_str) > 2 and url_str[1] == ":"
        )
        if is_local:
            folder_icon_path = os.path.join(self.icons_path, "folder.png")
            if os.path.exists(folder_icon_path):
                return QIcon(folder_icon_path)
        qurl = QUrl(url_str)
        if qurl.host():
            cached = self.get_cached_icon(qurl.host())
            if not cached.isNull():
                return cached
        return QIcon()

    def is_url_bookmarked(self, url_str):
        if not url_str or url_str == "about:blank":
            return False
        for i in range(self.bookmark_list.count()):
            item = self.bookmark_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == url_str:
                return True
        return False

    def update_bookmark_button_state(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            pending = getattr(widget, "_pending_url", None)
            url_str = pending.toString() if pending else widget.url().toString()
            if not url_str or url_str == "about:blank":
                self.btn_bookmark.setEnabled(False)
                dim_path = os.path.join(self.icons_path, "bookmark.png")
                if os.path.exists(dim_path):
                    self.btn_bookmark.setIcon(QIcon(dim_path))
                self.btn_bookmark.setToolTip("Cannot bookmark blank page")
            elif self.is_url_bookmarked(url_str):
                self.btn_bookmark.setEnabled(False)
                dim_path = os.path.join(self.icons_path, "bookmark.png")
                if os.path.exists(dim_path):
                    self.btn_bookmark.setIcon(QIcon(dim_path))
                self.btn_bookmark.setToolTip("Page is already bookmarked")
            else:
                self.btn_bookmark.setEnabled(True)
                blue_path = os.path.join(self.icons_path, "bookmark_blue.png")
                if os.path.exists(blue_path):
                    self.btn_bookmark.setIcon(QIcon(blue_path))
                else:
                    self.btn_bookmark.setIcon(
                        QIcon(os.path.join(self.icons_path, "bookmark.png"))
                    )
                self.btn_bookmark.setToolTip("Bookmark this page")
        else:
            self.btn_bookmark.setEnabled(False)
            dim_path = os.path.join(self.icons_path, "bookmark.png")
            if os.path.exists(dim_path):
                self.btn_bookmark.setIcon(QIcon(dim_path))
            self.btn_bookmark.setToolTip("Bookmark this page")

    def add_bookmark(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            title = widget.title()
            url_qurl = widget.url()
            url = url_qurl.toString()
            if not url or url == "about:blank":
                return

            title = self.clean_bookmark_title(title, url)

            # Check for duplicates (optional, but good UX)
            for i in range(self.bookmark_list.count()):
                item = self.bookmark_list.item(i)
                if item.data(Qt.ItemDataRole.UserRole) == url:
                    self.bookmark_list.setCurrentItem(item)
                    self.update_bookmark_button_state()
                    return  # Already exists

            item = QListWidgetItem(title)
            item.setData(Qt.ItemDataRole.UserRole, url)

            # Get favicon from browser, folder icon or disk cache
            icon = self.get_bookmark_icon(url, widget.icon())
            if not icon.isNull():
                item.setIcon(icon)
                if url_qurl.host() and not url.startswith("file://"):
                    self.save_cached_icon(url_qurl.host(), icon)

            self.bookmark_list.addItem(item)
            self.bookmark_list.setCurrentItem(item)
            self.save_bookmarks()
            self.update_bookmark_button_state()

            # Visual feedback tooltip on URL bar
            popup_pos = self.url_bar.mapToGlobal(
                QPoint(max(0, self.url_bar.width() - 170), self.url_bar.height() + 4)
            )
            QToolTip.showText(
                popup_pos, "📖 Bookmark added!", self.url_bar, msecShowTime=2500
            )

    def bookmark_tab(self, browser):
        """Bookmarks a specific tab browser view."""
        if not browser or not isinstance(browser, QWebEngineView):
            return
        pending = getattr(browser, "_pending_url", None)
        url_qurl = pending if pending else browser.url()
        url = url_qurl.toString()
        if not url or url == "about:blank":
            return
        title = self.clean_bookmark_title(browser.title(), url)

        # Check if duplicate
        for i in range(self.bookmark_list.count()):
            item = self.bookmark_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == url:
                self.bookmark_list.setCurrentItem(item)
                self.update_bookmark_button_state()
                return

        item = QListWidgetItem(title)
        item.setData(Qt.ItemDataRole.UserRole, url)
        icon = self.get_bookmark_icon(url, browser.icon())
        if not icon.isNull():
            item.setIcon(icon)
            if url_qurl.host() and not url.startswith("file://"):
                self.save_cached_icon(url_qurl.host(), icon)

        self.bookmark_list.addItem(item)
        self.bookmark_list.setCurrentItem(item)
        self.save_bookmarks()
        self.update_bookmark_button_state()

    def remove_bookmark_by_url(self, url):
        """Removes a bookmark matching the given URL."""
        for i in range(self.bookmark_list.count()):
            item = self.bookmark_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == url:
                self.bookmark_list.takeItem(i)
                self.save_bookmarks()
                self.update_bookmark_button_state()
                return

    def bookmark_all_open_tabs(self):
        """Bookmarks all open tabs in the browser."""
        count_added = 0
        for i in range(self.tabs.count() - 1):
            browser = self.tabs.widget(i)
            if browser and isinstance(browser, QWebEngineView):
                pending = getattr(browser, "_pending_url", None)
                url_qurl = pending if pending else browser.url()
                url = url_qurl.toString()
                if url and url != "about:blank" and not self.is_url_bookmarked(url):
                    title = self.clean_bookmark_title(browser.title(), url)
                    item = QListWidgetItem(title)
                    item.setData(Qt.ItemDataRole.UserRole, url)
                    icon = self.get_bookmark_icon(url, browser.icon())
                    if not icon.isNull():
                        item.setIcon(icon)
                        if url_qurl.host() and not url.startswith("file://"):
                            self.save_cached_icon(url_qurl.host(), icon)
                    self.bookmark_list.addItem(item)
                    count_added += 1
        if count_added > 0:
            self.save_bookmarks()
            self.update_bookmark_button_state()
            QToolTip.showText(
                QCursor.pos(), f"📚 Bookmarked {count_added} tab(s)!", self, msecShowTime=2500
            )

    def show_tab_context_menu(self, pos):
        """Displays context menu when right-clicking on tab bar."""
        tab_bar = self.tabs.tabBar()
        tab_index = tab_bar.tabAt(pos)
        is_valid_tab = (0 <= tab_index < self.tabs.count() - 1)

        menu = QMenu(self)
        menu.setStyle(LargeIconProxyStyle())
        menu.setStyleSheet("""
            QMenu {
                background-color: #252525;
                border: 1px solid #454545;
                border-radius: 8px;
                padding: 4px;
                color: #ffffff;
            }
            QMenu::item {
                padding: 4px 8px 4px 8px;
                background-color: transparent;
                border-radius: 6px;
                min-height: 28px;
                font-size: 14px;
                color: #ffffff;
            }
            QMenu::item:selected {
                background-color: #007AFF;
                color: #ffffff;
                border-radius: 6px;
            }
            QMenu::separator {
                height: 1px;
                background: #3f3f46;
                margin: 4px 8px;
            }
        """)

        browser = self.tabs.widget(tab_index) if is_valid_tab else None
        current_url = ""
        is_bookmarked = False
        if browser and isinstance(browser, QWebEngineView):
            pending = getattr(browser, "_pending_url", None)
            current_url = pending.toString() if pending else browser.url().toString()
            is_bookmarked = bool(current_url and self.is_url_bookmarked(current_url))

        # ── 1. Open Bookmark Submenu (First item per UX directive) ──
        open_icon_path = resource_path(os.path.join("assets", "icons", "open.png"))
        open_icon = QIcon(open_icon_path) if os.path.exists(open_icon_path) else QIcon()

        bookmarks_submenu = menu.addMenu(open_icon, "Open Bookmark")
        bookmarks_submenu.setStyle(LargeIconProxyStyle())
        bookmarks_submenu.setStyleSheet(menu.styleSheet())

        if self.bookmark_list.count() == 0:
            empty_act = bookmarks_submenu.addAction("(No Bookmarks Saved)")
            empty_act.setEnabled(False)
        else:
            for b_idx in range(self.bookmark_list.count()):
                b_item = self.bookmark_list.item(b_idx)
                b_url = b_item.data(Qt.ItemDataRole.UserRole)
                b_title = b_item.text()
                b_icon = b_item.icon()
                b_action = bookmarks_submenu.addAction(b_icon, b_title)
                b_action.triggered.connect(lambda checked=False, u=b_url: self.add_new_tab(u, b_title))

        # ── 2. Bookmark / Remove Bookmark for This Tab ──
        bookmark_blue_path = resource_path(os.path.join("assets", "icons", "bookmark_blue.png"))
        bookmark_icon_path = resource_path(os.path.join("assets", "icons", "bookmark.png"))
        bookmark_icon = QIcon(bookmark_blue_path) if os.path.exists(bookmark_blue_path) else (
            QIcon(bookmark_icon_path) if os.path.exists(bookmark_icon_path) else QIcon()
        )

        if is_valid_tab and current_url and current_url != "about:blank":
            if is_bookmarked:
                action_bookmark = menu.addAction(bookmark_icon, "Remove Bookmark")
                action_bookmark.triggered.connect(lambda: self.remove_bookmark_by_url(current_url))
            else:
                action_bookmark = menu.addAction(bookmark_icon, "Bookmark This Tab")
                action_bookmark.triggered.connect(lambda: self.bookmark_tab(browser))
        else:
            action_bookmark = menu.addAction(bookmark_icon, "Bookmark This Tab")
            action_bookmark.setEnabled(False)

        menu.addSeparator()

        # ── 3. Tab Navigation & Operations ──
        reload_icon_path = resource_path(os.path.join("assets", "icons", "reload.png"))
        reload_icon = QIcon(reload_icon_path) if os.path.exists(reload_icon_path) else QIcon()
        shortcut_label = "⌘R, F5" if IS_MAC else "F5, Ctrl+R"
        hard_shortcut_label = "⌘⇧R" if IS_MAC else "Ctrl+Shift+R, Ctrl+F5"

        action_reload = menu.addAction(reload_icon, f"Reload Tab ({shortcut_label})")
        if is_valid_tab and browser:
            action_reload.triggered.connect(lambda: self.reload_page(browser))
        else:
            action_reload.setEnabled(False)

        action_hard_reload = menu.addAction(f"Hard Reload Tab ({hard_shortcut_label})")
        if is_valid_tab and browser:
            action_hard_reload.triggered.connect(lambda: self.reload_page_bypass_cache(browser))
        else:
            action_hard_reload.setEnabled(False)

        periodic_menu = menu.addMenu("Periodic Refresh")
        if is_valid_tab and browser:
            current_interval = self.get_tab_periodic_refresh(browser)
            intervals = [
                (0, "Off"),
                (10, "Every 10 Seconds"),
                (30, "Every 30 Seconds"),
                (60, "Every 1 Minute"),
                (120, "Every 2 Minutes"),
                (300, "Every 5 Minutes"),
                (900, "Every 15 Minutes"),
                (1800, "Every 30 Minutes"),
            ]
            for sec, label in intervals:
                act = periodic_menu.addAction(label)
                act.setCheckable(True)
                act.setChecked(current_interval == sec)
                act.triggered.connect(
                    lambda checked=False, s=sec, b=browser: self.set_tab_periodic_refresh(b, s)
                )
            periodic_menu.addSeparator()
            act_custom = periodic_menu.addAction("Custom Interval...")
            act_custom.triggered.connect(
                lambda: self.prompt_custom_periodic_refresh(browser)
            )
        else:
            periodic_menu.setEnabled(False)

        new_icon_path = resource_path(os.path.join("assets", "icons", "new.png"))
        new_icon = QIcon(new_icon_path) if os.path.exists(new_icon_path) else QIcon()

        action_dup = menu.addAction(new_icon, "Duplicate Tab")
        if is_valid_tab and current_url and current_url != "about:blank":
            action_dup.triggered.connect(lambda: self.add_new_tab(current_url, browser.title() if isinstance(browser, QWebEngineView) else ""))
        else:
            action_dup.setEnabled(False)

        copy_icon_path = resource_path(os.path.join("assets", "icons", "copy.png"))
        copy_icon = QIcon(copy_icon_path) if os.path.exists(copy_icon_path) else QIcon()
        action_copy_url = menu.addAction(copy_icon, "Copy URL")
        if is_valid_tab and current_url and current_url != "about:blank":
            action_copy_url.triggered.connect(lambda: (
                QApplication.clipboard().setText(current_url),
                QToolTip.showText(QCursor.pos(), "📋 URL Copied!", self, msecShowTime=2000)
            ))
        else:
            action_copy_url.setEnabled(False)

        menu.addSeparator()

        # ── 4. Tab Creation & Close (Using shared company open/close/new icons) ──
        action_new = menu.addAction(new_icon, "New Tab")
        action_new.triggered.connect(lambda: self.add_new_tab())

        close_icon_path = resource_path(os.path.join("assets", "icons", "close.png"))
        close_icon = QIcon(close_icon_path) if os.path.exists(close_icon_path) else QIcon()
        action_close = menu.addAction(close_icon, "Close Tab")
        if is_valid_tab:
            action_close.triggered.connect(lambda: self.close_tab(tab_index))
        else:
            action_close.setEnabled(False)

        menu.exec(tab_bar.mapToGlobal(pos))

    def delete_bookmark(self):
        row = self.bookmark_list.currentRow()
        if row >= 0:
            self.bookmark_list.takeItem(row)
            self.save_bookmarks()
            self.update_bookmark_button_state()

    def set_homepage(self):
        widget = self.tabs.currentWidget()
        if widget and isinstance(widget, QWebEngineView):
            url = widget.url().toString()
            self.settings.setValue("homepage", url)
            QMessageBox.information(self, "Homepage Set", f"Homepage set to:\n{url}")

    def move_bookmark_up(self):
        row = self.bookmark_list.currentRow()
        if row > 0:
            item = self.bookmark_list.takeItem(row)
            self.bookmark_list.insertItem(row - 1, item)
            self.bookmark_list.setCurrentRow(row - 1)
            self.save_bookmarks()

    def move_bookmark_down(self):
        row = self.bookmark_list.currentRow()
        if row != -1 and row < self.bookmark_list.count() - 1:
            item = self.bookmark_list.takeItem(row)
            self.bookmark_list.insertItem(row + 1, item)
            self.bookmark_list.setCurrentRow(row + 1)
            self.save_bookmarks()

    def show_bookmark_context_menu(self, pos):
        item = self.bookmark_list.itemAt(pos)
        if not item:
            return
        row = self.bookmark_list.row(item)
        self.bookmark_list.setCurrentRow(row)
        url_str = item.data(Qt.ItemDataRole.UserRole)
        menu = QMenu(self)
        menu.setStyle(LargeIconProxyStyle())
        menu.setStyleSheet("""
            QMenu {
                background-color: #252525;
                border: 1px solid #454545;
                border-radius: 8px;
                padding: 4px;
                color: #ffffff;
            }
            QMenu::item {
                padding: 4px 8px 4px 8px;
                background-color: transparent;
                border-radius: 6px;
                color: #ffffff;
            }
            QMenu::item:selected {
                background-color: #007AFF;
                color: #ffffff;
                border-radius: 6px;
            }
            QMenu::separator {
                height: 1px;
                background: #3f3f46;
                margin: 4px 8px;
            }
        """)

        open_action = QAction("Open in New Tab", menu)
        open_action.triggered.connect(
            lambda: self.add_new_tab(url_str, label=item.text(), set_current=True)
        )
        menu.addAction(open_action)

        menu.addSeparator()
        move_up_act = QAction("▲ Move Up", menu)
        move_up_act.triggered.connect(self.move_bookmark_up)
        if row == 0:
            move_up_act.setEnabled(False)
        menu.addAction(move_up_act)

        move_down_act = QAction("▼ Move Down", menu)
        move_down_act.triggered.connect(self.move_bookmark_down)
        if row >= self.bookmark_list.count() - 1:
            move_down_act.setEnabled(False)
        menu.addAction(move_down_act)

        if url_str and (
            url_str.startswith("file://") or (len(url_str) >= 2 and url_str[1] == ":")
        ):
            local_path = QUrl(url_str).toLocalFile() or url_str.replace(
                "file:///", ""
            ).replace("file://", "")
            if (
                local_path
                and len(local_path) >= 3
                and local_path[0] == "/"
                and local_path[2] == ":"
            ):
                local_path = local_path[1:]
            if local_path and os.path.exists(local_path):
                menu.addSeparator()
                copy_file_act = QAction("📋 Copy File", menu)
                copy_file_act.triggered.connect(
                    lambda: self.copy_file_to_clipboard(local_path)
                )
                menu.addAction(copy_file_act)

                copy_path_act = QAction("Copy Path", menu)
                copy_path_act.triggered.connect(
                    lambda: QApplication.clipboard().setText(local_path)
                )
                menu.addAction(copy_path_act)

        menu.addSeparator()
        delete_action = QAction("Delete Bookmark", menu)
        delete_action.triggered.connect(self.delete_bookmark)
        menu.addAction(delete_action)

        menu.exec(self.bookmark_list.mapToGlobal(pos))

    def on_bookmark_clicked(self, item):
        url_str = item.data(Qt.ItemDataRole.UserRole)
        if url_str:
            self.add_new_tab(QUrl(url_str), item.text())

    def save_bookmarks(self):
        bookmarks = []
        for i in range(self.bookmark_list.count()):
            item = self.bookmark_list.item(i)
            bookmarks.append({"title": item.text(), "url": item.data(Qt.ItemDataRole.UserRole)})
        self.settings.setValue("bookmarks", json.dumps(bookmarks))

    def load_bookmarks(self):
        data = str(self.settings.value("bookmarks", "[]"))
        try:
            bookmarks = json.loads(data)
            for b in bookmarks:
                url_str = b["url"]
                clean_title = self.clean_bookmark_title(b.get("title", ""), url_str)
                item = QListWidgetItem(clean_title)
                item.setData(Qt.ItemDataRole.UserRole, url_str)

                # Look up folder icon or cached favicon for this bookmark
                icon = self.get_bookmark_icon(url_str)
                if not icon.isNull():
                    item.setIcon(icon)

                self.bookmark_list.addItem(item)
            self.update_bookmark_button_state()
        except (OSError, json.JSONDecodeError, KeyError) as e:
            logger.error(f"Failed to load bookmarks: {e}")

    # =========================================================================

    def show_about_dialog(self):
        """Shows the custom About dialog with an integrated in-app updater and Blue theme."""
        dialog = QDialog(self)
        dialog.setWindowTitle(f"About {APP_NAME}")
        dialog.setMinimumWidth(500)
        dialog.setStyleSheet("""
            QDialog { background-color: #0f172a; }
            QLabel  { background: transparent; color: #f3f4f6; }
        """)

        main_layout = QVBoxLayout(dialog)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSizeConstraint(QLayout.SizeConstraint.SetMinAndMaxSize)

        # ── Header ──────────────────────────────────────────────────────────
        header_widget = QWidget()
        header_widget.setStyleSheet(
            "background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0a192f, stop:1 #0f274a);"
        )
        header_layout = QVBoxLayout(header_widget)
        header_layout.setContentsMargins(32, 24, 32, 20)
        header_layout.setSpacing(6)

        icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
        if os.path.exists(icon_path):
            icon_label = QLabel()
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                icon_label.setPixmap(
                    pixmap.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                )
                icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                header_layout.addWidget(icon_label)

        app_name_lbl = QLabel(APP_NAME.upper())
        app_name_lbl.setStyleSheet(
            "color: #38bdf8; font-size: 15pt; font-weight: 700; letter-spacing: 2px;"
        )
        app_name_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(app_name_lbl)

        ver_lbl = QLabel(f"Version {APP_VERSION}")
        ver_lbl.setStyleSheet("color: #93c5fd; font-size: 10pt; letter-spacing: 1px;")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(ver_lbl)

        main_layout.addWidget(header_widget)

        # Thin divider
        div1 = QFrame()
        div1.setFrameShape(QFrame.Shape.HLine)
        div1.setFixedHeight(1)
        div1.setStyleSheet("background-color: #1e3a8a; border: none;")
        main_layout.addWidget(div1)

        # ── Body ────────────────────────────────────────────────────────────
        body_widget = QWidget()
        body_layout = QVBoxLayout(body_widget)
        body_layout.setContentsMargins(32, 20, 32, 22)
        body_layout.setSpacing(12)

        desc_lbl = QLabel(
            "A fast, secure, and privacy-respecting web browser built on the Wheelhouser framework."
        )
        desc_lbl.setWordWrap(True)
        desc_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_lbl.setStyleSheet("color: #cbd5e1; font-size: 9.5pt; line-height: 1.4;")
        body_layout.addWidget(desc_lbl)

        meta_lbl = QLabel(
            f"<b>Author:</b> <a href='mailto:steve.rock@wheelhouser.com' style='color:#38bdf8; text-decoration:none;'>steve.rock@wheelhouser.com</a> &nbsp;•&nbsp; <b>Company:</b> {COMPANY_NAME}"
        )
        meta_lbl.setOpenExternalLinks(True)
        meta_lbl.setTextFormat(Qt.TextFormat.RichText)
        meta_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        meta_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        meta_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")
        body_layout.addWidget(meta_lbl)

        website_lbl = QLabel(
            f'Visit <a href="{WEBSITE_URL}" '
            'style="color:#38bdf8; text-decoration:none; font-weight:600;">'
            f"{WEBSITE_URL.replace('https://', '')}</a> to learn more."
        )
        website_lbl.setOpenExternalLinks(True)
        website_lbl.setTextFormat(Qt.TextFormat.RichText)
        website_lbl.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
        )
        website_lbl.setWordWrap(True)
        website_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        website_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")
        body_layout.addWidget(website_lbl)

        # ── In-App Update Section ──────────────────────────────────────────
        update_frame = QFrame()
        update_frame.setStyleSheet("""
            QFrame#updateFrame {
                background-color: rgba(14, 30, 60, 0.85);
                border: 1px solid #2563eb;
                border-radius: 8px;
            }
        """)
        update_frame.setObjectName("updateFrame")
        up_layout = QVBoxLayout(update_frame)
        up_layout.setContentsMargins(20, 16, 20, 16)
        up_layout.setSpacing(10)

        up_title = QLabel("⬆  NEW UPDATE AVAILABLE")
        up_title.setStyleSheet(
            "color: #60a5fa; font-size: 10.5pt; font-weight: 700;"
            " border: none; background: transparent; letter-spacing: 1px;"
        )
        up_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        up_layout.addWidget(up_title)

        up_ver = QLabel("Checking for updates...")
        up_ver.setWordWrap(True)
        up_ver.setStyleSheet(
            "color: #e2e8f0; font-size: 9.5pt; border: none; background: transparent;"
        )
        up_ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        up_layout.addWidget(up_ver)

        # Dedicated styled command snippet widget with copy button
        cmd_box = QFrame()
        cmd_box.setObjectName("cmdBoxFrame")
        cmd_box.setStyleSheet("""
            QFrame#cmdBoxFrame {
                background-color: #0b1329;
                border: 1px solid #1e293b;
                border-radius: 6px;
            }
        """)
        cmd_box_layout = QHBoxLayout(cmd_box)
        cmd_box_layout.setContentsMargins(12, 6, 8, 6)
        cmd_box_layout.setSpacing(8)

        cmd_text = "sudo dnf upgrade web-browser"
        cmd_lbl = QLabel(cmd_text)
        cmd_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cmd_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cmd_lbl.setStyleSheet("""
            QLabel {
                color: #38bdf8;
                font-family: monospace;
                font-size: 9.5pt;
                font-weight: 600;
                border: none;
                background: transparent;
            }
        """)
        cmd_box_layout.addWidget(cmd_lbl, stretch=1)

        copy_btn = QPushButton()
        copy_icon_path = os.path.join(ICONS_PATH, "copy.png")
        if os.path.exists(copy_icon_path):
            copy_btn.setIcon(QIcon(copy_icon_path))
            copy_btn.setIconSize(QSize(16, 16))
        else:
            copy_btn.setText("📋")
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.setToolTip("Copy command to clipboard")
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(30, 41, 59, 0.8);
                border: 1px solid #334155;
                border-radius: 4px;
                padding: 4px 7px;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #38bdf8;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)

        def copy_cmd():
            QApplication.clipboard().setText(cmd_text)
            QToolTip.showText(QCursor.pos(), "Copied to clipboard!", copy_btn)

        copy_btn.clicked.connect(copy_cmd)
        cmd_box_layout.addWidget(copy_btn)

        cmd_box.setVisible(False)
        up_layout.addWidget(cmd_box)

        # Dedicated repository link label
        repo_lbl = QLabel(
            'Repository: <a href="https://github.com/steve-rock-wheelhouser/fedora-repo" '
            'style="color: #60a5fa; text-decoration: none;">'
            "github.com/steve-rock-wheelhouser/fedora-repo</a>"
        )
        repo_lbl.setOpenExternalLinks(True)
        repo_lbl.setTextFormat(Qt.TextFormat.RichText)
        repo_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        repo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        repo_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 8.5pt; border: none; background: transparent;"
        )
        repo_lbl.setVisible(False)
        up_layout.addWidget(repo_lbl)

        notes_lbl = QLabel()
        notes_lbl.setWordWrap(True)
        notes_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 8.5pt; border: none; background: transparent;"
        )
        notes_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        notes_lbl.setVisible(False)
        up_layout.addWidget(notes_lbl)

        dl_btn = QPushButton("🛍️  Update in Microsoft Store")
        dl_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        dl_btn.setStyleSheet("""
            QPushButton {
                background-color: #0284c7;
                color: white;
                font-weight: 700;
                font-size: 9.5pt;
                border: 1px solid #38bdf8;
                border-radius: 6px;
                padding: 8px 22px;
            }
            QPushButton:hover {
                background-color: #0369a1;
                border-color: #7dd3fc;
            }
            QPushButton:pressed { background-color: #075985; }
        """)
        dl_btn.setVisible(False)
        current_target_url = ["https://wheelhouser.com"]
        dl_btn.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(current_target_url[0]))
        )
        up_layout.addWidget(dl_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        # Status text when checking / up-to-date / error
        status_lbl = QLabel("Checking for updates...")
        status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 9pt; font-style: italic; margin-top: 4px;"
        )
        body_layout.addWidget(status_lbl)

        update_frame.setVisible(False)
        body_layout.addWidget(update_frame)

        # Copyright
        copyright_lbl = QLabel(f"Copyright © 2026 {COMPANY_NAME}. All rights reserved.")
        copyright_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        copyright_lbl.setStyleSheet("color: #64748b; font-size: 8pt; margin-top: 6px;")
        body_layout.addWidget(copyright_lbl)

        # Bottom Close Button and Desktop Shortcut Button
        btn_layout = QHBoxLayout()
        desktop_btn = QPushButton("🖥️  Add Desktop Shortcut")
        desktop_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        desktop_btn.setToolTip("Create a shortcut icon on your Desktop")
        desktop_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #38bdf8;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 16px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #38bdf8;
                color: #7dd3fc;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)
        desktop_btn.clicked.connect(lambda: create_desktop_shortcut(dialog))
        btn_layout.addWidget(desktop_btn)

        btn_layout.addStretch()
        ok_btn = QPushButton("OK")
        ok_btn.setMinimumWidth(100)
        ok_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 20px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #475569;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)
        ok_btn.clicked.connect(dialog.accept)
        btn_layout.addWidget(ok_btn)
        body_layout.addLayout(btn_layout)

        main_layout.addWidget(body_widget)

        # --- Update Check / Pre-cached Details Logic ---
        def apply_update_ui(latest_version, target_url, release_notes):
            status_lbl.setVisible(False)
            update_frame.setVisible(True)

            show_notes = False
            if sys.platform == "win32":
                cmd_box.setVisible(False)
                repo_lbl.setVisible(False)
                if target_url and "ms-windows-store" in target_url:
                    up_ver.setText(
                        f"Version <b>{latest_version}</b> is available in the Microsoft Store."
                    )
                    dl_btn.setText("🛍️  Update in Microsoft Store")
                else:
                    up_ver.setText(
                        f"Version <b>{latest_version}</b> is available for Windows."
                    )
                    dl_btn.setText("⬇️  Download Windows Update")
                show_notes = bool(release_notes)
            elif sys.platform == "darwin":
                cmd_box.setVisible(False)
                repo_lbl.setVisible(False)
                up_ver.setText(
                    f"Version <b>{latest_version}</b> is available for macOS."
                )
                dl_btn.setText("⬇️  Download macOS Update")
                show_notes = bool(release_notes)
            else:  # Linux
                up_ver.setText(f"Version <b>{latest_version}</b> is available:")
                cmd_box.setVisible(True)
                repo_lbl.setVisible(True)
                dl_btn.setText("📦  View Fedora Repository")
                if not target_url or "ms-windows-store" in target_url:
                    target_url = "https://github.com/steve-rock-wheelhouser/fedora-repo"

                # If release notes are just repeating the dnf command, suppress notes_lbl to prevent duplicates
                if (
                    release_notes
                    and "sudo dnf" not in release_notes.lower()
                    and "available in fedora" not in release_notes.lower()
                ):
                    show_notes = True
                else:
                    show_notes = False

            current_target_url[0] = target_url or "https://wheelhouser.com"

            if show_notes:
                notes_lbl.setText(release_notes)
                notes_lbl.setVisible(True)
            else:
                notes_lbl.setVisible(False)
            dl_btn.setVisible(True)

        if self._pending_update_version:
            apply_update_ui(
                self._pending_update_version,
                self._pending_update_url,
                self._pending_update_notes,
            )
        else:
            self.update_thread = UpdateCheckThread(APP_VERSION)

            def on_update_available(latest_version, target_url, release_notes):
                self.on_background_update_available(
                    latest_version, target_url, release_notes
                )
                apply_update_ui(latest_version, target_url, release_notes)

            def on_up_to_date():
                status_lbl.setText("✅ You are on the latest version.")
                status_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")

            def on_update_error(err):
                status_lbl.setText("Could not check for updates.")
                status_lbl.setStyleSheet("color: #ef4444; font-size: 9pt;")
                logger.warning(f"Update check failed: {err}")

            self.update_thread.update_available.connect(on_update_available)
            self.update_thread.up_to_date.connect(on_up_to_date)
            self.update_thread.error.connect(on_update_error)
            self.update_thread.start()

        dialog.exec()


MainWindow = WebBrowserApp


# ===========================================================================================
# --- Application Entry Point ---
# ===========================================================================================
if __name__ == "__main__":

    if os.name == "nt":
        # Static AppUserModelID (AUMID) for Windows Explorer and Taskbar grouping
        myappid = f"{APP_AUTHOR}.{APP_NAME}"
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass

    # Configure application metadata before QApplication initialization
    QCoreApplication.setApplicationName("com.wheelhouser.web-browser")
    QCoreApplication.setOrganizationName("Wheelhouser LLC")
    QCoreApplication.setOrganizationDomain("wheelhouser.com")
    QGuiApplication.setDesktopFileName("com.wheelhouser.web-browser")

    # Suppress duplicate portal registration and webengine context noise on Linux
    QLoggingCategory.setFilterRules(
        "qt.qpa.services.warning=false\nqt.qpa.services=false\nqt.webenginecontext.warning=false"
    )

    # Ensure bundled Qt plugins (e.g. Adwaita Wayland decoration on EL10) are registered
    # Only load bundled plugins on RHEL-family distributions when system plugin is absent
    _is_rhel_family = os.path.exists("/etc/redhat-release")
    if _is_rhel_family and platform.machine() in ("x86_64", "AMD64") and not os.path.exists("/usr/lib64/qt6/plugins/wayland-decoration-client/libadwaita.so"):
        _app_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for _p_dir in [os.path.join(_app_root, "plugins"), "/opt/web-browser/plugins"]:
            if os.path.isdir(_p_dir):
                QCoreApplication.addLibraryPath(_p_dir)

    app = QApplication(sys.argv)
    app_icon = resource_path(os.path.join("assets", "icons", "icon.png"))
    if os.path.exists(app_icon):
        app.setWindowIcon(QIcon(app_icon))
    app.setStyle("Fusion")
    app.styleHints().setColorScheme(Qt.ColorScheme.Dark)

    # Professional Wheelhouser Dark Palette
    dark_palette = QPalette()
    dark_palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.BrightText, QColor(255, 0, 0))
    dark_palette.setColor(QPalette.ColorRole.Link, QColor(0, 122, 255))
    dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(0, 122, 255))
    dark_palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
    app.setPalette(dark_palette)

    import signal

    signal.signal(signal.SIGINT, lambda *args: os._exit(0))
    signal.signal(signal.SIGTERM, lambda *args: os._exit(0))
    sig_timer = QTimer()
    sig_timer.timeout.connect(lambda: None)
    sig_timer.start(500)

    window = WebBrowserApp()

    # Headless / CI Smoke Test auto-exit:
    # If launched offscreen or with --smoke-test / --test-init, cleanly exit after verifying UI initialization
    is_smoke = (
        os.environ.get("QT_QPA_PLATFORM") == "offscreen"
        or "--smoke-test" in sys.argv
        or "--test-init" in sys.argv
    )
    if is_smoke:
        def _smoke_exit():
            try:
                window.close()
            finally:
                os._exit(0)

        QTimer.singleShot(1500, _smoke_exit)

    if getattr(window, "saved_was_maximized", False):
        window.showMaximized()
    else:
        window.show()
    sys.exit(app.exec())

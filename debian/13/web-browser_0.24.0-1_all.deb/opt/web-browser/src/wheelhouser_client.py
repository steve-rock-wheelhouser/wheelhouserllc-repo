#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Client library for connecting to the Wheelhouser AI Orchestrator via WebSockets.
#
# Copyright (C) 2026 Wheelhouser LLC
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Version Change Log (Roadmap):
# 0.1.0 - Initial version
# 0.2.0 - Added automatic reconnection and heartbeat
# 0.3.0 - Added message queue for sending commands from GUI apps
# 0.4.0 - Improved error handling and logging
# 0.5.0 - Added HTTPS support
# 0.6.0 - Added bidirectional RPC response handling (request_id observation returns)
# 0.6.1 - Guard NoneType websocket send calls, add persistent session pooling, and quote WebSocket URI
# 0.6.2 - Auto-detect plain HTTP/WS vs SSL, default secure to False for local orchestrator, and add instant protocol fallback

import os
import asyncio
import json
import threading
import queue
try:
    import websockets
except (ImportError, ModuleNotFoundError):
    websockets = None
import requests
import ssl
import urllib.parse
import urllib3

# Suppress insecure request warnings for local development (since we use self-signed certs)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from typing import Optional, Callable, Any


class WheelhouserClient:
    """
    A reusable client for connecting to the Wheelhouser AI Orchestrator via WebSockets.
    Handles automatic reconnection, heartbeats, bidirectional RPC responses, and command receiving.
    """
    on_connect: Optional[Callable[[], Any]] = None
    on_disconnect: Optional[Callable[[], Any]] = None

    def __init__(self, app_name: str, host: str = "localhost", port: int = 7800, secure: Optional[bool] = None):
        self.app_name = app_name
        self.host = host
        self.port = port
        if secure is None:
            # Default to False for local orchestrator development unless WAI_SECURE=1 is set
            self.secure = os.environ.get("WAI_SECURE", "").lower() in ("1", "true", "yes")
        else:
            self.secure = secure

        self._update_protocols(self.secure)
        self.websocket = None
        self.connected = False
        self.callback = None
        self.loop = None
        self.thread = None
        self.running = False
        self.send_queue = queue.Queue()
        self.on_connect = None
        self.on_disconnect = None
        self.http_session = requests.Session()

    def _update_protocols(self, secure: bool):
        self.secure = secure
        self.protocol_ws = "wss" if secure else "ws"
        self.protocol_http = "https" if secure else "http"
        quoted_app = urllib.parse.quote(self.app_name)
        self.uri = f"{self.protocol_ws}://{self.host}:{self.port}/ws/{quoted_app}"
        self.api_url = f"{self.protocol_http}://{self.host}:{self.port}"

    def send_message(self, data):
        """Queues a message to be sent to the Orchestrator."""
        self.send_queue.put(data)

    def send_response(self, request_id, result=None, status="success"):
        """Sends an RPC response back to the orchestrator for a specific request_id."""
        self.send_message({
            "type": "response",
            "request_id": request_id,
            "result": result or {"status": "executed"},
            "status": status
        })

    def set_command_callback(self, callback):
        """Sets the function to call when a command is received from the Orchestrator."""
        self.callback = callback

    def start(self):
        """Starts the connection loop in a background thread."""
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True, name=f"WAI-Client-{self.app_name}")
        self.thread.start()

    def stop(self):
        """Stops the client connection cleanly."""
        self.running = False
        if self.http_session:
            try:
                self.http_session.close()
            except Exception:
                pass

    def _run_loop(self):
        """Internal method to run the asyncio loop."""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._connect_forever())

    async def _connect_forever(self):
        """Main connection logic with retry."""
        if websockets is None:
            print(f"[{self.app_name}] websockets module not installed; WAI client disabled.")
            return

        while self.running:
            ssl_context = None
            if self.secure:
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE

            try:
                print(f"[{self.app_name}] Connecting to {self.uri}...")
                async with websockets.connect(self.uri, ssl=ssl_context) as websocket:
                    self.websocket = websocket
                    self.connected = True
                    print(f"[{self.app_name}] Connected to Orchestrator.")
                    if self.on_connect:
                        try:
                            self.on_connect()
                        except Exception as e:
                            print(f"[{self.app_name}] Error in on_connect: {e}")

                    # Start Heartbeat Task
                    heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                    sender_task = asyncio.create_task(self._sender_loop())

                    try:
                        async for message in websocket:
                            if not self.running:
                                break
                            data = json.loads(message)
                            if self.callback:
                                cb_result = self.callback(data)
                                req_id = data.get("request_id")
                                if req_id:
                                    self.send_response(req_id, result=cb_result)
                    except getattr(websockets, "ConnectionClosed", Exception):
                        print(f"[{self.app_name}] Connection lost.")
                    finally:
                        self.connected = False
                        self.websocket = None
                        if self.on_disconnect:
                            try:
                                self.on_disconnect()
                            except Exception as e:
                                print(f"[{self.app_name}] Error in on_disconnect: {e}")
                        heartbeat_task.cancel()
                        sender_task.cancel()
            except Exception as e:
                err_str = str(e)
                if self.secure and ("WRONG_VERSION_NUMBER" in err_str or "wrong version number" in err_str.lower()):
                    print(f"[{self.app_name}] Server does not use SSL. Falling back to unencrypted ws:// connection...")
                    self._update_protocols(secure=False)
                    continue
                print(f"[{self.app_name}] Connection failed: {e}. Retrying in 5s...")
                await asyncio.sleep(5)

    async def _heartbeat_loop(self):
        """Sends an in-band heartbeat over the existing WebSocket every 10 seconds."""
        while self.running and self.connected:
            try:
                if self.websocket:
                    await self.websocket.send(json.dumps({"type": "heartbeat"}))
                await asyncio.sleep(10)
            except Exception:
                break

    async def _sender_loop(self):
        """Sends messages from the queue."""
        while self.running and self.connected:
            try:
                while not self.send_queue.empty():
                    msg = self.send_queue.get_nowait()
                    if self.websocket:
                        await self.websocket.send(json.dumps(msg))
                await asyncio.sleep(0.05)
            except Exception:
                break

    def resolve(self, user_input, current_state=None):
        """
        Sends user input to the Orchestrator for intent resolution using pooled HTTP session.
        Returns the JSON response containing the command pipeline.
        """
        if current_state is None:
            current_state = {}

        # Ensure app_name is in the state so the Orchestrator loads the right manifest
        current_state["app_name"] = self.app_name

        payload = {
            "user_input": user_input,
            "current_state": current_state
        }

        try:
            response = self.http_session.post(
                f"{self.api_url}/resolve",
                json=payload,
                timeout=120,
                verify=not self.secure
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.SSLError as ssl_err:
            if self.secure and ("WRONG_VERSION_NUMBER" in str(ssl_err) or "wrong version number" in str(ssl_err).lower()):
                print(f"[{self.app_name}] Server does not use SSL on /resolve. Retrying via http://...")
                self._update_protocols(secure=False)
                try:
                    response = self.http_session.post(
                        f"{self.api_url}/resolve",
                        json=payload,
                        timeout=120,
                        verify=False
                    )
                    response.raise_for_status()
                    return response.json()
                except Exception as retry_err:
                    print(f"[{self.app_name}] Resolution retry failed: {retry_err}")
                    return {"error": str(retry_err), "pipeline": [], "response_text": "Connection error."}
            print(f"[{self.app_name}] Resolution failed: {ssl_err}")
            return {"error": str(ssl_err), "pipeline": [], "response_text": "Connection error."}
        except Exception as e:
            print(f"[{self.app_name}] Resolution failed: {e}")
            return {"error": str(e), "pipeline": [], "response_text": "Connection error."}
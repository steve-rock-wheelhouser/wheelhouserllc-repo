#!/usr/bin/python3
# -*- coding: utf-8 -*-
# File-Browser is a stand-alone file browser designed to completely remove the neeed for a native OS file browser on Linux, Windows, and macOS.
# Anyone who does cross-platform development is probably sick of having to open the native file explorer just to manage files, and File-Browser is designed to solve that problem by providing a fast, modern, and feature-rich file browser built with Python and PySide6 that works the same on every platform. It also includes AI features powered by the WAI Assistant framework.
# Having a single unified browser that works the same on every platform will save developers a huge amount of time and hassle, and allow them to focus on their work instead of dealing with the quirks and inconsistencies of different OS file explorers.
# 
# Copyright (C) 2026 Wheelhouser LLC
#
# This software is subject to the terms and conditions of the End-User License
# Agreement (EULA) provided with this software.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
#
# --- Setup Instructions ---
# Active the venv on linux/macOS:
# python -m venv .venv
# source .venv/bin/activate
# pip install --upgrade pip
#
# On Windows (PowerShell):
# python -m venv .venv
# .venv\Scripts\Activate.ps1
# Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
# pip install -r requirements.txt
# pip install --force-reinstall -r requirements.txt
#
#===========================================================================================

# Version Change Log (Roadmap):
# 0.1.0 - Initial development of File-Browser using basic Wheelhouser dark theme UI and the WAI Assistant framework for AI features. Core file browsing, License management and payment flow integrated with Stripe. Update checking implemented. Performance optimizations for large files underway. Initial testing and bug fixes in progress.
# 0.1.1 - Make the Quick Access sidebar start open in the visible state with a fixed minimum width. 
# 0.1.2 - Make Ctrl+h hide/unhide the "hidden" folders (those starting with a dot) in the file tree view, and show them again if Ctrl+h is pressed again. This is a common shortcut for toggling hidden files in file browsers.
# 0.1.3 - Add a "Downloads" quick access item to the sidebar, linking to the user's default downloads folder.
# 0.1.4 - Use the assets/icons/up.png, down.png, left.png, right.png, home.png icons for the navigation buttons in the toolbar instead of text. This will give it a more polished and modern look.
# 0.1.5 - Add a button to Add to Quick Access sidebar. When clicked, it should add the current folder to the sidebar for easy access later. This will allow users to quickly navigate to frequently used folders.
# 0.1.6 - Add a button below the Quick Access sidebar to delete items from the sidebar. When clicked, it should allow the user to select an item from the sidebar and remove it. This will help users manage their Quick Access shortcuts.
# 0.1.7 - Make the current dir persist across sessions. When the user closes and reopens the app, it should open to the last directory they were viewing instead of defaulting to home. This will improve user experience by remembering their last location.
# 0.1.8 - Clicking on an empty area of the file tree view should deselect any selected items and clear the selection and pull up a drop down menu which will include a "touch" function to create a folder or a file. This will make it easier to create new files and folders in the current directory without having to navigate away or use the file explorer context menu.
# 0.1.9 - Right clicking on a file or folder should bring up a context menu with options to "Open", "Copy", Copy to", "Move", "Move to", "Rename", "Delete", and "Properties". This will provide quick access to common file operations directly from the file tree view.
# 0.2.0 - If a file or folder is "Copied", when the user clicks on an empty area of the file tree view and selects "Paste", it should paste the copied file or folder into the current directory. This will allow users to easily copy and paste files and folders within the app without having to use the system clipboard or navigate away.
# 0.2.1 - Make the "Add to Quick Access" button square instead of rectangular, so its easier to find and click on.
# 0.2.2 - Make the "Destination Folder" UI an exact copy of the source folder in UI layout with the buttons and path bar.  It does not need an "About".
# 0.2.3 - Refactor the drop down menu when clicking on a folder to be: Open, Cut, Copy, Move to.., Copy to.. Rename, Compress.., Move to Trash, Properties.
# 0.2.4 - Refactor the drop down menu when clicking on an empty area to be: New Folder, Open With.., Open in Console, Paste (if clipboard has file), Select All, Properties.
# 0.2.5 - Add a "Preferences" Button to enable users to customize the app settings, such as view type (list, grid, etc), sorting options, and other UI preferences. This will allow users to tailor the app to their liking and improve their overall experience.
#           - I want to be able to set the default view type FOR EACH DIRECTORY to: "List View", "Tree View", "Tile View" (with small, medium, large) and have that persist across sessions. This will allow users to choose their preferred way of browsing files and make it the default when they open the app.
#           - There needs to be an option to "Apply to ALL" with a confirm dialog, so users can set their preferred view type for all directories at once if they want. This will make it easier for users to customize the app to their liking without having to set the view type for each directory individually.
# 0.2.6 - Bug: Size of files does not update.
# 0.3.0 - On a seperate thread, have the app scan the file system in the background and generate thumbnails for files and folders, and display those thumbnails in the file tree view. This will make it easier to visually identify files and folders, and provide a more modern and polished user experience.
# 0.3.1 - On a seperate background thread, have the app scan the folders to get the size of the folders and publish it in the "Size" column.
# 0.3.2 - Have sort on Size include the Suffixes (KB, MB, GB, etc) and sort correctly based on the actual size instead of just alphabetically. This will make it easier to sort files by size and find large files that may be taking up space.
# 0.3.3 - "Select All" needs to highlight all the items in the folders in the current directory.
# 0.3.4 - Make the Folder Size scan persistent across sessions.
# 0.3.5 - "Select All" + Copy must actually copy all of the selected files.  It is only copying one file. 
# 0.3.6 - Rename must work and update the view immediately after renaming a file or folder.  It is currently renaming the file but not refreshing the view, so it looks like the rename didn't work until you navigate away and back to the folder.
# 0.3.7 - In the "Rename" UI make with the width wider and the Ok and Cancel buttons, and if the object is a regular file, and not a directory, look for a ".*" (.txt, .xls, .xlsx, .json, etc) of file formats and assume that the extension is not going to be changed.  Therefore, only highlight the file name or editing and not the extension. 
# 0.3.8 - If a file or folder is selected, pressing the delete key should move it to the trash instead of permanently deleting it.  This will provide a safer way to delete files and allow users to recover files if they accidentally delete something.
# 0.3.9 - Let ctrl+a, ctrl+x, ctrl+c, ctrl+z, ctrl+y work for select all, cut, copy, undo, and redo operations.  This will provide a more familiar and efficient way to perform common file operations using keyboard shortcuts.
# 0.3.10 - Add a "Confirm Delete" option in the Preferences (set to enabled by default).  These must be persistent across sessions.
# 0.3.11 - ctrl-z should undo the last file operation (rename, move, copy, delete, etc) and ctrl-y should redo the last undone operation.  This will provide a way for users to easily undo and redo file operations if they make a mistake or change their mind.
# 0.3.12 - Add "Tabs" to the UI so users can have multiple folders open at once in the same window, and easily switch between them. Each tab would have its own file tree view and navigation history, but they would all share the same Quick Access sidebar and other settings. This will allow users to work with multiple folders more efficiently without having to open multiple windows.
# 0.3.13 - Add a built-in shell terminal that opens in the current directory and uses the linux command set (ls, cd, mv, cp, rm, etc) on all platforms. This will allow users to perform command line operations directly within the app without having to open a separate terminal window.
#            - Put the terminal in a collapsable tray, like the Quick Access sidebar, so it can be easily hidden and shown when needed. It should also be resizable so users can adjust the size of the terminal area as needed. This will provide a flexible and convenient way to access the terminal without taking up too much screen space when it's not needed.
#            - Construct the terminal as a seperate module that can be imported and used in other applications, like Notez. This will allow the terminal functionality to be reused across multiple apps and provide a consistent user experience.
# 0.3.14 - Add extract to the context menu when right clicking on zip files, which will extract the zip file into the current directory. This will provide a convenient way to extract zip files directly within the app without having to use a separate extraction tool.
# 0.3.15 - Always make the "About" button the right most button in the toolbar, and make it open a dialog with the app name, version, company name, website, and license information. This will provide users with easy access to important information about the app and its licensing.
# 0.3.16 - Add Xterm color support to the terminal, so it can display colored output from commands that use color (like ls --color). This will make the terminal output more visually appealing and easier to read.
# 0.3.17 - Added a Preference for setting the number of lines by default in the terminal, and make it persistent across sessions. This will allow users to customize the terminal to their liking and improve their overall experience.
# 0.3.18 - Add a Preference to set the number of rows the terminal shows when launched.
# 0.3.19 - If I close the right-most terminal, the next terminal to the left should become the new right-most terminal and get the "About" button in the toolbar.  This will ensure that the "About" button is always easily accessible in the toolbar, even when multiple terminals are open.
# 0.3.20 - Reverse the background color coding for the active and not active tabs in the terminal widget, making the active tab Lighter and the inactive tabs darker, improving visual clarity and making it easier for users to identify which terminal tab is currently active.
# 0.3.21 - Remove the padding between the Quick Access and around the main window to make it more compact.
# 0.3.22 - Add a search bar to the toolbar that allows users to search for files and folders in the current directory. This will provide a convenient way to quickly find specific files and folders without having to manually browse through the file tree.
# 0.3.23 - Add C:\Users\<username>\OneDrive\Pictures to the Quick Access by defualt, since that is where the user's photos are stored on Windows, and it would be convenient for users to have quick access to their photos from the file browser.
# 0.3.24 - Make the navigation buttons the same size as the buttons on the right (prefernces, add, etc).
# 0.3.25 - Make the min/max Quick Access state persistent across sessions, so if the user minimizes the Quick Access sidebar and then closes and reopens the app, it should remember that they had it minimized and keep it minimized. This will improve user experience by remembering their preferred layout.
# 0.3.26 - Make Tabs persistent across sessions, so if the user has multiple tabs open and then closes and reopens the app, it should restore those tabs and their respective directories. This will allow users to pick up right where they left off without having to manually reopen each tab and navigate back to their directories.
# 0.3.27 - If a user resizes the window, make it persistent across sessions, so when they close and reopen the app, it should remember the size they set and open to that size. This will improve user experience by remembering their preferred window size and layout.
# 0.3.28 - The search bar should filter the files and folders in the current directory as the user types, showing only those that match the search query. This will provide a convenient way to quickly find specific files and folders without having to manually browse through the file tree.
# 0.3.29 - Multiple select and "Copy to" does not copy all of the files and folders over to the new folder.
# 0.3.30 - Multiple select and "Move to Trash" does not move all of the files and folders to the trash.
# 0.3.31 - Error: Failed to "Move to Trash" for a folder with contents.
# 0.3.32 - Do not show the "About" button in the Terminal.  Only show the one for the file browser.
# 0.3.33 - In icon view, display more of the file name and use text wrapping to show the full name of the file instead of truncating it with ellipses. This will make it easier to identify files with long names in icon view and improve the overall user experience. 
# 0.3.34 - Bug fix: file name view 
# 0.3.35 - filter out NTUSER.DAT and other system files on Windows that the user doesn't need to see and can't do anything with, and that just clutters up the view and causes confusion.  This will make the file browser cleaner and easier to use on Windows by hiding unnecessary system files.
# 0.3.36 - filter out ntuser.ini file as well
# 0.4.0 - Add USB devices to the Quick Access sidebar when they are connected, and remove them when they are disconnected. This will provide users with quick access to their USB devices directly from the file browser without having to navigate through the file tree.
# 0.4.1 - Have the "Remove Item" button update to "Eject USB" when a USB device is selected in the Quick Access sidebar, and have it safely eject the USB device when clicked. This will provide a convenient way for users to safely eject their USB devices directly from the file browser without having to use the system's file explorer or other tools.
# 0.4.2 - Have the eject USB device run on its own thread so it doesn't freeze the UI while it's ejecting, and show a progress dialog while it's ejecting that shows the progress of the ejection and a cancel button to cancel the ejection if it's taking too long. This will improve the user experience by keeping the UI responsive during the ejection process and providing feedback on the progress of the ejection.
# 0.4.3 - When a tab is closed, if it is the active tab, the next tab to the left should become the new active tab.  If there are no more tabs to the left, then the next tab to the right should become active.  This will ensure that there is always an active tab when a tab is closed and improve the user experience when managing multiple tabs.
# 0.4.4 - Add Quick Access support for connecting to an Android phone via USB and browsing the phone's file system directly from the file browser. This will provide users with a convenient way to access and manage their Android phone's files directly from the file browser without having to use a separate tool or navigate through the file tree to find the phone's storage.
# 0.4.5 - Refined Android device naming and ensured temporary devices are not saved to Quick Access settings.
# 0.4.6 - Add extensive debug logging to the Quick Access panel loading and USB detection features to diagnose why items may not be appearing.
# 0.4.7 - On Windows, use PowerShell to detect WPD (MTP) devices like Android phones, as psutil does not see them as drives.
# 0.4.8 - On Windows, detect Android device media folders (Pictures, Videos, etc.) and add them to Quick Access, opening them in the native Windows Explorer when clicked.
# 0.4.9 - Make the "Name" column in the file tree view wider and the "Size" column narrower, so more of the file name is visible without truncation, and the size column doesn't take up too much space. This will improve the user experience by making it easier to read file names while still providing size information.
# 0.4.10 - Make the "Name" column narrower to better balance the layout between file names and other columns.
# 0.4.11 - Add the image thumbnail to the left of the file name in the "Name" column, and make it so that if a thumbnail is available for a file, it will show the thumbnail instead of the generic file icon. This will make it easier to visually identify files and provide a more modern and polished user experience.
# 0.4.12 - Add sort on File Name, Size, Type, and Date Modified columns, and make sure that the sorting works correctly for each column (e.g. sorting by size should sort based on actual file size, not just alphabetically). This will allow users to easily sort their files based on different criteria and find what they're looking for more efficiently.
# 0.4.13 - Add a cache for the image thumbnails so that they don't have to be regenerated every time the user navigates to a folder, which will improve performance when browsing folders with many images. The cache should be persistent across sessions so that thumbnails are saved and loaded from disk.
# 0.4.14 - Add image caching for regular files as well, not just thumbnails, so that icons for files and folders are also cached and load faster when navigating through the file tree. This will further improve performance and provide a smoother user experience when browsing files and folders.
# 0.4.15 - Add a context menu to the Android device view to allow copying files from the phone to the computer. This will allow users to transfer files from their mobile devices to their local storage.
# 0.4.16 - Make the blue lines in the UI a little less bright, so they are easier on the eyes and don't cause eye strain during extended use. This will improve the overall user experience by providing a more comfortable and visually appealing interface.
# 0.4.17 - Wrap long file names on "_" and or "-" in icon view, so that more of the file name is visible without truncation, while still keeping the layout clean and organized. This will make it easier to identify files with long names in icon view and improve the overall user experience.
# 0.4.18 - Reverted 0.4.17 due to layout issues in icon view.
# 0.4.19 - Re-implemented word wrapping for file names in icon view with improved layout handling to prevent overlapping icons. Increased grid size and added zero-width spaces for better wrapping on special characters.
# 0.4.20 - Improved icon view text wrapping to display full file names. Removed fixed grid size and implemented dynamic sizing in delegate to prevent overlap while allowing full text display.
# 0.4.21 - The navigation buttons (back, forward, up, and home) should be transparent background and boarder when not hovered over or actively being used. 
# 0.4.22 - Cleaned up navigation buttons.
# 0.4.23 - Added compatibility for termainl vs Terminal in the imports
# 0.4.24 - Updated the terminal to version 0.23.2
# 0.4.25 - Fix the significant delay when closing the app.  It sits there for about 4 seconds before closing.
# 0.5.0 - Add sorting by "Name", "Size", "Type", and "Date Modified" by clicking on the column headers.  
# 0.5.1 - Update the Tab css style to be consistent with Terminal.
# 0.5.2 - Ensure that the license manager is pointing to the correct URL for File Browser.
# 0.5.3 - Remove the white border arund the main view window
# 0.5.4 - Add "Open With..." to the context menu when right clicking on a file, which will open a dialog that allows the user to select an application to open the file with. This will provide users with more flexibility in how they open their files directly from the file browser without having to navigate through the file tree to find the file and then use the system's "Open With" functionality.
# 0.5.5 - Format the Open With dialog buttons to be the same size and make the default path for the applications be ~/AppData/Local/Programs on Windows and /Applications on macOS, and /usr/bin on Linux so that users are taken directly to the folder where their applications are likely to be located when they open the dialog. This will improve the user experience by making it easier and faster for users to find and select the application they want to use to open their files.
# 0.5.6 - Include the App Icon in the "Open With" dialog.
# 0.5.7 - Added --file-reference-choice=runtime \ to Fedora builds.
# 0.5.8 - Refactored project layout to Wheelhouser standard: established build-msix/ packaging suite, build-linux/, and build-mac/; updated build scripts, resolved module imports, and removed legacy root build scripts and Inno Setup references.
# 0.5.9 - Updated the copy process in the build script to also include the "commands" folder and "plugin_manager.py" from the Terminal project.
# 0.5.10 - Make the copy process dynamically reference the Terminal project relative to the location of the build script.
# 0.5.11 - Include the terminal assets/icons in the RPM build by copying them to the appropriate location in the build directory.
# 0.5.12 - Fixed resource_path to resolve assets from project root when running from src/, set application icon on both QApplication and main window, and resolved TerminalWidget import paths across environments.
# 0.6.0 - Updated About dialog to Wheelhouser standard aesthetic with dark navy gradient header, metadata, integrated cross-platform in-app updater with background checking, update button indicator styling, and desktop shortcut creation.
# 0.6.1 - Add ENABLE_LICENSING configuration flag (default False for Store release), decouple licensing from AI, and hide license status badge and Activate button when licensing is disabled.
# 0.6.2 - Guard TerminalWidget initialization and attribute calls against None, expand import candidates for PyInstaller frozen runtimes, and bundle terminal package into MSIX distribution.
# 0.6.3 - Adopt CANONICAL_AGENTS.md policy, integrate Wheelhouser Terminal into Linux RPM packaging, establish 3-tier automated test suite with pre-build gate, and create release tracking.
# 0.7.0 - Correct embedded terminal background color to match the file browser main window (#1e1e1e), register File Browser theme, add preference setting, and gracefully fallback when Terminal companion application settings are unconfigured.
# 0.7.1 - Resolve static analysis typing and enum scoping issues across PySide6 and cross-platform subsystems, configure import type annotations for psutil and requests, and fix terminal background color matching.
# 0.7.2 - Add icons to Quick Access sidebar items matching web-browser icon styling, support downloads, folder, and device icons, and optimize item spacing.
# 0.7.3 - Unify Quick Access folder icon styling so Home and Downloads match Desktop and Documents, and add Pictures, Music, and Videos to default Quick Access.
# 0.7.4 - Add Trash to Quick Access with dynamic full/empty icon state tracking, and add Quick Access item reordering with Move Up/Down buttons, context menu, and drag-and-drop.
# 0.7.5 - Make sorting persistent across sessions, keep folders grouped on top across all sort columns, and add GNOME Files style Empty Trash banner and context menus.
# 0.7.6 - Trash/ and Home/ cannot be removed from Quick Access (disabled remove item button and context menu), and file icons use vector SVG icons by file type from Text-Editor.
# 0.7.7 - Up, Back, Forward, and Home toolbar navigation buttons styled and unified with web-browser (32x32 button size, transparent style with #007AFF hover/pressed states, and matching vibrant blue squircle icons).
# 0.7.8 - Linux executable files (ELF binaries, .bin, .run, .elf, .appimage, a.out, and executable permission files) use authentic GNOME Files generic Linux executable icons; .rpm, .deb, and .iso files use package icons.
# 0.7.9 - Make psutil dependency optional with graceful fallback in USBDetector, resolve Bash 3.2 unbound variable error in macOS build script, add macOS build_mac.sh packaging and notarization suite with File-Browser.spec, add standardized Linux RPM output routing and non-interactive compiler handling, and update test suite environment resolution.
# 0.8.0 - Add comprehensive Android phone USB support: multi-platform device detection via GVFS MTP and FUSE on Linux, WPD on Windows, and volume monitoring on macOS; human-readable friendly device naming via GIO and WPD; direct Quick Access browsing with vector smartphone icons; safe clean unmount/disconnect handling; and MTP performance guards against high-latency recursive folder scanning.
# 0.8.1 - Resolve static analysis typing issues in USBDetector by adding explicit type annotations for partition and device deduplication lists.
# 0.8.2 - Update Quick Access minimize/expand toggle button tooltip to indicate Quick Access ('Minimize/Expand Quick Access') and unify button styling with web-browser 4px rounded radius corners and #007AFF hover styling.
# 0.8.3 - Make Terminal Preferences (font family, font size, scrollback lines, initial rows) and terminal themes fully persistent across sessions in FileBrowserApp, prevent theme overrides on restart, and synchronize terminal settings on dialog accept and application shutdown.
# 0.8.4 - Vendor standalone Wheelhouser Terminal package directly into repository root, bundle terminal assets and modules into macOS and Windows distribution packages, pin cryptography<45 to prevent OpenSSL symbols runtime crash on Intel Mac, and resolve defect tickets BUG-20261005_163312, BUG-20261005_164017, BUG-20261005_164501, and BUG-20261005_164407.
# 0.8.5 - Eliminate duplicate desktop entries on Debian by installing single canonical com.wheelhouser.file-browser.desktop, configure QCoreApplication.setApplicationName, QGuiApplication.setDesktopFileName, and StartupWMClass=com.wheelhouser.file-browser for Wayland/GNOME icon parity, and resolve BUG-20261005_200855 and BUG-20261005_200551.
# 0.9.0 - Completely remove commercial licensing system (license_manager.py, reset_license.py, PaymentDialog, activation mechanisms, and trial gates), fully unlocking all application features.
# 0.9.1 - Integrate refactored Wheelhouser Terminal v0.24.11 (src/main.py architecture), purge vendored terminal license files (license_manager.py, reset_license.py), and establish clean module compatibility shims.
# 0.9.2 - Synchronize vendored Wheelhouser Terminal to v0.25.0 with PySide6/Qt6 scoped enum modernizations and configure project-level pyrefly definitions.
# 0.9.3 - In shutdown() cleanly invoke self.terminal.cleanup() to prevent orphaned terminal processes and 'QProcess: Destroyed while process is still running' warnings upon window close, and synchronize vendored terminal to v0.28.0 with PTY support for interactive SSH.
# 0.9.4 - Fix embedded terminal plugin resolution on RPM distributions (Fedora 44, Rocky 10, Alma 10) by eliminating package path shadowing, adding robust spec loader fallback in vendored terminal compatibility shims, and making RPM launcher wrapper use dynamic Python interpreter discovery.
# 0.9.5 - Eliminate build hanging once and for all: remove legacy Nuitka compilation and sudo dnf/pip installations from build_rpm.sh, standardize RPM packaging architecture with canonical file-browser.spec, add master build-linux/build.sh and install.sh, fix Windows compile.ps1 terminal path resolution, add notary timeout to macOS packaging, and add watchdog timeout to Windows interactive task runner.
#
#===========================================================================================
#--- Imports ---
#===========================================================================================
import sys
import os
from typing import TYPE_CHECKING, Any, cast, Optional, Dict, List

# Ensure src directory is in sys.path for direct script execution and submodule imports
src_dir = os.path.dirname(os.path.abspath(__file__))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

import ctypes
if os.name == 'nt':
    import ctypes.wintypes
import json
import logging
import shutil
import subprocess
try:
    import psutil  # type: ignore
except ImportError:
    psutil = None
import queue
import zipfile
import re
import time
import tempfile
import hashlib
try:
    from platformdirs import user_data_dir
except ImportError:
    def user_data_dir(app_name="FileBrowser", app_author=None):
        import os, sys
        if sys.platform == "win32":
            base = os.environ.get("APPDATA", os.path.expanduser("~"))
            return os.path.join(base, app_author or "", app_name) if app_author else os.path.join(base, app_name)
        elif sys.platform == "darwin":
            return os.path.expanduser(f"~/Library/Application Support/{app_name}")
        else:
            xdg = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
            return os.path.join(xdg, app_name)
from PySide6.QtWidgets import (QApplication, QMainWindow, QFileSystemModel, QTreeView,
                               QVBoxLayout, QWidget, QPushButton,
                               QLabel, QListWidget, QLineEdit,
                               QMessageBox, QBoxLayout, QGridLayout, QTabWidget, QSplitter, QTabBar, QSpinBox,
                               QDialog, QProgressBar, QHBoxLayout, QFileDialog,
                               QListWidgetItem, QMenu, QInputDialog, QFormLayout, QStyledItemDelegate, QStyleOptionViewItem, QFileIconProvider,
                               QListView, QStackedWidget, QComboBox, QCheckBox, QAbstractItemView, QFrame, QProgressDialog, QToolTip, QLayout)
from PySide6.QtCore import (Qt, QStandardPaths, QSettings, QUrl, QTimer, QDir, QSortFilterProxyModel, QSize, QModelIndex, QFileInfo, QMimeData, QThread, Signal, QFile, QByteArray, QRectF, QCoreApplication)
from PySide6.QtGui import (QPixmap, QIcon, QDesktopServices, QKeySequence, QShortcut, QImageReader, QImage, QStandardItemModel, QStandardItem, QPalette, QColor, QCursor, QPainter, QGuiApplication)
from PySide6.QtSvg import QSvgRenderer

from wai_assistant import WAIAssistantManager
from update_manager import UpdateCheckThread


def _get_win_startupinfo():
    """Safely retrieves a Windows STARTUPINFO object with hidden window flags, returning None on non-Windows."""
    if hasattr(subprocess, "STARTUPINFO"):
        si = getattr(subprocess, "STARTUPINFO")()
        si.dwFlags |= getattr(subprocess, "STARTF_USESHOWWINDOW", 0)
        return si
    return None

# Import from the standalone terminal project or local vendored folder
terminal_candidates = [
    os.path.abspath(os.path.dirname(__file__)),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'terminal')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'terminal', 'src')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'terminal')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), 'terminal')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Terminal')),
    os.path.abspath(os.path.join(os.path.dirname(__file__), 'Terminal')),
]

# For PyInstaller bundled / frozen application runtimes:
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    terminal_candidates.insert(0, os.path.join(sys._MEIPASS, "terminal"))
    terminal_candidates.insert(0, sys._MEIPASS)

exe_dir = os.path.dirname(sys.executable)
terminal_candidates.extend([
    os.path.join(exe_dir, "_internal", "terminal"),
    os.path.join(exe_dir, "_internal"),
    os.path.join(exe_dir, "terminal"),
])

for p in terminal_candidates:
    if os.path.exists(p) and p not in sys.path:
        # Avoid prepending a directory named 'terminal' ahead of its parent if it is a package,
        # which would shadow the 'terminal' package with 'terminal.py'.
        if os.path.basename(p).lower() == 'terminal' and os.path.isfile(os.path.join(p, '__init__.py')):
            sys.path.append(p)
        else:
            sys.path.insert(0, p)

try:
    from terminal.main import TerminalWidget  # type: ignore
except (ImportError, Exception):
    try:
        from terminal.src.main import TerminalWidget  # type: ignore
    except (ImportError, Exception):
        try:
            from Terminal.src.main import TerminalWidget  # type: ignore
        except (ImportError, Exception):
            try:
                from terminal import TerminalWidget  # type: ignore
            except (ImportError, Exception):
                try:
                    from Terminal import TerminalWidget  # type: ignore
                except (ImportError, Exception):
                    try:
                        from Terminal.terminal import TerminalWidget  # type: ignore
                    except (ImportError, Exception):
                        try:
                            from terminal.terminal import TerminalWidget  # type: ignore
                        except (ImportError, Exception):
                            try:
                                from main import TerminalWidget  # type: ignore
                            except (ImportError, Exception):
                                TerminalWidget = None

if TerminalWidget is None:
    # Direct spec loader fallback if package imports failed due to shadowing
    potential_terminal_mains = [
        os.path.join(os.path.dirname(__file__), "terminal", "src", "main.py"),
        os.path.join(os.path.dirname(__file__), "..", "terminal", "src", "main.py"),
        os.path.join(os.path.dirname(__file__), "..", "..", "terminal", "src", "main.py"),
        "/opt/wheelhouser/file-browser/terminal/src/main.py",
        "/opt/wheelhouser/terminal/src/main.py",
    ]
    for tm_path in potential_terminal_mains:
        abs_tm = os.path.abspath(tm_path)
        if os.path.isfile(abs_tm):
            try:
                import importlib.util
                spec = importlib.util.spec_from_file_location("terminal.src.main", abs_tm)
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    sys.modules["terminal.src.main"] = mod
                    spec.loader.exec_module(mod)
                    TerminalWidget = getattr(mod, "TerminalWidget", None)
                    if TerminalWidget is not None:
                        break
            except Exception:
                pass

#===========================================================================================
#--- File Browser Application with Dark Theme ---
#===========================================================================================
VERSION = "0.9.5"
APP_NAME = "File-Browser"
APP_AUTHOR = "WheelhouserLLC"
APP_VERSION = "0.9.5"
COMPANY_NAME = "Wheelhouser LLC"
WEBSITE_URL = "https://wheelhouser.com"
ENABLE_AI = False # Set to False to disable AI features for Store release
STORE_RELEASE = True # Set to True to reduce log verbosity for Store release

#============================================================================================
#--- Resource Path Helper ---
#============================================================================================
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev, PyInstaller, and Nuitka """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        target = os.path.join(sys._MEIPASS, relative_path)
        if os.path.exists(target):
            return target

    if hasattr(sys, "_MEIPASS"):
        target = os.path.join(sys._MEIPASS, relative_path)
        if os.path.exists(target):
            return target
    
    # Check relative to executable (for PyInstaller/Nuitka standalone)
    exe_dir = os.path.dirname(sys.executable)
    target_exe = os.path.join(exe_dir, relative_path)
    if os.path.exists(target_exe):
        return target_exe

    src_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.dirname(src_dir)
    
    # Check if assets exist in root dir (e.g., project root when running from src)
    target_root = os.path.join(root_dir, relative_path)
    if os.path.exists(target_root):
        return target_root
        
    # Check if assets exist in src dir
    target_src = os.path.join(src_dir, relative_path)
    if os.path.exists(target_src):
        return target_src

    return target_root

#============================================================================================
# --- Trash & Quick Access Icons Helpers ---
#============================================================================================
def get_trash_directory() -> str:
    """Returns the standard browsable Trash directory for the platform."""
    if sys.platform == "darwin":
        return os.path.expanduser("~/.Trash")
    return os.path.expanduser("~/.local/share/Trash/files")

def is_trash_empty() -> bool:
    """Returns True if the system trash contains no files, False otherwise."""
    if os.name == 'nt':
        try:
            import ctypes
            from ctypes import wintypes
            class SHQUERYRBINFO(ctypes.Structure):
                _fields_ = [
                    ('cbSize', wintypes.DWORD),
                    ('i64Size', ctypes.c_int64),
                    ('i64NumItems', ctypes.c_int64)
                ]
            rb_info = SHQUERYRBINFO()
            rb_info.cbSize = ctypes.sizeof(SHQUERYRBINFO)
            windll = getattr(ctypes, 'windll', None)
            if windll:
                res = windll.shell32.SHQueryRecycleBinW(None, ctypes.byref(rb_info))
                if res == 0:
                    return rb_info.i64NumItems == 0
        except Exception:
            pass
        return True

    trash_dir = get_trash_directory()
    if os.path.exists(trash_dir):
        try:
            with os.scandir(trash_dir) as it:
                return not any(it)
        except Exception:
            return True
    return True

def is_trash_path(path: Optional[str]) -> bool:
    """Returns True if the given path is the Trash folder or inside it."""
    if not path:
        return False
    try:
        norm = os.path.abspath(os.path.normpath(path)).rstrip(os.sep)
        trash_dir = os.path.abspath(os.path.normpath(get_trash_directory())).rstrip(os.sep)
        if norm == trash_dir:
            return True
        trash_parent = os.path.dirname(trash_dir)
        if norm == trash_parent:
            return True
        if norm.startswith(trash_dir + os.sep) or norm.startswith(trash_parent + os.sep):
            return True
    except Exception:
        pass
    return False


def is_quick_access_permanent(item_text: str = "", item_path: Optional[str] = None) -> bool:
    """Returns True if the item is Home or Trash, which cannot be removed from Quick Access."""
    clean_text = (item_text or "").strip().rstrip("/")
    for prefix in ("📱 ", "💾 ", "📁 ", "🏠 ", "🗑️ ", "🗑 "):
        if clean_text.startswith(prefix):
            clean_text = clean_text[len(prefix):].strip()
    if clean_text.lower() in ("home", "trash"):
        return True
    if item_path:
        try:
            norm_p = os.path.abspath(os.path.normpath(item_path)).rstrip(os.sep)
            home_p = os.path.abspath(os.path.normpath(QDir.homePath())).rstrip(os.sep)
            user_home = os.path.abspath(os.path.normpath(os.path.expanduser("~"))).rstrip(os.sep)
            if norm_p in (home_p, user_home):
                return True
        except Exception:
            pass
        if is_trash_path(item_path):
            return True
    return False


def empty_trash_files() -> bool:
    """Permanently deletes all items in system trash."""
    if os.name == 'nt':
        try:
            import ctypes
            windll = getattr(ctypes, 'windll', None)
            if windll:
                res = windll.shell32.SHEmptyRecycleBinW(None, None, 7)
                if res == 0:
                    return True
        except Exception as e:
            logging.error(f"Windows SHEmptyRecycleBinW failed: {e}")

    trash_dirs_to_clean = []
    if sys.platform == "darwin":
        trash_dirs_to_clean.append(os.path.expanduser("~/.Trash"))
    else:
        xdg_data = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
        trash_base = os.path.join(xdg_data, "Trash")
        for sub in ("files", "info", "expunged"):
            trash_dirs_to_clean.append(os.path.join(trash_base, sub))
        
        browsable_trash = get_trash_directory()
        if browsable_trash not in trash_dirs_to_clean:
            trash_dirs_to_clean.append(browsable_trash)

    success = True
    for directory in trash_dirs_to_clean:
        if not os.path.exists(directory):
            continue
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            shutil.rmtree(entry.path, ignore_errors=True)
                        else:
                            os.unlink(entry.path)
                    except Exception as ex:
                        logging.warning(f"Failed to delete {entry.path}: {ex}")
                        success = False
        except Exception as ex:
            logging.warning(f"Failed scanning {directory}: {ex}")
            success = False

    return success

def confirm_empty_trash(parent=None) -> bool:
    """Shows a GNOME Files style confirmation dialog to empty the trash."""
    msg_box = QMessageBox(parent)
    msg_box.setWindowTitle("Empty Trash?")
    msg_box.setText("<h3>Empty all items from Trash?</h3>")
    msg_box.setInformativeText("All items in the Trash will be permanently deleted.")
    msg_box.setIcon(QMessageBox.Icon.Warning)

    empty_btn = msg_box.addButton("Empty Trash", QMessageBox.ButtonRole.DestructiveRole)
    cancel_btn = msg_box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
    msg_box.setDefaultButton(cancel_btn)

    empty_btn.setStyleSheet("""
        QPushButton {
            background-color: #c0392b;
            color: #ffffff;
            border: 1px solid #e74c3c;
            border-radius: 4px;
            padding: 6px 16px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #d63031;
        }
        QPushButton:pressed {
            background-color: #962d22;
        }
    """)
    cancel_btn.setStyleSheet("""
        QPushButton {
            background-color: #333333;
            color: #ffffff;
            border: 1px solid #555555;
            border-radius: 4px;
            padding: 6px 16px;
        }
        QPushButton:hover {
            background-color: #444444;
        }
    """)

    msg_box.exec()
    return msg_box.clickedButton() == empty_btn


def get_quick_access_icon(name: str = "", path: str = "", dev_type: Optional[str] = None) -> QIcon:
    """Returns an appropriate QIcon for a Quick Access sidebar item.
    Ensures all folder locations (Home, Downloads, Desktop, Documents, Pictures, Music, Videos)
    share a unified folder icon style, while Trash dynamically reflects empty or full states.
    """
    clean_name = name.strip().lower()

    # Check device types
    if dev_type == "usb":
        theme_usb = QIcon.fromTheme("drive-removable-media")
        if not theme_usb.isNull():
            return theme_usb
        return QFileIconProvider().icon(QFileIconProvider.IconType.Drive)
    elif dev_type == "android":
        for theme_name in ("phone", "smartphone", "multimedia-player", "phone-apple-iphone", "media-removable"):
            theme_phone = QIcon.fromTheme(theme_name)
            if not theme_phone.isNull():
                return theme_phone
        vector_phone = get_file_extension_qicon("phone")
        if not vector_phone.isNull():
            return vector_phone
        return QFileIconProvider().icon(QFileIconProvider.IconType.Drive)

    # Check Trash
    clean_path = os.path.abspath(path) if path else ""
    trash_path = os.path.abspath(get_trash_directory())
    if clean_name == "trash" or (clean_path and clean_path == trash_path):
        empty = is_trash_empty()
        if not empty:
            theme_full = QIcon.fromTheme("user-trash-full")
            if not theme_full.isNull():
                return theme_full
            bundled_full = resource_path("assets/icons/trash_full.png")
            if os.path.exists(bundled_full):
                return QIcon(bundled_full)
        else:
            theme_empty = QIcon.fromTheme("user-trash-empty")
            if not theme_empty.isNull():
                return theme_empty
            bundled_empty = resource_path("assets/icons/trash_empty.png")
            if os.path.exists(bundled_empty):
                return QIcon(bundled_empty)
            theme_trash = QIcon.fromTheme("user-trash")
            if not theme_trash.isNull():
                return theme_trash
        return QFileIconProvider().icon(QFileIconProvider.IconType.Trashcan)

    # For directories (Home, Desktop, Documents, Downloads, Pictures, Music, Videos, etc.),
    # query QFileIconProvider for the native platform folder icon.
    if path and os.path.exists(path):
        try:
            info = QFileInfo(path)
            provider_icon = QFileIconProvider().icon(info)
            if not provider_icon.isNull():
                return provider_icon
        except Exception:
            pass

    # Fallback to QFileIconProvider Folder icon
    try:
        provider_folder = QFileIconProvider().icon(QFileIconProvider.IconType.Folder)
        if not provider_folder.isNull():
            return provider_folder
    except Exception:
        pass

    # Fallback to bundled folder icon asset matching web-browser
    folder_icon = resource_path("assets/icons/folder.png")
    if os.path.exists(folder_icon):
        return QIcon(folder_icon)

    theme_folder = QIcon.fromTheme("folder")
    if not theme_folder.isNull():
        return theme_folder

    return QIcon()

#============================================================================================
# --- Desktop Shortcut & MSIX Helpers ---
#============================================================================================
def get_installed_msix_info():
    """Checks if File-Browser is running within or installed as an MSIX package on Windows.
    Returns a dict with 'pfn', 'app_id', 'root_folder', or None if not found.
    """
    if sys.platform != "win32":
        return None

    # 1. Check if the current process is running inside an AppX/MSIX package container
    try:
        import ctypes
        from ctypes import wintypes
        windll = getattr(ctypes, "windll", None)
        if windll is not None:
            buf_len = wintypes.UINT(256)
            buf = ctypes.create_unicode_buffer(256)
            if windll.kernel32.GetCurrentPackageFamilyName(ctypes.byref(buf_len), buf) == 0:
                val = buf.value.lower()
                if ("file-browser" in val or "filebrowser" in val) and "wheelhouser" in val:
                    return {
                        "pfn": buf.value,
                        "app_id": "FileBrowser",
                        "root_folder": os.path.dirname(sys.executable),
                    }
    except Exception:
        pass

    # 2. Check if sys.executable is running from WindowsApps
    if "windowsapps" in sys.executable.lower() and (
        ("file-browser" in sys.executable.lower() or "filebrowser" in sys.executable.lower()) and "wheelhouser" in sys.executable.lower()
    ):
        try:
            parts = sys.executable.split(os.sep)
            for part in parts:
                p_lower = part.lower()
                if "__" in part and (
                    ("file-browser" in p_lower or "filebrowser" in p_lower) and "wheelhouser" in p_lower
                ):
                    tokens = part.split("__")
                    name_prefix = tokens[0].split("_")[0]
                    pub_id = tokens[1]
                    return {
                        "pfn": f"{name_prefix}_{pub_id}",
                        "app_id": "FileBrowser",
                        "root_folder": os.path.dirname(sys.executable),
                    }
        except Exception:
            pass

    # 3. Query the Windows AppModel Repository in the registry for installed File-Browser package
    try:
        import winreg  # type: ignore[import-not-found]
        hkey_cu = getattr(winreg, "HKEY_CURRENT_USER", None)
        hkey_lm = getattr(winreg, "HKEY_LOCAL_MACHINE", None)
        open_key = getattr(winreg, "OpenKey", None)
        query_info_key = getattr(winreg, "QueryInfoKey", None)
        enum_key = getattr(winreg, "EnumKey", None)
        query_value_ex = getattr(winreg, "QueryValueEx", None)

        if hkey_cu is not None and hkey_lm is not None and open_key and query_info_key and enum_key and query_value_ex:
            for hive in (hkey_cu, hkey_lm):
                sub_path = r"Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages"
                try:
                    with open_key(hive, sub_path) as key:
                        num_subkeys = query_info_key(key)[0]
                        for i in range(num_subkeys):
                            name = enum_key(key, i)
                            lname = name.lower()
                            if ("file-browser" in lname or "filebrowser" in lname) and "wheelhouser" in lname:
                                try:
                                    with open_key(key, name) as pkg_key:
                                        root_folder, _ = query_value_ex(
                                            pkg_key, "PackageRootFolder"
                                        )
                                        num_apps = query_info_key(pkg_key)[0]
                                        app_id = "FileBrowser"
                                        if num_apps > 0:
                                            app_id = enum_key(pkg_key, 0)
                                        tokens = name.split("__")
                                        if len(tokens) == 2:
                                            pkg_name = tokens[0].split("_")[0]
                                            pub_id = tokens[1]
                                            pfn = f"{pkg_name}_{pub_id}"
                                        else:
                                            pfn = "WheelhouserLLC.File-Browser_2sq2b2t7jg2f6"
                                        return {
                                            "pfn": pfn,
                                            "app_id": app_id,
                                            "root_folder": root_folder,
                                        }
                                except Exception:
                                    pass
                except Exception:
                    pass
    except Exception:
        pass

    return None


def create_desktop_shortcut(parent=None):
    """Creates a desktop shortcut for File-Browser across Windows, macOS, and Linux."""
    try:
        app_name = APP_NAME
        desktop_dir = ""

        if sys.platform == "win32":
            user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
            onedrive_desktop = os.path.join(user_profile, "OneDrive", "Desktop")
            if os.path.exists(onedrive_desktop):
                desktop_dir = onedrive_desktop
            else:
                desktop_dir = os.path.join(user_profile, "Desktop")

            shortcut_path = os.path.join(desktop_dir, f"{app_name}.lnk")
            icon_ico = resource_path(os.path.join("assets", "icons", "icon.ico"))

            is_frozen = getattr(sys, "frozen", False) or (
                not sys.executable.lower().endswith("python.exe")
                and not sys.executable.lower().endswith("pythonw.exe")
            )

            msix_info = get_installed_msix_info()
            if msix_info:
                pfn = msix_info.get("pfn") or "WheelhouserLLC.File-Browser_2sq2b2t7jg2f6"
                app_id = msix_info.get("app_id") or "FileBrowser"
                target_exe = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "explorer.exe")
                arguments = f"shell:AppsFolder\\{pfn}!{app_id}"
                working_dir = msix_info.get("root_folder") or os.path.dirname(sys.executable)
                if msix_info.get("root_folder"):
                    pkg_ico = os.path.join(msix_info["root_folder"], "assets", "icons", "icon.ico")
                    if os.path.exists(pkg_ico):
                        icon_ico = pkg_ico
            elif is_frozen:
                target_exe = sys.executable
                arguments = ""
                working_dir = os.path.dirname(sys.executable)
            else:
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                working_dir = os.path.dirname(os.path.dirname(script_path))
                py_bin = sys.executable.replace("python.exe", "pythonw.exe")
                if not os.path.exists(py_bin):
                    py_bin = sys.executable
                target_exe = os.environ.get("COMSPEC", "C:\\Windows\\System32\\cmd.exe")
                arguments = f'/c start "" "{py_bin}" "{script_path}"'

            ps_content = f'''$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut("{shortcut_path}")
$s.TargetPath = "{target_exe}"
$s.Arguments = '{arguments}'
$s.WorkingDirectory = "{working_dir}"
$s.Description = "{app_name} by {COMPANY_NAME}"
if (Test-Path "{icon_ico}") {{
    $s.IconLocation = "{icon_ico},0"
}}
$s.Save()
'''
            temp_ps1 = os.path.join(os.environ.get("TEMP", "."), f"create_shortcut_{os.getpid()}.ps1")
            with open(temp_ps1, "w", encoding="utf-8") as f:
                f.write(ps_content)

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", temp_ps1],
                check=True,
                creationflags=creationflags,
            )
            try:
                os.remove(temp_ps1)
            except Exception:
                pass

        elif sys.platform == "darwin":
            desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            if getattr(sys, "frozen", False):
                app_bundle = os.path.abspath(os.path.join(os.path.dirname(sys.executable), "..", ".."))
                if app_bundle.endswith(".app"):
                    dest_app = os.path.join(desktop_dir, os.path.basename(app_bundle))
                    if os.path.exists(dest_app):
                        os.remove(dest_app)
                    os.symlink(app_bundle, dest_app)
            else:
                command_file = os.path.join(desktop_dir, f"{app_name}.command")
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                with open(command_file, "w", encoding="utf-8") as f:
                    f.write(f'#!/bin/bash\ncd "{os.path.dirname(os.path.dirname(script_path))}"\n"{sys.executable}" "{script_path}"\n')
                os.chmod(command_file, 0o755)

        else:  # Linux
            desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            desktop_file = os.path.join(desktop_dir, "com.wheelhouser.file-browser.desktop")
            icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
            if getattr(sys, "frozen", False):
                exec_cmd = f'"{sys.executable}"'
            else:
                script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "main.py"))
                exec_cmd = f'"{sys.executable}" "{script_path}"'

            content = f"""[Desktop Entry]
Type=Application
Name={app_name}
Comment={app_name} by {COMPANY_NAME}
Exec={exec_cmd}
Icon={icon_path}
Terminal=false
Categories=System;FileManager;Utility;
StartupWMClass=com.wheelhouser.file-browser
"""
            with open(desktop_file, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(desktop_file, 0o755)

        if parent:
            QMessageBox.information(
                parent,
                "Desktop Shortcut",
                "Desktop icon created successfully on your Desktop!",
            )
        return True
    except Exception as e:
        logging.error(f"Failed to create desktop shortcut: {e}")
        if parent:
            QMessageBox.warning(
                parent,
                "Desktop Shortcut",
                f"Failed to create desktop shortcut: {e}",
            )
        return False

#============================================================================================
# --- Update Manager Class ---
#============================================================================================
class AppUpdateManager(QWidget):
    update_found = Signal(str, str, str)  # version, url, notes

    def __init__(self, current_version, parent=None):
        super().__init__(parent)
        self.current_version = current_version
        self.update_thread = None

    def start_check(self):
        version_url = f"https://wheelhouser.com/updates/{APP_NAME.lower().replace(' ', '-')}/version.json"
        self.update_thread = UpdateCheckThread(self.current_version, version_url)
        self.update_thread.update_available.connect(self.on_update_available)
        self.update_thread.up_to_date.connect(self.on_up_to_date)
        self.update_thread.error.connect(self.on_error)

        def _on_update_finished():
            if hasattr(self, "update_thread") and self.update_thread:
                try:
                    self.update_thread.deleteLater()
                except RuntimeError:
                    pass
                self.update_thread = None

        self.update_thread.finished.connect(_on_update_finished)
        self.update_thread.start()

    def on_update_available(self, latest_version, target_url, release_notes):
        self.update_found.emit(latest_version, target_url, release_notes)

    def on_up_to_date(self):
        pass

    def on_error(self, error_msg):
        logging.warning(f"Startup update check failed: {error_msg}")

    def shutdown(self):
        t = getattr(self, "update_thread", None)
        if t:
            try:
                if t.isRunning():
                    try:
                        t.update_available.disconnect()
                    except Exception:
                        pass
                    try:
                        t.error.disconnect()
                    except Exception:
                        pass
                    try:
                        t.up_to_date.disconnect()
                    except Exception:
                        pass
                    t.quit()
                    if not t.wait(500):
                        t.terminate()
                        t.wait(100)
            except (RuntimeError, AttributeError):
                pass
            finally:
                self.update_thread = None

    def apply_update_style(self, button):
        # Semi-transparent red background to indicate update
        button.setStyleSheet("""
            QPushButton {
                background-color: rgba(200, 0, 0, 50);
                color: white;
                border: 1px solid #aa0000;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: rgba(200, 0, 0, 120);
                border: 1px solid #ff0000;
            }
        """)
        button.setText("Update")



#============================================================================================
# --- Proxy Model to Filter Dot Files ---
#============================================================================================
class DotFileProxyModel(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.show_dot = False
        self.name_filter = ""
        self.current_path = ""
        self.setRecursiveFilteringEnabled(True)

    def setShowDotFiles(self, show):
        self.show_dot = show
        self.invalidate()

    def setNameFilter(self, text):
        self.name_filter = text.lower()
        logging.debug(f"DotFileProxyModel: Filter set to '{self.name_filter}'")
        self.invalidate()

    def setCurrentPath(self, path):
        self.current_path = os.path.normpath(path).lower()
        self.invalidate()

    def filterAcceptsRow(self, source_row, source_parent):
        source_model = self.sourceModel()
        if not isinstance(source_model, QFileSystemModel):
            return super().filterAcceptsRow(source_row, source_parent)
        index = source_model.index(source_row, 0, source_parent)
        name = source_model.fileName(index)
        
        if not self.show_dot and name.startswith('.'):
            return False

        # Filter out NTUSER.DAT and ntuser.ini files which are system files
        if name.upper().startswith("NTUSER.DAT") or name.lower() == "ntuser.ini":
            return False

        # Always accept ancestors of current path to prevent view reset
        if self.current_path:
            path = source_model.filePath(index)
            norm_path = os.path.normpath(path).lower()
            if self.current_path.startswith(norm_path):
                if len(norm_path) == len(self.current_path) or \
                   (len(norm_path) < len(self.current_path) and \
                    (self.current_path[len(norm_path)] == os.sep or norm_path.endswith(os.sep))):
                    return True

        if self.name_filter and self.name_filter not in name.lower():
            return False
            
        if self.name_filter:
            logging.debug(f"DotFileProxyModel: Match found for '{name}'")
        return True

    def lessThan(self, left, right):
        source_model = self.sourceModel()
        if isinstance(source_model, QFileSystemModel):
            left_is_dir = source_model.isDir(left)
            right_is_dir = source_model.isDir(right)
            if left_is_dir != right_is_dir:
                return left_is_dir if self.sortOrder() == Qt.SortOrder.AscendingOrder else right_is_dir

            # Sort by Size (Column 1) using raw bytes from UserRole
            if left.column() == 1:
                left_data = source_model.data(left, Qt.ItemDataRole.UserRole)
                right_data = source_model.data(right, Qt.ItemDataRole.UserRole)
                l_size = left_data if isinstance(left_data, int) else 0
                r_size = right_data if isinstance(right_data, int) else 0
                return l_size < r_size
                
            # Sort by Type (Column 2)
            if left.column() == 2:
                return source_model.type(left) < source_model.type(right)
                
            # Sort by Date (Column 3)
            if left.column() == 3:
                return source_model.lastModified(left) < source_model.lastModified(right)
            
        return super().lessThan(left, right)

#============================================================================================
# --- Thumbnail Generation ---
#============================================================================================
class ThumbnailWorker(QThread):
    thumbnail_loaded = Signal(str, QImage)

    def __init__(self):
        super().__init__()
        self.queue = queue.Queue()
        self.running = True
        self._processed = set()
        self._paused = False

    def set_paused(self, paused):
        logging.debug(f"ThumbnailWorker paused state set to: {paused}")
        self._paused = paused

    def request_thumbnail(self, path):
        if path not in self._processed:
            self._processed.add(path)
            self.queue.put(path)

    def run(self):
        logging.debug(f"ThumbnailWorker started. Supported formats: {[bytes(fmt.data()).decode() for fmt in QImageReader.supportedImageFormats()]}")
        while self.running:
            if self._paused:
                time.sleep(0.1)
                continue

            try:
                path = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            
            try:
                reader = QImageReader(path)
                if reader.canRead():
                    reader.setScaledSize(QSize(128, 128))
                    reader.setAutoTransform(True)
                    image = reader.read()
                    
                    if not image.isNull():
                        # Ensure it's scaled if the reader didn't do it (some formats ignore setScaledSize)
                        if image.width() > 128 or image.height() > 128:
                            image = image.scaled(128, 128, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                        self.thumbnail_loaded.emit(path, image)
                    else:
                        logging.warning(f"Thumbnail image is null for {path}. Error: {reader.errorString()}")
                del reader
            except Exception as e:
                logging.warning(f"Failed to generate thumbnail for {path}: {e}")

    def stop(self):
        self.running = False
        self.wait()

#============================================================================================
# -- Folder Size Calculation ---
#============================================================================================
class FolderSizeWorker(QThread):
    size_calculated = Signal(str, object, str)

    def __init__(self):
        super().__init__()
        self.queue = queue.Queue()
        self.running = True
        self._processed = set()
        self._paused = False

    def set_paused(self, paused):
        logging.debug(f"FolderSizeWorker paused state set to: {paused}")
        self._paused = paused

    def request_size(self, path):
        if not path or "/gvfs/" in path or "mtp:host=" in path or path.startswith("wpd://"):
            return
        if path not in self._processed:
            self._processed.add(path)
            self.queue.put(path)

    def run(self):
        while self.running:
            if self._paused:
                time.sleep(0.1)
                continue

            try:
                path = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            
            total_size = 0
            try:
                for dirpath, dirnames, filenames in os.walk(path):
                    if not self.running:
                        return
                    for f in filenames:
                        fp = os.path.join(dirpath, f)
                        if not os.path.islink(fp):
                            try:
                                total_size += os.path.getsize(fp)
                            except OSError:
                                pass
            except Exception:
                pass
            
            if self.running:
                self.size_calculated.emit(path, total_size, self.format_size(total_size))

    def format_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"

    def stop(self):
        self.running = False
        self.wait()

#============================================================================================
# --- USB Device Detection ---
#============================================================================================
class USBDetector(QThread):
    """A thread that periodically checks for USB device connections and disconnections."""
    device_added = Signal(str, str, str)    # path, name, type
    device_removed = Signal(str) # path

    def __init__(self, parent=None):
        super().__init__(parent)
        self.running = False
        self.current_drives = set()

    def run(self):
        self.running = True
        
        # Initial check to populate list
        try:
            logging.debug("USBDetector: Performing initial scan...")
            self.current_drives = self._get_removable_drives()
            logging.debug(f"USBDetector: Initial scan found {len(self.current_drives)} drives: {self.current_drives}")
            for path, name, dev_type in self.current_drives:
                self.device_added.emit(path, name, dev_type)
        except Exception as e:
            logging.error(f"Initial USB scan failed: {e}")

        while self.running:
            try:
                new_drives = self._get_removable_drives()
                
                added_drives = new_drives - self.current_drives
                removed_drives = self.current_drives - new_drives

                if added_drives:
                    logging.debug(f"USBDetector: Detected {len(added_drives)} new drives.")
                for path, name, dev_type in added_drives:
                    logging.info(f"USB Device added: {name} at {path}")
                    self.device_added.emit(path, name, dev_type)

                if removed_drives:
                    logging.debug(f"USBDetector: Detected {len(removed_drives)} removed drives.")
                for path, name, dev_type in removed_drives:
                    logging.info(f"USB Device removed: {name} at {path}")
                    self.device_removed.emit(path)

                self.current_drives = new_drives
            except Exception as e:
                logging.warning(f"Error during USB scan: {e}")
            
            for _ in range(30):
                if not self.running:
                    break
                self.msleep(100)

    def _resolve_android_device_name(self, path: str, entry: str = "") -> str:
        """Resolves a human-readable friendly name for an Android device."""
        if shutil.which("gio"):
            try:
                proc = subprocess.run(["gio", "info", path], capture_output=True, text=True, timeout=1, check=False)
                for line in proc.stdout.splitlines():
                    if "standard::display-name:" in line or "display name:" in line:
                        disp_name = line.split(":", 1)[-1].strip()
                        if disp_name:
                            return disp_name
            except Exception:
                pass

        # Parse from entry or basename
        raw = entry or os.path.basename(path)
        if raw.startswith("mtp:host="):
            raw = raw[len("mtp:host="):]
        elif raw.startswith("gphoto2:host="):
            raw = raw[len("gphoto2:host="):]

        parts: List[str] = [p for p in raw.replace("_", " ").split() if p]
        deduped: List[str] = []
        for p in parts:
            if not deduped or p.lower() != deduped[-1].lower():
                deduped.append(p)
        clean = " ".join(deduped).strip()
        if clean:
            if len(clean) > 8 and clean.isalnum() and not any(k in clean.lower() for k in ("android", "samsung", "pixel", "phone")):
                return f"Android Device ({clean[:8]})"
            return clean

        return "Android Device"

    def _get_removable_drives(self):
        """Returns a set of tuples (path, name, type) for removable drives."""
        drives = set()
        logging.debug("USBDetector: Starting _get_removable_drives scan.")

        # 1. Enumerate filesystem partitions (using psutil with /proc/mounts fallback on Linux)
        all_partitions: List[Any] = []
        if psutil is not None:
            try:
                all_partitions.extend(psutil.disk_partitions(all=True))
            except Exception as e:
                logging.debug(f"USBDetector: psutil.disk_partitions error: {e}")

        if not all_partitions and sys.platform.startswith("linux") and os.path.exists("/proc/mounts"):
            try:
                from collections import namedtuple
                DiskPart = namedtuple("DiskPart", ["device", "mountpoint", "fstype", "opts"])
                with open("/proc/mounts", "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        fields = line.strip().split()
                        if len(fields) >= 4:
                            all_partitions.append(DiskPart(fields[0], fields[1], fields[2], fields[3]))
            except Exception as e:
                logging.debug(f"USBDetector: /proc/mounts read error: {e}")

        logging.debug(f"USBDetector: Found {len(all_partitions)} partitions to evaluate.")
        for part in all_partitions:
            is_removable = False
            dev_type = "usb"
            path = part.mountpoint

            # Filter out system loops and snaps
            if path.startswith(('/snap', '/var/lib/snapd', '/var/lib/docker')):
                continue

            if sys.platform == "win32":
                try:
                    import win32file
                    drive_type = win32file.GetDriveType(path)
                    if drive_type == win32file.DRIVE_REMOVABLE:
                        is_removable = True
                except (ImportError, Exception):
                    if 'removable' in part.opts or 'hotplug' in part.opts:
                        is_removable = True
            elif sys.platform == "darwin":
                if path.startswith('/Volumes') and 'nobrowse' not in part.opts:
                    is_removable = True
                    p_lower = path.lower()
                    if any(k in p_lower for k in ("android", "phone", "galaxy", "pixel", "mtp")):
                        dev_type = "android"
            else: # Linux and POSIX
                # If path is the GVFS root itself (e.g. /run/user/<uid>/gvfs), NEVER add it as a drive.
                if path.endswith('/gvfs') or 'gvfsd-fuse' in getattr(part, "device", "") or getattr(part, "fstype", "") == 'fuse.gvfsd-fuse':
                    continue

                if 'removable' in part.opts or 'hotplug' in part.opts:
                    is_removable = True
                elif '/media/' in path or '/run/media/' in path:
                    is_removable = True
                    p_lower = path.lower()
                    if any(k in p_lower for k in ("android", "phone", "galaxy", "pixel", "mtp")):
                        dev_type = "android"
                elif any(k in getattr(part, "fstype", "") for k in ("simple-mtpfs", "jmtpfs", "mtpfs", "go-mtpfs")) or 'mtp' in part.opts:
                    is_removable = True
                    dev_type = "android"

            if is_removable:
                name = ""
                if sys.platform == "win32":
                    try:
                        import win32api
                        volume_name, _, _, _, _ = win32api.GetVolumeInformation(path)
                        drive_letter = path.strip('\\')
                        name = f"{volume_name} ({drive_letter})" if volume_name else drive_letter
                    except (ImportError, Exception):
                        name = path.strip('\\')
                else:
                    if dev_type == "android":
                        name = self._resolve_android_device_name(path)
                    else:
                        name = os.path.basename(path)

                    if not name:
                        name = getattr(part, "device", "")
                logging.debug(f"USBDetector: Adding drive: Path='{path}', Name='{name}', Type='{dev_type}'")
                drives.add((path, name, dev_type))

        # 2. Linux GVFS / MTP Android phone detection
        if sys.platform.startswith("linux"):
            gvfs_dirs = []
            try:
                uid = os.getuid()
                gvfs_dirs.append(f"/run/user/{uid}/gvfs")
            except Exception:
                pass
            xdg_runtime = os.environ.get("XDG_RUNTIME_DIR")
            if xdg_runtime:
                gvfs_dirs.append(os.path.join(xdg_runtime, "gvfs"))
            gvfs_dirs.append(os.path.expanduser("~/.gvfs"))

            for gvfs_dir in gvfs_dirs:
                if os.path.exists(gvfs_dir) and os.path.isdir(gvfs_dir):
                    try:
                        for entry in os.listdir(gvfs_dir):
                            if entry.startswith(('mtp:host=', 'gphoto2:host=')):
                                dev_path = os.path.join(gvfs_dir, entry)
                                dev_name = self._resolve_android_device_name(dev_path, entry)
                                drives.add((dev_path, dev_name, "android"))
                                logging.debug(f"USBDetector: Found Linux MTP Android device: {dev_name} at {dev_path}")
                    except Exception as e:
                        logging.debug(f"USBDetector: Error reading GVFS dir {gvfs_dir}: {e}")

            # Also check GIO volume monitor if gio is installed
            if shutil.which("gio"):
                try:
                    proc = subprocess.run(["gio", "mount", "-li"], capture_output=True, text=True, timeout=2, check=False)
                    if proc.returncode == 0:
                        lines = proc.stdout.splitlines()
                        curr_vol_name = ""
                        curr_is_mtp = False
                        curr_mount_path = ""
                        for line in lines:
                            line_s = line.strip()
                            if line.startswith("Volume(") or line.startswith("Drive("):
                                curr_vol_name = line_s.split(":", 1)[-1].strip() if ":" in line_s else ""
                                curr_is_mtp = False
                                curr_mount_path = ""
                            elif "GProxyVolumeMonitorMTP" in line_s:
                                curr_is_mtp = True
                            elif curr_is_mtp and line_s.startswith("default_location="):
                                loc = line_s.split("=", 1)[-1].strip()
                                if loc.startswith("mtp://"):
                                    try:
                                        info_p = subprocess.run(["gio", "info", loc], capture_output=True, text=True, timeout=1, check=False)
                                        for info_l in info_p.stdout.splitlines():
                                            if "local path:" in info_l:
                                                curr_mount_path = info_l.split(":", 1)[-1].strip()
                                            elif "standard::display-name:" in info_l or "display name:" in info_l:
                                                curr_vol_name = info_l.split(":", 1)[-1].strip()
                                    except Exception:
                                        pass
                            elif curr_is_mtp and curr_mount_path and os.path.exists(curr_mount_path):
                                drives.add((curr_mount_path, curr_vol_name or "Android Device", "android"))
                                curr_mount_path = ""
                except Exception as e:
                    logging.debug(f"USBDetector: GIO probe error: {e}")

            # If no GVFS Android device was found yet, probe sysfs for connected Android devices to automount
            if not any(dev_t == "android" for _, _, dev_t in drives) and shutil.which("gio"):
                try:
                    usb_dir = "/sys/bus/usb/devices"
                    if os.path.exists(usb_dir):
                        for dev in os.listdir(usb_dir):
                            p = os.path.join(usb_dir, dev)
                            mfg_p = os.path.join(p, "manufacturer")
                            prod_p = os.path.join(p, "product")
                            mfg = ""
                            if os.path.exists(mfg_p):
                                try:
                                    with open(mfg_p, "r", encoding="utf-8", errors="ignore") as f:
                                        mfg = f.read().strip()
                                except Exception:
                                    pass
                            prod = ""
                            if os.path.exists(prod_p):
                                try:
                                    with open(prod_p, "r", encoding="utf-8", errors="ignore") as f:
                                        prod = f.read().strip()
                                except Exception:
                                    pass
                            is_android_hw = any(k in (mfg + " " + prod).lower() for k in ("android", "samsung", "pixel", "google", "xiaomi", "huawei", "oneplus", "oppo", "vivo", "motorola", "lg electronics"))
                            if is_android_hw:
                                bus_p = os.path.join(p, "busnum")
                                dev_p = os.path.join(p, "devnum")
                                if os.path.exists(bus_p) and os.path.exists(dev_p):
                                    try:
                                        with open(bus_p, "r", encoding="utf-8", errors="ignore") as f:
                                            bus = f.read().strip().zfill(3)
                                        with open(dev_p, "r", encoding="utf-8", errors="ignore") as f:
                                            devnum = f.read().strip().zfill(3)
                                        subprocess.run(["gio", "mount", f"mtp://[usb:{bus},{devnum}]/"], capture_output=True, timeout=1, check=False)
                                        subprocess.run(["gio", "mount", f"gphoto2://[usb:{bus},{devnum}]/"], capture_output=True, timeout=1, check=False)
                                    except Exception:
                                        pass
                except Exception as e:
                    logging.debug(f"USBDetector: sysfs mount probe error: {e}")

        # 3. Windows WPD (Android/MTP) Detection (runs unconditionally on win32)
        if sys.platform == "win32":
            try:
                logging.debug("USBDetector: Scanning for WPD devices via PowerShell...")
                ps_script = """
                    try {
                        $pnpDevices = Get-PnpDevice -Class WPD -Status OK
                        foreach ($pnpDevice in $pnpDevices) {
                            $deviceName = $pnpDevice.FriendlyName
                            if (-not $deviceName) { continue }
                            Write-Output "wpd://$($deviceName);;$($deviceName)"
                        }
                    } catch {}
                """
                cmd = ["powershell", "-NoProfile", "-Command", ps_script]
                startupinfo = _get_win_startupinfo()

                proc = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo, check=False)
                if proc.returncode == 0:
                    lines = proc.stdout.strip().splitlines()
                    for line in lines:
                        parts = line.strip().split(';;', 1)
                        if len(parts) == 2:
                            path, name = parts
                            dev_type = "android"
                            drives.add((path, name, dev_type))
                            logging.debug(f"USBDetector: Found WPD item: Name='{name}', Path='{path}', Type='{dev_type}'")
            except Exception as e:
                logging.error(f"Error scanning WPD devices: {e}")

        logging.debug(f"USBDetector: _get_removable_drives finished. Found {len(drives)} drives.")
        return drives

    def stop(self):
        self.running = False
        self.wait()

class USBEjectThread(QThread):
    result = Signal(bool, str)

    def __init__(self, path):
        super().__init__()
        self.path = path

    def run(self):
        logging.info(f"Attempting to eject device at path: {self.path}")
        
        device = None
        if psutil is not None:
            try:
                for part in psutil.disk_partitions(all=True):
                    if part.mountpoint == self.path:
                        device = part.device
                        break
            except Exception as e:
                self.result.emit(False, f"Failed to find device info: {e}")
                return
        
        if not device and sys.platform != "win32":
            # Check for GVFS/MTP paths on Linux which don't have a block device
            if not ("/run/user" in self.path or "gvfs" in self.path or "mtp" in self.path or "wpd://" in self.path):
                self.result.emit(False, f"Could not find device for mount point: {self.path}")
                return

        success = False
        error_message = ""

        try:
            if sys.platform == "win32":
                import ctypes
                from ctypes import wintypes

                GENERIC_READ = 0x80000000
                FILE_SHARE_READ = 0x00000001
                FILE_SHARE_WRITE = 0x00000002
                OPEN_EXISTING = 3
                
                FSCTL_LOCK_VOLUME = 0x00090018
                FSCTL_DISMOUNT_VOLUME = 0x00090020
                IOCTL_STORAGE_EJECT_MEDIA = 0x002D4808
                INVALID_HANDLE_VALUE = -1
                
                drive_letter = self.path.strip('\\')
                volume_path = f"\\\\.\\{drive_letter}"
                
                h_vol = ctypes.windll.kernel32.CreateFileW(
                    ctypes.c_wchar_p(volume_path),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    None,
                    OPEN_EXISTING,
                    0,
                    None
                )

                if h_vol == INVALID_HANDLE_VALUE:
                    raise ctypes.WinError()

                try:
                    bytes_returned = wintypes.DWORD()
                    ctypes.windll.kernel32.DeviceIoControl(h_vol, FSCTL_LOCK_VOLUME, None, 0, None, 0, ctypes.byref(bytes_returned), None)
                    ctypes.windll.kernel32.DeviceIoControl(h_vol, FSCTL_DISMOUNT_VOLUME, None, 0, None, 0, ctypes.byref(bytes_returned), None)
                    if ctypes.windll.kernel32.DeviceIoControl(h_vol, IOCTL_STORAGE_EJECT_MEDIA, None, 0, None, 0, ctypes.byref(bytes_returned), None):
                        success = True
                finally:
                    ctypes.windll.kernel32.CloseHandle(h_vol)

            elif sys.platform == "darwin":
                proc = subprocess.run(['diskutil', 'eject', self.path], capture_output=True, text=True, check=False)
                if proc.returncode == 0:
                    success = True
                else:
                    error_message = proc.stderr.strip()

            else: # Linux
                if device:
                    proc = subprocess.run(['udisksctl', 'unmount', '-b', device], capture_output=True, text=True, check=False)
                    if proc.returncode == 0:
                        subprocess.run(['udisksctl', 'power-off', '-b', device], capture_output=True, text=True, check=False)
                        success = True
                    else:
                        error_message = proc.stderr.strip()
                else:
                    # Try unmounting GVFS/FUSE mount
                    proc = subprocess.run(['gio', 'mount', '-u', self.path], capture_output=True, text=True, check=False)
                    if proc.returncode == 0:
                        success = True
                    else:
                        # Fallback to fusermount
                        proc = subprocess.run(['fusermount', '-u', self.path], capture_output=True, text=True, check=False)
                        if proc.returncode == 0:
                            success = True
                        else:
                            error_message = proc.stderr.strip()

        except Exception as e:
            error_message = str(e)
            logging.error(f"Eject failed for {self.path}: {e}")

        if success:
            is_android = "mtp" in self.path or "gvfs" in self.path or "wpd://" in self.path
            dev_label = "Android device" if is_android else "Device"
            self.result.emit(True, f"{dev_label} at {self.path} has been safely disconnected.")
        else:
            self.result.emit(False, f"Failed to eject device at {self.path}.\n\n{error_message}\n\nIt may be in use by another program.")

#============================================================================================
# --- Vector File Type SVG Icons (Matching Text-Editor) ---
#============================================================================================
FILE_EXTENSION_SVGS: Dict[str, str] = {
    "py": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#3776ab"/><path d="M11.5 5.5c-2.5 0-3.5.8-3.5 2v1.5h4v.5h-5.5C4.5 9.5 4 10.8 4 12.8s.7 2.2 2 2.2h1.5v-1.8c0-1.2 1-2.2 2.2-2.2h3.8c1 0 1.5-.7 1.5-1.5V7.5c0-1.2-1-2-3-2zm-1.2 1.2c.4 0 .8.4.8.8s-.4.8-.8.8-.8-.4-.8-.8.4-.8.8-.8zm2.2 11.8c2.5 0 3.5-.8 3.5-2V15h-4v-.5h5.5c2 0 2.5-1.3 2.5-3.3s-.7-2.2-2-2.2h-1.5v1.8c0 1.2-1 2.2-2.2 2.2h-3.8c-1 0-1.5.7-1.5 1.5v2c0 1.2 1 2 3 2zm1.2-1.2c-.4 0-.8-.4-.8-.8s.4-.8.8-.8.8.4.8.8-.4.8-.8.8z" fill="#ffd43b"/></svg>',
    "c": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#00599c"/><text x="12" y="16.5" font-family="sans-serif" font-weight="bold" font-size="13" fill="#ffffff" text-anchor="middle">C</text></svg>',
    "cpp": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#004482"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="10" fill="#ffffff" text-anchor="middle">C++</text></svg>',
    "java": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#ea2d2e"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="8.5" fill="#ffffff" text-anchor="middle">JAVA</text></svg>',
    "rs": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#ce412b"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">RS</text></svg>',
    "rb": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#cc342d"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="9" fill="#ffffff" text-anchor="middle">RUBY</text></svg>',
    "asm": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#2b5b84"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="9" fill="#ffffff" text-anchor="middle">ASM</text></svg>',
    "so": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#6366f1"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="10" fill="#ffffff" text-anchor="middle">.so</text></svg>',
    "html": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#e44d26"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">&lt;/&gt;</text></svg>',
    "css": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#264de4"/><text x="12" y="17" font-family="sans-serif" font-weight="900" font-size="14" fill="#ffffff" text-anchor="middle">#</text></svg>',
    "js": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#f7df1e"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="11" fill="#000000" text-anchor="middle">JS</text></svg>',
    "ts": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#3178c6"/><text x="12" y="16" font-family="sans-serif" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">TS</text></svg>',
    "csv": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#107c41"/><path d="M6 6h12v12H6z" fill="none" stroke="#ffffff" stroke-width="1.5"/><line x1="12" y1="6" x2="12" y2="18" stroke="#ffffff" stroke-width="1.5"/><line x1="6" y1="12" x2="18" y2="12" stroke="#ffffff" stroke-width="1.5"/></svg>',
    "json": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#f59e0b"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="12" fill="#000000" text-anchor="middle">{ }</text></svg>',
    "yaml": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#8b5cf6"/><circle cx="8" cy="8" r="2" fill="#ffffff"/><circle cx="16" cy="16" r="2" fill="#ffffff"/><line x1="8" y1="10" x2="8" y2="18" stroke="#ffffff" stroke-width="1.5"/><line x1="16" y1="6" x2="16" y2="14" stroke="#ffffff" stroke-width="1.5"/></svg>',
    "md": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#0284c7"/><path d="M5 15V9l3 3 3-3v6M17 12l-2 3-2-3M15 9v6" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    "txt": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>',
    "pdf": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#ef4444"/><text x="12" y="15" font-family="sans-serif" font-weight="900" font-size="8" fill="#ffffff" text-anchor="middle">PDF</text></svg>',
    "image": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#c084fc" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    "video": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#22d3ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
    "audio": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#f43f5e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    "archive": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#eab308" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    "exe": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>',
    "code": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    "sh": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#4e5666"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="#4ade80" text-anchor="middle">&gt;_</text></svg>',
    "ps1": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#012456"/><text x="12" y="16" font-family="monospace" font-weight="bold" font-size="11" fill="#ffffff" text-anchor="middle">&gt;_</text></svg>',
    "git": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><rect width="22" height="22" x="1" y="1" rx="4" fill="#f05032"/><circle cx="8" cy="8" r="2" fill="#ffffff"/><circle cx="16" cy="12" r="2" fill="#ffffff"/><circle cx="8" cy="16" r="2" fill="#ffffff"/><path d="M8 8v8M8 12h5" stroke="#ffffff" stroke-width="1.5"/></svg>',
    "phone": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><rect x="5" y="2" width="14" height="20" rx="3" ry="3" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/><rect x="7" y="5" width="10" height="13" rx="1" fill="#0f172a"/><circle cx="12" cy="3.5" r="0.6" fill="#94a3b8"/><line x1="10" y1="19.5" x2="14" y2="19.5" stroke="#94a3b8" stroke-width="1" stroke-linecap="round"/></svg>',
    "package": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48"><defs><linearGradient id="pkg_top" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#f5dcba"/><stop offset="100%" stop-color="#e7c69c"/></linearGradient><linearGradient id="pkg_left" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#dbae78"/><stop offset="100%" stop-color="#c7965c"/></linearGradient><linearGradient id="pkg_right" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#cb985c"/><stop offset="100%" stop-color="#b37e42"/></linearGradient><linearGradient id="pkg_tape" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#4a90e2"/><stop offset="100%" stop-color="#2060b0"/></linearGradient></defs><polygon points="24,45 44,35 24,25 4,35" fill="#000000" opacity="0.25"/><polygon points="24,24 44,14 44,33 24,43" fill="url(#pkg_right)"/><polygon points="4,14 24,24 24,43 4,33" fill="url(#pkg_left)"/><polygon points="24,5 44,14 24,24 4,14" fill="url(#pkg_top)"/><line x1="14" y1="9.5" x2="34" y2="19" stroke="#b37e42" stroke-width="0.8" opacity="0.6"/><polygon points="21,6.5 27,9.5 27,22.5 21,19.5" fill="url(#pkg_tape)"/><polygon points="21,19.5 27,22.5 27,34 21,31" fill="url(#pkg_tape)" opacity="0.9"/><polygon points="8,21 16,25 16,30 8,26" fill="#ffffff" opacity="0.85"/><line x1="10" y1="23" x2="14" y2="25" stroke="#333333" stroke-width="0.8"/><line x1="10" y1="25" x2="14" y2="27" stroke="#333333" stroke-width="0.8"/></svg>',
    "linux_exec": '<svg height="128px" viewBox="0 0 128 128" width="128px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><clipPath id="a"><path d="m 4 4 h 119 v 119 h -119 z m 0 0"/></clipPath><clipPath id="b"><path d="m 69.164062 6.558594 l 51.542969 51.542968 c 3.046875 3.046876 3.046875 7.988282 0 11.035157 l -51.542969 51.542969 c -3.046874 3.046874 -7.988281 3.046874 -11.035156 0 l -51.542968 -51.542969 c -3.046876 -3.046875 -3.046876 -7.988281 0 -11.035157 l 51.542968 -51.542968 c 3.046875 -3.046875 7.988282 -3.046875 11.035156 0 z m 0 0"/></clipPath><clipPath id="c"><path d="m 48 32 h 75 v 91 h -75 z m 0 0"/></clipPath><clipPath id="d"><path d="m 69.164062 6.558594 l 51.542969 51.542968 c 3.046875 3.046876 3.046875 7.988282 0 11.035157 l -51.542969 51.542969 c -3.046874 3.046874 -7.988281 3.046874 -11.035156 0 l -51.542968 -51.542969 c -3.046876 -3.046875 -3.046876 -7.988281 0 -11.035157 l 51.542968 -51.542968 c 3.046875 -3.046875 7.988282 -3.046875 11.035156 0 z m 0 0"/></clipPath><clipPath id="e"><path d="m 4 4 h 57 v 89 h -57 z m 0 0"/></clipPath><clipPath id="f"><path d="m 69.164062 6.558594 l 51.542969 51.542968 c 3.046875 3.046876 3.046875 7.988282 0 11.035157 l -51.542969 51.542969 c -3.046874 3.046874 -7.988281 3.046874 -11.035156 0 l -51.542968 -51.542969 c -3.046876 -3.046875 -3.046876 -7.988281 0 -11.035157 l 51.542968 -51.542968 c 3.046875 -3.046875 7.988282 -3.046875 11.035156 0 z m 0 0"/></clipPath><g clip-path="url(#a)"><g clip-path="url(#b)"><path d="m 65.136719 2.53125 l 59.597656 59.597656 c 0.824219 0.824219 0.824219 2.15625 0 2.980469 l -59.597656 59.597656 c -0.824219 0.824219 -2.15625 0.824219 -2.980469 0 l -59.597656 -59.597656 c -0.824219 -0.824219 -0.824219 -2.15625 0 -2.980469 l 59.597656 -59.597656 c 0.824219 -0.824219 2.15625 -0.824219 2.980469 0 z m 0 0" fill="#3584e4"/></g></g><g clip-path="url(#c)"><g clip-path="url(#d)"><path d="m 100.933594 32.875 l -2.410156 7.273438 c -0.117188 -0.007813 -0.230469 -0.011719 -0.347657 -0.015626 c -1.953125 0.011719 -3.902343 0.164063 -5.835937 0.449219 l -3.363282 -6.949219 c -2.4375 0.46875 -4.832031 1.117188 -7.171874 1.945313 l 0.558593 7.65625 c -1.910156 0.78125 -3.765625 1.707031 -5.542969 2.761719 l -5.78125 -5.148438 c -2.066406 1.371094 -4.027343 2.890625 -5.867187 4.554688 l 3.4375 6.84375 c -1.464844 1.460937 -2.820313 3.027344 -4.058594 4.6875 l -7.328125 -2.550782 c -1.378906 2.058594 -2.605468 4.21875 -3.660156 6.460938 l 5.785156 5 c -0.792968 1.910156 -1.441406 3.878906 -1.945312 5.886719 l -7.738282 0.449219 c -0.492187 2.429687 -0.800781 4.894531 -0.921874 7.371093 l 7.273437 2.410157 c -0.003906 0.113281 -0.011719 0.230468 -0.015625 0.347656 c 0.015625 1.953125 0.164062 3.902344 0.449219 5.835937 l -6.949219 3.363281 c 0.46875 2.433594 1.117188 4.832032 1.945312 7.167969 l 7.65625 -0.554687 c 0.785157 1.910156 1.707032 3.765625 2.761719 5.542968 l -5.148437 5.78125 c 1.371094 2.066407 2.894531 4.027344 4.554687 5.867188 l 6.84375 -3.4375 c 1.460938 1.464844 3.027344 2.820312 4.6875 4.054688 l -2.546875 7.332031 c 2.054688 1.378906 4.214844 2.601562 6.457032 3.660156 l 5 -5.785156 c 1.914062 0.792969 3.878906 1.441406 5.886718 1.945312 l 0.453125 7.738281 c 2.429688 0.488282 4.890625 0.796876 7.367188 0.921876 l 2.410156 -7.273438 c 0.117187 0.003906 0.230469 0.011719 0.347656 0.015625 c 1.953125 -0.015625 3.902344 -0.164063 5.835938 -0.449219 l 3.363281 6.949219 c 2.433594 -0.46875 4.832031 -1.117187 7.167969 -1.945313 l -0.554688 -7.65625 c 1.910157 -0.785156 3.765625 -1.707031 5.542969 -2.761718 l 5.78125 5.144531 c 2.066406 -1.367187 4.027344 -2.890625 5.867188 -4.550781 l -3.4375 -6.847656 c 1.464843 -1.457032 2.820312 -3.023438 4.054687 -4.683594 l 7.332031 2.546875 c 1.378906 -2.058594 2.601563 -4.214844 3.660156 -6.457031 l -5.785156 -5 c 0.792969 -1.914063 1.441406 -3.878907 1.945313 -5.886719 l 7.738281 -0.453125 c 0.492188 -2.429688 0.796875 -4.890625 0.921875 -7.367188 l -7.273437 -2.410156 c 0.003906 -0.117188 0.011718 -0.230469 0.015624 -0.347656 c -0.015624 -1.953125 -0.164062 -3.902344 -0.449218 -5.835938 l 6.949218 -3.363281 c -0.46875 -2.4375 -1.117187 -4.832031 -1.945312 -7.171875 l -7.65625 0.558594 c -0.785156 -1.914063 -1.707031 -3.765625 -2.761719 -5.542969 l 5.144531 -5.78125 c -1.367187 -2.066406 -2.890624 -4.027344 -4.550781 -5.867187 l -6.847656 3.4375 c -1.457031 -1.464844 -3.023437 -2.820313 -4.683594 -4.058594 l 2.546875 -7.328125 c -2.058594 -1.378907 -4.214844 -2.605469 -6.457031 -3.660157 l -5 5.785157 c -1.914063 -0.792969 -3.878906 -1.441407 -5.886719 -1.945313 l -0.453125 -7.738281 c -2.429687 -0.492187 -4.890625 -0.800781 -7.367187 -0.921875 z m -2.757813 18.484375 c 17.09375 0 30.949219 13.855469 30.949219 30.949219 s -13.855469 30.949218 -30.949219 30.949218 s -30.949219 -13.855468 -30.949219 -30.949218 s 13.855469 -30.949219 30.949219 -30.949219 z m 0 0" fill="#98c1f1"/></g></g><g clip-path="url(#e)"><g clip-path="url(#f)"><path d="m 13.84375 -6.292969 l -2.414062 7.273438 c -0.113282 -0.007813 -0.230469 -0.011719 -0.347657 -0.019531 c -1.953125 0.015624 -3.902343 0.167968 -5.832031 0.453124 l -3.367188 -6.949218 c -2.433593 0.46875 -4.832031 1.117187 -7.167968 1.945312 l 0.558594 7.65625 c -1.914063 0.78125 -3.765626 1.703125 -5.542969 2.757813 l -5.785157 -5.144531 c -2.066406 1.371093 -4.027343 2.890624 -5.867187 4.554687 l 3.4375 6.84375 c -1.464844 1.460937 -2.820313 3.027344 -4.054687 4.683594 l -7.328126 -2.546875 c -1.382812 2.058594 -2.605468 4.21875 -3.664062 6.460937 l 5.789062 5 c -0.792968 1.910157 -1.445312 3.878907 -1.949218 5.886719 l -7.738282 0.449219 c -0.488281 2.429687 -0.796874 4.894531 -0.917968 7.367187 l 7.273437 2.414063 c -0.007812 0.113281 -0.011719 0.230469 -0.019531 0.347656 c 0.015625 1.953125 0.167969 3.902344 0.453125 5.832031 l -6.949219 3.367188 c 0.464844 2.433594 1.117188 4.832031 1.941406 7.167968 l 7.660157 -0.558593 c 0.78125 1.914062 1.703125 3.765625 2.757812 5.542969 l -5.144531 5.785156 c 1.367188 2.066406 2.890625 4.027344 4.554688 5.867187 l 6.84375 -3.4375 c 1.460937 1.464844 3.027343 2.820313 4.683593 4.054688 l -2.546875 7.328125 c 2.058594 1.382812 4.21875 2.605468 6.457032 3.664062 l 5.003906 -5.785156 c 1.910156 0.789062 3.878906 1.441406 5.886718 1.945312 l 0.449219 7.738282 c 2.429688 0.488281 4.890625 0.796875 7.367188 0.917968 l 2.410156 -7.273437 c 0.117187 0.007813 0.234375 0.015625 0.347656 0.019531 c 1.953125 -0.015625 3.902344 -0.167968 5.835938 -0.453125 l 3.367187 6.949219 c 2.433594 -0.464844 4.828125 -1.117188 7.167969 -1.941406 l -0.558594 -7.660156 c 1.914063 -0.78125 3.765625 -1.703126 5.542969 -2.757813 l 5.785156 5.144531 c 2.066406 -1.367187 4.027344 -2.890625 5.863282 -4.554687 l -3.4375 -6.84375 c 1.46875 -1.460938 2.824218 -3.023438 4.058593 -4.683594 l 7.328125 2.546875 c 1.382813 -2.058594 2.605469 -4.21875 3.664063 -6.457031 l -5.789063 -5 c 0.792969 -1.914063 1.445313 -3.882813 1.949219 -5.890625 l 7.734375 -0.449219 c 0.492188 -2.429687 0.800781 -4.890625 0.921875 -7.367188 l -7.273437 -2.410157 c 0.007812 -0.117187 0.011718 -0.234375 0.019531 -0.347656 c -0.015625 -1.953125 -0.167969 -3.902344 -0.453125 -5.835937 l 6.949218 -3.367188 c -0.46875 -2.433594 -1.117187 -4.828125 -1.941406 -7.167969 l -7.660156 0.558594 c -0.78125 -1.914063 -1.703125 -3.765625 -2.757812 -5.542969 l 5.144531 -5.785156 c -1.371094 -2.066406 -2.890625 -4.027344 -4.554688 -5.863281 l -6.84375 3.4375 c -1.460937 -1.464844 -3.027343 -2.824219 -4.683593 -4.058594 l 2.546874 -7.328125 c -2.058593 -1.378906 -4.21875 -2.605469 -6.460937 -3.664062 l -5 5.789062 c -1.910156 -0.792969 -3.878906 -1.445312 -5.886719 -1.949219 l -0.449218 -7.734375 c -2.429688 -0.492187 -4.894532 -0.800781 -7.367188 -0.921875 z m 0 0" fill="#1a5fb4"/></g></g><path d="m 5.167969 60.457031 c -1.234375 3.042969 -0.613281 6.644531 1.859375 9.117188 l 50.660156 50.664062 c 3.300781 3.300781 8.617188 3.300781 11.917969 0 l 50.660156 -50.664062 c 2.472656 -2.472657 3.09375 -6.074219 1.859375 -9.117188 c -0.410156 1.019531 -1.03125 1.972657 -1.859375 2.800781 l -50.660156 50.660157 c -3.300781 3.300781 -8.617188 3.300781 -11.917969 0 l -50.660156 -50.660157 c -0.828125 -0.828124 -1.449219 -1.78125 -1.859375 -2.800781 z m 0 0" fill="#1a5fb4" fill-opacity="0.501961"/></svg>',
    "generic": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
}

_FILE_ICON_CACHE: Dict[str, QIcon] = {}


def is_linux_executable_file(path_str: Optional[str]) -> bool:
    """Checks if a filesystem path is an executable ELF binary or executable file on Linux."""
    if not path_str:
        return False
    try:
        if os.path.isfile(path_str):
            try:
                with open(path_str, "rb") as f:
                    if f.read(4) == b"\x7fELF":
                        return True
            except (OSError, PermissionError):
                pass
            if os.access(path_str, os.X_OK):
                ext = os.path.splitext(path_str)[1].lower()
                if not ext or ext in (".bin", ".run", ".elf", ".out", ".appimage", ".x86_64", ".x86"):
                    return True
    except (OSError, ValueError):
        pass
    return False


def get_file_extension_qicon(ext_or_path: Optional[str]) -> QIcon:
    """Returns a high-resolution QIcon for the given file extension or path using Text-Editor SVG vectors."""
    if not ext_or_path:
        key = "generic"
    else:
        ext_str = ext_or_path.lower().split("?")[0].split("#")[0]
        filename = os.path.basename(ext_str)
        if ext_str in ("phone", "android", "smartphone") or filename in ("phone", "android", "smartphone"):
            key = "phone"
        elif filename.startswith(".git") or ext_str.endswith(".gitignore"):
            key = "git"
        elif "." in ext_str:
            ext = ext_str.rsplit(".", 1)[-1]
            if ext in ("rpm", "deb", "iso", "pkg", "apk", "flatpak", "snap", "appx", "msix"):
                key = "package"
            elif ext in ("bin", "run", "elf", "appimage", "x86_64", "x86", "out"):
                key = "linux_exec"
            elif ext in ("py", "pyw", "ipynb"):
                key = "py"
            elif ext in ("c", "h"):
                key = "c"
            elif ext in ("cpp", "hpp", "cxx", "hxx", "cc", "hh", "c++", "tpp", "inl"):
                key = "cpp"
            elif ext in ("java", "class", "jar"):
                key = "java"
            elif ext in ("rs", "rlib"):
                key = "rs"
            elif ext in ("rb", "rake", "gemspec", "ru"):
                key = "rb"
            elif ext in ("asm", "s", "nasm", "inc", "a51"):
                key = "asm"
            elif ext in ("so", "dylib", "dll", "lib", "a", "o", "obj"):
                key = "so"
            elif ext in ("html", "htm", "xhtml"):
                key = "html"
            elif ext in ("css", "scss", "sass", "less", "qss"):
                key = "css"
            elif ext in ("js", "jsx", "mjs", "cjs"):
                key = "js"
            elif ext in ("ts", "tsx"):
                key = "ts"
            elif ext in ("csv", "tsv", "xlsx", "xls", "ods"):
                key = "csv"
            elif ext in ("json", "jsonc", "json5"):
                key = "json"
            elif ext in ("yaml", "yml", "toml", "ini", "cfg", "conf", "env"):
                key = "yaml"
            elif ext in ("md", "markdown", "rst"):
                key = "md"
            elif ext in ("ps1", "psm1", "psd1"):
                key = "ps1"
            elif ext in ("sh", "bash", "zsh", "fish"):
                key = "sh"
            elif ext in ("txt", "log", "rtf"):
                key = "txt"
            elif ext == "pdf":
                key = "pdf"
            elif ext in ("png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico", "tiff", "avif"):
                key = "image"
            elif ext in ("mp4", "mov", "mkv", "avi", "wmv", "webm", "flv", "ts", "m4v"):
                key = "video"
            elif ext in ("mp3", "wav", "flac", "aac", "ogg", "m4a", "wma"):
                key = "audio"
            elif ext in ("zip", "rar", "7z", "tar", "gz", "bz2", "xz"):
                key = "archive"
            elif ext in ("exe", "bat", "cmd"):
                key = "exe"
            elif ext in ("go", "cs", "sql", "xml"):
                key = "code"
            else:
                key = "linux_exec" if is_linux_executable_file(ext_or_path) else "generic"
        elif is_linux_executable_file(ext_or_path):
            key = "linux_exec"
        elif filename in ("package", "rpm", "deb", "iso", "pkg"):
            key = "package"
        elif filename in ("linux_exec", "executable", "bin", "run", "elf", "appimage", "a.out"):
            key = "linux_exec"
        elif filename in ("readme", "license", "copying", "authors", "changelog"):
            key = "txt"
        else:
            key = "generic"

    if key in _FILE_ICON_CACHE:
        return _FILE_ICON_CACHE[key]

    try:
        svg_data = FILE_EXTENSION_SVGS.get(key, FILE_EXTENSION_SVGS["generic"])
        renderer = QSvgRenderer(QByteArray(svg_data.encode("utf-8")))
        icon = QIcon()
        for size in (16, 24, 32, 48, 64, 128):
            img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
            img.fill(Qt.GlobalColor.transparent)
            painter = QPainter(img)
            target_size = size * (25.0 / 32.0)
            offset = (size - target_size) / 2.0
            renderer.render(painter, QRectF(offset, offset, target_size, target_size))
            painter.end()
            icon.addPixmap(QPixmap.fromImage(img))
        _FILE_ICON_CACHE[key] = icon
        return icon
    except (ValueError, TypeError, RuntimeError, OSError):
        return QIcon()


#============================================================================================
# --- Custom QFileSystemModel to Handle Thumbnails and Folder Sizes ---
#============================================================================================
class ThumbnailFileSystemModel(QFileSystemModel):
    def __init__(self):
        super().__init__()
        self.thumbnail_cache = {}
        self.worker = ThumbnailWorker()
        self.worker.thumbnail_loaded.connect(self.on_thumbnail_loaded)
        self.worker.start()
        self.image_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.gif', '.svg', '.webp', '.ico', '.tif', '.tiff'}
        
        self.cache_dir = user_data_dir(APP_NAME, APP_AUTHOR)
        self.cache_file = os.path.join(self.cache_dir, "folder_sizes.json")
        self.folder_size_cache = self.load_cache()
        
        self.size_worker = FolderSizeWorker()
        self.size_worker.size_calculated.connect(self.on_folder_size_loaded)
        self.size_worker.start()

    def load_cache(self):
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            logging.warning(f"Failed to load folder size cache: {e}")
        return {}

    def save_cache(self):
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump(self.folder_size_cache, f)
        except Exception as e:
            logging.warning(f"Failed to save folder size cache: {e}")

    def data(self, index, role=Qt.ItemDataRole.DecorationRole):
        if role == Qt.ItemDataRole.DecorationRole and index.column() == 0:
            path = self.filePath(index)
            if path in self.thumbnail_cache:
                return self.thumbnail_cache[path]
            
            if not self.isDir(index):
                ext = os.path.splitext(path)[1].lower()
                if ext in self.image_extensions:
                    self.worker.request_thumbnail(path)
                return get_file_extension_qicon(path)
        
        elif role == Qt.ItemDataRole.DisplayRole and index.column() == 1:
            if self.isDir(index):
                path = self.filePath(index)
                self.size_worker.request_size(path)
                if path in self.folder_size_cache:
                    return self.folder_size_cache[path][1]
                
                return "..."
        
        elif role == Qt.ItemDataRole.UserRole and index.column() == 1:
            if self.isDir(index):
                path = self.filePath(index)
                if path in self.folder_size_cache:
                    return self.folder_size_cache[path][0] # Return raw bytes
                return 0
            else:
                return self.size(index) # QFileSystemModel returns bytes for files
                
        return super().data(index, role)

    def on_thumbnail_loaded(self, path, image):
        pixmap = QPixmap.fromImage(image)
        if pixmap.isNull():
             logging.warning(f"Pixmap is null for {path}")
             return
        icon = QIcon(pixmap)
        self.thumbnail_cache[path] = icon
        
        index = self.index(path)
        if index.isValid():
            self.dataChanged.emit(index, index, [Qt.ItemDataRole.DecorationRole])
        else:
            logging.warning(f"Invalid index for path {path} in on_thumbnail_loaded")
            
    def on_folder_size_loaded(self, path, raw_size, size_str):
        self.folder_size_cache[path] = (raw_size, size_str)
        index = self.index(path)
        if index.isValid():
            # Column 1 is size
            size_index = index.sibling(index.row(), 1)
            self.dataChanged.emit(size_index, size_index, [Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.UserRole])
            
    def shutdown(self):
        self.worker.stop()
        self.size_worker.stop()
        self.save_cache()

    def set_workers_paused(self, paused):
        logging.debug(f"ThumbnailFileSystemModel pausing workers: {paused}")
        self.worker.set_paused(paused)
        self.size_worker.set_paused(paused)

#============================================================================================
# --- WPD Sorting Proxy Model ---
#============================================================================================
class WPDSortFilterProxyModel(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSortCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.setDynamicSortFilter(True)

    def lessThan(self, left, right):
        source_model = self.sourceModel()
        
        # Always sort folders first
        # IsFolder is stored in column 0 UserRole
        left_is_folder = source_model.data(source_model.index(left.row(), 0, left.parent()), Qt.ItemDataRole.UserRole)
        right_is_folder = source_model.data(source_model.index(right.row(), 0, right.parent()), Qt.ItemDataRole.UserRole)
        
        if left_is_folder != right_is_folder:
            # If Ascending, we want True (Folder) < False (File) to be treated as "Folder comes first"
            # But standard sort puts smaller items first.
            # If we return True, left comes first.
            # We want Folder (True) to come first.
            return self.sortOrder() == Qt.SortOrder.AscendingOrder if left_is_folder else self.sortOrder() != Qt.SortOrder.AscendingOrder

        # For Size (1) and Date (3), use the UserRole data which holds raw values
        if left.column() == 1 or left.column() == 3:
            left_data = source_model.data(left, Qt.ItemDataRole.UserRole)
            right_data = source_model.data(right, Qt.ItemDataRole.UserRole)
            
            if left_data is None: 
                left_data = 0 if left.column() == 1 else ""
            if right_data is None: 
                right_data = 0 if right.column() == 1 else ""
            
            return left_data < right_data
        
        return super().lessThan(left, right)

#============================================================================================
# --- Folder Selection Dialog for Copy/Move Operations ---
#============================================================================================
class FolderSelectionDialog(QDialog):
    def __init__(self, parent=None, start_path=None):
        super().__init__(parent)
        self.setWindowTitle("Select Destination Folder")
        self.resize(1000, 600)
        
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        self.sidebar_minimized = False
        self.history = []
        self.history_index = -1
        
        # Main Layout for Dialog (Browser + Buttons)
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Browser Widget (Mimics Main Window Central Widget)
        self.browser_widget = QWidget()
        self.browser_layout = QBoxLayout(QBoxLayout.Direction.LeftToRight, self.browser_widget)
        self.browser_layout.setContentsMargins(0, 0, 0, 0)
        self.browser_layout.setSpacing(0)
        
        # --- Sidebar ---
        self.sidebar_container = QWidget()
        self.sidebar_layout = QBoxLayout(QBoxLayout.Direction.TopToBottom, self.sidebar_container)
        self.sidebar_layout.setContentsMargins(5, 5, 5, 5)
        
        self.sidebar_label = QLabel("Quick Access")
        self.note_list = QListWidget()
        self.note_list.setIconSize(QSize(18, 18))
        self.note_list.setStyleSheet("""
            QListWidget {
                border: none;
                background-color: #252525;
            }
            QListWidget::item {
                padding: 4px;
            }
        """)
        self.load_quick_access_items()
        self.note_list.itemClicked.connect(self.on_sidebar_click)
        
        self.sidebar_layout.addWidget(self.sidebar_label)
        self.sidebar_layout.addWidget(self.note_list)
        
        # Toggle Button
        self.btn_toggle_sidebar = QPushButton("<")
        self.btn_toggle_sidebar.setFixedWidth(16)
        self.btn_toggle_sidebar.setToolTip("Minimize/Expand Quick Access")
        self.btn_toggle_sidebar.clicked.connect(self.toggle_sidebar)
        self.btn_toggle_sidebar.setStyleSheet("""
            QPushButton {
                background-color: #252525;
                color: #888;
                border-left: 1px solid #444;
                border-right: 1px solid #444;
                font-size: 10px;
                padding: 0px;
                min-height: 80px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #333;
                color: #007AFF;
            }
        """)
        
        # --- Content Area ---
        self.content_container = QWidget()
        self.content_layout = QVBoxLayout(self.content_container)
        self.content_layout.setContentsMargins(5, 5, 5, 5)
        
        # Toolbar
        self.toolbar_widget = QWidget()
        self.toolbar_layout = QGridLayout(self.toolbar_widget)
        self.toolbar_layout.setContentsMargins(0, 0, 0, 5)
        
        btn_square_size = 32
        tool_icon_size = QSize(28, 28)
        nav_btn_style = """
            QPushButton {
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 2px;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
            QPushButton:pressed {
                background-color: #007AFF;
            }
            QPushButton:disabled {
                background-color: transparent;
                border: 1px solid transparent;
            }
        """
        
        # Back
        self.btn_back = QPushButton("◀")
        self.btn_back.setStyleSheet(nav_btn_style)
        self.btn_back.setFixedSize(btn_square_size, btn_square_size)
        self.btn_back.setIconSize(tool_icon_size)
        back_icon = resource_path(os.path.join("assets", "icons", "back.png"))
        if not os.path.exists(back_icon):
            back_icon = resource_path(os.path.join("assets", "icons", "left.png"))
        if os.path.exists(back_icon):
            self.btn_back.setIcon(QIcon(back_icon))
            self.btn_back.setText("")
        self.btn_back.clicked.connect(self.go_back)
        
        # Forward
        self.btn_forward = QPushButton("▶")
        self.btn_forward.setStyleSheet(nav_btn_style)
        self.btn_forward.setFixedSize(btn_square_size, btn_square_size)
        self.btn_forward.setIconSize(tool_icon_size)
        forward_icon = resource_path(os.path.join("assets", "icons", "forward.png"))
        if not os.path.exists(forward_icon):
            forward_icon = resource_path(os.path.join("assets", "icons", "right.png"))
        if os.path.exists(forward_icon):
            self.btn_forward.setIcon(QIcon(forward_icon))
            self.btn_forward.setText("")
        self.btn_forward.clicked.connect(self.go_forward)
        
        # Up
        self.btn_up = QPushButton("▲")
        self.btn_up.setStyleSheet(nav_btn_style)
        self.btn_up.setFixedSize(btn_square_size, btn_square_size)
        self.btn_up.setIconSize(tool_icon_size)
        up_icon = resource_path(os.path.join("assets", "icons", "up.png"))
        if os.path.exists(up_icon):
            self.btn_up.setIcon(QIcon(up_icon))
            self.btn_up.setText("")
        self.btn_up.clicked.connect(self.go_up)
        
        # Home
        self.btn_home = QPushButton("🏠")
        self.btn_home.setStyleSheet(nav_btn_style)
        self.btn_home.setFixedSize(btn_square_size, btn_square_size)
        self.btn_home.setIconSize(tool_icon_size)
        home_icon = resource_path(os.path.join("assets", "icons", "home.png"))
        if os.path.exists(home_icon):
            self.btn_home.setIcon(QIcon(home_icon))
            self.btn_home.setText("")
        self.btn_home.clicked.connect(self.go_home)
        
        # Address Bar
        self.address_bar = QLineEdit()
        self.address_bar.returnPressed.connect(self.navigate_to_address)
        
        self.toolbar_layout.addWidget(self.btn_back, 0, 0)
        self.toolbar_layout.addWidget(self.btn_forward, 0, 1)
        self.toolbar_layout.addWidget(self.btn_up, 0, 2)
        self.toolbar_layout.addWidget(self.btn_home, 0, 3)
        self.toolbar_layout.addWidget(self.address_bar, 0, 4)
        
        # Tree View
        self.model = QFileSystemModel()
        self.model.setRootPath(QDir.rootPath())
        self.model.setFilter(QDir.Filter.AllDirs | QDir.Filter.NoDotAndDotDot)
        
        self.proxy_model = DotFileProxyModel(self)
        self.proxy_model.setSourceModel(self.model)
        
        self.tree = QTreeView()
        self.tree = FileTreeView()
        self.tree.setModel(self.proxy_model)
        self.tree.setRootIndex(self.proxy_model.mapFromSource(self.model.index(QDir.rootPath())))
        self.tree.setSortingEnabled(True)
        self.tree.setColumnWidth(0, 300)
        self.tree.hideColumn(1)
        self.tree.hideColumn(2)
        self.tree.hideColumn(3)
        self.tree.doubleClicked.connect(self.on_tree_double_click)
        
        self.content_layout.addWidget(self.toolbar_widget)
        self.content_layout.addWidget(self.tree)
        
        self.browser_layout.addWidget(self.sidebar_container)
        self.browser_layout.addWidget(self.btn_toggle_sidebar)
        self.browser_layout.addWidget(self.content_container)
        
        self.sidebar_container.setFixedWidth(180)
        
        self.main_layout.addWidget(self.browser_widget)
        
        # Dialog Buttons
        btn_container = QWidget()
        btn_layout = QHBoxLayout(btn_container)
        btn_layout.setContentsMargins(10, 10, 10, 10)
        
        self.btn_select = QPushButton("Select Folder")
        self.btn_select.setFixedSize(120, 30)
        self.btn_select.clicked.connect(self.accept)
        
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setFixedSize(120, 30)
        self.btn_cancel.clicked.connect(self.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_select)
        btn_layout.addWidget(self.btn_cancel)
        
        self.main_layout.addWidget(btn_container)
        
        # Initialize
        if start_path and os.path.exists(start_path):
            self.navigate_to(start_path)
        else:
            self.go_home()

    def load_quick_access_items(self):
        data = self.settings.value("quick_access_items")
        items = []
        if data:
            try:
                items = json.loads(data)
            except Exception:
                pass
        if not items:
            items = [
                {"name": "Home", "path": QDir.homePath()},
                {"name": "Desktop", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation)},
                {"name": "Documents", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)},
                {"name": "Downloads", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)},
                {"name": "Pictures", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)},
                {"name": "Music", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MusicLocation)},
                {"name": "Videos", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MoviesLocation)},
                {"name": "Trash", "path": get_trash_directory()},
            ]

        # Ensure Pictures, Music, Videos, and Trash are added if missing from previous settings
        existing_names = {entry.get("name", "").strip().lower() for entry in items}
        for std_name, std_path in [
            ("Pictures", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)),
            ("Music", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MusicLocation)),
            ("Videos", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MoviesLocation)),
            ("Trash", get_trash_directory()),
        ]:
            if std_name.lower() not in existing_names and std_path and (std_name == "Trash" or os.path.exists(std_path)):
                items.append({"name": std_name, "path": std_path})
                existing_names.add(std_name.lower())

        if sys.platform == "win32":
            onedrive_pics = os.path.join(os.path.expanduser("~"), "OneDrive", "Pictures")
            if os.path.exists(onedrive_pics):
                if not any(item.get("path") == onedrive_pics for item in items):
                    items.append({"name": "Pictures", "path": onedrive_pics})

        self.note_list.clear()
        for entry in items:
            name = entry.get("name")
            path = entry.get("path")
            if name and path:
                item = QListWidgetItem(get_quick_access_icon(name=name, path=path), name)
                item.setData(Qt.ItemDataRole.UserRole, path)
                self.note_list.addItem(item)

    def on_sidebar_click(self, item):
        path = item.data(Qt.ItemDataRole.UserRole)
        if path:
            if not os.path.exists(path) and item.text().lower() == "trash":
                try:
                    os.makedirs(path, exist_ok=True)
                except Exception:
                    pass
            self.navigate_to(path)

    def toggle_sidebar(self):
        self.sidebar_minimized = not self.sidebar_minimized
        self.btn_toggle_sidebar.setText(">" if self.sidebar_minimized else "<")
        if self.sidebar_minimized:
            self.sidebar_container.setFixedWidth(0)
            self.sidebar_container.hide()
        else:
            self.sidebar_container.show()
            self.sidebar_container.setFixedWidth(180)

    def navigate_to(self, path):
        path = os.path.normpath(path)
        if not os.path.exists(path):
            return
        if self.history_index >= 0 and self.history[self.history_index] == path:
            return
        if self.history_index < len(self.history) - 1:
            self.history = self.history[:self.history_index+1]
        self.history.append(path)
        self.history_index = len(self.history) - 1
        self.update_view(path)

    def update_view(self, path):
        self.model.setRootPath(path)
        source_index = self.model.index(path)
        proxy_index = self.proxy_model.mapFromSource(source_index)
        self.tree.setRootIndex(proxy_index)
        self.address_bar.setText(path)
        self.update_nav_buttons()

    def update_nav_buttons(self):
        self.btn_back.setEnabled(self.history_index > 0)
        self.btn_forward.setEnabled(self.history_index < len(self.history) - 1)

    def navigate_to_address(self):
        path = self.address_bar.text()
        self.navigate_to(path)

    def go_back(self):
        if self.history_index > 0:
            self.history_index -= 1
            path = self.history[self.history_index]
            self.update_view(path)

    def go_forward(self):
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            path = self.history[self.history_index]
            self.update_view(path)

    def go_up(self):
        current = self.address_bar.text()
        parent = os.path.dirname(current)
        self.navigate_to(parent)

    def go_home(self):
        self.navigate_to(QDir.homePath())
        
    def on_tree_double_click(self, index):
        source_index = self.proxy_model.mapToSource(index)
        path = self.model.filePath(source_index)
        if os.path.isdir(path):
            self.navigate_to(path)

    def selected_path(self):
        indexes = self.tree.selectedIndexes()
        if indexes:
            source_index = self.proxy_model.mapToSource(indexes[0])
            path = self.model.filePath(source_index)
            if os.path.isdir(path):
                return path
        return self.address_bar.text()

#============================================================================================
# --- Open With Dialog ---
#============================================================================================
class OpenWithDialog(QDialog):
    def __init__(self, file_path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Open With...")
        self.file_path = file_path
        self.selected_app = None
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        self.resize(400, 300)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Choose an application to open:\n{os.path.basename(file_path)}"))

        self.app_list = QListWidget()
        self.load_recent_apps()
        layout.addWidget(self.app_list)
        self.app_list.setIconSize(QSize(32, 32))

        btn_layout = QHBoxLayout()
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browse_for_app)
        btn_layout.addWidget(browse_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        dialog_btns = QHBoxLayout()
        ok_btn = QPushButton("OK")
        cancel_btn = QPushButton("Cancel")
        ok_btn.setFixedWidth(100)
        cancel_btn.setFixedWidth(100)
        ok_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        dialog_btns.addStretch()
        dialog_btns.addWidget(ok_btn)
        dialog_btns.addWidget(cancel_btn)
        layout.addLayout(dialog_btns)

    def load_recent_apps(self):
        raw_apps = self.settings.value("open_with_apps", [])
        if isinstance(raw_apps, str):
            apps = [raw_apps] if raw_apps else []
        elif isinstance(raw_apps, list):
            apps = [str(x) for x in raw_apps]
        else:
            apps = []
        provider = QFileIconProvider()
        if apps:
            for app_path in apps:
                if os.path.exists(app_path):
                    item = QListWidgetItem(os.path.basename(app_path))
                    item.setData(Qt.ItemDataRole.UserRole, app_path)
                    item.setIcon(provider.icon(QFileInfo(app_path)))
                    self.app_list.addItem(item)

    def save_recent_apps(self, new_app_path):
        raw_apps = self.settings.value("open_with_apps", [])
        if isinstance(raw_apps, str):
            apps = [raw_apps] if raw_apps else []
        elif isinstance(raw_apps, list):
            apps = [str(x) for x in raw_apps]
        else:
            apps = []
        if new_app_path in apps: 
            apps.remove(new_app_path)
        apps.insert(0, new_app_path)
        self.settings.setValue("open_with_apps", apps[:10])

    def browse_for_app(self):
        start_dir = "/usr/bin"
        if sys.platform == "win32":
            start_dir = os.path.join(os.path.expanduser("~"), "AppData", "Local", "Programs")
        elif sys.platform == "darwin":
            start_dir = "/Applications"
            
        filter_str = {"win32": "Applications (*.exe)", "darwin": "Applications (*.app)"}.get(sys.platform, "All files (*)")
        app_path, _ = QFileDialog.getOpenFileName(self, "Select Application", start_dir, filter_str)
        if app_path:
            if not any(self.app_list.item(i).data(Qt.ItemDataRole.UserRole) == app_path for i in range(self.app_list.count())):
                item = QListWidgetItem(os.path.basename(app_path))
                item.setData(Qt.ItemDataRole.UserRole, app_path)
                provider = QFileIconProvider()
                item.setIcon(provider.icon(QFileInfo(app_path)))
                self.app_list.insertItem(0, item)
            self.app_list.setCurrentRow(0)

    def accept(self):
        current_item = self.app_list.currentItem()
        if current_item:
            self.selected_app = current_item.data(Qt.ItemDataRole.UserRole)
            self.save_recent_apps(self.selected_app)
            super().accept()
        else:
            QMessageBox.warning(self, "No Application Selected", "Please select an application or browse for one.")

#============================================================================================
# -- File View Mixin & Classes ---
#============================================================================================
if TYPE_CHECKING:
    _BaseItemView = QAbstractItemView
else:
    _BaseItemView = object


class FileViewActions(_BaseItemView):
    """Mixin class to handle file operations and context menus for both Tree and List views."""
    def init_actions(self):
        self._cut_paths = []
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._undo_stack = []
        self._redo_stack = []

    def add_undo_action(self, action):
        self._undo_stack.append(action)
        self._redo_stack.clear()

    def undo(self):
        if not self._undo_stack:
            return
        action = self._undo_stack.pop()
        self._redo_stack.append(action)
        self.perform_undo(action)

    def redo(self):
        if not self._redo_stack:
            return
        action = self._redo_stack.pop()
        self._undo_stack.append(action)
        self.perform_redo(action)

    def perform_undo(self, action):
        try:
            op = action['type']
            if op == 'rename':
                os.rename(action['new_path'], action['old_path'])
            elif op in ('new_folder', 'new_file'):
                if os.path.isdir(action['path']):
                    shutil.rmtree(action['path'])
                else:
                    os.remove(action['path'])
            elif op == 'copy':
                for dest in action['dest_paths']:
                    if os.path.isdir(dest):
                        shutil.rmtree(dest)
                    else:
                        os.remove(dest)
            elif op == 'move':
                for src, dest in zip(action['src_paths'], action['dest_paths']):
                    shutil.move(dest, src)
        except Exception as e:
            logging.warning(f"Undo failed: {e}")

    def perform_redo(self, action):
        try:
            op = action['type']
            if op == 'rename':
                os.rename(action['old_path'], action['new_path'])
            elif op == 'new_folder':
                os.makedirs(action['path'], exist_ok=True)
            elif op == 'new_file':
                with open(action['path'], 'w'): 
                    pass
            elif op == 'copy':
                for src, dest in zip(action['src_paths'], action['dest_paths']):
                    if os.path.isdir(src):
                        shutil.copytree(src, dest)
                    else:
                        shutil.copy2(src, dest)
            elif op == 'move':
                for src, dest in zip(action['src_paths'], action['dest_paths']):
                    shutil.move(src, dest)
        except Exception as e:
            logging.warning(f"Redo failed: {e}")

    def get_current_path(self):
        proxy_model: Any = self.model()
        if not proxy_model or not hasattr(proxy_model, "mapToSource"):
            return QDir.homePath()
        root_index = self.rootIndex()
        source_index = proxy_model.mapToSource(root_index)
        fs_model: Any = proxy_model.sourceModel()
        if not fs_model or not hasattr(fs_model, "filePath"):
            return QDir.homePath()
        return fs_model.filePath(source_index)

    def mousePressEvent(self, event):
        # Deselect if clicking on empty space
        index = self.indexAt(event.position().toPoint())
        if not index.isValid():
            self.clearSelection()
            self.setCurrentIndex(QModelIndex())
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copy_to_clipboard(None)
        elif event.matches(QKeySequence.StandardKey.Cut):
            self.cut_to_clipboard(None)
        elif event.matches(QKeySequence.StandardKey.Paste):
            self.paste_files(self.get_current_path())
        elif event.matches(QKeySequence.StandardKey.SelectAll):
            self.selectAll()
        elif event.matches(QKeySequence.StandardKey.Undo):
            self.undo()
        elif event.matches(QKeySequence.StandardKey.Redo):
            self.redo()
        elif event.key() == Qt.Key.Key_Delete:
            self.delete_item()
        else:
            super().keyPressEvent(event)

    def contextMenuEvent(self, event):
        index = self.indexAt(event.pos())
        if index.isValid():
            self.show_item_context_menu(index, event.globalPos())
            return

        current_path = self.get_current_path()
        in_trash = is_trash_path(current_path)

        menu = QMenu(self)
        
        clipboard = QApplication.clipboard()
        has_paste = clipboard.mimeData().hasUrls()
        
        new_folder_action = menu.addAction("New Folder")
        new_file_action = menu.addAction("New File")
        open_with_action = menu.addAction("Open With..")
        console_action = menu.addAction("Open in Console")
        menu.addSeparator()
        
        empty_trash_action = None
        if in_trash:
            empty_trash_action = menu.addAction("Empty Trash...")
            empty_trash_action.setEnabled(not is_trash_empty())
            menu.addSeparator()

        paste_action = menu.addAction("Paste")
        if not has_paste:
            paste_action.setEnabled(False)
            
        menu.addSeparator()
        select_all_action = menu.addAction("Select All")
        menu.addSeparator()
        props_action = menu.addAction("Properties")
        
        action = menu.exec(event.globalPos())
        
        if not current_path:
            return
            
        if action == new_folder_action:
            self.create_new_folder(current_path)
        elif action == new_file_action:
            self.create_new_file(current_path)
        elif action == open_with_action:
            QDesktopServices.openUrl(QUrl.fromLocalFile(current_path))
        elif action == console_action:
            self.open_in_console(current_path)
        elif empty_trash_action and action == empty_trash_action:
            win = self.window()
            if hasattr(win, "empty_trash"):
                win.empty_trash()
        elif action == paste_action:
            self.paste_files(current_path)
        elif action == select_all_action:
            self.selectAll()
        elif action == props_action:
            self.show_properties(current_path)

    def create_new_folder(self, path):
        name, ok = QInputDialog.getText(self, "New Folder", "Name:")
        if ok and name:
            new_path = os.path.join(path, name)
            if not os.path.exists(new_path):
                try:
                    os.makedirs(new_path)
                    self.add_undo_action({'type': 'new_folder', 'path': new_path})
                except OSError as e:
                    QMessageBox.warning(self, "Error", f"Failed to create folder: {e}")
            else:
                QMessageBox.warning(self, "Error", "Folder already exists.")

    def open_in_console(self, path):
        try:
            if hasattr(self, 'open_terminal_requested'):
                self.open_terminal_requested.emit(path)
                return

            if sys.platform == 'win32':
                subprocess.Popen(['start', 'cmd'], cwd=path, shell=True)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', '-a', 'Terminal', path])
            else:
                # Linux fallback
                subprocess.Popen(['x-terminal-emulator'], cwd=path)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to open console: {e}")

    def paste_files(self, target_path):
        clipboard = QApplication.clipboard()
        mime_data = clipboard.mimeData()
        
        undo_src = []
        undo_dest = []
        is_move_op = False
        
        if mime_data.hasUrls():
            for url in mime_data.urls():
                src_path = url.toLocalFile()
                if not os.path.exists(src_path):
                    continue
                
                src_name = os.path.basename(src_path)
                dest_path = os.path.join(target_path, src_name)
                
                if os.path.exists(dest_path):
                    base, ext = os.path.splitext(src_name)
                    
                    # Check for existing " - Copy" pattern to increment instead of appending
                    match = re.match(r"^(.*) - Copy(?: \((\d+)\))?$", base)
                    if match:
                        base = match.group(1)
                        
                    new_name = f"{base} - Copy{ext}"
                    dest_path = os.path.join(target_path, new_name)
                    
                    if os.path.exists(dest_path):
                        counter = 2
                        while True:
                            new_name = f"{base} - Copy ({counter}){ext}"
                            dest_path = os.path.join(target_path, new_name)
                            if not os.path.exists(dest_path):
                                break
                            counter += 1
                
                try:
                    is_cut = src_path in self._cut_paths
                    
                    if is_cut:
                        is_move_op = True
                        shutil.move(src_path, dest_path)
                        if src_path in self._cut_paths:
                            self._cut_paths.remove(src_path)
                    else:
                        if os.path.isdir(src_path):
                            shutil.copytree(src_path, dest_path)
                        else:
                            shutil.copy2(src_path, dest_path)
                            
                    undo_src.append(src_path)
                    undo_dest.append(dest_path)
                except Exception as e:
                    QMessageBox.warning(self, "Paste Error", f"Failed to paste {src_name}:\n{e}")

            if undo_src:
                self.add_undo_action({
                    'type': 'move' if is_move_op else 'copy',
                    'src_paths': undo_src,
                    'dest_paths': undo_dest
                })

    def show_item_context_menu(self, index, global_pos):
        menu = QMenu(self)
        
        proxy_model: Any = self.model()
        if not proxy_model or not hasattr(proxy_model, "mapToSource"):
            return
        source_index = proxy_model.mapToSource(index)
        fs_model: Any = proxy_model.sourceModel()
        if not fs_model or not hasattr(fs_model, "filePath"):
            return
        file_path = fs_model.filePath(source_index)
        
        open_action = menu.addAction("Open")
        
        open_with_action = None
        if not os.path.isdir(file_path):
            open_with_action = menu.addAction("Open With...")
            menu.addSeparator()

        cut_action = menu.addAction("Cut")
        copy_action = menu.addAction("Copy")
        move_to_action = menu.addAction("Move to...")
        copy_to_action = menu.addAction("Copy to...")
        menu.addSeparator()
        rename_action = menu.addAction("Rename")
        compress_action = menu.addAction("Compress...")
        
        extract_action = None
        if file_path.lower().endswith('.zip'):
            extract_action = menu.addAction("Extract")
            
        trash_action = menu.addAction("Move to Trash")
        menu.addSeparator()
        props_action = menu.addAction("Properties")
        
        action = menu.exec(global_pos)
        
        if action == open_action:
            QDesktopServices.openUrl(QUrl.fromLocalFile(file_path))
        elif open_with_action and action == open_with_action:
            self.open_with(file_path)
        elif action == cut_action:
            self.cut_to_clipboard(file_path)
        elif action == copy_action:
            self.copy_to_clipboard(file_path)
        elif action == move_to_action:
            self.move_file_to(file_path)
        elif action == copy_to_action:
            self.copy_file_to(file_path)
        elif action == rename_action:
            self.edit(index)
            self.rename_item(index)
        elif action == compress_action:
            self.compress_item(file_path)
        elif extract_action and action == extract_action:
            self.extract_item(file_path)
        elif action == trash_action:
            self.delete_item(file_path)
        elif action == props_action:
            self.show_properties(file_path)

    def get_selected_paths(self):
        paths = []
        seen = set()
        indexes = self.selectedIndexes()
        proxy_model: Any = self.model()
        if not proxy_model or not hasattr(proxy_model, "sourceModel"):
            return []
        source_model: Any = proxy_model.sourceModel()
        if not source_model or not hasattr(source_model, "filePath"):
            return []
        
        for idx in indexes:
            if idx.isValid():
                src_idx = proxy_model.mapToSource(idx)
                path = source_model.filePath(src_idx)
                if path and path not in seen:
                    seen.add(path)
                    paths.append(path)
        return paths

    def rename_item(self, index):
        proxy_model: Any = self.model()
        if not proxy_model or not hasattr(proxy_model, "mapToSource"):
            return
        source_index = proxy_model.mapToSource(index)
        fs_model: Any = proxy_model.sourceModel()
        if not fs_model or not hasattr(fs_model, "filePath") or not hasattr(fs_model, "fileName"):
            return
        
        old_path = fs_model.filePath(source_index)
        old_name = fs_model.fileName(source_index)
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Rename")
        dialog.resize(400, 100)
        
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("New Name:"))
        
        input_field = QLineEdit(old_name)
        layout.addWidget(input_field)
        
        if not os.path.isdir(old_path):
            base, ext = os.path.splitext(old_name)
            if ext:
                input_field.setSelection(0, len(base))
            else:
                input_field.selectAll()
        else:
            input_field.selectAll()
            
        btn_layout = QHBoxLayout()
        btn_ok = QPushButton("OK")
        btn_cancel = QPushButton("Cancel")
        
        btn_ok.setFixedWidth(100)
        btn_cancel.setFixedWidth(100)
        
        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)
        btn_layout.addWidget(btn_cancel)
        
        layout.addLayout(btn_layout)
        input_field.setFocus()
        
        if dialog.exec() == int(QDialog.DialogCode.Accepted):
            new_name = input_field.text().strip()
            if new_name and new_name != old_name:
                parent_dir = os.path.dirname(old_path)
                new_path = os.path.join(parent_dir, new_name)
                
                if os.path.exists(new_path):
                    QMessageBox.warning(self, "Error", "A file or folder with that name already exists.")
                    return
                    
                try:
                    os.rename(old_path, new_path)
                    self.add_undo_action({'type': 'rename', 'old_path': old_path, 'new_path': new_path})
                except OSError as e:
                    QMessageBox.warning(self, "Error", f"Failed to rename: {e}")

    def copy_to_clipboard(self, path):
        self._cut_paths = []
        paths = self.get_selected_paths()
        if not paths and path:
            paths = [path]
            
        mime_data = QMimeData()
        mime_data.setUrls([QUrl.fromLocalFile(p) for p in paths])
        QApplication.clipboard().setMimeData(mime_data)

    def cut_to_clipboard(self, path):
        paths = self.get_selected_paths()
        if not paths and path:
            paths = [path]
            
        self._cut_paths = paths
        mime_data = QMimeData()
        mime_data.setUrls([QUrl.fromLocalFile(p) for p in paths])
        QApplication.clipboard().setMimeData(mime_data)

    def compress_item(self, path):
        try:
            if os.path.isdir(path):
                shutil.make_archive(path, 'zip', path)
            else:
                with zipfile.ZipFile(f"{path}.zip", 'w', zipfile.ZIP_DEFLATED) as zf:
                    zf.write(path, os.path.basename(path))
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to compress: {e}")

    def extract_item(self, path):
        try:
            # Extract to a folder named after the zip file
            folder_name = os.path.splitext(os.path.basename(path))[0]
            target_dir = os.path.join(os.path.dirname(path), folder_name)
            
            # Handle duplicates
            if os.path.exists(target_dir):
                i = 1
                while os.path.exists(f"{target_dir} ({i})"):
                    i += 1
                target_dir = f"{target_dir} ({i})"
            
            os.makedirs(target_dir)
            
            with zipfile.ZipFile(path, 'r') as zf:
                zf.extractall(target_dir)
                
            self.add_undo_action({'type': 'new_folder', 'path': target_dir})
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to extract: {e}")

    def copy_file_to(self, path):
        paths = []
        if path:
            selected = self.get_selected_paths()
            paths = selected if path in selected else [path]
        else:
            paths = self.get_selected_paths()

        if not paths:
            return

        dest_dir = None
        dlg = FolderSelectionDialog(self, os.path.dirname(paths[0]))
        if dlg.exec() == int(QDialog.DialogCode.Accepted):
            dest_dir = dlg.selected_path()
            
        if dest_dir:
            for src_path in paths:
                try:
                    name = os.path.basename(src_path)
                    dest_path = os.path.join(dest_dir, name)
                    if os.path.isdir(src_path):
                        shutil.copytree(src_path, dest_path)
                    else:
                        shutil.copy2(src_path, dest_path)
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to copy {os.path.basename(src_path)}: {e}")

    def move_file_to(self, path):
        paths = []
        if path:
            selected = self.get_selected_paths()
            paths = selected if path in selected else [path]
        else:
            paths = self.get_selected_paths()

        if not paths:
            return

        dest_dir = None
        dlg = FolderSelectionDialog(self, os.path.dirname(paths[0]))
        if dlg.exec() == int(QDialog.DialogCode.Accepted):
            dest_dir = dlg.selected_path()
            
        if dest_dir:
            for src_path in paths:
                try:
                    shutil.move(src_path, dest_dir)
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to move {os.path.basename(src_path)}: {e}")

    def send_to_trash(self, path):
        if QFile.moveToTrash(path):
            if hasattr(self, 'update_trash_icon'):
                self.update_trash_icon()
            return True
        
        # Fallback for Windows using SHFileOperation
        if os.name == 'nt':
            try:
                windll = getattr(ctypes, "windll", None)
                if windll is not None:
                    class SHFILEOPSTRUCTW(ctypes.Structure):
                        _fields_ = [
                            ("hwnd", ctypes.wintypes.HWND),
                            ("wFunc", ctypes.wintypes.UINT),
                            ("pFrom", ctypes.wintypes.LPCWSTR),
                            ("pTo", ctypes.wintypes.LPCWSTR),
                            ("fFlags", ctypes.wintypes.WORD),
                            ("fAnyOperationsAborted", ctypes.wintypes.BOOL),
                            ("hNameMappings", ctypes.c_void_p),
                            ("lpszProgressTitle", ctypes.wintypes.LPCWSTR)
                        ]
                    
                    FO_DELETE = 3
                    FOF_ALLOWUNDO = 0x0040
                    FOF_NOCONFIRMATION = 0x0010
                    FOF_SILENT = 0x0004
                    FOF_NOERRORUI = 0x0400
                    
                    fileop = SHFILEOPSTRUCTW()
                    fileop.hwnd = 0
                    fileop.wFunc = FO_DELETE
                    fileop.pFrom = path + "\0\0"
                    fileop.pTo = None
                    fileop.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI
                    
                    result = windll.shell32.SHFileOperationW(ctypes.byref(fileop))
                    if result == 0:
                        return True
                    logging.warning(f"SHFileOperationW failed with code: {result}")
            except Exception as e:
                logging.error(f"Windows fallback trash failed: {e}")
        
        return False

    def delete_item(self, path=None):
        paths = []
        if path:
            selected = self.get_selected_paths()
            paths = selected if path in selected else [path]
        else:
            paths = self.get_selected_paths()
            
        if not paths:
            logging.info("No paths selected for deletion.")
            return

        logging.debug(f"delete_item requested for paths: {paths}")
        # Filter nested paths to avoid errors when deleting parent directories
        paths.sort(key=len)
        unique_paths = []
        for p in paths:
            is_child = False
            for parent in unique_paths:
                if p.startswith(os.path.join(parent, '')):
                    is_child = True
                    break
            if not is_child:
                unique_paths.append(p)
        paths = unique_paths
        logging.debug(f"delete_item unique paths to delete: {paths}")

        settings = QSettings(COMPANY_NAME, APP_NAME)
        confirm = settings.value("confirm_delete", True, type=bool)

        if confirm:
            count = len(paths)
            msg = f"Are you sure you want to move {count} items to the trash?" if count > 1 else f"Are you sure you want to move {os.path.basename(paths[0])} to the trash?"
            
            dialog = QDialog(self)
            dialog.setWindowTitle("Move to Trash")
            dialog.resize(350, 120)
            
            layout = QVBoxLayout(dialog)
            lbl = QLabel(msg)
            lbl.setWordWrap(True)
            layout.addWidget(lbl)
            
            btn_layout = QHBoxLayout()
            btn_yes = QPushButton("Yes")
            btn_no = QPushButton("No")
            
            btn_yes.setFixedWidth(100)
            btn_no.setFixedWidth(100)
            
            btn_yes.clicked.connect(dialog.accept)
            btn_no.clicked.connect(dialog.reject)
            
            btn_layout.addStretch()
            btn_layout.addWidget(btn_yes)
            btn_layout.addWidget(btn_no)
            
            layout.addLayout(btn_layout)
            
            if dialog.exec() != int(QDialog.DialogCode.Accepted):
                logging.info("Deletion cancelled by user.")
                return

        # Pause background workers to release file locks
        model: Any = self.model()
        source_model = None
        if hasattr(model, 'sourceModel'):
            source_model = model.sourceModel()
            if hasattr(source_model, 'set_workers_paused'):
                source_model.set_workers_paused(True)
        
        # Wait a tiny bit for threads to actually pause/release handles
        QApplication.processEvents()
        time.sleep(0.1)

        try:
            for p in paths:
                logging.debug(f"Processing path for deletion: {p}")
                if not os.path.exists(p):
                    logging.warning(f"Path does not exist, skipping: {p}")
                    continue

                # Diagnostic: Check if file is locked
                if os.path.isfile(p):
                    try:
                        # Try to open for append to check for exclusive locks
                        with open(p, 'a+'):
                            pass
                        logging.debug(f"Lock check: File {p} seems accessible (writable).")
                    except Exception as e:
                        logging.warning(f"Lock check: File {p} appears locked or inaccessible. Error: {e}")

                native_path = QDir.toNativeSeparators(p)
                success = False
                for i in range(10):
                    logging.debug(f"Attempt {i+1}/10 to move to trash: {native_path}")
                    if self.send_to_trash(native_path):
                        logging.info(f"Successfully moved to trash: {native_path}")
                        success = True
                        break
                    
                    logging.warning(f"Failed to move to trash (attempt {i+1}/10): {native_path}")
                    
                    # Log file info to see if permissions are weird
                    info = QFileInfo(p)
                    logging.debug(f"FileInfo: isWritable={info.isWritable()}, isReadable={info.isReadable()}, isHidden={info.isHidden()}")
                    
                    QApplication.processEvents()
                    time.sleep(0.3)
                
                if not success:
                    logging.error(f"Permanently failed to move to trash: {p}")
                    QMessageBox.warning(self, "Error", f"Failed to move to trash: {p}")
        finally:
            logging.debug("Resuming background workers...")
            if source_model and hasattr(source_model, 'set_workers_paused'):
                source_model.set_workers_paused(False)
            if hasattr(self, 'update_trash_icon'):
                self.update_trash_icon()

    def show_properties(self, path):
        info = QFileInfo(path)
        dialog = QDialog(self)
        dialog.setWindowTitle("Properties")
        layout = QFormLayout(dialog)
        
        layout.addRow("Name:", QLabel(info.fileName()))
        layout.addRow("Type:", QLabel("Folder" if info.isDir() else "File"))
        layout.addRow("Size:", QLabel(f"{info.size()} bytes"))
        layout.addRow("Location:", QLabel(info.absolutePath()))
        layout.addRow("Created:", QLabel(info.birthTime().toString()))
        layout.addRow("Modified:", QLabel(info.lastModified().toString()))
        
        dialog.exec()

    def open_with(self, file_path):
        dialog = OpenWithDialog(file_path, self)
        if dialog.exec() == int(QDialog.DialogCode.Accepted):
            app_path = dialog.selected_app
            if app_path:
                try:
                    if sys.platform == 'darwin' and app_path.endswith('.app'):
                        subprocess.Popen(['open', '-a', app_path, file_path])
                    else:
                        subprocess.Popen([app_path, file_path])
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to open file with selected application:\n{e}")

    def create_new_file(self, path):
        dialog = QDialog(self)
        dialog.setWindowTitle("New File")
        dialog.resize(400, 120)
        
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Name:"))
        
        input_field = QLineEdit()
        layout.addWidget(input_field)
        
        btn_layout = QHBoxLayout()
        btn_ok = QPushButton("OK")
        btn_cancel = QPushButton("Cancel")
        
        btn_ok.setFixedWidth(100)
        btn_cancel.setFixedWidth(100)
        
        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)
        
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)
        btn_layout.addWidget(btn_cancel)
        
        layout.addLayout(btn_layout)
        input_field.setFocus()
        
        if dialog.exec() == int(QDialog.DialogCode.Accepted):
            name = input_field.text().strip()
            if name:
                new_path = os.path.join(path, name)
                if not os.path.exists(new_path):
                    try:
                        with open(new_path, 'w'):
                            pass
                        self.add_undo_action({'type': 'new_file', 'path': new_path})
                    except OSError as e:
                        QMessageBox.warning(self, "Error", f"Failed to create file: {e}")
                else:
                    QMessageBox.warning(self, "Error", "File already exists.")

#============================================================================================
# --- File View Classes ---
#============================================================================================
class FileTreeView(FileViewActions, QTreeView):
    open_terminal_requested = Signal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_actions()
        self.setIconSize(QSize(32, 32))

#============================================================================================
# --- Custom Delegate for Icon View Text Wrapping ---
#============================================================================================
class IconViewDelegate(QStyledItemDelegate):
    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if option.text:
            # Insert zero-width space after separators to allow wrapping
            option.text = option.text.replace("_", "_\u200b").replace("-", "-\u200b").replace(".", ".\u200b")
        
        option.features |= QStyleOptionViewItem.ViewItemFeature.WrapText
        option.textElideMode = Qt.TextElideMode.ElideNone
        option.displayAlignment = Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter

    def sizeHint(self, option, index):
        # Fixed width for the column/item
        width = 120
        
        # Calculate text height
        self.initStyleOption(option, index)
        text = option.text
        font_metrics = option.fontMetrics
        rect = font_metrics.boundingRect(0, 0, width, 0, Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignHCenter, text)
        
        # Icon height (64) + padding + text height
        height = 64 + 10 + rect.height() + 10
        return QSize(width, height)

#============================================================================================
# -- The ListView is currently not used in the main app, but it's implemented here for future use if we want to add a toggle between Tree and List views. It has the same context menu and file operations as the TreeView, but displays items in a grid of icons with labels instead of a hierarchical tree structure. ---
#============================================================================================
class FileIconView(FileViewActions, QListView):
    open_terminal_requested = Signal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_actions()
        self.setViewMode(QListView.ViewMode.IconMode)
        self.setResizeMode(QListView.ResizeMode.Adjust) 
        self.setWordWrap(True)
        self.setSpacing(10)
        self.setIconSize(QSize(64, 64))
        self.setUniformItemSizes(False)
        self.setMovement(QListView.Movement.Static)
        self.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.setItemDelegate(IconViewDelegate(self))

#============================================================================================   
# -- The ListView is currently not used in the main app, but it's implemented here for future use if we want to add a toggle between Tree and List views. It has the same context menu and file operations as the TreeView, but displays items in a simple list format with small icons and text labels. This view is more compact and allows for faster scanning of file names, while the IconView is better for visually identifying files by their icons. ---
#============================================================================================
class FileListView(FileViewActions, QListView):
    open_terminal_requested = Signal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_actions()
        self.setViewMode(QListView.ViewMode.ListMode)
        self.setUniformItemSizes(True)
        self.setResizeMode(QListView.ResizeMode.Adjust)


#============================================================================================
# --- WPD (Android/MTP) File Copying ---
#============================================================================================
class WPDCopyThread(QThread):
    copy_finished = Signal(str) # path to temp file
    error_occurred = Signal(str)

    def __init__(self, wpd_path, filename):
        super().__init__()
        self.wpd_path = wpd_path # "wpd://Device/Storage/Folder"
        self.filename = filename
        self._temp_dir = None

    def get_temp_dir(self):
        return self._temp_dir

    def run(self):
        logging.debug(f"WPDCopyThread: Starting copy for {self.filename} from {self.wpd_path}")
        # 1. Create a temp directory
        self._temp_dir = tempfile.mkdtemp(prefix="file-browser-")
        logging.debug(f"WPDCopyThread: Created temp dir {self._temp_dir}")
        
        # 2. Construct PowerShell script
        shell_path = self.wpd_path.replace("wpd://", "").replace("/", "\\")
        
        ps_safe_shell_path = shell_path.replace("`", "``").replace('"', '`"').replace("$", "`$")
        ps_safe_filename = self.filename.replace("`", "``").replace('"', '`"').replace("$", "`$")
        ps_safe_temp_dir = self._temp_dir.replace("`", "``").replace('"', '`"').replace("$", "`$")

        ps_script = f"""
        $ErrorActionPreference = 'Stop'
        try {{
            $shell = New-Object -ComObject Shell.Application
            Write-Output "DEBUG: Navigating to {ps_safe_shell_path}"
            
            # Navigate to the folder
            $path = "{ps_safe_shell_path}"
            $parts = $path -split '[\\\\/]' | Where-Object {{ $_ }}
            $folder = $shell.NameSpace(17) # This PC
            foreach ($part in $parts) {{
                $item = $folder.ParseName($part)
                if ($null -eq $item) {{
                    $item = $folder.Items() | Where-Object {{ $_.Name -eq $part }} | Select-Object -First 1
                }}
                if ($null -eq $item) {{ throw "Path part not found: '$part' in '$($folder.Title)'" }}
                $folder = $item.GetFolder
                if ($null -eq $folder) {{ throw "'$part' is not a folder." }}
            }}
            
            Write-Output "DEBUG: Looking for file {ps_safe_filename}"
            $fileItem = $folder.ParseName("{ps_safe_filename}")
            if ($null -eq $fileItem) {{
                $fileItem = $folder.Items() | Where-Object {{ $_.Name -eq "{ps_safe_filename}" }} | Select-Object -First 1
            }}
            if ($null -eq $fileItem) {{ throw "File not found: '{ps_safe_filename}' in '$($folder.Title)'" }}
            
            Write-Output "DEBUG: Found file item: $($fileItem.Name)"
            Write-Output "DEBUG: File size: $($fileItem.Size)"
            
            $destination = $shell.NameSpace("{ps_safe_temp_dir}")
            
            Write-Output "DEBUG: Copying to {ps_safe_temp_dir}"
            # Options: 4 (no progress) + 16 (Yes to All) = 20
            $destination.CopyHere($fileItem, 20)
            
            # Give the copy operation a moment to initialize
            Start-Sleep -Milliseconds 500
            
            $timeoutSeconds = 60
            $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
            
            while ($stopwatch.Elapsed.TotalSeconds -lt $timeoutSeconds) {{
                # Find the first (and should be only) file in the temp dir
                $filesInDest = Get-ChildItem -Path "{ps_safe_temp_dir}"
                if ($filesInDest.Count -gt 0) {{
                    $destinationFilePath = $filesInDest[0].FullName
                    Write-Output "DEBUG: Found potential file in temp dir: $destinationFilePath"
                    try {{
                        $item = Get-Item $destinationFilePath -ErrorAction Stop
                        if ($item.Length -gt 0) {{
                            # Check for size stability to ensure copy is complete
                            $size1 = $item.Length
                            Start-Sleep -Milliseconds 300
                            $size2 = (Get-Item $destinationFilePath).Length
                            if ($size1 -eq $size2) {{
                                Write-Output "RESULT:$destinationFilePath"
                                exit 0
                            }}
                        }}
                    }} catch {{
                        # File exists but is not ready (locked or size 0), continue loop
                        Write-Output "DEBUG: File found but not ready, retrying..."
                    }}
                }}
                Start-Sleep -Milliseconds 500
            }}
            
            # Final check in case loop timed out but file is actually there
            $filesInDest = Get-ChildItem -Path "{ps_safe_temp_dir}"
            if ($filesInDest.Count -gt 0 -and $filesInDest[0].Length -gt 0) {{
                Write-Output "RESULT:$($filesInDest[0].FullName)"
                exit 0
            }}

            throw "Timeout or error waiting for file copy to complete."
        }} catch {{
            Write-Output "ERROR: $($_.Exception.Message)"
            Write-Output "DEBUG: Exception Item: $_"
        }}
        """
        
        try:
            cmd = ["powershell", "-NoProfile", "-Command", ps_script]
            startupinfo = _get_win_startupinfo()
            
            logging.debug("WPDCopyThread: Executing PowerShell command...")
            proc = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo, check=False)
            
            lines = proc.stdout.strip().splitlines()
            result_path = None
            
            for line in lines:
                if line.startswith("DEBUG:"):
                    logging.debug(f"WPDCopyThread PS: {line}")
                elif line.startswith("ERROR:"):
                    logging.error(f"WPDCopyThread PS Error: {line}")
                    self.error_occurred.emit(line)
                    self.cleanup()
                    return
                elif line.startswith("RESULT:"):
                    result_path = line.replace("RESULT:", "").strip()
            
            if result_path and os.path.exists(result_path):
                logging.info(f"WPDCopyThread: Copy successful to {result_path}")
                self.copy_finished.emit(result_path)
            else:
                error_msg = proc.stderr.strip() if proc.stderr else "Unknown script error."
                logging.error(f"WPDCopyThread: Copy failed. No result path. Stderr: {error_msg}")
                self.error_occurred.emit("Copy script failed. See logs for details.")
                self.cleanup()
                
        except Exception as e:
            logging.error(f"WPDCopyThread: Exception: {e}", exc_info=True)
            self.error_occurred.emit(str(e))
            self.cleanup()

    def cleanup(self):
        if self._temp_dir and os.path.exists(self._temp_dir):
            try:
                shutil.rmtree(self._temp_dir)
            except Exception as e:
                logging.warning(f"Failed to clean up temp dir {self._temp_dir}: {e}")

#============================================================================================
# --- WPD (Android/MTP) Thumbnail Generation ---
#============================================================================================
class WPDThumbnailWorker(QThread):
    thumbnail_loaded = Signal(str, QImage) # wpd_path, thumbnail_image

    def __init__(self):
        super().__init__()
        self.queue = queue.Queue()
        self.running = True
        self._processed = set()

    def request_thumbnail(self, wpd_path):
        if wpd_path not in self._processed:
            self._processed.add(wpd_path)
            self.queue.put(wpd_path)
            logging.debug(f"WPDThumbnailWorker: Queued {wpd_path}")

    def run(self):
        while self.running:
            try:
                wpd_path = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue

            logging.debug(f"WPDThumbnailWorker: Processing {wpd_path}")
            temp_dir = None
            try:
                temp_dir = tempfile.mkdtemp(prefix="wpd-thumb-")
                
                parts = wpd_path.replace("wpd://", "").split('/')
                filename = parts[-1]
                wpd_folder_path = "wpd://" + "/".join(parts[:-1])

                shell_path = wpd_folder_path.replace("wpd://", "").replace("/", "\\")
                ps_safe_shell_path = shell_path.replace("`", "``").replace('"', '`"').replace("$", "`$")
                ps_safe_filename = filename.replace("`", "``").replace('"', '`"').replace("$", "`$")
                ps_safe_temp_dir = temp_dir.replace("`", "``").replace('"', '`"').replace("$", "`$")

                ps_script = f"""$ErrorActionPreference = 'Stop'
                try {{
                    $shell = New-Object -ComObject Shell.Application
                    $path = "{ps_safe_shell_path}"
                    $parts = $path -split '[\\\\/]' | Where-Object {{ $_ }}
                    $folder = $shell.NameSpace(17)
                    foreach ($part in $parts) {{
                        $item = $folder.ParseName($part)
                        if ($null -eq $item) {{
                            $item = $folder.Items() | Where-Object {{ $_.Name -eq $part }} | Select-Object -First 1
                        }}
                        if ($null -eq $item) {{ throw "Path part not found: '$part' in '$($folder.Title)'" }}
                        $folder = $item.GetFolder
                        if ($null -eq $folder) {{ throw "'$part' is not a folder." }}
                    }}
                    $fileItem = $folder.ParseName("{ps_safe_filename}")
                    if ($null -eq $fileItem) {{
                        $fileItem = $folder.Items() | Where-Object {{ $_.Name -eq "{ps_safe_filename}" }} | Select-Object -First 1
                    }}
                    if ($null -eq $fileItem) {{ throw "File not found: '{ps_safe_filename}' in '$($folder.Title)'" }}
                    $destination = $shell.NameSpace("{ps_safe_temp_dir}")
                    $destination.CopyHere($fileItem, 20)
                    Start-Sleep -Milliseconds 500
                    $timeoutSeconds = 30
                    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                    while ($stopwatch.Elapsed.TotalSeconds -lt $timeoutSeconds) {{
                        $filesInDest = Get-ChildItem -Path "{ps_safe_temp_dir}"
                        if ($filesInDest.Count -gt 0) {{
                            $destinationFilePath = $filesInDest[0].FullName
                            try {{
                                $item = Get-Item $destinationFilePath -ErrorAction Stop
                                if ($item.Length -gt 0) {{
                                    Write-Output "RESULT:$destinationFilePath"
                                    exit 0
                                }}
                            }} catch {{}}
                        }}
                        Start-Sleep -Milliseconds 500
                    }}
                    throw "Timeout waiting for thumbnail file copy."
                }} catch {{ Write-Output "ERROR: $($_.Exception.Message)" }}
                """
                cmd = ["powershell", "-NoProfile", "-Command", ps_script]
                startupinfo = _get_win_startupinfo()
                proc = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo, check=False)
                output = proc.stdout.strip()
                
                if output.startswith("RESULT:"):
                    result_path = output.replace("RESULT:", "").strip()
                else:
                    result_path = None

                if result_path and os.path.exists(result_path):
                    reader = QImageReader(result_path)
                    if reader.canRead():
                        reader.setScaledSize(QSize(128, 128)) 
                        reader.setAutoTransform(True)
                        image = reader.read() 
                        
                        if not image.isNull():
                            if image.width() > 128 or image.height() > 128:
                                image = image.scaled(128, 128, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                            self.thumbnail_loaded.emit(wpd_path, image)
            except Exception as e:
                logging.warning(f"Failed to generate WPD thumbnail for {wpd_path}: {e}")
            finally:
                if temp_dir and os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)

    def stop(self):
        self.running = False
        self.wait()

#============================================================================================
# --- WPD (Android/MTP) File System Model ---
#============================================================================================
class WPDListThread(QThread):
    results_ready = Signal(list)
    error_occurred = Signal(str)

    def __init__(self, path_str):
        super().__init__()
        self.path_str = path_str

    def run(self):
        # path_str format: "wpd://Device Name/Storage/Folder"
        logging.debug(f"WPDListThread: Starting for path: {self.path_str}")
        # Escape backticks and double-quotes for PowerShell
        ps_safe_path = self.path_str.replace("wpd://", "").replace("/", "\\").replace("`", "``").replace('"', '`"').replace("$", "`$")
        
        # PowerShell script to list items via Shell.Application
        ps_script = f"""
        $ErrorActionPreference = 'Stop'
        try {{
            $path = "{ps_safe_path}"
            # Split path and filter out empty parts that can result from leading/trailing slashes
            $parts = $path -split '[\\\\/]' | Where-Object {{ $_ }}
            
            $shell = New-Object -ComObject Shell.Application
            # Start at "This PC" namespace (virtual folder)
            $folder = $shell.NameSpace(17) 
            
            # Traverse the path parts to get to the target folder
            foreach ($part in $parts) {{
                $item = $folder.ParseName($part)
                if ($null -eq $item) {{
                    $item = $folder.Items() | Where-Object {{ $_.Name -eq $part }} | Select-Object -First 1
                }}
                if ($null -eq $item) {{ throw "Path part not found: '$part' in '$($folder.Title)'" }}
                
                # GetFolder is the way to descend into a directory-like object
                $folder = $item.GetFolder
                if ($null -eq $folder) {{ throw "'$part' is not a folder." }}
            }}
            
            # Now list items in the final folder
            $items = $folder.Items()
            $res = @()
            foreach ($i in $items) {{
                $date = $i.ModifyDate
                $dateStr = ""
                if ($date) {{ $dateStr = $date.ToString("yyyy-MM-dd HH:mm:ss") }}
                $res += @{{ Name=$i.Name; Path=$i.Path; IsFolder=$i.IsFolder; Size=$i.Size; Type=$i.Type; Date=$dateStr }}
            }}
            $res | ConvertTo-Json -Compress
        }} catch {{
            # If anything goes wrong, output a clear error message
            Write-Output "ERROR: $($_.Exception.Message)"
        }}
        """
        
        try:
            cmd = ["powershell", "-NoProfile", "-Command", ps_script]
            startupinfo = _get_win_startupinfo()
            
            logging.debug("WPDListThread: Executing PowerShell command...")
            proc = subprocess.run(cmd, capture_output=True, text=True, startupinfo=startupinfo, check=False)
            output = proc.stdout.strip()
            stderr = proc.stderr.strip()

            logging.debug(f"WPDListThread: PowerShell stdout:\n{output}")
            if stderr:
                logging.warning(f"WPDListThread: PowerShell stderr:\n{stderr}")
            
            if output.startswith("ERROR:"):
                logging.error(f"WPDListThread: PowerShell script returned an error: {output}")
                self.error_occurred.emit(output)
            elif output:
                try:
                    data = json.loads(output)
                    if isinstance(data, dict): # Single item
                        data = [data]
                    logging.debug(f"WPDListThread: Successfully parsed {len(data)} items from JSON.")
                    self.results_ready.emit(data)
                except json.JSONDecodeError as e:
                    logging.error(f"WPDListThread: JSON decode error: {e}. Raw output: {output}")
                    # Empty folder or weird output
                    self.results_ready.emit([])
            else:
                logging.debug("WPDListThread: PowerShell returned empty output. Emitting empty list.")
                self.results_ready.emit([])
                
        except Exception as e:
            logging.error(f"WPDListThread: Exception during run: {e}", exc_info=True)
            self.error_occurred.emit(str(e))

class WPDFileSystemModel(QStandardItemModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHorizontalHeaderLabels(["Name", "Size", "Type", "Date Modified"])
        self.current_path = ""
        self.worker = None

        # New
        self.thumbnail_cache = {}
        self.cache_dir = os.path.join(user_data_dir(APP_NAME, APP_AUTHOR), "wpd_thumbnails")
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
        except Exception as e:
            logging.warning(f"Failed to create WPD thumbnail cache dir: {e}")

        self.thumbnail_worker = WPDThumbnailWorker()
        self.thumbnail_worker.thumbnail_loaded.connect(self.on_wpd_thumbnail_loaded)
        self.thumbnail_worker.start()
        self.image_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.gif', '.svg', '.webp', '.ico', '.tif', '.tiff'}

    def get_cached_icon(self, wpd_path):
        if wpd_path in self.thumbnail_cache:
            return self.thumbnail_cache[wpd_path]
        
        try:
            hashed_name = hashlib.md5(wpd_path.encode('utf-8')).hexdigest() + ".png"
            cache_path = os.path.join(self.cache_dir, hashed_name)
            if os.path.exists(cache_path):
                pixmap = QPixmap(cache_path)
                if not pixmap.isNull():
                    icon = QIcon(pixmap)
                    self.thumbnail_cache[wpd_path] = icon
                    return icon
        except Exception:
            pass
        return None

    def setPath(self, path):
        logging.debug(f"WPDFileSystemModel: setPath called with '{path}'")
        self.current_path = path
        self.removeRows(0, self.rowCount())
        
        # Add "Loading..." item
        item = QStandardItem("Loading...")
        self.appendRow(item)
        
        if self.worker and self.worker.isRunning():
            logging.debug("WPDFileSystemModel: Terminating previous worker.")
            self.worker.terminate()
            self.worker.wait()
            
        self.worker = WPDListThread(path)
        self.worker.results_ready.connect(self.on_results)
        self.worker.error_occurred.connect(self.on_error)
        self.worker.start()

    def on_results(self, items):
        logging.debug(f"WPDFileSystemModel: on_results received {len(items)} items for path '{self.current_path}'.")
        self.removeRows(0, self.rowCount())
        
        # Add ".." if not at root (root is wpd://DeviceName)
        if self.current_path.count('/') > 2: # wpd://Device has 2 slashes
            back_item = QStandardItem("..")
            back_item.setData(True, Qt.ItemDataRole.UserRole) # IsFolder
            self.appendRow(back_item)

        if not items and self.current_path.count('/') <= 2:
            info_item = QStandardItem("Unable to list files. Device may be locked or need permissions.")
            info_item.setToolTip("Please unlock your phone and grant file access permission if prompted on the phone's screen.")
            info_item.setSelectable(False)
            info_item.setEditable(False)
            self.appendRow(info_item)
            return

        for i in items:
            name = i.get("Name", "Unknown") # This might not have an extension
            path_with_ext = i.get("Path", "")
            
            # WPD items often return a GUID for Path. If it looks like a GUID, ignore it.
            if path_with_ext.startswith("{") and path_with_ext.endswith("}"):
                filename_from_path = name
            else:
                filename_from_path = os.path.basename(path_with_ext) if path_with_ext else name
            logging.debug(f"WPD item: Display='{name}', Full='{filename_from_path}', Type='{i.get('Type', '')}'")

            name_item = QStandardItem(name)
            is_folder = i.get("IsFolder", False)
            name_item.setData(is_folder, Qt.ItemDataRole.UserRole)
            name_item.setData(filename_from_path, int(Qt.ItemDataRole.UserRole) + 10) # Store full filename

            # The path used for cache and worker requests MUST use the full filename
            full_wpd_path_for_thumb = f"{self.current_path}/{filename_from_path}"

            cached_icon = self.get_cached_icon(full_wpd_path_for_thumb)
            if cached_icon:
                name_item.setIcon(cached_icon)
            elif is_folder:
                name_item.setIcon(QIcon(resource_path(os.path.join("assets", "icons", "folder.png"))))
            else:
                name_item.setIcon(get_file_extension_qicon(filename_from_path))
                ext = os.path.splitext(filename_from_path)[1].lower()
                is_image = False
                if ext in self.image_extensions:
                    is_image = True
                else:
                    # Fallback: Check Type string for image keywords if extension is missing
                    t = i.get("Type", "").lower()
                    if any(x in t for x in ["jpg", "jpeg", "png", "bmp", "gif", "image", "picture", "photo", "heic", "webp", "tif"]):
                        is_image = True

                if is_image:
                    logging.debug(f"Requesting WPD thumbnail for '{filename_from_path}'")
                    self.thumbnail_worker.request_thumbnail(full_wpd_path_for_thumb)

            size_val = i.get("Size", 0)
            size_str = f"{size_val / 1024:.1f} KB" if size_val else ""
            size_item = QStandardItem(size_str)
            size_item.setData(size_val, Qt.ItemDataRole.UserRole) # Store raw size for sorting
            
            type_item = QStandardItem(i.get("Type", ""))
            
            date_str = i.get("Date", "")
            date_item = QStandardItem(date_str)
            date_item.setData(date_str, Qt.ItemDataRole.UserRole) # Store date string for sorting (ISO format sorts correctly)
            
            self.appendRow([name_item, size_item, type_item, date_item])

    def on_error(self, msg):
        logging.error(f"WPDFileSystemModel: on_error received for path '{self.current_path}': {msg}")
        self.removeRows(0, self.rowCount())
        item = QStandardItem(f"Error: {msg}")
        self.appendRow(item)

    def on_wpd_thumbnail_loaded(self, wpd_path, image):
        logging.debug(f"WPD thumbnail loaded for {wpd_path}")
        pixmap = QPixmap.fromImage(image)
        if pixmap.isNull():
             logging.warning(f"WPD Pixmap is null for {wpd_path}")
             return
        icon = QIcon(pixmap)
        self.thumbnail_cache[wpd_path] = icon
        
        try:
            hashed_name = hashlib.md5(wpd_path.encode('utf-8')).hexdigest() + ".png"
            cache_path = os.path.join(self.cache_dir, hashed_name)
            pixmap.save(cache_path, "PNG")
        except Exception as e:
            logging.warning(f"Failed to save WPD thumbnail to cache: {e}")
        
        filename = wpd_path.split('/')[-1]
        for row in range(self.rowCount()):
            item = self.item(row, 0)
            # Match using the stored full filename, not the display text
            if item and item.data(int(Qt.ItemDataRole.UserRole) + 10) == filename:
                logging.debug(f"Setting icon for item with full name {filename}")
                item.setIcon(icon)
                break

    def shutdown(self):
        logging.debug("Shutting down WPDFileSystemModel workers.")
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait() 
            
        if hasattr(self, 'thumbnail_worker') and self.thumbnail_worker.isRunning():
            self.thumbnail_worker.stop()

#============================================================================================
# --- Browser Tab Class ---
#============================================================================================
class BrowserTab(QWidget):
    path_changed = Signal(str)
    open_terminal_requested = Signal(str)
    sort_changed = Signal(int, Qt.SortOrder)

    def __init__(self, shared_model, view_prefs, start_path=None, parent=None):
        super().__init__(parent)
        self.model = shared_model
        self.view_prefs = view_prefs
        self.history = []
        self.history_index = -1
        self.show_hidden_files = False
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        self.proxy_model = DotFileProxyModel(self)
        self.proxy_model.setSourceModel(self.model)
        
        self.tree = FileTreeView()
        self.list_view = FileListView()
        self.icon_view = FileIconView()
        
        # Dedicated view for WPD (Android) devices
        self.wpd_view = QTreeView()
        self.wpd_model = WPDFileSystemModel()
        
        # Use proxy model for sorting
        self.wpd_proxy_model = WPDSortFilterProxyModel(self)
        self.wpd_proxy_model.setSourceModel(self.wpd_model)
        self.wpd_view.setModel(self.wpd_proxy_model)
        
        self.wpd_view.setColumnWidth(0, 420)
        self.wpd_view.setColumnWidth(1, 100)
        self.wpd_view.doubleClicked.connect(self.on_wpd_double_click)
        self.wpd_view.setIconSize(QSize(32, 32))
        self.wpd_view.setAlternatingRowColors(True)
        self.wpd_view.setSortingEnabled(True)
        self.wpd_view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.wpd_view.customContextMenuRequested.connect(self.on_wpd_context_menu)
        
        self.view_stack = QStackedWidget()
        self.view_stack.addWidget(self.tree)
        self.view_stack.addWidget(self.list_view)
        self.view_stack.addWidget(self.icon_view)
        self.view_stack.addWidget(self.wpd_view)
        
        main_layout.addWidget(self.view_stack)
        
        for view in [self.tree, self.list_view, self.icon_view]:
            view.setModel(self.proxy_model)
            view.doubleClicked.connect(self.on_double_click)
            view.open_terminal_requested.connect(self.open_terminal_requested.emit)

        # Load and restore persistent sort column and order
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        try:
            saved_sort_col = int(cast(Any, self.settings.value("sort_column", 0)))
            if saved_sort_col not in (0, 1, 2, 3):
                saved_sort_col = 0
        except (ValueError, TypeError):
            saved_sort_col = 0

        try:
            default_order = Qt.SortOrder.AscendingOrder.value
            saved_sort_order_val = int(cast(Any, self.settings.value("sort_order", default_order)))
            saved_sort_order = Qt.SortOrder(saved_sort_order_val)
        except (ValueError, TypeError):
            saved_sort_order = Qt.SortOrder.AscendingOrder

        self.tree.setColumnWidth(0, 420)
        self.tree.setColumnWidth(1, 100)
        self.tree.setSortingEnabled(True)
        self.tree.header().setSortIndicator(saved_sort_col, saved_sort_order)
        self.proxy_model.sort(saved_sort_col, saved_sort_order)
        self.tree.header().sortIndicatorChanged.connect(self.on_sort_indicator_changed)
            
        if start_path and os.path.exists(start_path):
            self.navigate_to(start_path)
        else:
            self.navigate_to(QDir.homePath())

    def on_sort_indicator_changed(self, column: int, order: Qt.SortOrder):
        try:
            order_val = order.value if hasattr(order, "value") else int(cast(Any, order))
            self.settings.setValue("sort_column", column)
            self.settings.setValue("sort_order", order_val)
        except Exception as e:
            logging.warning(f"Failed to save sort settings: {e}")
        self.sort_changed.emit(column, order)

    def apply_sort(self, column: int, order: Qt.SortOrder):
        self.tree.header().blockSignals(True)
        self.tree.header().setSortIndicator(column, order)
        self.tree.header().blockSignals(False)
        self.proxy_model.sort(column, order)

    def on_double_click(self, index):
        source_index = self.proxy_model.mapToSource(index)
        path = self.model.filePath(source_index)
        if os.path.isdir(path):
            self.navigate_to(path)
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def on_wpd_double_click(self, index):
        # Map proxy index to source index
        source_index = self.wpd_proxy_model.mapToSource(index)
        item = self.wpd_model.itemFromIndex(source_index.siblingAtColumn(0))
        
        if not item:
            return
        
        name = item.text()
        if name == "..":
            self.go_up()
            return
            
        is_folder = item.data(Qt.ItemDataRole.UserRole)
        
        if is_folder:
            new_path = f"{self.get_current_path()}/{name}"
            self.navigate_to(new_path)
        else:
            # Copy to temp and open
            self.open_wpd_file(name)

    def on_wpd_context_menu(self, pos):
        index = self.wpd_view.indexAt(pos)
        if not index.isValid():
            return
        
        source_index = self.wpd_proxy_model.mapToSource(index)
        item = self.wpd_model.itemFromIndex(source_index.siblingAtColumn(0))
        if not item:
            return

        menu = QMenu(self)
        copy_action = menu.addAction("Copy to PC...")
        
        action = menu.exec(self.wpd_view.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.copy_wpd_to_pc(item)

    def copy_wpd_to_pc(self, item):
        filename = item.text()
        # Use full filename if available in UserRole
        full_name = item.data(int(Qt.ItemDataRole.UserRole) + 10)
        if full_name:
            filename = full_name
            
        dlg = FolderSelectionDialog(self, QDir.homePath())
        if dlg.exec() == int(QDialog.DialogCode.Accepted):
            target_dir = dlg.selected_path()
            if target_dir:
                self.perform_wpd_copy_to_pc(filename, target_dir)

    def perform_wpd_copy_to_pc(self, filename, target_dir):
        self.progress_dialog = QProgressDialog(f"Copying {filename} to PC...", "Cancel", 0, 0, self)
        self.progress_dialog.setWindowTitle("Copying File")
        self.progress_dialog.setWindowModality(Qt.WindowModality.WindowModal)
        self.progress_dialog.setMinimumDuration(0)
        
        self.wpd_copy_worker = WPDCopyThread(self.get_current_path(), filename)
        
        def on_finish(temp_path):
            if self.progress_dialog.wasCanceled():
                self.wpd_copy_worker.cleanup()
                return
            
            self.progress_dialog.close()
            
            try:
                dest_path = os.path.join(target_dir, os.path.basename(temp_path))
                if os.path.exists(dest_path):
                    base, ext = os.path.splitext(os.path.basename(temp_path))
                    i = 1
                    while os.path.exists(dest_path):
                        dest_path = os.path.join(target_dir, f"{base} ({i}){ext}")
                        i += 1
                
                if os.path.isdir(temp_path):
                    shutil.copytree(temp_path, dest_path)
                else:
                    shutil.copy2(temp_path, dest_path)
                
                logging.info(f"Copied WPD file to: {dest_path}")
                QMessageBox.information(self, "Success", f"File copied to:\n{dest_path}")
            except Exception as e:
                logging.error(f"Failed to move copied file: {e}")
                QMessageBox.warning(self, "Error", f"Failed to save file: {e}")
            finally:
                self.wpd_copy_worker.cleanup()

        def on_error(msg):
            if self.progress_dialog.wasCanceled():
                return
            self.progress_dialog.close()
            logging.error(f"Failed to copy WPD file: {msg}")
            QMessageBox.warning(self, "Error", f"Could not copy file from device.\n\n{msg}")

        self.wpd_copy_worker.copy_finished.connect(on_finish)
        self.wpd_copy_worker.error_occurred.connect(on_error)
        self.progress_dialog.canceled.connect(lambda: logging.info("WPD copy cancelled by user."))
        
        self.progress_dialog.show()
        self.wpd_copy_worker.start()

    def open_wpd_file(self, filename):
        self.progress_dialog = QProgressDialog(f"Copying {filename} from device...", "Cancel", 0, 0, self)
        self.progress_dialog.setWindowTitle("Opening File")
        self.progress_dialog.setWindowModality(Qt.WindowModality.WindowModal)
        self.progress_dialog.setMinimumDuration(500)
        
        copy_worker = WPDCopyThread(self.get_current_path(), filename)
        
        def on_finish(temp_path):
            if self.progress_dialog.wasCanceled():
                # If user cancelled, clean up the temp directory that was created
                copy_worker.cleanup()
                return
            
            self.progress_dialog.close()
            logging.info(f"Copied WPD file to temporary path: {temp_path}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(temp_path))
            # The temp dir will be cleaned up by the OS on reboot.

        def on_error(msg):
            if self.progress_dialog.wasCanceled():
                return
            self.progress_dialog.close()
            logging.error(f"Failed to copy WPD file: {msg}")
            QMessageBox.warning(self, "Error", f"Could not open file from device.\n\n{msg}")

        copy_worker.copy_finished.connect(on_finish)
        copy_worker.error_occurred.connect(on_error)
        self.progress_dialog.canceled.connect(lambda: logging.info("WPD copy cancelled by user."))
        
        self.progress_dialog.show()
        copy_worker.start()
        
    def navigate_to(self, path):
        # Handle WPD paths
        if path.startswith("wpd://"):
            # Don't normalize wpd paths with os.path
            pass
        else:
            path = os.path.normpath(path)
            if not os.path.exists(path):
                return
            
        if self.history_index >= 0 and self.history[self.history_index] == path:
            pass
        else:
            if self.history_index < len(self.history) - 1:
                self.history = self.history[:self.history_index+1]
            self.history.append(path)
            self.history_index = len(self.history) - 1
            
        if not path.startswith("wpd://"):
            self.proxy_model.setCurrentPath(path)
            
        self.update_view(path)
        self.path_changed.emit(path)

    def update_view(self, path):
        if path.startswith("wpd://"):
            self.view_stack.setCurrentWidget(self.wpd_view)
            self.wpd_model.setPath(path)
            return

        self.model.setRootPath(path)
        source_index = self.model.index(path)
        proxy_index = self.proxy_model.mapFromSource(source_index)
        
        mode = self.view_prefs["paths"].get(path, self.view_prefs.get("default", "tree"))
        
        if mode == "list":
            self.view_stack.setCurrentWidget(self.list_view)
            self.list_view.setRootIndex(proxy_index)
        elif mode == "tile":
            self.view_stack.setCurrentWidget(self.icon_view)
            self.icon_view.setRootIndex(proxy_index)
        else:
            self.view_stack.setCurrentWidget(self.tree)
            self.tree.setRootIndex(proxy_index)

    def go_back(self):
        if self.history_index > 0:
            self.history_index -= 1
            path = self.history[self.history_index]
            self.update_view(path)
            self.path_changed.emit(path)

    def go_forward(self):
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            path = self.history[self.history_index]
            self.update_view(path)
            self.path_changed.emit(path)

    def go_up(self):
        current = self.get_current_path()
        if current.startswith("wpd://"):
            # Simple string manipulation for virtual paths
            if '/' not in current.replace("wpd://", ""):
                self.navigate_to(QDir.homePath())
                return
            parent = current.rsplit('/', 1)[0]
        else:
            parent = os.path.dirname(current)
            if parent.endswith('/gvfs') or parent.endswith('/.gvfs') or os.path.basename(current).startswith(('mtp:host=', 'gphoto2:host=')):
                self.navigate_to(QDir.homePath())
                return
        self.navigate_to(parent)

    def go_home(self):
        self.navigate_to(QDir.homePath())
        
    def get_current_path(self):
        if self.history and self.history_index >= 0:
            return self.history[self.history_index]
        return QDir.homePath()

    def get_active_view(self):
        return self.view_stack.currentWidget()

    def toggle_hidden_files(self, force_state=None):
        if force_state is not None:
            self.show_hidden_files = force_state
        else:
            self.show_hidden_files = not self.show_hidden_files
        self.proxy_model.setShowDotFiles(self.show_hidden_files)
        
    def copy_to_clipboard(self, path):
        view = self.get_active_view()
        if hasattr(view, "copy_to_clipboard"):
            view.copy_to_clipboard(path)
        
    def paste_files(self, path):
        view = self.get_active_view()
        if hasattr(view, "paste_files"):
            view.paste_files(path)

    def shutdown(self):
        self.wpd_model.shutdown()

#============================================================================================
# --- Main Application Window ---
#============================================================================================
class FileBrowserApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.log_dir = user_data_dir(APP_NAME, APP_AUTHOR)
        os.makedirs(self.log_dir, exist_ok=True)
        log_file = os.path.join(self.log_dir, "notez.log")

        root_logger = logging.getLogger()
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        log_level = logging.WARNING if STORE_RELEASE else logging.DEBUG
        root_logger.setLevel(log_level)
        file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        file_handler.setLevel(log_level)
        root_logger.addHandler(file_handler)
        
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        root_logger.addHandler(console_handler)
        logging.info("Logging initialized.")
        #print(f"Log file path: {log_file}")
        #print(f"Notes directory: {self.notes_dir}")

        self.setWindowTitle(APP_NAME)
        
        self.settings = QSettings(COMPANY_NAME, APP_NAME)
        window_size = self.settings.value("window_size", QSize(900, 600))
        if isinstance(window_size, QSize):
            self.resize(window_size)
        else:
            self.resize(900, 600)
        
        app_icon = QIcon()
        ico_path = resource_path(os.path.join("assets", "icons", "icon.ico"))
        png_path = resource_path(os.path.join("assets", "icons", "icon.png"))
        if os.path.exists(ico_path):
            app_icon.addFile(ico_path)
        if os.path.exists(png_path):
            app_icon.addFile(png_path)
        if not app_icon.isNull():
            self.setWindowIcon(app_icon)
        
        self.sidebar_minimized = self.settings.value("sidebar_minimized", False, type=bool)
        
        # Load View Preferences
        raw_prefs = self.settings.value("view_prefs", {"default": "tree", "paths": {}})
        if isinstance(raw_prefs, str):
            try:
                self.view_prefs = json.loads(raw_prefs) # Handle legacy if any
            except Exception:
                self.view_prefs = {"default": "tree", "paths": {}}
        elif isinstance(raw_prefs, dict):
            self.view_prefs = dict(raw_prefs)
        else:
            self.view_prefs = {"default": "tree", "paths": {}}
        if not isinstance(self.view_prefs.get("paths"), dict):
            self.view_prefs["paths"] = {}
        
        # File System Model
        self.model = ThumbnailFileSystemModel()
        self.model.setRootPath(QDir.rootPath())
        self.model.setFilter(QDir.Filter.NoDotAndDotDot | QDir.Filter.AllDirs | QDir.Filter.Files | QDir.Filter.Hidden)

        self.setup_ui()
        self.apply_dark_theme()

        # Instantiate the new AI Assistant Manager
        if ENABLE_AI:
            self.wai_manager = WAIAssistantManager(
                app_name=APP_NAME,
                parent_widget=self,
                get_context_cb=self.get_wai_context,
                execute_pipeline_cb=self.execute_wai_pipeline
            )
            self.wai_manager.connectionChanged.connect(self.btn_wai.setEnabled)

        # Start USB device detection
        self.usb_detector = USBDetector(self)
        self.usb_detector.device_added.connect(self.add_usb_device)
        self.usb_detector.device_removed.connect(self.remove_usb_device)
        self.usb_detector.start()

        # Startup update check
        self._pending_update_version = None
        self._pending_update_url = None
        self._pending_update_notes = None
        self.update_manager = AppUpdateManager(APP_VERSION, self)
        self.update_manager.update_found.connect(self.on_update_found)
        self.update_manager.start_check()

        # Trash state polling timer to ensure dynamic icon updates
        self.trash_timer = QTimer(self)
        self.trash_timer.setInterval(5000)
        self.trash_timer.timeout.connect(self.update_trash_icon)
        self.trash_timer.start()

    def on_update_found(self, latest_version, url, notes):
        self._pending_update_version = latest_version
        self._pending_update_url = url
        self._pending_update_notes = notes
        if hasattr(self, 'btn_about') and self.btn_about:
            self.update_manager.apply_update_style(self.btn_about)
            self.btn_about.setToolTip(f"New version {latest_version} available!")

    def apply_dark_theme(self):
        logging.debug("Applying dark theme with adjusted blue color (#005BB5).")
        close_icon = resource_path(os.path.join("assets", "icons", "custom_close.png"))
        close_icon = close_icon.replace("\\", "/")

        # Theme Variables
        main_bg = "#1e1e1e"
        view_bg = "#111111"      # Darker background for file views and active tab
        text_color = "#ffffff"
        accent_color = "#005BB5"
        border_color = "#555555"
        button_bg = "#323232"
        panel_bg = "#252525"     # Menus, Lists
        hover_bg = "#424242"

        style_sheet = f"""
            QWidget {{
                background-color: {main_bg};
                color: {text_color};
                font-family: "Segoe UI", "Arial", sans-serif;
                font-size: 14px;
            }}
            /* File Views */
            QTreeView, QListView, QTableView {{
                background-color: {view_bg};
                border: none;
            }}
            QPushButton {{
                background-color: {button_bg};
                border: 1px solid {border_color};
                border-radius: 4px;
                padding: 6px;
                min-height: 20px;
            }}
            QPushButton:hover {{
                background-color: {hover_bg};
                border: 1px solid {accent_color};
            }}
            QPushButton:checked {{
                background-color: {accent_color};
                border: 1px solid {accent_color};
            }}
            QPushButton:disabled {{
                background-color: {main_bg};
                color: {border_color};
                border: 1px solid #333;
            }}
            QComboBox {{
                background-color: {button_bg};
                border: 1px solid {border_color};
                border-radius: 4px;
                padding: 5px;
                min-height: 20px;
            }}
            QComboBox:hover {{
                border: 1px solid {accent_color};
            }}
            QComboBox QAbstractItemView {{
                background-color: {panel_bg};
                border: 1px solid {border_color};
                selection-background-color: #444444;
                selection-color: {text_color};
                outline: none;
                border-radius: 8px;
            }}
            QComboBox QAbstractItemView::item {{
                min-height: 25px;
            }}
            QComboBox QAbstractItemView::item:selected,
            QComboBox QAbstractItemView::item:hover {{
                background-color: #444444;
                border: 1px solid {accent_color};
                border-radius: 8px;
                color: {text_color};
            }}
            QMenu {{
                background-color: {panel_bg};
                border: 1px solid {border_color};
            }}
            QMenu::item {{
                padding: 6px 24px;
                background-color: transparent;
                color: {text_color};
            }}
            QMenu::item:selected {{
                background-color: {panel_bg};
                border: 1px solid {accent_color};
                border-radius: 4px;
            }}
            QColorDialog QPushButton {{
                min-width: 100px;
            }}
            QListWidget {{
                background-color: {panel_bg};
                border: 1px solid {border_color};
                border-radius: 4px;
            }}
            QListWidget::item {{
                padding: 4px;
            }}
            QGroupBox {{
                border: 1px solid {main_bg};
                border-radius: 5px;
                margin-top: 10px;
                color: #ddd;
            }}
            QSlider {{
                min-height: 32px;
            }}
            QSlider::groove:horizontal {{
                border: 1px solid {border_color};
                height: 36px;
                background: {button_bg};
                margin: 0px;
                border-radius: 18px;
            }}
            QSlider::handle:horizontal {{
                background: {accent_color};
                border: 1px solid {accent_color};
                width: 36px;
                height: 36px;
                margin: 0px;
                border-radius: 18px;
            }}
            QPushButton#aboutButton {{
                background-color: transparent;
                border: none;
                padding: 4px 8px;
                color: #00BFFF;
            }}
            QPushButton#aboutButton:hover {{
                background-color: {hover_bg};
                border: none;
                border-radius: 4px;
            }}
            QPushButton#aboutButton:pressed {{
                background-color: #333333;
                border: none;
            }}
            QToolTip {{
                border: none;
                background-color: black;
                color: white;
                border-radius: 4px;
                padding: 5px;
            }}
            QTabWidget {{
                border: none;
                padding: 0px;
                margin: 0px;
                background-color: {main_bg};
            }}
            QTabWidget::tab-bar {{
                border: none;
                left: 0;
            }}
            QTabBar {{
                background: {main_bg};
                border: none;
                min-height: 30px;
                qproperty-drawBase: 0;
            }}
            QTabWidget::pane {{
                border: 0px;
                background-color: {view_bg};
                top: 0px;
            }}
            QTabBar::tab {{
                background: {main_bg};
                color: #888;
                padding: 4px 12px;
                height: 30px;
                border: 1px solid {main_bg};
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                margin-right: 2px;
                margin-top: 0px;
            }}
            QTabBar::tab:selected {{
                background: {view_bg};
                color: white;
                border-left: 1px solid {view_bg};
                border-top: 1px solid {view_bg};
                border-right: 1px solid {view_bg};
                border-bottom: 1px solid {view_bg}; 
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }}
            QTabBar::tab:hover {{
                background: {button_bg};
            }}
            QTabBar::close-button {{
                image: url({close_icon});
                subcontrol-position: right;
                margin-right: 5px;
                padding: 2px;
                width: 12px;
                height: 12px;
                border-radius: 2px;
            }}
            QTabBar::close-button:hover {{
                background-color: {accent_color};
                border-radius: 2px;
            }}
            QTabBar::tab:last {{
                background: transparent;
                border: none;
                margin-left: 2px;
            }}
            QTabBar::tab:last:hover {{
                background-color: {hover_bg};
                border-radius: 4px;
            }}
            QTabBar::tab:last:selected {{
                background: transparent;
                border: none;
            }}
        """
        app = QApplication.instance()
        if isinstance(app, QApplication):
            app.setStyleSheet(style_sheet)

    def setup_ui(self):
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.main_layout = QBoxLayout(QBoxLayout.Direction.LeftToRight, self.main_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        self.sidebar_container = QWidget()
        self.sidebar_layout = QBoxLayout(QBoxLayout.Direction.TopToBottom, self.sidebar_container)
        
        self.sidebar_label = QLabel("Quick Access")
        self.note_list = QListWidget()
        self.note_list.setIconSize(QSize(18, 18))
        self.note_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.note_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        if self.note_list.model() is not None:
            self.note_list.model().rowsMoved.connect(
                lambda *args: self.save_quick_access_items()
            )
        self.note_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.note_list.customContextMenuRequested.connect(
            self.show_quick_access_context_menu
        )
        
        self.load_quick_access_items()
            
        self.note_list.itemClicked.connect(lambda item: self.on_sidebar_click(item))
        self.note_list.itemSelectionChanged.connect(lambda: self.on_sidebar_selection_changed())

        self.sidebar_layout.addWidget(self.sidebar_label)
        self.sidebar_layout.addWidget(self.note_list)
        
        self.btn_remove_quick = QPushButton("Remove Item")
        self.btn_remove_quick.setEnabled(False)
        self.btn_remove_quick.clicked.connect(self.remove_from_quick_access)
        self.sidebar_layout.addWidget(self.btn_remove_quick)

        # Move Up & Move Down Reorder Buttons matching web-browser
        self.qa_reorder_layout = QHBoxLayout()
        self.qa_reorder_layout.setSpacing(4)
        self.btn_move_qa_up = QPushButton("▲ Up")
        self.btn_move_qa_up.setToolTip("Move selected item up")
        self.btn_move_qa_up.setEnabled(False)
        self.btn_move_qa_up.clicked.connect(self.move_quick_access_up)
        self.btn_move_qa_down = QPushButton("▼ Down")
        self.btn_move_qa_down.setToolTip("Move selected item down")
        self.btn_move_qa_down.setEnabled(False)
        self.btn_move_qa_down.clicked.connect(self.move_quick_access_down)
        self.qa_reorder_layout.addWidget(self.btn_move_qa_up)
        self.qa_reorder_layout.addWidget(self.btn_move_qa_down)
        self.sidebar_layout.addLayout(self.qa_reorder_layout)
        
        self.btn_toggle_sidebar = QPushButton(">" if self.sidebar_minimized else "<")
        self.btn_toggle_sidebar.setFixedWidth(16)
        self.btn_toggle_sidebar.setToolTip("Minimize/Expand Quick Access")
        self.btn_toggle_sidebar.clicked.connect(self.toggle_sidebar)
        self.btn_toggle_sidebar.setStyleSheet("""
            QPushButton {
                background-color: #252525;
                color: #888;
                border-left: 1px solid #444;
                border-right: 1px solid #444;
                font-size: 10px;
                padding: 0px;
                min-height: 80px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #333;
                color: #007AFF;
            }
        """)

        self.content_container = QWidget()
        self.content_layout = QVBoxLayout(self.content_container)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(0)
        
        self.toolbar_widget = QWidget()
        self.toolbar_layout = QGridLayout(self.toolbar_widget)
        self.toolbar_layout.setContentsMargins(0, 0, 0, 0)
        
        # --- Toolbar ---
        btn_square_size = 32
        tool_icon_size = QSize(28, 28)
        icon_size = tool_icon_size
        transparent_btn_style = """
            QPushButton {
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 2px;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
            QPushButton:pressed {
                background-color: #007AFF;
            }
            QPushButton:disabled {
                background-color: transparent;
                border: 1px solid transparent;
            }
        """
        
        action_btn_style = """
            QPushButton {
                background-color: #323232;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 0px;
            }
            QPushButton:hover {
                background-color: #424242;
                border: 1px solid #007AFF;
            }
            QPushButton:pressed {
                background-color: #007AFF;
            }
        """

        self.btn_back = QPushButton("◀")
        self.btn_back.setToolTip("Back")
        self.btn_back.setStyleSheet(transparent_btn_style)
        self.btn_back.setIconSize(tool_icon_size)
        self.btn_back.setFixedSize(btn_square_size, btn_square_size)
        back_icon = resource_path(os.path.join("assets", "icons", "back.png"))
        if not os.path.exists(back_icon):
            back_icon = resource_path(os.path.join("assets", "icons", "left.png"))
        if os.path.exists(back_icon):
            self.btn_back.setIcon(QIcon(back_icon))
            self.btn_back.setText("")
        self.btn_back.clicked.connect(self.go_back)

        self.btn_forward = QPushButton("▶")
        self.btn_forward.setToolTip("Forward")
        self.btn_forward.setStyleSheet(transparent_btn_style)
        self.btn_forward.setIconSize(tool_icon_size)
        self.btn_forward.setFixedSize(btn_square_size, btn_square_size)
        forward_icon = resource_path(os.path.join("assets", "icons", "forward.png"))
        if not os.path.exists(forward_icon):
            forward_icon = resource_path(os.path.join("assets", "icons", "right.png"))
        if os.path.exists(forward_icon):
            self.btn_forward.setIcon(QIcon(forward_icon))
            self.btn_forward.setText("")
        self.btn_forward.clicked.connect(self.go_forward)

        self.btn_up = QPushButton("▲")
        self.btn_up.setToolTip("Up")
        self.btn_up.setStyleSheet(transparent_btn_style)
        self.btn_up.setIconSize(tool_icon_size)
        self.btn_up.setFixedSize(btn_square_size, btn_square_size)
        up_icon = resource_path(os.path.join("assets", "icons", "up.png"))
        if os.path.exists(up_icon):
            self.btn_up.setIcon(QIcon(up_icon))
            self.btn_up.setText("")
        self.btn_up.clicked.connect(self.go_up)

        self.btn_home = QPushButton("🏠")
        self.btn_home.setToolTip("Home")
        self.btn_home.setStyleSheet(transparent_btn_style)
        self.btn_home.setIconSize(tool_icon_size)
        self.btn_home.setFixedSize(btn_square_size, btn_square_size)
        home_icon = resource_path(os.path.join("assets", "icons", "home.png"))
        if os.path.exists(home_icon):
            self.btn_home.setIcon(QIcon(home_icon))
            self.btn_home.setText("")
        self.btn_home.clicked.connect(self.go_home)
        
        self.address_bar = QLineEdit()
        self.address_bar.returnPressed.connect(self.navigate_to_address)
        
        self.toolbar_layout.addWidget(self.btn_back, 0, 0)
        self.toolbar_layout.addWidget(self.btn_forward, 0, 1)
        self.toolbar_layout.addWidget(self.btn_up, 0, 2)
        self.toolbar_layout.addWidget(self.btn_home, 0, 3)
        self.toolbar_layout.addWidget(self.address_bar, 0, 4)

        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search...")
        self.search_bar.setFixedWidth(200)
        self.search_bar.textChanged.connect(self.on_search_changed)
        self.toolbar_layout.addWidget(self.search_bar, 0, 5)

        self.btn_add_quick = QPushButton()
        self.btn_add_quick.setToolTip("Add to Quick Access")
        self.btn_add_quick.setStyleSheet(action_btn_style)
        self.btn_add_quick.setIconSize(icon_size)
        self.btn_add_quick.setFixedSize(btn_square_size, btn_square_size)
        icon_path = resource_path(os.path.join("assets", "icons", "add.png"))
        if os.path.exists(icon_path):
            self.btn_add_quick.setIcon(QIcon(icon_path))
        else:
            self.btn_add_quick.setText("+")
        self.btn_add_quick.clicked.connect(self.add_to_quick_access)
        self.toolbar_layout.addWidget(self.btn_add_quick, 0, 6)

        self.btn_wai = QPushButton("AI")
        self.btn_wai.setToolTip("WAI Assistant (AI)")
        # Connect to the WAI Manager instead of the local class
        if ENABLE_AI:
            self.btn_wai.clicked.connect(self.open_wai_dialog)
        else:
            self.btn_wai.hide()
        self.btn_wai.setEnabled(False)
        self.toolbar_layout.addWidget(self.btn_wai, 0, 7)

        self.btn_prefs = QPushButton()
        self.btn_prefs.setToolTip("Preferences")
        self.btn_prefs.setStyleSheet(action_btn_style)
        self.btn_prefs.setIconSize(icon_size)
        self.btn_prefs.setFixedSize(btn_square_size, btn_square_size)
        icon_path = resource_path(os.path.join("assets", "icons", "settings.png")) # Assuming icon exists or fallback
        if os.path.exists(icon_path):
            self.btn_prefs.setIcon(QIcon(icon_path))
        else:
            self.btn_prefs.setText("⚙")
        self.btn_prefs.clicked.connect(self.show_preferences)
        self.toolbar_layout.addWidget(self.btn_prefs, 0, 8)

        self.btn_terminal = QPushButton()
        self.btn_terminal.setToolTip("Toggle Terminal")
        self.btn_terminal.setStyleSheet(action_btn_style)
        self.btn_terminal.setIconSize(icon_size)
        self.btn_terminal.setFixedSize(btn_square_size, btn_square_size)
        self.btn_terminal.setText(">_")
        self.btn_terminal.clicked.connect(self.toggle_terminal)
        self.toolbar_layout.addWidget(self.btn_terminal, 0, 9)

        self.btn_about = QPushButton("About")
        self.btn_about.setObjectName("aboutButton")
        self.btn_about.clicked.connect(self.show_about_dialog)
        self.toolbar_layout.addWidget(self.btn_about, 0, 10)

        self.shortcut_toggle_hidden = QShortcut(QKeySequence("Ctrl+H"), self)
        self.shortcut_toggle_hidden.activated.connect(self.toggle_hidden_files)

        self.shortcut_new_tab = QShortcut(QKeySequence("Ctrl+T"), self)
        self.shortcut_new_tab.activated.connect(self.add_new_tab)
        
        self.shortcut_close_tab = QShortcut(QKeySequence("Ctrl+W"), self)
        self.shortcut_close_tab.activated.connect(self.close_current_tab)

        self.content_layout.addWidget(self.toolbar_widget)

        # Trash Information Banner (GNOME Files style)
        self.trash_banner = QFrame()
        self.trash_banner.setObjectName("trashBanner")
        self.trash_banner.setStyleSheet("""
            QFrame#trashBanner {
                background-color: #25282c;
                border-bottom: 1px solid #3d424a;
            }
            QLabel#trashBannerLabel {
                color: #ffffff;
                font-size: 13px;
                font-weight: bold;
            }
            QLabel#trashBannerSubLabel {
                color: #9aa0a6;
                font-size: 11px;
            }
            QPushButton#btnEmptyTrash {
                background-color: #373e48;
                color: #ffffff;
                border: 1px solid #4f5866;
                border-radius: 4px;
                padding: 5px 14px;
                font-size: 12px;
                font-weight: 600;
            }
            QPushButton#btnEmptyTrash:hover {
                background-color: #c0392b;
                border-color: #e74c3c;
            }
            QPushButton#btnEmptyTrash:disabled {
                background-color: #282b30;
                color: #666666;
                border: 1px solid #383c44;
            }
        """)
        trash_banner_layout = QHBoxLayout(self.trash_banner)
        trash_banner_layout.setContentsMargins(12, 6, 12, 6)

        self.trash_banner_icon = QLabel()
        self.trash_banner_icon.setPixmap(get_quick_access_icon(name="Trash").pixmap(22, 22))

        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)

        self.trash_banner_title = QLabel("Trash")
        self.trash_banner_title.setObjectName("trashBannerLabel")
        self.trash_banner_desc = QLabel("Items in the Trash will be permanently deleted.")
        self.trash_banner_desc.setObjectName("trashBannerSubLabel")
        text_layout.addWidget(self.trash_banner_title)
        text_layout.addWidget(self.trash_banner_desc)

        self.btn_empty_trash = QPushButton("Empty Trash...")
        self.btn_empty_trash.setObjectName("btnEmptyTrash")
        self.btn_empty_trash.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_empty_trash.clicked.connect(self.empty_trash)

        trash_banner_layout.addWidget(self.trash_banner_icon)
        trash_banner_layout.addSpacing(8)
        trash_banner_layout.addLayout(text_layout)
        trash_banner_layout.addStretch()
        trash_banner_layout.addWidget(self.btn_empty_trash)

        self.trash_banner.hide()
        self.content_layout.addWidget(self.trash_banner)
        
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(False)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        self.tabs.tabBarClicked.connect(self.on_tab_bar_clicked)
        
        # Add dummy "+" tab
        self.tabs.addTab(QWidget(), "+")
        self.tabs.setTabToolTip(0, "New Tab (Ctrl+T)")
        self.tabs.tabBar().setTabButton(0, QTabBar.ButtonPosition.RightSide, None)
        
        # Terminal Setup
        if TerminalWidget is not None:
            self.terminal = TerminalWidget(parent=self)
            self.terminal.btn_about.hide()
            self.terminal.btn_prefs.hide()
            self.terminal.cwd_changed.connect(self.navigate_to)
            # Apply all saved terminal preferences across sessions
            self.apply_terminal_preferences()

            if not bool(self.settings.value("terminal_visible", False, type=bool)):
                self.terminal.hide()
            
            self.splitter = QSplitter(Qt.Orientation.Vertical)
            self.splitter.addWidget(self.tabs)
            self.splitter.addWidget(self.terminal)
            self.splitter.setCollapsible(0, False)
            self.splitter.setCollapsible(1, True)
        else:
            self.terminal = None
            if hasattr(self, "btn_terminal"):
                self.btn_terminal.setEnabled(False)
                self.btn_terminal.setToolTip("Terminal is unavailable")
            self.splitter = QSplitter(Qt.Orientation.Vertical)
            self.splitter.addWidget(self.tabs)
            self.splitter.setCollapsible(0, False)
        
        self.content_layout.addWidget(self.splitter)
        
        self.main_layout.addWidget(self.sidebar_container)
        self.main_layout.addWidget(self.btn_toggle_sidebar)
        self.main_layout.addWidget(self.content_container)
        
        if self.sidebar_minimized:
            self.sidebar_container.setFixedWidth(0)
            self.sidebar_container.hide()
        else:
            self.sidebar_container.setFixedWidth(180)
        
        # Restore tabs
        saved_tabs = self.settings.value("open_tabs")
        tabs_restored = False
        
        if saved_tabs:
            try:
                paths = json.loads(saved_tabs)
                if paths and isinstance(paths, list):
                    for path in paths:
                        if os.path.exists(path):
                            self.add_new_tab(path)
                            tabs_restored = True
            except Exception:
                pass
        
        if not tabs_restored:
            last_path = self.settings.value("last_directory")
            if last_path and os.path.exists(last_path):
                self.add_new_tab(last_path)
            else:
                self.add_new_tab(QDir.homePath())

        # Restore active tab index
        if tabs_restored:
            active_index = int(cast(Any, self.settings.value("active_tab_index", 0, type=int)))
            if 0 <= active_index < self.tabs.count() - 1:
                self.tabs.setCurrentIndex(active_index)
            
        # Sync terminal directory if it is set to be visible
        if self.terminal and bool(self.settings.value("terminal_visible", False, type=bool)):
            self.terminal.set_current_directory(self.address_bar.text())
            QTimer.singleShot(100, self.apply_terminal_height)

    def resizeEvent(self, event):
        super().resizeEvent(event)

    def toggle_sidebar(self):
        self.sidebar_minimized = not self.sidebar_minimized
        self.settings.setValue("sidebar_minimized", self.sidebar_minimized)
        if self.sidebar_minimized:
            self.btn_toggle_sidebar.setText(">")
        else:
            self.btn_toggle_sidebar.setText("<")
        
        if self.sidebar_minimized:
            self.sidebar_container.setFixedWidth(0)
            self.sidebar_container.hide()
        else:
            self.sidebar_container.show()
            self.sidebar_container.setFixedWidth(180)

    def apply_terminal_height(self):
        if not self.terminal:
            return
        rows = int(cast(Any, self.settings.value("terminal_initial_rows", 15, type=int)))
        target_height = (rows * 20) + 40 # Approx 20px/row + input bar
        total_height = self.splitter.height()
        if total_height > 0:
            self.splitter.setSizes([total_height - target_height, target_height])

    def apply_terminal_preferences(self):
        """Applies all saved terminal preferences across sessions (scrollback lines,
        font family, font size, and theme).
        """
        if not self.terminal:
            return

        # 1. Scrollback lines
        term_lines = int(cast(Any, self.settings.value("scrollback_lines", 1000, type=int)))
        if hasattr(self.terminal, "set_scrollback_lines"):
            self.terminal.set_scrollback_lines(term_lines)

        # 2. Font family
        saved_font = str(self.settings.value("terminal_font_family", ""))
        if saved_font and hasattr(self.terminal, "set_font_family"):
            self.terminal.set_font_family(saved_font)

        # 3. Font size
        saved_font_size = int(cast(Any, self.settings.value("terminal_font_size", 0, type=int)))
        if saved_font_size > 0 and hasattr(self.terminal, "set_font_size"):
            self.terminal.set_font_size(saved_font_size)

        # 4. Terminal theme
        self.apply_terminal_theme()

    def apply_terminal_theme(self):
        """Ensures the embedded terminal background color matches the file browser main window (#1e1e1e)
        by default, while respecting and persisting user-selected themes across sessions.
        """
        if not self.terminal:
            return

        main_bg = "#1e1e1e"
        fb_theme = {
            "name": "File Browser",
            "bg": main_bg,
            "fg": "#ffffff",
            "ansi": [
                '#000000', '#cd3131', '#0dbc79', '#e5e510', '#2472c8', '#bc3fbc', '#11a8cd', '#e5e5e5',
                '#666666', '#f14c4c', '#23d18b', '#f5f543', '#3b8eea', '#d670d6', '#29b8db', '#ffffff'
            ]
        }

        if hasattr(self.terminal, "plugin_manager") and hasattr(self.terminal.plugin_manager, "themes"):
            self.terminal.plugin_manager.themes["File Browser"] = fb_theme

        # Determine target theme: default to File Browser (#1e1e1e) to match main window background
        target_theme = str(self.settings.value("terminal_theme", "File Browser"))
        if not target_theme:
            target_theme = "File Browser"
            self.settings.setValue("terminal_theme", "File Browser")

        if hasattr(self.terminal, "set_theme"):
            self.terminal.set_theme(target_theme)
        elif hasattr(self.terminal, "tabs"):
            for i in range(self.terminal.tabs.count()):
                w = self.terminal.tabs.widget(i)
                if hasattr(w, "current_theme"):
                    w.current_theme["bg"] = main_bg
                    if hasattr(w, "apply_theme"):
                        w.apply_theme()

    def toggle_terminal(self):
        if not self.terminal:
            return
        if self.terminal.isVisible():
            self.terminal.hide()
            self.settings.setValue("terminal_visible", False)
        else:
            self.terminal.show()
            self.settings.setValue("terminal_visible", True)
            self.apply_terminal_height()
            self.terminal.set_current_directory(self.address_bar.text())
            if self.terminal.input_line:
                self.terminal.input_line.setFocus()

    # --- Logic ---
    def on_sidebar_click(self, item):
        path = item.data(Qt.ItemDataRole.UserRole)
        if path:
            if not os.path.exists(path) and item.text().lower() == "trash":
                try:
                    os.makedirs(path, exist_ok=True)
                except Exception:
                    pass
            dev_type = item.data(int(Qt.ItemDataRole.UserRole) + 1)
            if dev_type == "android":
                # Just navigate internally now
                self.navigate_to(path)
            else:
                self.navigate_to(path)
    
    def on_sidebar_selection_changed(self):
        selected_items = self.note_list.selectedItems()
        if not selected_items:
            self.btn_remove_quick.setEnabled(False)
            self.btn_remove_quick.setText("Remove Item")
            self.btn_remove_quick.setToolTip("Remove selected item from Quick Access")
            if hasattr(self, "btn_move_qa_up"):
                self.btn_move_qa_up.setEnabled(False)
                self.btn_move_qa_down.setEnabled(False)
            return

        item = selected_items[0]
        row = self.note_list.row(item)
        count = self.note_list.count()

        if hasattr(self, "btn_move_qa_up"):
            self.btn_move_qa_up.setEnabled(row > 0)
            self.btn_move_qa_down.setEnabled(row < count - 1)

        path = item.data(Qt.ItemDataRole.UserRole)
        if is_quick_access_permanent(item.text(), path):
            self.btn_remove_quick.setEnabled(False)
            self.btn_remove_quick.setText("Remove Item")
            display_name = item.text().rstrip("/")
            self.btn_remove_quick.setToolTip(f"{display_name} cannot be removed from Quick Access")
            return

        self.btn_remove_quick.setEnabled(True)
        role = item.data(int(Qt.ItemDataRole.UserRole) + 1)
        if role == "usb":
            self.btn_remove_quick.setText("Eject USB")
            self.btn_remove_quick.setToolTip("Safely eject the selected USB device")
        elif role == "android":
            self.btn_remove_quick.setText("Disconnect")
            self.btn_remove_quick.setToolTip("Safely disconnect the Android device")
        else:
            self.btn_remove_quick.setText("Remove Item")
            self.btn_remove_quick.setToolTip("Remove selected item from Quick Access")

    def on_tab_bar_clicked(self, index):
        if index == self.tabs.count() - 1:
            self.add_new_tab()

    def add_new_tab(self, path=None):
        if not path:
            path = QDir.homePath()
            if self.tabs.count() > 1:
                current = self.tabs.currentWidget()
                if current and isinstance(current, BrowserTab):
                    path = current.get_current_path()

        tab = BrowserTab(self.model, self.view_prefs, path)
        tab.path_changed.connect(self.on_tab_path_changed)
        tab.open_terminal_requested.connect(self.open_terminal_at)
        tab.sort_changed.connect(self.on_sort_preference_changed)
        
        index = self.tabs.insertTab(self.tabs.count() - 1, tab, os.path.basename(path) or path)
        self.tabs.setCurrentIndex(index)
        self.tabs.tabBar().setTabButton(self.tabs.count() - 1, QTabBar.ButtonPosition.RightSide, None)
        self.address_bar.setText(path)
        self.address_bar.setFocus()
        self.update_trash_banner()

    def close_tab(self, index):
        if index == self.tabs.count() - 1:
            return
            
        if self.tabs.count() > 2:
            widget_to_close = self.tabs.widget(index)
            if isinstance(widget_to_close, BrowserTab):
                widget_to_close.shutdown()
            was_current = (index == self.tabs.currentIndex())

            self.tabs.removeTab(index)
            self.tabs.tabBar().setTabButton(self.tabs.count() - 1, QTabBar.ButtonPosition.RightSide, None)
            
            if was_current and index > 0:
                self.tabs.setCurrentIndex(index - 1)
        else:
            self.close()

    def close_current_tab(self):
        self.close_tab(self.tabs.currentIndex())

    def on_tab_changed(self, index):
        if index >= 0:
            tab = self.tabs.widget(index)
            if isinstance(tab, BrowserTab):
                self.address_bar.setText(tab.get_current_path())
                self.search_bar.setText(tab.proxy_model.name_filter)
                if self.terminal and self.terminal.isVisible():
                    self.terminal.set_current_directory(tab.get_current_path())
                self.update_nav_buttons()
                self.update_trash_banner()

    def on_tab_path_changed(self, path):
        sender_tab = self.sender()
        if isinstance(sender_tab, BrowserTab):
            index = self.tabs.indexOf(sender_tab)
            if index >= 0:
                tab_title = os.path.basename(path) or path
                if tab_title.startswith("mtp:host="):
                    raw = tab_title[len("mtp:host="):]
                    parts = [p for p in raw.replace("_", " ").split() if p]
                    deduped = []
                    for p in parts:
                        if not deduped or p.lower() != deduped[-1].lower():
                            deduped.append(p)
                    tab_title = " ".join(deduped).strip() or "Android Device"
                elif tab_title.startswith("gphoto2:host="):
                    raw = tab_title[len("gphoto2:host="):]
                    parts = [p for p in raw.replace("_", " ").split() if p]
                    tab_title = " ".join(dict.fromkeys(parts)).strip() or "Camera/Phone"
                elif path.startswith("wpd://") and "/" not in path.replace("wpd://", ""):
                    tab_title = path.replace("wpd://", "") or "Android Device"
                self.tabs.setTabText(index, tab_title)
                if index == self.tabs.currentIndex():
                    self.address_bar.setText(path)
                    self.search_bar.setText(sender_tab.proxy_model.name_filter)
                    if self.terminal and self.terminal.isVisible():
                        self.terminal.set_current_directory(path)
                    self.update_nav_buttons()
                    self.update_trash_banner()

    def navigate_to(self, path):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.navigate_to(path)

    def on_search_changed(self, text):
        logging.debug(f"Search text changed: {text}")
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.proxy_model.setNameFilter(text)
            widget.update_view(widget.get_current_path())

    def update_view(self, path):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.update_view(path)

    def update_nav_buttons(self):
        tab = self.tabs.currentWidget()
        if isinstance(tab, BrowserTab):
            self.btn_back.setEnabled(tab.history_index > 0)
            self.btn_forward.setEnabled(tab.history_index < len(tab.history) - 1)
        else:
            self.btn_back.setEnabled(False)
            self.btn_forward.setEnabled(False)

    def navigate_to_address(self):
        path = self.address_bar.text()
        self.navigate_to(path)

    def go_back(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.go_back()

    def go_forward(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.go_forward()

    def go_up(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.go_up()

    def go_home(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.go_home()

    def open_terminal_at(self, path):
        if not self.terminal:
            return
        if not self.terminal.isVisible():
            self.toggle_terminal()
        self.terminal.set_current_directory(path)
        if self.terminal.input_line:
            self.terminal.input_line.setFocus()

    def add_to_quick_access(self):
        path = self.address_bar.text()
        if not path or not os.path.exists(path):
            return
        
        # Check for duplicates
        for i in range(self.note_list.count()):
            item = self.note_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == path:
                return
        
        name = os.path.basename(path) or path
        item = QListWidgetItem(get_quick_access_icon(name=name, path=path), name)
        item.setData(Qt.ItemDataRole.UserRole, path)
        self.note_list.addItem(item)
        self.save_quick_access_items()

    def remove_from_quick_access(self):
        item = self.note_list.currentItem()
        if not item:
            return

        path = item.data(Qt.ItemDataRole.UserRole)
        if is_quick_access_permanent(item.text(), path):
            return

        dev_type = item.data(int(Qt.ItemDataRole.UserRole) + 1)
        if dev_type in ["usb", "android"]:
            path = item.data(Qt.ItemDataRole.UserRole)
            if dev_type == "usb":
                self.eject_usb_device(path)
            elif dev_type == "android":
                if path and path.startswith("wpd://"):
                    self.remove_usb_device(path)
                    QMessageBox.information(self, "Disconnect", "Android device disconnected. You can now safely unplug your phone.")
                else:
                    self.eject_usb_device(path)
        else:
            self.note_list.takeItem(self.note_list.row(item))
            self.save_quick_access_items()
            self.on_sidebar_selection_changed()

    def move_quick_access_up(self):
        row = self.note_list.currentRow()
        if row > 0:
            item = self.note_list.takeItem(row)
            self.note_list.insertItem(row - 1, item)
            self.note_list.setCurrentRow(row - 1)
            self.save_quick_access_items()
            self.on_sidebar_selection_changed()

    def move_quick_access_down(self):
        row = self.note_list.currentRow()
        if row != -1 and row < self.note_list.count() - 1:
            item = self.note_list.takeItem(row)
            self.note_list.insertItem(row + 1, item)
            self.note_list.setCurrentRow(row + 1)
            self.save_quick_access_items()
            self.on_sidebar_selection_changed()

    def on_sort_preference_changed(self, column: int, order: Qt.SortOrder):
        """Persists sorting preference and synchronizes across all open tabs."""
        try:
            order_val = order.value if hasattr(order, "value") else int(cast(Any, order))
            self.settings.setValue("sort_column", column)
            self.settings.setValue("sort_order", order_val)
        except Exception as e:
            logging.warning(f"Failed saving sort settings to QSettings: {e}")
        sender = self.sender()
        for i in range(self.tabs.count() - 1):
            tab = self.tabs.widget(i)
            if isinstance(tab, BrowserTab) and tab != sender:
                tab.apply_sort(column, order)

    def update_trash_banner(self):
        """Displays or updates GNOME Files style Empty Trash banner when viewing Trash."""
        tab = self.tabs.currentWidget()
        if not isinstance(tab, BrowserTab):
            if hasattr(self, "trash_banner"):
                self.trash_banner.hide()
            return
        current_path = tab.get_current_path()
        if is_trash_path(current_path):
            is_empty = is_trash_empty()
            self.btn_empty_trash.setEnabled(not is_empty)
            if is_empty:
                self.trash_banner_title.setText("Trash is empty")
                self.trash_banner_desc.setText("There are no deleted items in Trash.")
            else:
                self.trash_banner_title.setText("Trash")
                self.trash_banner_desc.setText("Items in the Trash will be permanently deleted.")
            self.trash_banner_icon.setPixmap(get_quick_access_icon(name="Trash").pixmap(22, 22))
            self.trash_banner.show()
        else:
            if hasattr(self, "trash_banner"):
                self.trash_banner.hide()

    def empty_trash(self):
        """Prompts for confirmation and permanently empties the trash, updating UI."""
        if is_trash_empty():
            QMessageBox.information(self, "Trash is Empty", "There are no items in the Trash.")
            return

        if not confirm_empty_trash(self):
            return

        empty_trash_files()
        
        # Refresh current views in all tabs
        for i in range(self.tabs.count() - 1):
            tab = self.tabs.widget(i)
            if isinstance(tab, BrowserTab):
                tab.proxy_model.invalidate()
                tab.update_view(tab.get_current_path())
        
        self.update_trash_icon()
        self.update_trash_banner()

    def show_quick_access_context_menu(self, pos):
        item = self.note_list.itemAt(pos)
        if not item:
            return
        row = self.note_list.row(item)
        self.note_list.setCurrentRow(row)
        path = item.data(Qt.ItemDataRole.UserRole)
        dev_type = item.data(int(Qt.ItemDataRole.UserRole) + 1)
        is_trash = (item.text().lower() == "trash") or is_trash_path(path)
        is_permanent = is_quick_access_permanent(item.text(), path)

        menu = QMenu(self)
        open_act = menu.addAction("Open")
        open_act.triggered.connect(lambda: self.on_sidebar_click(item))

        open_tab_act = menu.addAction("Open in New Tab")
        open_tab_act.triggered.connect(lambda: self.add_new_tab(path))

        if is_trash:
            empty_act = menu.addAction("Empty Trash...")
            empty_act.setEnabled(not is_trash_empty())
            empty_act.triggered.connect(self.empty_trash)

        menu.addSeparator()

        move_up_act = menu.addAction("▲ Move Up")
        move_up_act.triggered.connect(self.move_quick_access_up)
        if row == 0:
            move_up_act.setEnabled(False)

        move_down_act = menu.addAction("▼ Move Down")
        move_down_act.triggered.connect(self.move_quick_access_down)
        if row >= self.note_list.count() - 1:
            move_down_act.setEnabled(False)

        if not is_permanent:
            menu.addSeparator()
            if dev_type == "usb":
                remove_act = menu.addAction("Eject USB")
                remove_act.triggered.connect(self.remove_from_quick_access)
            elif dev_type == "android":
                remove_act = menu.addAction("Disconnect")
                remove_act.triggered.connect(self.remove_from_quick_access)
            else:
                remove_act = menu.addAction("Remove from Quick Access")
                remove_act.triggered.connect(self.remove_from_quick_access)

        menu.exec(self.note_list.mapToGlobal(pos))

    def update_trash_icon(self):
        """Updates the icon of the Trash entry in Quick Access based on contents."""
        trash_path = os.path.abspath(get_trash_directory())
        for i in range(self.note_list.count()):
            item = self.note_list.item(i)
            item_path = os.path.abspath(item.data(Qt.ItemDataRole.UserRole) or "")
            if item.text().lower() == "trash" or (item_path and item_path == trash_path):
                icon = get_quick_access_icon(name="Trash", path=item_path)
                item.setIcon(icon)
                break
        self.update_trash_banner()

    def load_quick_access_items(self):
        logging.debug("--- Loading Quick Access items ---")
        data = self.settings.value("quick_access_items")
        logging.debug(f"Raw quick_access_items from settings: {data}")
        items = []
        
        if data:
            try:
                items = json.loads(data)
                logging.debug(f"Loaded {len(items)} items from settings.")
            except Exception as e:
                logging.warning(f"Failed to parse quick_access_items JSON: {e}")
                pass
        
        if not items:
            logging.debug("No saved items found, creating default Quick Access items.")
            items = [
                {"name": "Home", "path": QDir.homePath()},
                {"name": "Desktop", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation)},
                {"name": "Documents", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)},
                {"name": "Downloads", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)},
                {"name": "Pictures", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)},
                {"name": "Music", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MusicLocation)},
                {"name": "Videos", "path": QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MoviesLocation)},
                {"name": "Trash", "path": get_trash_directory()},
            ]

        # Ensure Pictures, Music, Videos, and Trash are added if missing from previous settings
        existing_names = {entry.get("name", "").strip().lower() for entry in items}
        for std_name, std_path in [
            ("Pictures", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation)),
            ("Music", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MusicLocation)),
            ("Videos", QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MoviesLocation)),
            ("Trash", get_trash_directory()),
        ]:
            if std_name.lower() not in existing_names and std_path and (std_name == "Trash" or os.path.exists(std_path)):
                logging.debug(f"Adding standard folder {std_name} to Quick Access: {std_path}")
                items.append({"name": std_name, "path": std_path})
                existing_names.add(std_name.lower())

        if sys.platform == "win32":
            onedrive_pics = os.path.join(os.path.expanduser("~"), "OneDrive", "Pictures")
            if os.path.exists(onedrive_pics):
                if not any(item.get("path") == onedrive_pics for item in items):
                    logging.debug(f"Adding OneDrive Pictures to Quick Access: {onedrive_pics}")
                    items.append({"name": "Pictures", "path": onedrive_pics})

        self.note_list.clear()
        logging.debug(f"Processing {len(items)} final items for Quick Access.")
        for entry in items:
            name = entry.get("name")
            path = entry.get("path")
            if name and path:
                logging.debug(f"Adding to Quick Access: Name='{name}', Path='{path}'")
                display_name = name
                for prefix in ("📱 ", "💾 ", "📁 ", "🏠 "):
                    if display_name.startswith(prefix):
                        display_name = display_name[len(prefix):]
                icon = get_quick_access_icon(name=display_name, path=path)
                item = QListWidgetItem(icon, display_name)
                item.setData(Qt.ItemDataRole.UserRole, path)
                self.note_list.addItem(item)
            else:
                logging.warning(f"Skipping invalid Quick Access entry: {entry}")
        logging.debug("--- Finished loading Quick Access items ---")

    def save_quick_access_items(self):
        items = []
        for i in range(self.note_list.count()):
            item = self.note_list.item(i)
            # Only save non-USB items
            if item.data(int(Qt.ItemDataRole.UserRole) + 1) not in ["usb", "android"]:
                items.append({
                    "name": item.text(),
                    "path": item.data(Qt.ItemDataRole.UserRole)
                })
        self.settings.setValue("quick_access_items", json.dumps(items))

    def add_usb_device(self, path, name, dev_type="usb"):
        """Adds a USB device to the Quick Access list."""
        logging.debug(f"add_usb_device called: Path='{path}', Name='{name}', Type='{dev_type}'")
        for i in range(self.note_list.count()):
            item = self.note_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == path:
                logging.debug(f"USB device at path '{path}' already in Quick Access. Skipping.")
                return

        dev_icon = get_quick_access_icon(name=name, path=path, dev_type=dev_type)
        if not dev_icon.isNull():
            item = QListWidgetItem(dev_icon, name)
        else:
            fallback_emoji = "📱" if dev_type == "android" else "💾"
            item = QListWidgetItem(f"{fallback_emoji} {name}")
        item.setData(Qt.ItemDataRole.UserRole, path)
        item.setData(int(Qt.ItemDataRole.UserRole) + 1, dev_type)
        self.note_list.addItem(item)
        logging.info(f"Added '{name}' to Quick Access.")

    def remove_usb_device(self, path):
        """Removes a USB device from the Quick Access list."""
        logging.debug(f"remove_usb_device called for path: '{path}'")
        for i in range(self.note_list.count()):
            item = self.note_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == path and item.data(int(Qt.ItemDataRole.UserRole) + 1) in ["usb", "android"]:
                self.note_list.takeItem(i)
                logging.info(f"Removed device at '{path}' from Quick Access.")
                break

        # If any open tab was viewing the removed device, safely navigate back to home
        for t_idx in range(self.tabs.count() - 1):
            tab = self.tabs.widget(t_idx)
            if isinstance(tab, BrowserTab):
                cur = tab.get_current_path()
                if cur == path or cur.startswith(path.rstrip('/') + '/'):
                    tab.navigate_to(QDir.homePath())

    def eject_usb_device(self, path):
        """Safely ejects a USB device or disconnects an Android device."""
        is_android = "mtp" in path or "gvfs" in path or "wpd://" in path
        title = "Disconnecting" if is_android else "Ejecting"
        msg = "Disconnecting Android device..." if is_android else "Ejecting USB device..."
        self.progress_dialog = QProgressDialog(msg, "Cancel", 0, 0, self)
        self.progress_dialog.setWindowTitle(title)
        self.progress_dialog.setWindowModality(Qt.WindowModality.WindowModal)
        self.progress_dialog.setMinimumDuration(0)
        self.progress_dialog.canceled.connect(self.on_eject_cancel)
        
        self.eject_thread = USBEjectThread(path)
        self.eject_thread.result.connect(self.on_eject_complete)
        self.eject_thread.finished.connect(self.progress_dialog.close)
        
        self.progress_dialog.show()
        self.eject_thread.start()

    def on_eject_complete(self, success, message):
        is_android = "android" in message.lower()
        title = "Disconnect Success" if is_android and success else ("Disconnect Error" if is_android else ("Eject Success" if success else "Eject Error"))
        if success:
            QMessageBox.information(self, title, message)
        else:
            QMessageBox.warning(self, title, message)

    def on_eject_cancel(self):
        if hasattr(self, 'eject_thread') and self.eject_thread.isRunning():
            try:
                self.eject_thread.result.disconnect(self.on_eject_complete)
            except Exception:
                pass
            logging.info("Eject cancelled by user.")

    def toggle_hidden_files(self, force_state=None):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            widget.toggle_hidden_files(force_state)
            
    def show_preferences(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Preferences")
        dlg.setFixedSize(400, 480)
        layout = QVBoxLayout(dlg)
        
        layout.addWidget(QLabel("Default View for Current Directory:"))
        
        combo = QComboBox()
        combo.addItems(["Tree View (Details)", "List View", "Tile View (Icons)"])
        
        current_path = self.address_bar.text()
        paths_prefs = self.view_prefs.get("paths", {})
        if not isinstance(paths_prefs, dict):
            paths_prefs = {}
            self.view_prefs["paths"] = paths_prefs
        current_mode = paths_prefs.get(current_path, self.view_prefs.get("default", "tree"))
        
        if current_mode == "list": 
            combo.setCurrentIndex(1)
        elif current_mode == "tile": 
            combo.setCurrentIndex(2)
        else: 
            combo.setCurrentIndex(0)
        
        layout.addWidget(combo)
        
        chk_apply_all = QCheckBox("Apply to ALL directories (Set as Global Default)")
        layout.addWidget(chk_apply_all)
        
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(line)
        
        chk_confirm = QCheckBox("Confirm Delete")
        chk_confirm.setChecked(bool(cast(Any, self.settings.value("confirm_delete", True, type=bool))))
        layout.addWidget(chk_confirm)

        layout.addWidget(QLabel("Terminal Scrollback Lines:"))
        spin_lines = QSpinBox()
        spin_lines.setRange(100, 10000)
        spin_lines.setSingleStep(100)
        spin_lines.setValue(int(cast(Any, self.settings.value("scrollback_lines", 1000, type=int))))
        layout.addWidget(spin_lines)
        
        layout.addWidget(QLabel("Terminal Initial Height (Rows):"))
        spin_rows = QSpinBox()
        spin_rows.setRange(5, 100)
        spin_rows.setValue(int(cast(Any, self.settings.value("terminal_initial_rows", 15, type=int))))
        layout.addWidget(spin_rows)

        layout.addWidget(QLabel("Terminal Font Family:"))
        font_combo = QComboBox()
        fonts = ["Consolas", "'Courier New'", "Menlo", "'DejaVu Sans Mono'", "monospace", "Arial", "'Segoe UI'", "Verdana"]
        if self.terminal and hasattr(self.terminal, "plugin_manager") and hasattr(self.terminal.plugin_manager, "get_custom_fonts"):
            for cf in self.terminal.plugin_manager.get_custom_fonts():
                formatted_cf = f"'{cf}'" if " " in cf else cf
                if formatted_cf not in fonts:
                    fonts.append(formatted_cf)
        font_combo.addItems([f.replace("'", "") for f in fonts])
        
        saved_font = str(self.settings.value("terminal_font_family", ""))
        current_font: str = saved_font or (str(getattr(self.terminal, "font_family", "Consolas")) if self.terminal else "Consolas")
        if current_font in fonts:
            font_combo.setCurrentIndex(fonts.index(current_font))
            
        layout.addWidget(font_combo)

        layout.addWidget(QLabel("Terminal Font Size:"))
        spin_font_size = QSpinBox()
        spin_font_size.setRange(8, 72)
        saved_font_size = int(cast(Any, self.settings.value("terminal_font_size", 0, type=int)))
        current_font_size: int = saved_font_size if saved_font_size > 0 else (int(getattr(self.terminal, "font_size", 12)) if self.terminal else 12)
        spin_font_size.setValue(current_font_size)
        layout.addWidget(spin_font_size)

        layout.addWidget(QLabel("Terminal Theme:"))
        theme_combo = QComboBox()
        available_themes = ["File Browser (Match Main Window)", "Wheelhouser Dark", "XTerm", "Solarized Dark", "Ubuntu", "PowerShell"]
        theme_combo.addItems(available_themes)
        saved_theme = str(self.settings.value("terminal_theme", ""))
        curr_theme: str = saved_theme or (str(getattr(self.terminal, "theme_name", "File Browser")) if self.terminal else "File Browser")
        if curr_theme == "File Browser":
            theme_combo.setCurrentIndex(0)
        elif curr_theme in available_themes:
            theme_combo.setCurrentIndex(available_themes.index(curr_theme))
        layout.addWidget(theme_combo)
        
        btn_layout = QHBoxLayout()
        btn_ok = QPushButton("OK")
        btn_cancel = QPushButton("Cancel")
        btn_ok.setFixedWidth(100)
        btn_cancel.setFixedWidth(100)
        btn_ok.clicked.connect(dlg.accept)
        btn_cancel.clicked.connect(dlg.reject)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)
        btn_layout.addWidget(btn_cancel)
        layout.addLayout(btn_layout)
        
        if dlg.exec() == int(QDialog.DialogCode.Accepted):
            idx = combo.currentIndex()
            mode = "tree"
            if idx == 1:
                mode = "list"
            elif idx == 2: 
                mode = "tile"
            
            if chk_apply_all.isChecked():
                confirm = QMessageBox.question(
                    self,
                    "Confirm",
                    "This will reset all directory-specific view settings to this new default. Continue?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )
                if confirm == QMessageBox.StandardButton.Yes:
                    self.view_prefs["default"] = mode
                    self.view_prefs["paths"] = {}
            else:
                paths_dict = self.view_prefs.setdefault("paths", {})
                if isinstance(paths_dict, dict):
                    paths_dict[current_path] = mode
            
            self.settings.setValue("confirm_delete", chk_confirm.isChecked())
            new_lines = spin_lines.value()
            self.settings.setValue("scrollback_lines", new_lines)
            new_rows = spin_rows.value()
            self.settings.setValue("terminal_initial_rows", new_rows)
            chosen_font = fonts[font_combo.currentIndex()]
            chosen_font_size = spin_font_size.value()
            self.settings.setValue("terminal_font_family", chosen_font)
            self.settings.setValue("terminal_font_size", chosen_font_size)
            selected_theme = available_themes[theme_combo.currentIndex()]
            if selected_theme.startswith("File Browser"):
                selected_theme = "File Browser"
            self.settings.setValue("terminal_theme", selected_theme)

            if self.terminal:
                if hasattr(self.terminal, "set_font_family"):
                    self.terminal.set_font_family(chosen_font)
                if hasattr(self.terminal, "set_font_size"):
                    self.terminal.set_font_size(chosen_font_size)
                if hasattr(self.terminal, "set_scrollback_lines"):
                    self.terminal.set_scrollback_lines(new_lines)
                self.apply_terminal_theme()
                if self.terminal.isVisible():
                    self.apply_terminal_height()
            self.settings.setValue("view_prefs", self.view_prefs)
            self.update_view(current_path)

    def get_active_view(self):
        widget = self.tabs.currentWidget()
        if isinstance(widget, BrowserTab):
            return widget.get_active_view()
        return None

    # =========================================================================
    # WAI Assistant Callbacks
    # =========================================================================
    
    def open_wai_dialog(self):
        """Called when the WAI button is clicked in the UI."""
        opened = self.wai_manager.open_dialog()
        if not opened:
            QMessageBox.warning(self, "Connection Error", "WAI Assistant is not connected to the server.\nPlease check your connection and try again.")

    def get_wai_context(self, include_text=True):
        """Callback for WAIAssistantManager to gather current app state."""
        current_path = self.address_bar.text()
        state = {
            "current_path": current_path,
            "files_in_view": [self.model.fileName(self.model.index(current_path, i)) for i in range(self.model.rowCount(self.model.index(current_path)))]
        }
        return state

    def execute_wai_pipeline(self, pipeline):
        """Callback to execute a parsed JSON pipeline from the orchestrator."""
        normalized_pipeline = []
        for cmd in pipeline:
            if "payload" in cmd and "intent" in cmd["payload"]:
                payload = cmd["payload"]
                new_cmd = payload.get("parameters", {}).copy()
                new_cmd["action"] = payload["intent"]
                new_cmd["parameters"] = payload.get("parameters", {})
                normalized_pipeline.append(new_cmd)
            else:
                normalized_pipeline.append(cmd)
        pipeline = normalized_pipeline

        logging.info(f"Executing pipeline with {len(pipeline)} commands")
        
        current_path = self.address_bar.text()

        for cmd in pipeline:
            action = cmd.get("action")
            params = cmd.get("parameters", {})
            
            if action == "feedback":
                if hasattr(self, 'wai_manager') and self.wai_manager.dialog:
                    self.wai_manager.dialog.append_message("System", params.get("question", "Clarification needed."))
            elif action == "navigate":
                path = cmd.get("path") or params.get("path")
                if path:
                    self.navigate_to(path)
            elif action == "go_back":
                self.go_back()
            elif action == "go_forward":
                self.go_forward()
            elif action == "go_up":
                self.go_up()
            elif action == "go_home":
                self.go_home()
            elif action == "toggle_hidden_files":
                show = params.get("show")
                self.toggle_hidden_files(force_state=show)
            elif action == "add_quick_access":
                self.add_to_quick_access()
            elif action == "create_folder":
                name = params.get("name")
                if name:
                    target = os.path.join(current_path, name)
                    try:
                        os.makedirs(target, exist_ok=True)
                    except Exception as e:
                        logging.error(f"WAI create_folder failed: {e}")
            elif action == "create_file":
                name = params.get("name")
                if name:
                    target = os.path.join(current_path, name)
                    try:
                        with open(target, 'w'): 
                            pass
                    except Exception as e:
                        logging.error(f"WAI create_file failed: {e}")
            elif action == "delete_item":
                name = params.get("name")
                if name:
                    target = os.path.join(current_path, name) if not os.path.isabs(name) else name
                    if os.path.exists(target):
                        try:
                            if os.path.isdir(target):
                                shutil.rmtree(target)
                            else:
                                os.remove(target)
                        except Exception as e:
                            logging.error(f"WAI delete_item failed: {e}")
            elif action == "rename_item":
                old_name = params.get("old_name")
                new_name = params.get("new_name")
                if old_name and new_name:
                    src = os.path.join(current_path, old_name) if not os.path.isabs(old_name) else old_name
                    dst = os.path.join(current_path, new_name) if not os.path.isabs(new_name) else os.path.join(os.path.dirname(src), new_name)
                    try:
                        os.rename(src, dst)
                    except Exception as e:
                        logging.error(f"WAI rename_item failed: {e}")
            elif action == "copy_item":
                name = params.get("name")
                if name:
                    target = os.path.join(current_path, name) if not os.path.isabs(name) else name
                    if os.path.exists(target):
                        active_view = self.get_active_view()
                        if active_view and hasattr(active_view, "copy_to_clipboard"):
                            active_view.copy_to_clipboard(target)
            elif action == "paste_item":
                active_view = self.get_active_view()
                if active_view and hasattr(active_view, "paste_files"):
                    active_view.paste_files(current_path)
            elif action == "open_item":
                name = params.get("name")
                if name:
                    target = os.path.join(current_path, name) if not os.path.isabs(name) else name
                    if os.path.exists(target):
                        if os.path.isdir(target):
                            self.navigate_to(target)
                        else:
                            QDesktopServices.openUrl(QUrl.fromLocalFile(target))
            else:
                logging.warning(f"Unknown WAI action: {action}")


    def shutdown(self):
        """Cleans up background threads and timers."""
        if hasattr(self, 'trash_timer') and self.trash_timer:
            try:
                self.trash_timer.stop()
            except Exception:
                pass
        if hasattr(self, 'update_manager') and self.update_manager:
            try:
                self.update_manager.shutdown()
            except Exception:
                pass
        if hasattr(self, 'update_thread') and self.update_thread:
            try:
                if self.update_thread.isRunning():
                    self.update_thread.quit()
                    self.update_thread.wait(300)
            except Exception:
                pass
        if hasattr(self, 'terminal') and self.terminal:
            try:
                term_update_thread = getattr(self.terminal, "update_thread", None)
                if term_update_thread and term_update_thread.isRunning():
                    term_update_thread.quit()
                    term_update_thread.wait(500)
            except Exception:
                pass
        if hasattr(self, 'wai_manager') and self.wai_manager:
            try:
                self.wai_manager.stop()
            except Exception:
                pass
        if hasattr(self, 'shared_model') and self.shared_model:
            try:
                self.shared_model.shutdown()
            except Exception:
                pass
        if hasattr(self, 'model') and self.model:
            try:
                self.model.shutdown()
            except Exception:
                pass
        if hasattr(self, 'usb_detector') and self.usb_detector:
            try:
                self.usb_detector.stop()
            except Exception:
                pass
        if hasattr(self, 'tabs') and self.tabs:
            for i in range(self.tabs.count() - 1):
                widget = self.tabs.widget(i)
                if isinstance(widget, BrowserTab):
                    widget.shutdown()
        if hasattr(self, 'terminal') and self.terminal:
            try:
                self.terminal.cleanup()
            except Exception:
                pass

    def close(self):
        self.shutdown()
        return super().close()

    def closeEvent(self, event):
        self.shutdown()
        
        # Save open tabs
        tab_paths = []
        for i in range(self.tabs.count() - 1): # Exclude the last "+" tab
            widget = self.tabs.widget(i)
            if isinstance(widget, BrowserTab):
                tab_paths.append(widget.get_current_path())
        
        self.settings.setValue("open_tabs", json.dumps(tab_paths))
        self.settings.setValue("active_tab_index", self.tabs.currentIndex())
        
        self.settings.setValue("last_directory", self.address_bar.text())
        if self.terminal:
            self.settings.setValue("terminal_visible", self.terminal.isVisible())
            if hasattr(self.terminal, "theme_name") and self.terminal.theme_name:
                self.settings.setValue("terminal_theme", self.terminal.theme_name)
            if hasattr(self.terminal, "font_family") and self.terminal.font_family:
                self.settings.setValue("terminal_font_family", self.terminal.font_family)
            if hasattr(self.terminal, "font_size") and self.terminal.font_size:
                self.settings.setValue("terminal_font_size", self.terminal.font_size)
            if hasattr(self.terminal, "max_lines") and self.terminal.max_lines:
                self.settings.setValue("scrollback_lines", self.terminal.max_lines)
        self.settings.setValue("window_size", self.size())
        super().closeEvent(event)

    def show_about_dialog(self):
        """Shows the custom About dialog with an integrated in-app updater and Blue theme."""
        dialog = QDialog(self)
        dialog.setWindowTitle(f"About {APP_NAME}")
        dialog.setMinimumWidth(500)
        dialog.setStyleSheet("""
            QDialog { background-color: #0f172a; }
            QLabel  { background: transparent; color: #f3f4f6; }
        """)

        main_layout = QVBoxLayout(dialog)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSizeConstraint(QLayout.SizeConstraint.SetMinAndMaxSize)

        # ── Header ──────────────────────────────────────────────────────────
        header_widget = QWidget()
        header_widget.setStyleSheet(
            "background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0a192f, stop:1 #0f274a);"
        )
        header_layout = QVBoxLayout(header_widget)
        header_layout.setContentsMargins(32, 24, 32, 20)
        header_layout.setSpacing(6)

        icon_path = resource_path(os.path.join("assets", "icons", "icon.png"))
        if os.path.exists(icon_path):
            icon_label = QLabel()
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                icon_label.setPixmap(
                    pixmap.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                )
                icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                header_layout.addWidget(icon_label)

        app_name_lbl = QLabel(APP_NAME.upper())
        app_name_lbl.setStyleSheet(
            "color: #38bdf8; font-size: 15pt; font-weight: 700; letter-spacing: 2px;"
        )
        app_name_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(app_name_lbl)

        ver_lbl = QLabel(f"Version {APP_VERSION}")
        ver_lbl.setStyleSheet("color: #93c5fd; font-size: 10pt; letter-spacing: 1px;")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(ver_lbl)

        main_layout.addWidget(header_widget)

        # Thin divider
        div1 = QFrame()
        div1.setFrameShape(QFrame.Shape.HLine)
        div1.setFixedHeight(1)
        div1.setStyleSheet("background-color: #1e3a8a; border: none;")
        main_layout.addWidget(div1)

        # ── Body ────────────────────────────────────────────────────────────
        body_widget = QWidget()
        body_layout = QVBoxLayout(body_widget)
        body_layout.setContentsMargins(32, 20, 32, 22)
        body_layout.setSpacing(12)

        desc_lbl = QLabel(
            "A fast, customizable file browser designed for power users with integrated terminal, tabbed browsing, and file management."
        )
        desc_lbl.setWordWrap(True)
        desc_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_lbl.setStyleSheet("color: #cbd5e1; font-size: 9.5pt; line-height: 1.4;")
        body_layout.addWidget(desc_lbl)

        meta_lbl = QLabel(
            f"<b>Author:</b> <a href='mailto:steve.rock@wheelhouser.com' style='color:#38bdf8; text-decoration:none;'>steve.rock@wheelhouser.com</a> &nbsp;•&nbsp; <b>Company:</b> {COMPANY_NAME}"
        )
        meta_lbl.setOpenExternalLinks(True)
        meta_lbl.setTextFormat(Qt.TextFormat.RichText)
        meta_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        meta_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        meta_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")
        body_layout.addWidget(meta_lbl)

        website_lbl = QLabel(
            f'Visit <a href="{WEBSITE_URL}" '
            'style="color:#38bdf8; text-decoration:none; font-weight:600;">'
            f"{WEBSITE_URL.replace('https://', '')}</a> to learn more."
        )
        website_lbl.setOpenExternalLinks(True)
        website_lbl.setTextFormat(Qt.TextFormat.RichText)
        website_lbl.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
        )
        website_lbl.setWordWrap(True)
        website_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        website_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")
        body_layout.addWidget(website_lbl)

        # ── In-App Update Section ──────────────────────────────────────────
        update_frame = QFrame()
        update_frame.setStyleSheet("""
            QFrame#updateFrame {
                background-color: rgba(14, 30, 60, 0.85);
                border: 1px solid #2563eb;
                border-radius: 8px;
            }
        """)
        update_frame.setObjectName("updateFrame")
        up_layout = QVBoxLayout(update_frame)
        up_layout.setContentsMargins(20, 16, 20, 16)
        up_layout.setSpacing(10)

        up_title = QLabel("⬆  NEW UPDATE AVAILABLE")
        up_title.setStyleSheet(
            "color: #60a5fa; font-size: 10.5pt; font-weight: 700;"
            " border: none; background: transparent; letter-spacing: 1px;"
        )
        up_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        up_layout.addWidget(up_title)

        up_ver = QLabel("Checking for updates...")
        up_ver.setWordWrap(True)
        up_ver.setStyleSheet(
            "color: #e2e8f0; font-size: 9.5pt; border: none; background: transparent;"
        )
        up_ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        up_layout.addWidget(up_ver)

        # Dedicated styled command snippet widget with copy button
        cmd_box = QFrame()
        cmd_box.setObjectName("cmdBoxFrame")
        cmd_box.setStyleSheet("""
            QFrame#cmdBoxFrame {
                background-color: #0b1329;
                border: 1px solid #1e293b;
                border-radius: 6px;
            }
        """)
        cmd_box_layout = QHBoxLayout(cmd_box)
        cmd_box_layout.setContentsMargins(12, 6, 8, 6)
        cmd_box_layout.setSpacing(8)

        cmd_text = "sudo dnf upgrade file-browser"
        cmd_lbl = QLabel(cmd_text)
        cmd_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cmd_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cmd_lbl.setStyleSheet("""
            QLabel {
                color: #38bdf8;
                font-family: monospace;
                font-size: 9.5pt;
                font-weight: 600;
                border: none;
                background: transparent;
            }
        """)
        cmd_box_layout.addWidget(cmd_lbl, stretch=1)

        copy_btn = QPushButton()
        copy_icon_path = resource_path(os.path.join("assets", "icons", "copy.png"))
        if os.path.exists(copy_icon_path):
            copy_btn.setIcon(QIcon(copy_icon_path))
            copy_btn.setIconSize(QSize(16, 16))
        else:
            copy_btn.setText("📋")
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.setToolTip("Copy command to clipboard")
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(30, 41, 59, 0.8);
                border: 1px solid #334155;
                border-radius: 4px;
                padding: 4px 7px;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #38bdf8;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)

        def copy_cmd():
            QApplication.clipboard().setText(cmd_text)
            QToolTip.showText(QCursor.pos(), "Copied to clipboard!", copy_btn)

        copy_btn.clicked.connect(copy_cmd)
        cmd_box_layout.addWidget(copy_btn)

        cmd_box.setVisible(False)
        up_layout.addWidget(cmd_box)

        # Dedicated repository link label
        repo_lbl = QLabel(
            'Repository: <a href="https://github.com/steve-rock-wheelhouser/fedora-repo" '
            'style="color: #60a5fa; text-decoration: none;">'
            "github.com/steve-rock-wheelhouser/fedora-repo</a>"
        )
        repo_lbl.setOpenExternalLinks(True)
        repo_lbl.setTextFormat(Qt.TextFormat.RichText)
        repo_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        repo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        repo_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 8.5pt; border: none; background: transparent;"
        )
        repo_lbl.setVisible(False)
        up_layout.addWidget(repo_lbl)

        notes_lbl = QLabel()
        notes_lbl.setWordWrap(True)
        notes_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 8.5pt; border: none; background: transparent;"
        )
        notes_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        notes_lbl.setVisible(False)
        up_layout.addWidget(notes_lbl)

        dl_btn = QPushButton("🛍️  Update in Microsoft Store")
        dl_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        dl_btn.setStyleSheet("""
            QPushButton {
                background-color: #0284c7;
                color: white;
                font-weight: 700;
                font-size: 9.5pt;
                border: 1px solid #38bdf8;
                border-radius: 6px;
                padding: 8px 22px;
            }
            QPushButton:hover {
                background-color: #0369a1;
                border-color: #7dd3fc;
            }
            QPushButton:pressed { background-color: #075985; }
        """)
        dl_btn.setVisible(False)
        current_target_url = ["https://wheelhouser.com"]
        dl_btn.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(current_target_url[0]))
        )
        up_layout.addWidget(dl_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        # Status text when checking / up-to-date / error
        status_lbl = QLabel("Checking for updates...")
        status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 9pt; font-style: italic; margin-top: 4px;"
        )
        body_layout.addWidget(status_lbl)

        update_frame.setVisible(False)
        body_layout.addWidget(update_frame)

        # Copyright
        copyright_lbl = QLabel(f"Copyright © 2026 {COMPANY_NAME}. All rights reserved.")
        copyright_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        copyright_lbl.setStyleSheet("color: #64748b; font-size: 8pt; margin-top: 6px;")
        body_layout.addWidget(copyright_lbl)

        # Bottom Buttons
        btn_layout = QHBoxLayout()
        desktop_btn = QPushButton("🖥️  Add Desktop Shortcut")
        desktop_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        desktop_btn.setToolTip("Create a shortcut icon on your Desktop")
        desktop_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #38bdf8;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 16px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #38bdf8;
                color: #7dd3fc;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)
        desktop_btn.clicked.connect(lambda: create_desktop_shortcut(dialog))
        btn_layout.addWidget(desktop_btn)

        btn_layout.addStretch()

        ok_btn = QPushButton("OK")
        ok_btn.setMinimumWidth(100)
        ok_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 7px 20px;
                font-size: 9.5pt;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #475569;
            }
            QPushButton:pressed {
                background-color: #0f172a;
            }
        """)
        ok_btn.clicked.connect(dialog.accept)
        btn_layout.addWidget(ok_btn)
        body_layout.addLayout(btn_layout)

        main_layout.addWidget(body_widget)

        # --- Update Check / Pre-cached Details Logic ---
        def apply_update_ui(latest_version, target_url, release_notes):
            status_lbl.setVisible(False)
            update_frame.setVisible(True)

            show_notes = False
            if sys.platform == "win32":
                cmd_box.setVisible(False)
                repo_lbl.setVisible(False)
                if target_url and "ms-windows-store" in target_url:
                    up_ver.setText(
                        f"Version <b>{latest_version}</b> is available in the Microsoft Store."
                    )
                    dl_btn.setText("🛍️  Update in Microsoft Store")
                else:
                    up_ver.setText(
                        f"Version <b>{latest_version}</b> is available for Windows."
                    )
                    dl_btn.setText("⬇️  Download Windows Update")
                show_notes = bool(release_notes)
            elif sys.platform == "darwin":
                cmd_box.setVisible(False)
                repo_lbl.setVisible(False)
                up_ver.setText(
                    f"Version <b>{latest_version}</b> is available for macOS."
                )
                dl_btn.setText("⬇️  Download macOS Update")
                show_notes = bool(release_notes)
            else:  # Linux
                up_ver.setText(f"Version <b>{latest_version}</b> is available:")
                cmd_box.setVisible(True)
                repo_lbl.setVisible(True)
                dl_btn.setText("📦  View Fedora Repository")
                if not target_url or "ms-windows-store" in target_url:
                    target_url = "https://github.com/steve-rock-wheelhouser/fedora-repo"

                if (
                    release_notes
                    and "sudo dnf" not in release_notes.lower()
                    and "available in fedora" not in release_notes.lower()
                ):
                    show_notes = True
                else:
                    show_notes = False

            current_target_url[0] = target_url or "https://wheelhouser.com"

            if show_notes:
                notes_lbl.setText(release_notes)
                notes_lbl.setVisible(True)
            else:
                notes_lbl.setVisible(False)
            dl_btn.setVisible(True)

        if getattr(self, "_pending_update_version", None):
            apply_update_ui(
                self._pending_update_version,
                self._pending_update_url,
                self._pending_update_notes,
            )
        else:
            version_url = f"https://wheelhouser.com/updates/{APP_NAME.lower().replace(' ', '-')}/version.json"
            self.update_thread = UpdateCheckThread(APP_VERSION, version_url)

            def on_update_available(latest_version, target_url, release_notes):
                self.on_update_found(latest_version, target_url, release_notes)
                apply_update_ui(latest_version, target_url, release_notes)

            def on_up_to_date():
                status_lbl.setText("✅ You are on the latest version.")
                status_lbl.setStyleSheet("color: #94a3b8; font-size: 9pt;")

            def on_update_error(err):
                status_lbl.setText("Could not check for updates.")
                status_lbl.setStyleSheet("color: #ef4444; font-size: 9pt;")
                logging.warning(f"Update check failed: {err}")

            self.update_thread.update_available.connect(on_update_available)
            self.update_thread.up_to_date.connect(on_up_to_date)
            self.update_thread.error.connect(on_update_error)

            def _on_about_update_finished():
                if hasattr(self, "update_thread") and self.update_thread:
                    try:
                        self.update_thread.deleteLater()
                    except RuntimeError:
                        pass
                    self.update_thread = None

            self.update_thread.finished.connect(_on_about_update_finished)
            self.update_thread.start()

        def on_dialog_finished(result):
            t = getattr(self, "update_thread", None)
            if t:
                try:
                    if t.isRunning():
                        try:
                            t.update_available.disconnect()
                        except Exception:
                            pass
                        try:
                            t.up_to_date.disconnect()
                        except Exception:
                            pass
                        try:
                            t.error.disconnect()
                        except Exception:
                            pass
                        t.quit()
                        if not t.wait(300):
                            t.terminate()
                            t.wait(100)
                except (RuntimeError, AttributeError):
                    pass
                finally:
                    self.update_thread = None

        dialog.finished.connect(on_dialog_finished)
        dialog.exec()
        
#===========================================================================================
# --- Application Entry Point ---
#===========================================================================================
if __name__ == "__main__":
    if os.name == 'nt' and hasattr(ctypes, "windll"):
        myappid = f'{APP_AUTHOR}.{APP_NAME}.{APP_VERSION}'
        getattr(ctypes, "windll").shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

    # Configure application metadata before QApplication initialization for Wayland / GNOME desktop tracking
    QCoreApplication.setApplicationName("com.wheelhouser.file-browser")
    QCoreApplication.setOrganizationName("Wheelhouser LLC")
    QCoreApplication.setOrganizationDomain("wheelhouser.com")
    QGuiApplication.setDesktopFileName("com.wheelhouser.file-browser")

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    app_icon = QIcon()
    ico_path = resource_path(os.path.join("assets", "icons", "icon.ico"))
    png_path = resource_path(os.path.join("assets", "icons", "icon.png"))
    svg_path = resource_path(os.path.join("assets", "icons", "icon.svg"))
    if os.path.exists(ico_path):
        app_icon.addFile(ico_path)
    if os.path.exists(png_path):
        app_icon.addFile(png_path)
    if os.path.exists(svg_path):
        app_icon.addFile(svg_path)
    if not app_icon.isNull():
        app.setWindowIcon(app_icon)
    
    # Force a dark theme palette to ensure consistent look across platforms
    app.styleHints().setColorScheme(Qt.ColorScheme.Dark)
    dark_palette = QPalette()
    dark_palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(0, 0, 0))
    dark_palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
    dark_palette.setColor(QPalette.ColorRole.BrightText, QColor(255, 0, 0))
    dark_palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.HighlightedText, QColor(0, 0, 0))
    app.setPalette(dark_palette)
    
    window = FileBrowserApp()
    window.show()
    sys.exit(app.exec())
    
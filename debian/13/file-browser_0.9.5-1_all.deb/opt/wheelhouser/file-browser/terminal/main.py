"""Compatibility shim exposing TerminalWidget and main entrypoint for embedded terminal integration."""
import sys
import os

_dir = os.path.dirname(os.path.abspath(__file__))
_src = os.path.join(_dir, "src")
for _p in (_dir, _src):
    if _p not in sys.path:
        sys.path.insert(0, _p)

TerminalWidget = None
TerminalMainWindow = None
main = None

_src_main = os.path.join(_src, "main.py")
if os.path.exists(_src_main):
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("terminal.src.main", _src_main)
        if spec and spec.loader:
            _mod = importlib.util.module_from_spec(spec)
            sys.modules["terminal.src.main"] = _mod
            spec.loader.exec_module(_mod)
            TerminalWidget = getattr(_mod, "TerminalWidget", None)
            TerminalMainWindow = getattr(_mod, "TerminalMainWindow", None)
            main = getattr(_mod, "main", None)
    except Exception:
        pass

if TerminalWidget is None:
    try:
        from .src.main import TerminalWidget, TerminalMainWindow, main
    except (ImportError, Exception):
        try:
            from src.main import TerminalWidget, TerminalMainWindow, main  # type: ignore
        except (ImportError, Exception):
            pass

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]

if __name__ == "__main__":
    if callable(main):
        main()


import sys
import os

package_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(package_dir, "src")
for p in (package_dir, src_dir):
    if p not in sys.path:
        sys.path.insert(0, p)

# Expose the main widget for easy import
# Usage: from terminal import TerminalWidget
TerminalWidget = None
TerminalMainWindow = None
main = None

_src_main = os.path.join(src_dir, "main.py")
if os.path.exists(_src_main):
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("terminal.src.main", _src_main)
        if spec and spec.loader:
            _mod = importlib.util.module_from_spec(spec)
            sys.modules["terminal.src.main"] = _mod
            spec.loader.exec_module(_mod)
            TerminalWidget = getattr(_mod, "TerminalWidget", None)
            TerminalMainWindow = getattr(_mod, "TerminalMainWindow", None)
            main = getattr(_mod, "main", None)
    except Exception:
        pass

if TerminalWidget is None:
    try:
        from .src.main import TerminalWidget, TerminalMainWindow, main
    except ImportError:
        try:
            from src.main import TerminalWidget, TerminalMainWindow, main  # type: ignore
        except (ImportError, Exception):
            pass

__all__ = ["TerminalWidget", "TerminalMainWindow", "main"]


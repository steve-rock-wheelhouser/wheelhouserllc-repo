#!/usr/bin/env bash
#
# Wheelhouser Git Tools - undo.sh
# Version: 1.9.1
#
# Safely undos the most recent Git commit (git reset --soft HEAD~1),
# keeping all file modifications staged and preserved in the working tree.
#
# Version Change Log:
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1, update macOS DMG package manifests, and increment version to trigger clean multi-platform build.
# 1.9.0 - Add resilient Developer ID fallback and graceful preflight checks for missing notary-profile on macOS build nodes, resolving notarization and keychain exit code 69 on Intel and headless nodes.
# 1.8.1 - Fix PowerShell parsing error in push.ps1 by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION across push/pull/sync/undo.
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull & push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
# 1.7.0 - Enhance scaffold skeleton with asset subdirectories, macOS/Windows build dirs, build-linux desktop launcher placement, and full GPLv3 license.
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs.
# 1.3.0 - Released as GPLv3. Added dynamic version resolution from main.py.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.1 - Initial release of safe commit rollback utility.
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.9.1}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Safe Commit Undo (v${VERSION})

Usage: undo [options]
       ./undo.sh [options]

Options:
  --hard                Dangerous: Discard all file modifications (git reset --hard HEAD~1).
  -y, --yes             Skip confirmation prompt when using --hard.
  -h, --help            Show this help documentation.
  -v, --version         Show script version.

Description:
  By default, 'undo' runs a soft rollback (git reset --soft HEAD~1).
  All modified, added, and deleted files from the undone commit remain
  safely preserved in your staging area. Nothing is deleted.

Examples:
  undo                  # Safely rollback last commit, keep changes staged
  undo --hard -y        # Completely discard last commit and its file changes
EOF
}

HARD_RESET=false
CONFIRM_YES=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --hard)
            HARD_RESET=true
            shift
            ;;
        -y|--yes)
            CONFIRM_YES=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--version)
            echo "undo (Wheelhouser Git Tools) v${VERSION}"
            exit 0
            ;;
        *)
            echo "❌ Error: Unknown argument '$1'" >&2
            echo "Run 'undo --help' for usage." >&2
            exit 1
            ;;
    esac
done

# Ensure inside a git repository
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "❌ Error: Current directory is not inside a Git repository." >&2
    exit 1
fi

# Verify there is at least one parent commit to undo to
if ! git rev-parse HEAD~1 >/dev/null 2>&1; then
    echo "❌ Error: Repository is on the initial commit. There is no parent commit to undo to." >&2
    exit 1
fi

COMMIT_HASH=$(git rev-parse --short HEAD)
COMMIT_MSG=$(git log -1 --pretty=format:"%s")

echo "=================================================================="
echo "⏪ Undoing Commit: ${COMMIT_HASH} (\"${COMMIT_MSG}\")"
echo "=================================================================="

if [ "$HARD_RESET" = "true" ]; then
    if [ "$CONFIRM_YES" != "true" ]; then
        echo "⚠️ WARNING: You specified --hard. This will PERMANENTLY delete all uncommitted"
        echo "   changes and revert the working tree to the previous commit."
        read -r -p "Are you sure you want to proceed? [y/N]: " RESPONSE
        if [[ ! "$RESPONSE" =~ ^[Yy]$ ]]; then
            echo "Aborted. No changes were made."
            exit 0
        fi
    fi
    git reset --hard HEAD~1
    echo "=================================================================="
    echo "✅ [SUCCESS] Reverted to previous commit (changes discarded)."
    echo "=================================================================="
else
    git reset --soft HEAD~1
    echo "=================================================================="
    echo "✅ [SUCCESS] Successfully rolled back commit ${COMMIT_HASH}!"
    echo "📁 All file modifications remain safely staged in your working tree."
    echo "   • Run 'git status' to inspect modified files."
    echo "   • Run 'push \"new commit message\"' when ready to re-commit."
    echo "=================================================================="
fi

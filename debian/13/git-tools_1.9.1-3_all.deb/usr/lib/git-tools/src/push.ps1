<#
.SYNOPSIS
    Wheelhouser Git Tools - push.ps1
.DESCRIPTION
    Stages local changes, performs pre-commit security audits, commits with message,
    and pushes the current branch to GitHub with automatic upstream tracking.
.PARAMETER Message
    Commit message to apply.
.PARAMETER Force
    Force push to remote branch (git push --force).
.PARAMETER ForceWithLease
    Safer force push verifying remote ref has not diverged.
.PARAMETER AllowSensitive
    Bypass pre-commit security audit for sensitive file extensions.
.PARAMETER Help
    Displays command reference.
.PARAMETER Version
    Displays version information.
#>

# Version Change Log:
# 1.8.1 - Fix PowerShell parsing error by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION.
# 1.6.0 - Ignore intentional file deletions during pre-commit sensitive scan, preventing false-positive blocks.
# 1.5.0 - Implement git-tools init, merge, and canonical project scaffolding.
# 1.3.0 - Released as GPLv3. Added ESC keypress abort, direct /dev/tty prompt, and expanded credential rules.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.0 - Initial centralized release for cross-platform Git automation suite with
#         dynamic Git resolution, pre-commit secret scanning, and force-with-lease.

[CmdletBinding()]
param(
    [Parameter(Position = 0, Mandatory = $false)]
    [string]$Message,

    [switch]$Force,
    [switch]$ForceWithLease,
    [switch]$AllowSensitive,
    [switch]$Help,
    [Alias("Version")][switch]$ShowVersion
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainPy = Join-Path $ScriptDir "main.py"
$VERSION = "1.9.1"
if (Test-Path $MainPy) {
    $match = Select-String -Path $MainPy -Pattern '^VERSION\s*=\s*["'']([^"'']+)["'']'
    if ($match -and $match.Matches.Groups.Count -gt 1) {
        $VERSION = $match.Matches.Groups[1].Value
    }
}
$APP_VERSION = $VERSION

if ($Help) {
    Write-Host "Wheelhouser Git Tools - Push Automation (v$APP_VERSION)" -ForegroundColor Cyan
    Write-Host "`nUsage: push [options] [commit message]" -ForegroundColor Yellow
    Write-Host "       push.ps1 [options] [commit message]`n" -ForegroundColor Yellow
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -Message <msg>      Specify commit message directly."
    Write-Host "  -Force              Force push to remote branch (git push --force)."
    Write-Host "  -ForceWithLease     Safer force push verifying remote ref has not diverged."
    Write-Host "  -AllowSensitive     Bypass pre-commit security audit for sensitive file extensions."
    Write-Host "  -Help               Show this help documentation."
    Write-Host "  -Version            Show script version."
    exit 0
}

if ($ShowVersion) {
    Write-Host "Wheelhouser Git Tools push.ps1 v$APP_VERSION" -ForegroundColor Cyan
    exit 0
}

# Resolve Git executable dynamically
$GitCmd = $null
$foundGit = Get-Command git.exe -ErrorAction SilentlyContinue
if ($foundGit) {
    $GitCmd = $foundGit.Source
} else {
    $fallbackPaths = @(
        "C:\Program Files\Git\cmd\git.exe",
        "C:\Program Files (x86)\Git\cmd\git.exe",
        "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe"
    )
    foreach ($path in $fallbackPaths) {
        if (Test-Path $path) {
            $GitCmd = $path
            break
        }
    }
}

if (-not $GitCmd) {
    Write-Error "Git executable not found. Please install Git or ensure git.exe is in your PATH."
    exit 1
}

# Check if inside git working tree
& $GitCmd rev-parse --is-inside-work-tree 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Error "Not a git repository (or any parent directory up to mount point). Please run push inside a git repository."
    exit 1
}

# Pre-commit security check: detect accidental secret / credential files
if (-not $AllowSensitive) {
    $statusLines = & $GitCmd status --porcelain 2>$null
    $sensitiveMatches = @()
    if ($statusLines) {
        foreach ($line in $statusLines) {
            if ($line.Length -lt 4) { continue }
            $status = $line.Substring(0, 2)
            $file = $line.Substring(3).Trim()
            if ($file -match ' -> ') {
                $file = ($file -split ' -> ')[-1].Trim()
            }
            $file = $file.Trim('"')
            # If file was deleted and is absent on disk, it is a removal, not an accidental leak
            if ($status -match 'D' -and -not (Test-Path $file)) {
                continue
            }
            if ($file -match '\.(key|pem|p12|pfx|pkcs12|kdbx|asc)$' -or $file -match 'id_(rsa|dsa|ecdsa|ed25519)(\.pub)?$' -or $file -match '^.*\.env(\..+)?$' -or $file -match '[-_](secret|credentials)\.') {
                $sensitiveMatches += $file
            }
        }
    }

    if ($sensitiveMatches.Count -gt 0) {
        Write-Host "ERROR: Potential sensitive / secret file(s) detected in repository:" -ForegroundColor Red
        foreach ($s in $sensitiveMatches) {
            Write-Host "  $s" -ForegroundColor Red
        }
        Write-Host "Aborting commit to prevent accidental leak. Add to .gitignore or use -AllowSensitive to override." -ForegroundColor Yellow
        exit 1
    }
}

function Read-CommitMessageWithEscape {
    param([string]$Prompt = "Commit Message: ")
    Write-Host -NoNewline $Prompt
    
    if (-not [Console]::IsInputRedirected) {
        $chars = [System.Collections.Generic.List[char]]::new()
        while ($true) {
            $key = [Console]::ReadKey($true)
            if ($key.Key -eq [ConsoleKey]::Escape) {
                Write-Host "`nCommit cancelled by user (ESC pressed)." -ForegroundColor Yellow
                exit 130
            }
            elseif ($key.Key -eq [ConsoleKey]::Enter) {
                Write-Host ""
                return (-join $chars)
            }
            elseif ($key.Key -eq [ConsoleKey]::Backspace) {
                if ($chars.Count -gt 0) {
                    $chars.RemoveAt($chars.Count - 1)
                    Write-Host -NoNewline "`b `b"
                }
            }
            else {
                $chars.Add($key.KeyChar)
                Write-Host -NoNewline $key.KeyChar
            }
        }
    } else {
        return (Read-Host)
    }
}

# Prompt for commit message if empty
if (-not $Message -or $Message.Trim().Length -eq 0) {
    $Message = Read-CommitMessageWithEscape "Commit Message: "
}

if (-not $Message -or $Message.Trim().Length -eq 0) {
    Write-Error "Commit message cannot be empty. Aborting push."
    exit 1
}

# Display status summary
Write-Host "==> Repository status:" -ForegroundColor Cyan
& $GitCmd status -sb

# Stage all changes
Write-Host "==> Staging all changes..." -ForegroundColor Cyan
& $GitCmd add -A

# Check for staged changes
& $GitCmd diff --cached --quiet
$hasNoStagedDiff = ($LASTEXITCODE -eq 0)

$branch = (& $GitCmd rev-parse --abbrev-ref HEAD).Trim()

if ($hasNoStagedDiff) {
    # Check if there are local commits ahead of upstream
    & $GitCmd rev-parse --verify --quiet "@{upstream}" 2>$null | Out-Null
    $hasUpstream = ($LASTEXITCODE -eq 0)

    $commitsAhead = 0
    if ($hasUpstream) {
        $aheadCount = (& $GitCmd rev-list --count "@{upstream}..HEAD" 2>$null)
        if ($aheadCount) {
            $commitsAhead = [int]$aheadCount.Trim()
        }
    }

    if ($commitsAhead -gt 0) {
        Write-Host "No newly staged changes, but $commitsAhead local commit(s) are ahead of upstream. Pushing existing commits..." -ForegroundColor Yellow
    } else {
        Write-Host "No staged changes to commit and local branch is up-to-date with remote." -ForegroundColor Green
        exit 0
    }
} else {
    Write-Host "==> Committing changes: $Message" -ForegroundColor Cyan
    & $GitCmd commit -m "$Message"
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Commit failed. Aborting push."
        exit 1
    }
}

Write-Host "==> Pushing branch '$branch' to remote..." -ForegroundColor Cyan
if ($Force -and $ForceWithLease) {
    Write-Error "Specify either -Force or -ForceWithLease, not both."
    exit 1
} elseif ($Force) {
    Write-Host "Force push enabled (-Force)" -ForegroundColor Yellow
    & $GitCmd push --force origin $branch
} elseif ($ForceWithLease) {
    Write-Host "Safer force push enabled (-ForceWithLease)" -ForegroundColor Yellow
    & $GitCmd push --force-with-lease origin $branch
} else {
    & $GitCmd rev-parse --abbrev-ref --symbolic-full-name "${branch}@{upstream}" 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        & $GitCmd push origin $branch
    } else {
        Write-Host "==> Setting upstream for new branch '$branch'..." -ForegroundColor Cyan
        & $GitCmd push -u origin $branch
    }
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Push failed. Please check remote repository permissions and branch state."
    exit 1
}

Write-Host "Push completed successfully." -ForegroundColor Green
#!/usr/bin/env bash
#
# Wheelhouser Git Tools - push.sh
# Version: 1.9.1
#
# Stages local changes, performs pre-commit security audits, commits with message,
# and pushes the current branch to GitHub with automatic upstream tracking.
#
# Version Change Log:
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1, update macOS DMG package manifests, and increment version to trigger clean multi-platform build.
# 1.9.0 - Add resilient Developer ID fallback and graceful preflight checks for missing notary-profile on macOS build nodes, resolving notarization and keychain exit code 69 on Intel and headless nodes.
# 1.8.1 - Fix PowerShell parsing error in push.ps1 by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION across push/pull/sync/undo.
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull & push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
# 1.7.0 - Enhance scaffold skeleton with asset subdirectories, macOS/Windows build dirs, build-linux desktop launcher placement, and full GPLv3 license.
# 1.6.0 - Ignore intentional file deletions during pre-commit sensitive scan, preventing false-positive blocks.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs.
# 1.3.0 - Released as GPLv3. Added ESC keypress abort, direct /dev/tty prompt, and expanded credential rules.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.0 - Initial centralized release for cross-platform Git automation suite with
#         pre-commit secret scanning, branch auto-tracking, and force-with-lease.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.9.1}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Push Automation (v${VERSION})

Usage: push [options] [commit message]
       ./push.sh [options] [commit message]

Options:
  -m, --message <msg>   Specify commit message directly.
  -f, --force           Force push to remote branch (git push --force).
  --force-with-lease    Safer force push verifying remote ref has not diverged.
  --allow-sensitive     Bypass pre-commit security audit for sensitive file extensions.
  -h, --help            Show this help documentation.
  -v, --version         Show script version.

Examples:
  push "feat(cli): add installation shim"
  push -m "fix(auth): update token expiration"
  push --force-with-lease "refactor: simplify push logic"
EOF
}

FORCE_PUSH=false
FORCE_WITH_LEASE=false
ALLOW_SENSITIVE=false
COMMIT_MSG=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--version)
            echo "Wheelhouser Git Tools push.sh v${VERSION}"
            exit 0
            ;;
        -f|--force)
            FORCE_PUSH=true
            shift
            ;;
        --force-with-lease)
            FORCE_WITH_LEASE=true
            shift
            ;;
        --allow-sensitive)
            ALLOW_SENSITIVE=true
            shift
            ;;
        -m|--message)
            if [[ $# -lt 2 ]]; then
                echo "❌ Error: --message requires a commit message argument." >&2
                exit 1
            fi
            COMMIT_MSG="$2"
            shift 2
            ;;
        *)
            if [[ -n "${COMMIT_MSG}" ]]; then
                COMMIT_MSG+=" "
            fi
            COMMIT_MSG+="$1"
            shift
            ;;
    esac
done

# Ensure git is available
if ! command -v git >/dev/null 2>&1; then
    echo "❌ Error: Git is not installed or not available in PATH." >&2
    exit 1
fi

# Ensure caller is inside a git working tree
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "❌ Error: Not a git repository (or any parent directory up to mount point)." >&2
    echo "Please navigate into a git repository before running push." >&2
    exit 1
fi

# Pre-commit security check: detect accidental secret / credential files
if [[ "${ALLOW_SENSITIVE}" != true ]]; then
    SENSITIVE_FILES=""
    while IFS= read -r line || [[ -n "$line" ]]; do
        [[ -z "$line" ]] && continue
        status="${line:0:2}"
        filepath="${line:3}"
        # Handle rename 'orig -> new'
        if [[ "$filepath" == *" -> "* ]]; then
            filepath="${filepath##* -> }"
        fi
        filepath="${filepath%\"}"
        filepath="${filepath#\"}"
        # If file was deleted and is absent on disk, it is a removal, not an accidental leak
        if [[ "$status" =~ D ]] && [[ ! -e "$filepath" ]]; then
            continue
        fi
        if echo "$filepath" | grep -qE '\.(key|pem|p12|pfx|pkcs12|kdbx|asc)$|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?$|^.*\.env(\..+)?$|[-_](secret|credentials)\.'; then
            if [[ -z "$SENSITIVE_FILES" ]]; then
                SENSITIVE_FILES="$filepath"
            else
                SENSITIVE_FILES="${SENSITIVE_FILES}"$'\n'"$filepath"
            fi
        fi
    done < <(git status --porcelain 2>/dev/null || true)

    if [[ -n "${SENSITIVE_FILES}" ]]; then
        echo "❌ ERROR: Potential sensitive / secret file(s) detected in repository:" >&2
        echo "${SENSITIVE_FILES}" >&2
        echo "Aborting commit to prevent accidental leak. Add to .gitignore or use --allow-sensitive to override." >&2
        exit 1
    fi
fi

# Function to read commit message with ESC key cancellation support
prompt_commit_message() {
    local prompt="${1:-Commit Message: }"
    local py_msg
    py_msg=$(python3 -c "
import sys, os, termios, tty, select

try:
    tty_out = open('/dev/tty', 'w')
except Exception:
    tty_out = sys.stderr

prompt = sys.argv[1] if len(sys.argv) > 1 else 'Commit Message: '
tty_out.write(prompt)
tty_out.flush()

if not sys.stdin.isatty():
    line = sys.stdin.readline()
    if line.startswith('\x1b') and len(line) <= 2:
        sys.exit(130)
    sys.stdout.write(line.strip())
    sys.exit(0)

fd = sys.stdin.fileno()
old = termios.tcgetattr(fd)
chars = []
try:
    tty.setcbreak(fd)
    while True:
        ch = sys.stdin.read(1)
        if ch == '\x1b':
            r, _, _ = select.select([sys.stdin], [], [], 0.05)
            if r:
                sys.stdin.read(2)
                continue
            tty_out.write('\n🚫 Commit cancelled by user (ESC pressed).\n')
            tty_out.flush()
            sys.exit(130)
        elif ch in ('\r', '\n'):
            tty_out.write('\n')
            tty_out.flush()
            sys.stdout.write(''.join(chars))
            sys.exit(0)
        elif ch in ('\x7f', '\x08'):
            if chars:
                chars.pop()
                tty_out.write('\b \b')
                tty_out.flush()
        elif ch in ('\x03', '\x04'):
            tty_out.write('\n🚫 Commit cancelled by user.\n')
            tty_out.flush()
            sys.exit(130)
        else:
            chars.append(ch)
            tty_out.write(ch)
            tty_out.flush()
finally:
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
" "$prompt")
    local code=$?
    if [[ $code -eq 130 ]]; then
        return 130
    fi
    echo "$py_msg"
    return 0
}

# If no commit message provided, prompt interactively
if [[ -z "${COMMIT_MSG}" ]]; then
    if [[ -t 0 ]]; then
        COMMIT_MSG=$(prompt_commit_message "Commit Message: ")
        PROMPT_STATUS=$?
        if [[ ${PROMPT_STATUS} -eq 130 ]]; then
            exit 130
        elif [[ ${PROMPT_STATUS} -ne 0 ]]; then
            exit ${PROMPT_STATUS}
        fi
    else
        echo "❌ Error: Commit message is required in non-interactive mode. Use -m \"message\"." >&2
        exit 1
    fi
fi

if [[ -z "${COMMIT_MSG}" || "${COMMIT_MSG// /}" == "" ]]; then
    echo "❌ Error: Commit message cannot be empty. Aborting push." >&2
    exit 1
fi

# Display current status summary
echo "==> Repository status:"
git status -sb || true

# Stage all changes
echo "==> Staging all changes..."
git add -A

# Determine if there are staged changes
STAGED_DIFF=0
if git diff --cached --quiet; then
    STAGED_DIFF=1
fi

if [[ "${STAGED_DIFF}" -eq 1 ]]; then
    # Check if there are local commits ahead of upstream
    HAS_UPSTREAM=0
    if git rev-parse --verify --quiet "@{upstream}" >/dev/null 2>&1; then
        HAS_UPSTREAM=1
    fi

    COMMITS_AHEAD=0
    if [[ "${HAS_UPSTREAM}" -eq 1 ]]; then
        COMMITS_AHEAD=$(git rev-list --count @{upstream}..HEAD 2>/dev/null || echo 0)
    fi

    if [[ "${COMMITS_AHEAD}" -gt 0 ]]; then
        echo "ℹ️ No newly staged changes, but ${COMMITS_AHEAD} local commit(s) are ahead of upstream. Pushing existing commits..."
    else
        echo "✅ No staged changes to commit and local branch is up-to-date with remote."
        exit 0
    fi
else
    echo "==> Committing changes: ${COMMIT_MSG}"
    git commit -m "${COMMIT_MSG}"
fi

# Determine current branch safely
BRANCH="$(git symbolic-ref --short HEAD 2>/dev/null || git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")"

# Verify branch is not detached
if [[ "${BRANCH}" == "HEAD" ]]; then
    echo "⚠️ Warning: You are in 'detached HEAD' state." >&2
    if [[ "${FORCE_PUSH}" != true ]]; then
        echo "Push aborted. Create a branch or use --force to override." >&2
        exit 1
    fi
fi

echo "==> Pushing branch '${BRANCH}' to remote..."
if [[ "${FORCE_PUSH}" == true && "${FORCE_WITH_LEASE}" == true ]]; then
    echo "❌ Error: Specify either --force or --force-with-lease, not both." >&2
    exit 1
elif [[ "${FORCE_PUSH}" == true ]]; then
    echo "⚠️ Force push enabled (--force)"
    git push --force origin "${BRANCH}"
elif [[ "${FORCE_WITH_LEASE}" == true ]]; then
    echo "⚠️ Safer force push enabled (--force-with-lease)"
    git push --force-with-lease origin "${BRANCH}"
else
    # Check if remote branch / upstream exists
    if git rev-parse --abbrev-ref --symbolic-full-name "${BRANCH}@{upstream}" >/dev/null 2>&1; then
        git push origin "${BRANCH}"
    else
        echo "==> Upstream tracking branch not set. Setting upstream to origin/${BRANCH}..."
        git push -u origin "${BRANCH}"
    fi
fi

echo "✅ Push completed successfully."
#!/usr/bin/env python3
"""Wheelhouser Git Tools - Main Entry Point.

Primary application entry point providing:
    python3 src/main.py [command]
    python3 -m src.main [command]

Version Change Log:
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1, update macOS DMG package manifests, and increment version to trigger clean multi-platform build.
# 1.9.0 - Add resilient Developer ID fallback and graceful preflight checks for missing notary-profile on macOS build nodes, resolving notarization and keychain exit code 69 on Intel and headless nodes.
# 1.8.1 - Fix PowerShell parsing error in push.ps1 by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION across push/pull/sync/undo.
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull and push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
# 1.7.0 - Enhance scaffold skeleton with asset subdirectories, macOS/Windows build dirs, build-linux desktop launcher placement, and full GPLv3 license.
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs
# 1.3.0 - Robust projects root fallback (prefers ~/Projects, falls back to ~/ on failure across all platforms), and dynamic release increments.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation, and rename desktop launcher terminal to git-tools.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Eliminate duplicate desktop launcher in applications and dock favorites.
# 1.1.2 - Standardize desktop launcher, icon packaging, and AppStream metadata modeled after auto-updates.
# 1.1.1 - Add Linux desktop launcher builder (build_desktop.sh), master build runner (build.sh), and sandbox isolation.
# 1.1.0 - Add standardized src/main.py entry point and synchronize versioning across suite.
"""

from __future__ import annotations

import sys
from pathlib import Path

VERSION = "1.9.1"
APP_VERSION = "1.9.1"
__version__ = "1.9.1"

# Ensure src directory or git_tools parent is in sys.path
bin_dir = Path(__file__).resolve().parent
candidate_dirs = [
    bin_dir,
    bin_dir / "src",
    bin_dir.parent / "lib" / "git-tools" / "src",
    Path("/usr/lib/git-tools/src"),
    Path("/usr/local/lib/git-tools/src"),
    Path.home() / ".local/lib/git-tools/src",
    Path.home() / "Projects/git-tools/src",
]

for d in candidate_dirs:
    if d.is_dir() and (d / "git_tools").is_dir():
        if str(d) not in sys.path:
            sys.path.insert(0, str(d))
        break

from git_tools.cli import main

if __name__ == "__main__":
    sys.exit(main())

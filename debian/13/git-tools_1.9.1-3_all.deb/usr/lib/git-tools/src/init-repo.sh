#!/usr/bin/env bash
# ==============================================================================
# src/init-repo.sh - Wheelhouser Git Tools Repository Initializer
# Version: 1.9.1
#
# Version Change Log:
# 1.9.1 - Enforce strict Authenticode signature verification in build_msix.ps1, update macOS DMG package manifests, and increment version to trigger clean multi-platform build.
# 1.9.0 - Add resilient Developer ID fallback and graceful preflight checks for missing notary-profile on macOS build nodes, resolving notarization and keychain exit code 69 on Intel and headless nodes.
# 1.8.1 - Fix PowerShell parsing error in push.ps1 by quoting '@{upstream}..HEAD' and resolve SwitchParameter name collision with $VERSION across push/pull/sync/undo.
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull & push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
# 1.7.0 - Enhance scaffold skeleton with asset subdirectories, macOS/Windows build dirs, build-linux desktop launcher placement, and full GPLv3 license.
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Initial implementation of repository initialization shim.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="$(command -v python3 || command -v python || true)"

if [ -z "${PYTHON_BIN}" ]; then
    echo "❌ Error: Python 3 is required to run git-tools init." >&2
    exit 1
fi

exec "${PYTHON_BIN}" "${SCRIPT_DIR}/main.py" init "$@"

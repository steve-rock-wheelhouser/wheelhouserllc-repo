#!/usr/bin/env bash
#
# Wheelhouser Git Tools - pull.sh
# Version: 1.8.0
#
# Pulls latest changes from remote repository, with safe stash handling,
# fast-forward priority, optional rebase, and force-reset capabilities.
#
# Version Change Log:
# 1.8.0 - Implement git-tools fleet-sync (safe bi-directional pull & push), fleet-push, and clone for single repos and wildcard namespaces (steve-rock-wheelhouser/*).
# 1.7.0 - Enhance scaffold skeleton with asset subdirectories, macOS/Windows build dirs, build-linux desktop launcher placement, and full GPLv3 license.
# 1.6.0 - Implement git-tools purge-history for permanent Git object scrubbing, resolve pre-commit deletion false-positives, and optimize packfile garbage collection.
# 1.5.0 - Implement git-tools init, merge (with conflict simulation and branch pruning), and canonical project scaffolding.
# 1.4.1 - Enforce strict Authenticode code signing in build_msix.ps1 without silent fallback, and resolve BUG-20260930_204016.
# 1.4.0 - Add cross-platform remote build orchestration (git-tools build), pre-build test gate enforcement, and initial epic architectures.
# 1.3.1 - Resolve bugs.
# 1.3.0 - Released as GPLv3. Added projects root fallback and dynamic version inheritance.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.0 - Initial centralized release for cross-platform Git automation suite with
#         safe autostash, fast-forward priority, and rebase support.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=""
if [ -f "${SCRIPT_DIR}/main.py" ]; then
    VERSION=$(grep -E "^VERSION\s*=" "${SCRIPT_DIR}/main.py" | head -n 1 | awk -F"['\"]" '{print $2}')
fi
VERSION="${VERSION:-1.8.0}"
APP_VERSION="${VERSION}"

show_help() {
    cat <<EOF
Wheelhouser Git Tools - Pull Automation (v${VERSION})

Usage: pull [options]
       ./pull.sh [options]

Options:
  -f, --force         Force sync: overwrite local changes and reset to origin/<branch>.
  -r, --rebase        Pull using rebase instead of merge (git pull --rebase).
  -a, --autostash     Automatically stash and pop uncommitted changes without prompting.
  -h, --help          Show this help documentation.
  -v, --version       Show script version.

Examples:
  pull
  pull --autostash
  pull --rebase
  pull --force
EOF
}

FORCE_SYNC=false
USE_REBASE=false
AUTO_STASH=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            show_help
            exit 0
            ;;
        -v|--version)
            echo "Wheelhouser Git Tools pull.sh v${VERSION}"
            exit 0
            ;;
        -f|--force)
            FORCE_SYNC=true
            shift
            ;;
        -r|--rebase)
            USE_REBASE=true
            shift
            ;;
        -a|--autostash)
            AUTO_STASH=true
            shift
            ;;
        *)
            echo "❌ Unknown option: $1" >&2
            show_help >&2
            exit 1
            ;;
    esac
done

# Ensure git is available
if ! command -v git >/dev/null 2>&1; then
    echo "❌ Error: Git is not installed or not available in PATH." >&2
    exit 1
fi

# Ensure caller is inside a git working tree
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "❌ Error: Not a git repository (or any parent directory up to mount point)." >&2
    echo "Please navigate into a git repository before running pull." >&2
    exit 1
fi

BRANCH="$(git symbolic-ref --short HEAD 2>/dev/null || git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")"
echo "==> Current branch: '${BRANCH}'"

# Fetch latest changes from origin
echo "==> Fetching latest changes from remote..."
git fetch --prune origin || echo "⚠️ Warning: git fetch origin returned non-zero; continuing with pull..."

# Check if remote branch exists
REMOTE="origin"
REMOTE_EXISTS=0
if git rev-parse --verify --quiet "refs/remotes/${REMOTE}/${BRANCH}" >/dev/null 2>&1; then
    REMOTE_EXISTS=1
fi

if [[ "${FORCE_SYNC}" == true ]]; then
    if [[ "${REMOTE_EXISTS}" -eq 0 ]]; then
        echo "❌ Error: Remote branch 'refs/remotes/${REMOTE}/${BRANCH}' does not exist. Cannot force reset." >&2
        exit 1
    fi
    echo "⚠️ Force mode enabled. Resetting local checkout to match ${REMOTE}/${BRANCH}..."
    git reset --hard "${REMOTE}/${BRANCH}"
    git clean -fd
    echo "✅ Force sync complete. Working tree reset to ${REMOTE}/${BRANCH}."
    exit 0
fi

STASHED=false
# Check for uncommitted changes
if [[ -n "$(git status --porcelain 2>/dev/null)" ]]; then
    echo "⚠️ Notice: You have uncommitted changes in your working tree."
    SHOULD_STASH=false
    if [[ "${AUTO_STASH}" == true ]]; then
        SHOULD_STASH=true
    elif [[ -t 0 ]]; then
        read -r -p "Do you want to stash local changes before pulling? (y/n): " RESPONSE
        if [[ "${RESPONSE}" =~ ^[Yy]$ ]]; then
            SHOULD_STASH=true
        fi
    else
        echo "ℹ️ Non-interactive mode without --autostash: proceeding without stashing."
    fi

    if [[ "${SHOULD_STASH}" == true ]]; then
        echo "==> Stashing local changes..."
        if ! git stash save "git-tools auto-stash $(date +'%Y-%m-%d %H:%M:%S')"; then
            echo "❌ Error: Failed to stash changes. Aborting pull." >&2
            exit 1
        fi
        STASHED=true
        echo "✅ Changes stashed."
    fi
fi

# Perform pull
echo "==> Pulling updates for '${BRANCH}' from ${REMOTE}..."
if [[ "${USE_REBASE}" == true ]]; then
    if ! git pull --rebase "${REMOTE}" "${BRANCH}"; then
        echo "❌ Error: Pull with rebase failed. Please resolve conflicts manually." >&2
        exit 1
    fi
else
    # Try fast-forward only first
    if git pull --ff-only "${REMOTE}" "${BRANCH}" 2>/dev/null; then
        echo "✅ Successfully fast-forwarded to latest commit."
    else
        # Fall back to standard pull
        if ! git pull "${REMOTE}" "${BRANCH}"; then
            echo "❌ Error: Pull failed. You may have conflicting changes with remote." >&2
            exit 1
        fi
    fi
fi

# Restore stash if we stashed earlier
if [[ "${STASHED}" == true ]]; then
    echo "==> Restoring stashed changes..."
    if ! git stash pop; then
        echo "⚠️ Warning: Failed to cleanly pop stashed changes. Please resolve stash conflict manually with 'git stash list'." >&2
    else
        echo "✅ Stashed changes restored."
    fi
fi

echo "✅ Pull completed successfully."
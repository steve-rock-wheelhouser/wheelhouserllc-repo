@echo off
rem Wheelhouser Git Tools - push.cmd wrapper for Windows Command Prompt
rem Version: 1.0.0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0push.ps1" %*
exit /b %ERRORLEVEL%

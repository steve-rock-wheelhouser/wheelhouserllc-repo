#!/usr/bin/env bash
# ==============================================================================
# build-remote.sh - Wheelhouser Remote Build & Packaging Trigger
# Wheelhouser LLC (c) 2026
#
# Connects the local project to Wheelhouser Orchestra to trigger
# multi-platform compilation across active build nodes.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Ensure git-tools is accessible
if command -v git-tools >/dev/null 2>&1; then
    exec git-tools build "$@"
elif [ -f "${SCRIPT_DIR}/main.py" ]; then
    exec python3 "${SCRIPT_DIR}/main.py" build "$@"
else
    echo "❌ Error: git-tools entry point not found." >&2
    exit 1
fi

@echo off
rem Wheelhouser Git Tools - sync.cmd wrapper for PowerShell sync.ps1
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0sync.ps1" %*
if %ERRORLEVEL% EQU 0 goto :eof
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0sync.ps1" %*

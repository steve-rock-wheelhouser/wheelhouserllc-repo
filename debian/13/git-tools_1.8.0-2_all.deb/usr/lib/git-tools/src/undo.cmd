@echo off
rem Wheelhouser Git Tools - undo.cmd wrapper for PowerShell undo.ps1
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0undo.ps1" %*
if %ERRORLEVEL% EQU 0 goto :eof
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0undo.ps1" %*

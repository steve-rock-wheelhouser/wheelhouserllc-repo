# ==============================================================================
# src/init-repo.ps1 - Wheelhouser Git Tools Repository Initializer
# Version: 1.5.0
#
# Version Change Log:
# 1.5.0 - Initial implementation of repository initialization shim.
# ==============================================================================

$VERSION = "1.8.0"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
python "$scriptDir\main.py" init $args
exit $LASTEXITCODE

<#
.SYNOPSIS
    Wheelhouser Git Tools - pull.ps1
.DESCRIPTION
    Pulls latest changes from remote repository, with safe stash handling,
    fast-forward priority, optional rebase, and force-reset capabilities.
.PARAMETER Force
    Force sync: overwrite local changes and reset to origin/<branch>.
.PARAMETER Rebase
    Pull using rebase instead of merge (git pull --rebase).
.PARAMETER AutoStash
    Automatically stash and pop uncommitted changes without prompting.
.PARAMETER Help
    Displays command reference.
.PARAMETER Version
    Displays version information.
#>

# Version Change Log:
# 1.3.0 - Released as GPLv3. Added projects root fallback and dynamic version inheritance.
# 1.2.0 - Add persistent projects root configuration, interactive arrow-key project navigation.
# 1.1.4 - Dynamic build version inheritance from src/main.py, manpage addition, and pre-build quality validation.
# 1.1.3 - Synchronize release version across suite.
# 1.1.2 - Synchronize release version across suite.
# 1.1.1 - Synchronize release version across suite.
# 1.1.0 - Synchronize version and add integration with standardized suite entry points.
# 1.0.0 - Initial centralized release for cross-platform Git automation suite with
#         dynamic Git resolution, safe autostash, fast-forward priority, and rebase support.

[CmdletBinding()]
param(
    [switch]$Force,
    [switch]$Rebase,
    [switch]$AutoStash,
    [switch]$Help,
    [switch]$Version
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainPy = Join-Path $ScriptDir "main.py"
$VERSION = "1.8.0"
if (Test-Path $MainPy) {
    $match = Select-String -Path $MainPy -Pattern '^VERSION\s*=\s*["'']([^"'']+)["'']'
    if ($match -and $match.Matches.Groups.Count -gt 1) {
        $VERSION = $match.Matches.Groups[1].Value
    }
}
$APP_VERSION = $VERSION

if ($Help) {
    Write-Host "Wheelhouser Git Tools - Pull Automation (v$APP_VERSION)" -ForegroundColor Cyan
    Write-Host "`nUsage: pull [options]" -ForegroundColor Yellow
    Write-Host "       pull.ps1 [options]`n" -ForegroundColor Yellow
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -Force       Force sync: overwrite local changes and reset to origin/<branch>."
    Write-Host "  -Rebase      Pull using rebase instead of merge (git pull --rebase)."
    Write-Host "  -AutoStash   Automatically stash and pop uncommitted changes without prompting."
    Write-Host "  -Help        Show this help documentation."
    Write-Host "  -Version     Show script version."
    exit 0
}

if ($Version) {
    Write-Host "Wheelhouser Git Tools pull.ps1 v$APP_VERSION" -ForegroundColor Cyan
    exit 0
}

# Resolve Git executable dynamically
$GitCmd = $null
$foundGit = Get-Command git.exe -ErrorAction SilentlyContinue
if ($foundGit) {
    $GitCmd = $foundGit.Source
} else {
    $fallbackPaths = @(
        "C:\Program Files\Git\cmd\git.exe",
        "C:\Program Files (x86)\Git\cmd\git.exe",
        "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe"
    )
    foreach ($path in $fallbackPaths) {
        if (Test-Path $path) {
            $GitCmd = $path
            break
        }
    }
}

if (-not $GitCmd) {
    Write-Error "Git executable not found. Please install Git or ensure git.exe is in your PATH."
    exit 1
}

# Check if inside git working tree
& $GitCmd rev-parse --is-inside-work-tree 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Error "Not a git repository (or any parent directory up to mount point). Please run pull inside a git repository."
    exit 1
}

$branch = (& $GitCmd rev-parse --abbrev-ref HEAD).Trim()
Write-Host "==> Current branch: '$branch'" -ForegroundColor Cyan

# Fetch latest changes
Write-Host "==> Fetching latest changes from remote..." -ForegroundColor Cyan
& $GitCmd fetch --prune origin

$remoteBranch = "origin/$branch"
& $GitCmd rev-parse --verify --quiet "refs/remotes/$remoteBranch" 2>$null | Out-Null
$remoteExists = ($LASTEXITCODE -eq 0)

if ($Force) {
    if (-not $remoteExists) {
        Write-Error "Remote branch 'refs/remotes/$remoteBranch' does not exist. Cannot force reset."
        exit 1
    }
    Write-Host "Force mode enabled. Resetting local checkout to match $remoteBranch..." -ForegroundColor Yellow
    & $GitCmd reset --hard $remoteBranch
    & $GitCmd clean -fd
    Write-Host "Force sync complete. Working tree reset to $remoteBranch." -ForegroundColor Green
    exit 0
}

$stashed = $false
$status = & $GitCmd status --porcelain 2>$null
if ($status -and $status.Length -gt 0) {
    Write-Host "Notice: You have uncommitted changes in your working tree." -ForegroundColor Yellow
    $shouldStash = $false

    if ($AutoStash) {
        $shouldStash = $true
    } else {
        $resp = Read-Host "Do you want to stash local changes before pulling? (y/n)"
        if ($resp -eq 'y' -or $resp -eq 'Y') {
            $shouldStash = $true
        }
    }

    if ($shouldStash) {
        Write-Host "==> Stashing local changes..." -ForegroundColor Cyan
        & $GitCmd stash save "git-tools auto-stash $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Failed to stash changes. Aborting pull."
            exit 1
        }
        $stashed = $true
        Write-Host "Changes stashed." -ForegroundColor Green
    }
}

Write-Host "==> Pulling updates for '$branch' from origin..." -ForegroundColor Cyan
if ($Rebase) {
    & $GitCmd pull --rebase origin $branch
} else {
    # Attempt fast-forward first
    & $GitCmd pull --ff-only origin $branch 2>$null
    if ($LASTEXITCODE -ne 0) {
        & $GitCmd pull origin $branch
    }
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Pull failed. You may have conflicting changes with remote."
    exit 1
}

if ($stashed) {
    Write-Host "==> Restoring stashed changes..." -ForegroundColor Cyan
    & $GitCmd stash pop
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "Failed to cleanly pop stashed changes. Please resolve stash conflicts manually with 'git stash list'."
    } else {
        Write-Host "Stashed changes restored." -ForegroundColor Green
    }
}

Write-Host "Pull completed successfully." -ForegroundColor Green
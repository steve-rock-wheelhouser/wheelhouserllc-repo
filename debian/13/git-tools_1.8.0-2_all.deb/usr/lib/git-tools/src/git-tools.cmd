@echo off
rem Wheelhouser Git Tools - git-tools.cmd wrapper for Windows
rem Version: 1.0.0
where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python "%~dp0git-tools" %*
) else (
    where py >nul 2>nul
    if %ERRORLEVEL% equ 0 (
        py "%~dp0git-tools" %*
    ) else (
        echo Error: Python 3 is required to run git-tools CLI. Please install Python.
        exit /b 1
    )
)
exit /b %ERRORLEVEL%

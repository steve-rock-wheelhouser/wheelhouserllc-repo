"""Wheelhouser Git Tools - Module Entry Point.

Enables invocation via:
    python3 -m git_tools [command]
"""

from __future__ import annotations

import sys
from .cli import main

if __name__ == "__main__":
    sys.exit(main())

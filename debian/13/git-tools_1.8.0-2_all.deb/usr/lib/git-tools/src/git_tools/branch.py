"""Wheelhouser Git Tools - Branch Hygiene & Maintenance.

Provides utilities for safely pruning local branches merged into main/master.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import List, Tuple

PROTECTED_BRANCH_PATTERNS = [
    re.compile(r"^main$", re.IGNORECASE),
    re.compile(r"^master$", re.IGNORECASE),
    re.compile(r"^develop?$", re.IGNORECASE),
    re.compile(r"^release.*", re.IGNORECASE),
    re.compile(r"^production$", re.IGNORECASE),
    re.compile(r"^stable$", re.IGNORECASE),
]


def is_protected_branch(branch: str) -> bool:
    """Check if a branch name is considered protected."""
    clean = branch.strip().lstrip("* ").strip()
    return any(p.match(clean) for p in PROTECTED_BRANCH_PATTERNS)


def get_default_branch(repo_path: Path) -> str:
    """Detect default branch (main, master, or HEAD)."""
    res = subprocess.run(
        ["git", "-C", str(repo_path), "symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
        capture_output=True,
        text=True,
        check=False,
    )
    if res.returncode == 0 and res.stdout.strip():
        # E.g. origin/main -> main
        return res.stdout.strip().split("/")[-1]

    # Check local branches
    local_branches = subprocess.run(
        ["git", "-C", str(repo_path), "branch", "--list"],
        capture_output=True,
        text=True,
        check=False,
    ).stdout.splitlines()

    for b in local_branches:
        clean = b.strip().lstrip("* ").strip()
        if clean in ("main", "master"):
            return clean

    return "main"


def prune_merged_branches(
    repo_path: Path,
    dry_run: bool = False,
) -> Tuple[List[str], List[str]]:
    """Prune local branches that have been merged into the default branch.

    Returns (pruned_branches, errors).
    """
    pruned: List[str] = []
    errors: List[str] = []

    # 1. Fetch with prune
    subprocess.run(
        ["git", "-C", str(repo_path), "fetch", "--prune"],
        capture_output=True,
        text=True,
        check=False,
    )

    # 2. Identify default and current branch
    default_branch = get_default_branch(repo_path)
    current_branch = subprocess.run(
        ["git", "-C", str(repo_path), "symbolic-ref", "--short", "HEAD"],
        capture_output=True,
        text=True,
        check=False,
    ).stdout.strip()

    # 3. Find merged branches
    res = subprocess.run(
        ["git", "-C", str(repo_path), "branch", "--merged", default_branch],
        capture_output=True,
        text=True,
        check=False,
    )
    if res.returncode != 0:
        return [], [f"Failed to query merged branches: {res.stderr.strip()}"]

    candidates = [
        line.strip().lstrip("* ").strip()
        for line in res.stdout.splitlines()
        if line.strip()
    ]

    for b in candidates:
        if is_protected_branch(b) or b == current_branch or b == default_branch:
            continue

        if dry_run:
            pruned.append(b)
        else:
            del_res = subprocess.run(
                ["git", "-C", str(repo_path), "branch", "-d", b],
                capture_output=True,
                text=True,
                check=False,
            )
            if del_res.returncode == 0:
                pruned.append(b)
            else:
                errors.append(f"Failed to delete '{b}': {del_res.stderr.strip()}")

    return pruned, errors


from dataclasses import dataclass


@dataclass
class BranchInfo:
    name: str
    is_current: bool
    is_remote: bool
    upstream: str
    ahead: int
    behind: int
    last_commit_hash: str
    last_commit_msg: str
    last_commit_date: str


def list_repository_branches(repo_path: Path) -> List[BranchInfo]:
    """Gather all local and remote branches with commit metrics."""
    if not (repo_path / ".git").exists():
        return []

    branches: List[BranchInfo] = []

    # 1. Fetch local branches
    res_local = subprocess.run(
        [
            "git",
            "-C",
            str(repo_path),
            "for-each-ref",
            "--format=%(refname:short)%09%(HEAD)%09%(upstream:short)%09%(objectname:short)%09%(committerdate:relative)%09%(symref)%09%(contents:subject)",
            "refs/heads",
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    for line in res_local.stdout.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t", 6)
        if len(parts) >= 6:
            name = parts[0].strip()
            is_current = (parts[1].strip() == "*")
            upstream = parts[2].strip()
            commit_hash = parts[3].strip()
            commit_date = parts[4].strip()
            symref = parts[5].strip()
            commit_msg = parts[6].strip() if len(parts) > 6 else ""

            if symref:
                continue

            ahead = 0
            behind = 0
            if upstream:
                rev_res = subprocess.run(
                    ["git", "-C", str(repo_path), "rev-list", "--left-right", "--count", f"{upstream}...{name}"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if rev_res.returncode == 0:
                    counts = rev_res.stdout.strip().split()
                    if len(counts) == 2:
                        try:
                            behind = int(counts[0])
                            ahead = int(counts[1])
                        except ValueError:
                            pass

            branches.append(
                BranchInfo(
                    name=name,
                    is_current=is_current,
                    is_remote=False,
                    upstream=upstream,
                    ahead=ahead,
                    behind=behind,
                    last_commit_hash=commit_hash,
                    last_commit_msg=commit_msg,
                    last_commit_date=commit_date,
                )
            )

    # 2. Fetch remote branches (excluding symbolic refs like origin/HEAD)
    res_remote = subprocess.run(
        [
            "git",
            "-C",
            str(repo_path),
            "for-each-ref",
            "--format=%(refname:short)%09%(HEAD)%09%(upstream:short)%09%(objectname:short)%09%(committerdate:relative)%09%(symref)%09%(contents:subject)",
            "refs/remotes",
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    for line in res_remote.stdout.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t", 6)
        if len(parts) >= 6:
            name = parts[0].strip()
            commit_hash = parts[3].strip()
            commit_date = parts[4].strip()
            symref = parts[5].strip()
            commit_msg = parts[6].strip() if len(parts) > 6 else ""

            if symref or name.endswith("/HEAD") or not "/" in name:
                continue

            branches.append(
                BranchInfo(
                    name=name,
                    is_current=False,
                    is_remote=True,
                    upstream="",
                    ahead=0,
                    behind=0,
                    last_commit_hash=commit_hash,
                    last_commit_msg=commit_msg,
                    last_commit_date=commit_date,
                )
            )

    return branches


def render_branches_dashboard(branches: List[BranchInfo], repo_name: str = "") -> str:
    """Format branch list into a colorized, clean status dashboard."""
    BOLD = "\033[1m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    lines: List[str] = []
    title = f"BRANCHES: {repo_name}" if repo_name else "REPOSITORY BRANCHES"
    lines.append(f"{BOLD}{CYAN}=============================================================================================={RESET}")
    lines.append(f"{BOLD}           {title}{RESET}")
    lines.append(f"{BOLD}{CYAN}=============================================================================================={RESET}")
    lines.append(f"{BOLD}{'NUM':<4} {'BRANCH NAME':<24} {'TYPE':<9} {'UPSTREAM':<18} {'STATUS':<15} {'LAST COMMIT':<24}{RESET}")
    lines.append(f"{CYAN}{'-' * 94}{RESET}")

    if not branches:
        lines.append(f"  {DIM}(No branches found){RESET}")
    else:
        for idx, b in enumerate(branches, start=1):
            marker = f"{GREEN}►{RESET}" if b.is_current else " "
            b_type = f"{DIM}[remote]{RESET}" if b.is_remote else f"{CYAN}[local]{RESET}"
            name_colored = f"{BOLD}{GREEN}{b.name}{RESET}" if b.is_current else b.name

            # Status column
            if b.is_remote:
                status_str = f"{DIM}--{RESET}"
            elif b.upstream:
                parts = []
                if b.ahead > 0:
                    parts.append(f"↑{b.ahead}")
                if b.behind > 0:
                    parts.append(f"↓{b.behind}")
                status_str = f"{YELLOW}{' '.join(parts)}{RESET}" if parts else f"{GREEN}✓ In Sync{RESET}"
            else:
                status_str = f"{DIM}(no upstream){RESET}"

            upstream_str = b.upstream if b.upstream else f"{DIM}--{RESET}"
            commit_preview = f"{b.last_commit_hash} ({b.last_commit_date})"
            if b.last_commit_msg:
                msg_snippet = b.last_commit_msg[:24] + "..." if len(b.last_commit_msg) > 24 else b.last_commit_msg
                commit_preview = f"{b.last_commit_hash} {msg_snippet}"

            lines.append(f"{idx:2d}. {marker} {name_colored:<33} {b_type:<18} {upstream_str:<18} {status_str:<24} {commit_preview}")

    lines.append(f"{BOLD}{CYAN}=============================================================================================={RESET}")
    return "\n".join(lines)


def switch_repository_branch(repo_path: Path, branch_name: str, create: bool = False) -> Tuple[bool, str]:
    """Switch or create a branch in target repository."""
    cmd = ["git", "-C", str(repo_path), "switch"]
    if create:
        cmd.append("-c")
    cmd.append(branch_name)

    res = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if res.returncode == 0:
        return True, res.stdout.strip() or f"Switched to branch '{branch_name}'"

    # Fallback to git checkout
    fb_cmd = ["git", "-C", str(repo_path), "checkout"]
    if create:
        fb_cmd.append("-b")
    fb_cmd.append(branch_name)
    fb_res = subprocess.run(fb_cmd, capture_output=True, text=True, check=False)
    if fb_res.returncode == 0:
        return True, fb_res.stdout.strip() or f"Switched to branch '{branch_name}'"

    return False, res.stderr.strip() or fb_res.stderr.strip()

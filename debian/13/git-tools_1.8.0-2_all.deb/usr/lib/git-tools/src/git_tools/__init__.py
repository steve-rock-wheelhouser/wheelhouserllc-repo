"""Wheelhouser Git Tools Package.

Cross-platform Git automation suite and centralized repository management.
"""

from .version import __version__

__all__ = ["__version__"]

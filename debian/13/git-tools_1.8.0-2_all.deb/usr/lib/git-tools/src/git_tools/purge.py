"""Wheelhouser Git Tools - Repository History Purger.

Enables developers and administrators to permanently scrub sensitive files, credentials,
or bloated legacy binary directories from the entire Git commit history across all branches.
Reclaims repository packfile disk space and prepares clean trees for remote force pushing.

Version Change Log:
# 1.6.0 - Initial implementation of git-tools purge-history engine with automatic garbage collection.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple


def get_repo_git_dir(repo_path: Path) -> Optional[Path]:
    """Find the .git directory for a repository."""
    try:
        res = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode == 0:
            git_dir = Path(res.stdout.strip())
            if not git_dir.is_absolute():
                git_dir = (repo_path / git_dir).resolve()
            return git_dir
    except Exception:
        pass
    return None


def get_repo_objects_size(repo_path: Path) -> int:
    """Calculate the total size in bytes of the Git objects database."""
    git_dir = get_repo_git_dir(repo_path)
    if not git_dir or not git_dir.is_dir():
        return 0

    total_bytes = 0
    objects_dir = git_dir / "objects"
    if objects_dir.is_dir():
        for root, _, files in os.walk(objects_dir):
            for f in files:
                try:
                    total_bytes += (Path(root) / f).stat().st_size
                except OSError:
                    pass
    return total_bytes


def format_bytes(size_bytes: int) -> str:
    """Format bytes into a human-readable string (KB, MB, GB)."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def find_matching_commits(repo_path: Path, target_path: str) -> List[Tuple[str, str]]:
    """Find all historical commits that modified or introduced the target path."""
    clean_target = target_path.strip().strip("/")
    try:
        res = subprocess.run(
            ["git", "-C", str(repo_path), "log", "--all", "--oneline", "--", clean_target],
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode != 0 or not res.stdout.strip():
            return []

        commits: List[Tuple[str, str]] = []
        for line in res.stdout.splitlines():
            line = line.strip()
            if line:
                parts = line.split(" ", 1)
                sha = parts[0]
                msg = parts[1] if len(parts) > 1 else ""
                commits.append((sha, msg))
        return commits
    except Exception:
        return []


def purge_path(
    repo_path: Path,
    target_path: str,
    push_remote: bool = False,
    remote_name: str = "origin",
) -> Tuple[bool, str, int, int]:
    """Permanently excise target_path from Git commit history across all branches and tags.

    Parameters
    ----------
    repo_path : Path
        Directory of the Git repository.
    target_path : str
        Relative path of the file or directory to purge (e.g. 'Executables' or 'secret.key').
    push_remote : bool
        If True, executes git push --force --all and --tags to remote origin upon successful purge.
    remote_name : str
        Remote name to push to if push_remote is True (default 'origin').

    Returns
    -------
    Tuple[bool, str, int, int]
        (success, message, size_before_bytes, size_after_bytes)
    """
    clean_target = target_path.strip().strip("/")
    if not clean_target:
        return False, "Target path cannot be empty.", 0, 0

    git_dir = get_repo_git_dir(repo_path)
    if not git_dir:
        return False, f"Directory '{repo_path}' is not a valid Git repository.", 0, 0

    # Ensure working tree is clean or abort
    status_res = subprocess.run(
        ["git", "-C", str(repo_path), "status", "--porcelain"],
        capture_output=True,
        text=True,
        check=False,
    )
    if status_res.returncode != 0:
        return False, f"Failed to check git status in '{repo_path}'.", 0, 0

    # Check if untracked or unstaged files are present
    uncommitted = [
        line for line in status_res.stdout.splitlines()
        if line.strip() and not line.strip().endswith(clean_target)
    ]
    if uncommitted:
        return (
            False,
            "Working tree has uncommitted modifications. Please commit or stash changes before purging history.",
            0,
            0,
        )

    commits = find_matching_commits(repo_path, clean_target)
    if not commits:
        return False, f"No commits in history touched '{clean_target}'. Nothing to purge.", 0, 0

    size_before = get_repo_objects_size(repo_path)

    # Check if git-filter-repo is available
    has_filter_repo = shutil.which("git-filter-repo") is not None

    if has_filter_repo:
        # Use git-filter-repo
        cmd = ["git-filter-repo", "--path", clean_target, "--invert-paths", "--force"]
        res = subprocess.run(cmd, cwd=repo_path, capture_output=True, text=True, check=False)
        if res.returncode != 0:
            return False, f"git-filter-repo failed: {res.stderr or res.stdout}", size_before, size_before
    else:
        # Universal fallback: git filter-branch
        filter_index_cmd = f"git rm --cached --ignore-unmatch -r -- '{clean_target}'"
        cmd = [
            "git",
            "filter-branch",
            "--force",
            "--index-filter",
            filter_index_cmd,
            "--prune-empty",
            "--tag-name-filter",
            "cat",
            "--",
            "--all",
        ]
        res = subprocess.run(cmd, cwd=repo_path, capture_output=True, text=True, check=False)
        if res.returncode != 0:
            return False, f"git filter-branch failed: {res.stderr or res.stdout}", size_before, size_before

    # Clean up backup refs left by filter-branch
    backup_refs_dir = git_dir / "refs" / "original"
    if backup_refs_dir.exists():
        try:
            shutil.rmtree(backup_refs_dir)
        except Exception:
            pass

    # Expire reflog and prune all dangling objects
    subprocess.run(
        ["git", "-C", str(repo_path), "reflog", "expire", "--expire=now", "--all"],
        capture_output=True,
        check=False,
    )
    subprocess.run(
        ["git", "-C", str(repo_path), "gc", "--prune=now", "--aggressive"],
        capture_output=True,
        check=False,
    )

    size_after = get_repo_objects_size(repo_path)
    reclaimed = max(0, size_before - size_after)

    msg_lines = [
        f"Successfully purged '{clean_target}' across all historical commits!",
        f"Commits rewritten: {len(commits)}",
        f"Git objects size before: {format_bytes(size_before)}",
        f"Git objects size after:  {format_bytes(size_after)}",
        f"Disk space reclaimed:    {format_bytes(reclaimed)}",
    ]

    # Handle push to remote if requested
    if push_remote:
        push_all = subprocess.run(
            ["git", "-C", str(repo_path), "push", remote_name, "--force", "--all"],
            capture_output=True,
            text=True,
            check=False,
        )
        push_tags = subprocess.run(
            ["git", "-C", str(repo_path), "push", remote_name, "--force", "--tags"],
            capture_output=True,
            text=True,
            check=False,
        )
        if push_all.returncode == 0 and push_tags.returncode == 0:
            msg_lines.append(f"Remote '{remote_name}' successfully updated with force push.")
        else:
            err = push_all.stderr or push_tags.stderr
            msg_lines.append(f"Warning: Remote force push encountered errors:\n{err}")

    return True, "\n".join(msg_lines), size_before, size_after

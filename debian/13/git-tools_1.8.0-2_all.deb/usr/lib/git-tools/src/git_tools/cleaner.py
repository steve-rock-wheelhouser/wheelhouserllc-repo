"""Wheelhouser Git Tools - Open-Source Repository Cleaner & Auditor.

Enables developers to scan existing repositories for legacy, repo-local push and pull
scripts (push.sh, pull.sh, push.ps1, pull.ps1) and cleanly remove them so the repositories
can be safely published as open-source without proprietary workflow clutter.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

LEGACY_FILES = [
    "push.sh",
    "pull.sh",
    "sync.sh",
    "undo.sh",
    "push.ps1",
    "pull.ps1",
    "sync.ps1",
    "undo.ps1",
    "push.cmd",
    "pull.cmd",
    "sync.cmd",
    "undo.cmd",
]


def audit_repository(repo_path: Path) -> List[str]:
    """Check a specific directory for legacy push/pull scripts.

    Returns a list of legacy filenames found in the repository root.
    """
    found: List[str] = []
    for filename in LEGACY_FILES:
        target = repo_path / filename
        if target.is_file():
            found.append(filename)
    return found


def scan_workspace(workspace_path: Path) -> Dict[Path, List[str]]:
    """Scan a parent directory containing multiple repositories.

    Returns a dictionary mapping repository paths to the list of legacy files found.
    """
    results: Dict[Path, List[str]] = {}
    if not workspace_path.is_dir():
        return results

    # Check if the path itself is a git repository
    if (workspace_path / ".git").is_dir():
        found = audit_repository(workspace_path)
        if found:
            results[workspace_path] = found
        return results

    # Scan child directories
    for child in sorted(workspace_path.iterdir()):
        if child.is_dir() and not child.name.startswith("."):
            found = audit_repository(child)
            if found:
                results[child] = found

    return results


def clean_repository(
    repo_path: Path,
    dry_run: bool = False,
    stage_git: bool = True,
) -> Tuple[List[str], List[str]]:
    """Remove legacy push and pull scripts from a repository.

    Parameters
    ----------
    repo_path : Path
        Directory of the repository to clean.
    dry_run : bool
        If True, only report which files would be removed without deleting them.
    stage_git : bool
        If True and repository is a Git working tree, stage deletions via 'git rm' or 'git add -u'.

    Returns
    -------
    Tuple[List[str], List[str]]
        (removed_files, errors)
    """
    found = audit_repository(repo_path)
    removed: List[str] = []
    errors: List[str] = []

    is_git = (repo_path / ".git").is_dir()

    for filename in found:
        file_path = repo_path / filename
        if dry_run:
            removed.append(filename)
            continue

        try:
            if is_git and stage_git:
                # Attempt git rm
                res = subprocess.run(
                    ["git", "rm", "-f", filename],
                    cwd=repo_path,
                    capture_output=True,
                    text=True,
                )
                if res.returncode == 0:
                    removed.append(filename)
                    continue

            # Fallback to standard filesystem unlink
            if file_path.exists():
                file_path.unlink()
                removed.append(filename)

                if is_git and stage_git:
                    # Stage the deletion if git was present
                    subprocess.run(
                        ["git", "add", "-u", filename],
                        cwd=repo_path,
                        capture_output=True,
                    )
        except Exception as e:
            errors.append(f"{filename}: {str(e)}")

    return removed, errors

"""Wheelhouser Git Tools - Build Orchestration Dispatcher.

Integrates client repositories with Wheelhouser Orchestra to trigger
cross-platform compilation, enforce pre-build test gates, and report build status.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import List, Optional

from .config import get_projects_root
from .security import scan_working_tree


def find_orchestra_dir() -> Optional[Path]:
    """Locate the Wheelhouser Orchestra directory."""
    projects_root = get_projects_root()
    candidates = [
        projects_root / "orchestra",
        Path("/home/user/Projects/orchestra"),
        Path.home() / "Projects" / "orchestra",
        Path(__file__).resolve().parent.parent.parent.parent / "orchestra",
    ]
    for cand in candidates:
        if cand.is_dir() and (cand / "build_all_linux.sh").is_file():
            return cand.resolve()
    return None


def detect_target_project(explicit_project: Optional[str] = None) -> Optional[str]:
    """Detect target project name from explicit argument or current repository directory."""
    if explicit_project:
        return explicit_project.strip()

    # Attempt to resolve from current git repo
    try:
        res = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode == 0 and res.stdout.strip():
            repo_path = Path(res.stdout.strip())
            return repo_path.name
    except Exception:
        pass

    # Fallback to current working directory name
    return Path.cwd().name


def run_build(
    project: Optional[str] = None,
    build_only: bool = True,
    platform_filter: str = "all",
    force: bool = False,
    dry_run: bool = False,
    limit: Optional[str] = None,
    skip_tests: bool = False,
) -> int:
    """Execute cross-platform build orchestration via Wheelhouser Orchestra."""
    target_project = detect_target_project(project)
    if not target_project:
        print("❌ Error: Could not determine target project name. Specify project name.", file=sys.stderr)
        return 1

    print(f"==================================================================")
    print(f"       WHEELHOUSER BUILD ORCHESTRATION: {target_project}")
    print(f"==================================================================")

    projects_root = get_projects_root()
    project_dir = projects_root / target_project
    if not project_dir.is_dir():
        # Check current directory
        if Path.cwd().name == target_project:
            project_dir = Path.cwd()
        else:
            print(f"❌ Error: Project directory not found at {project_dir}", file=sys.stderr)
            return 1

    # --- Gate 1: Pre-Build Test Gate (AGENTS.md Rule 9) ---
    if not skip_tests:
        test_runner = project_dir / "tests" / "run_tests.sh"
        if test_runner.is_file():
            print(f"==> [Gate 1] Running pre-build automated test suite ({test_runner.name})...")
            test_res = subprocess.run(
                ["bash", str(test_runner)],
                cwd=str(project_dir),
                check=False,
            )
            if test_res.returncode != 0:
                print(f"❌ Pre-Build Test Gate FAILED (Exit Code: {test_res.returncode})", file=sys.stderr)
                print("   Build aborted per AGENTS.md Rule 9.", file=sys.stderr)
                return 1
            print("  ✔ Pre-Build Test Gate: PASSED")
        else:
            print(f"ℹ️ Notice: No tests/run_tests.sh found in '{target_project}'. Proceeding with build.")

    # --- Gate 2: Pre-Flight Security & Secret Audit ---
    print(f"==> [Gate 2] Running pre-flight security scan on '{target_project}'...")
    found_secrets = scan_working_tree(project_dir)
    if found_secrets:
        print(f"❌ Security Scan FAILED: {len(found_secrets)} sensitive file(s) detected!", file=sys.stderr)
        print("   Remove sensitive files before building.", file=sys.stderr)
        return 1
    print("  ✔ Security Pre-Flight Scan: PASSED (0 secrets found)")

    # --- Gate 3: Locate Orchestra Orchestrator ---
    orchestra_dir = find_orchestra_dir()
    if not orchestra_dir:
        print("❌ Error: Wheelhouser Orchestra not found in workspace or system.", file=sys.stderr)
        print("   Ensure 'orchestra' is cloned into ~/Projects/orchestra.", file=sys.stderr)
        return 1

    orchestrator_script = orchestra_dir / "build_all_linux.sh"
    cmd = [str(orchestrator_script), "--project", target_project]

    if build_only:
        cmd.append("--build-only")
    if platform_filter != "all":
        cmd.extend(["--platform", platform_filter])
    if force:
        cmd.append("--force")
    if dry_run:
        cmd.append("--check")
    if limit:
        cmd.extend(["--limit", limit])

    print(f"==> Dispatching to Orchestra: {' '.join(cmd)}")
    print("------------------------------------------------------------------")
    sys.stdout.flush()

    res = subprocess.run(cmd, cwd=str(orchestra_dir), check=False)
    if res.returncode == 0:
        print("------------------------------------------------------------------")
        print(f"✅ Build Orchestration Completed Successfully for '{target_project}'!")
        return 0
    else:
        print("------------------------------------------------------------------", file=sys.stderr)
        print(f"❌ Build Orchestration Exited with Code {res.returncode}", file=sys.stderr)
        return res.returncode

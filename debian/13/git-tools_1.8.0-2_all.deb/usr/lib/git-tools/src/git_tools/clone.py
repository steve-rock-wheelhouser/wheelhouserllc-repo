"""Wheelhouser Git Tools - Clone Automation Module.

Provides single-repository and bulk-namespace cloning capabilities:
- Shorthand target resolution (e.g. 'steve-rock-wheelhouser/terminal' -> git@github.com:steve-rock-wheelhouser/terminal.git)
- Wildcard namespace cloning (e.g. 'steve-rock-wheelhouser/*' -> discovers and clones all repositories)
- Full Git URL cloning (SSH, HTTPS)
- Safe idempotency: skips existing repositories or optionally updates them with pull
- Supports --dry-run, --dest, --sync-existing, --https, and GitHub API authentication tokens
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set, Tuple

from .config import get_projects_root


@dataclass
class CloneResult:
    name: str
    url: str
    dest: Path
    status: str  # 'cloned', 'skipped', 'synced', 'failed', 'dry-run'
    message: str


def resolve_github_token(explicit_token: Optional[str] = None) -> Optional[str]:
    """Retrieve GitHub token from argument, environment variables, or config file."""
    if explicit_token:
        return explicit_token.strip()

    for env_var in ("GITHUB_TOKEN", "GH_TOKEN"):
        val = os.environ.get(env_var)
        if val and val.strip():
            return val.strip()

    token_file = Path.home() / ".github_token"
    if token_file.is_file():
        try:
            return token_file.read_text(encoding="utf-8").strip()
        except OSError:
            pass

    return None


def fetch_owner_repositories(owner: str, token: Optional[str] = None) -> List[str]:
    """Fetch all repository names for a given GitHub owner (user or organization)."""
    repo_names: Set[str] = set()
    token = resolve_github_token(token)

    headers = {
        "User-Agent": "Wheelhouser-GitTools",
        "Accept": "application/vnd.github.v3+json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    endpoints = []
    # If authenticated token is provided and querying own account, /user/repos returns both public & private
    if token:
        endpoints.append("https://api.github.com/user/repos?per_page=100&affiliation=owner,collaborator,organization_member")
    endpoints.append(f"https://api.github.com/users/{owner}/repos?per_page=100")
    endpoints.append(f"https://api.github.com/orgs/{owner}/repos?per_page=100")

    for url in endpoints:
        page = 1
        while page <= 10:  # Cap at 1000 repos max
            paged_url = f"{url}&page={page}" if "?" in url else f"{url}?page={page}"
            try:
                req = urllib.request.Request(paged_url, headers=headers)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.load(resp)
                    if not isinstance(data, list) or not data:
                        break
                    for item in data:
                        if isinstance(item, dict):
                            r_owner = item.get("owner", {}).get("login", "")
                            r_name = item.get("name", "")
                            # If checking user repos, ensure repo belongs to or is under target owner
                            if r_name and (not r_owner or r_owner.lower() == owner.lower() or not token):
                                repo_names.add(r_name)
                    if len(data) < 100:
                        break
                    page += 1
            except urllib.error.HTTPError as e:
                # 404 is normal when probing /users vs /orgs; 403 indicates rate limit
                if e.code == 403:
                    print(f"⚠️  GitHub API rate limit encountered: {e.reason}", file=sys.stderr)
                break
            except Exception:
                break

    # If owner matches steve-rock-wheelhouser, supplement with known workspace catalog apps
    if owner.lower() in ("steve-rock-wheelhouser", "wheelhouser"):
        manifest_paths = [
            Path("/home/user/Projects/orchestra/cross_platform_apps.json"),
            Path.home() / "Projects" / "orchestra" / "cross_platform_apps.json",
        ]
        for mp in manifest_paths:
            if mp.is_file():
                try:
                    apps_data = json.loads(mp.read_text(encoding="utf-8"))
                    for app_name in apps_data.keys():
                        repo_names.add(app_name)
                except Exception:
                    pass

    return sorted(list(repo_names))


def parse_clone_target(target: str, use_https: bool = False) -> Tuple[str, List[Tuple[str, str]]]:
    """
    Parses clone target into (mode, list_of_(repo_name, clone_url)).
    Modes:
      - 'wildcard': multiple repositories (owner/*)
      - 'single': single repository (owner/repo or full URL)
    """
    target = target.strip()

    # Case 1: Full URL (SSH or HTTPS)
    if target.startswith(("git@", "https://", "http://", "ssh://")):
        clean_url = target.rstrip("/")
        name = clean_url.split("/")[-1]
        if name.endswith(".git"):
            name = name[:-4]
        return "single", [(name, target)]

    # Case 2: Wildcard (e.g. 'steve-rock-wheelhouser/*' or 'owner/*')
    if target.endswith("/*") or target.endswith("/\\*"):
        owner = target.split("/")[0].strip()
        return "wildcard", [(owner, "")]

    # Case 3: Shorthand 'owner/repo'
    if "/" in target:
        parts = target.split("/", 1)
        owner, repo = parts[0].strip(), parts[1].strip()
        if repo.endswith(".git"):
            repo = repo[:-4]
        if use_https:
            url = f"https://github.com/{owner}/{repo}.git"
        else:
            url = f"git@github.com:{owner}/{repo}.git"
        return "single", [(repo, url)]

    # Case 4: Bare repo name without owner (assume steve-rock-wheelhouser default)
    repo = target[:-4] if target.endswith(".git") else target
    if use_https:
        url = f"https://github.com/steve-rock-wheelhouser/{repo}.git"
    else:
        url = f"git@github.com:steve-rock-wheelhouser/{repo}.git"
    return "single", [(repo, url)]


def clone_target(
    target: str,
    dest_dir: Optional[Path] = None,
    dry_run: bool = False,
    sync_existing: bool = False,
    token: Optional[str] = None,
    use_https: bool = False,
) -> List[CloneResult]:
    """Execute cloning for a single target or wildcard namespace."""
    if dest_dir is None:
        dest_dir = get_projects_root()
    dest_dir = dest_dir.resolve()
    dest_dir.mkdir(parents=True, exist_ok=True)

    mode, targets = parse_clone_target(target, use_https=use_https)
    results: List[CloneResult] = []

    if mode == "wildcard":
        owner = targets[0][0]
        print(f"🔍 Discovering repositories under '{owner}/*'...")
        repo_names = fetch_owner_repositories(owner, token=token)
        if not repo_names:
            print(f"⚠️  No repositories discovered for '{owner}'.", file=sys.stderr)
            return results

        print(f"📦 Found {len(repo_names)} repository candidate(s) for '{owner}'.\n")
        targets_to_clone = []
        for rname in repo_names:
            if use_https:
                url = f"https://github.com/{owner}/{rname}.git"
            else:
                url = f"git@github.com:{owner}/{rname}.git"
            targets_to_clone.append((rname, url))
    else:
        targets_to_clone = targets

    for repo_name, clone_url in targets_to_clone:
        local_path = dest_dir / repo_name

        # Case A: Local repository already exists
        if local_path.exists() and (local_path / ".git").exists():
            if sync_existing:
                if dry_run:
                    results.append(
                        CloneResult(
                            name=repo_name,
                            url=clone_url,
                            dest=local_path,
                            status="dry-run",
                            message=f"[DRY RUN] Would update existing '{repo_name}' with git pull --autostash --rebase",
                        )
                    )
                else:
                    print(f"🔄 Updating existing '{repo_name}'...")
                    pull_res = subprocess.run(
                        ["git", "-C", str(local_path), "pull", "--autostash", "--rebase"],
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                    if pull_res.returncode == 0:
                        first_line = pull_res.stdout.strip().splitlines()[0] if pull_res.stdout.strip() else "Up to date."
                        results.append(
                            CloneResult(
                                name=repo_name,
                                url=clone_url,
                                dest=local_path,
                                status="synced",
                                message=f"Updated ({first_line})",
                            )
                        )
                    else:
                        err = pull_res.stderr.strip() or pull_res.stdout.strip()
                        results.append(
                            CloneResult(
                                name=repo_name,
                                url=clone_url,
                                dest=local_path,
                                status="failed",
                                message=f"Pull failed: {err}",
                            )
                        )
            else:
                results.append(
                    CloneResult(
                        name=repo_name,
                        url=clone_url,
                        dest=local_path,
                        status="skipped",
                        message=f"Already cloned in {local_path.name}/",
                    )
                )
            continue

        # Case B: Target path exists but is not a Git repo
        if local_path.exists():
            results.append(
                CloneResult(
                    name=repo_name,
                    url=clone_url,
                    dest=local_path,
                    status="failed",
                    message=f"Path '{local_path}' exists and is not a Git repository",
                )
            )
            continue

        # Case C: Clone missing repository
        if dry_run:
            results.append(
                CloneResult(
                    name=repo_name,
                    url=clone_url,
                    dest=local_path,
                    status="dry-run",
                    message=f"[DRY RUN] Would clone {clone_url} -> {local_path}",
                )
            )
            continue

        print(f"📥 Cloning '{repo_name}' from {clone_url}...")
        clone_cmd = ["git", "clone", clone_url, str(local_path)]
        clone_res = subprocess.run(
            clone_cmd,
            capture_output=True,
            text=True,
            check=False,
        )

        if clone_res.returncode == 0:
            results.append(
                CloneResult(
                    name=repo_name,
                    url=clone_url,
                    dest=local_path,
                    status="cloned",
                    message=f"✔ Cloned successfully to {local_path}",
                )
            )
        else:
            err = clone_res.stderr.strip() or clone_res.stdout.strip()
            results.append(
                CloneResult(
                    name=repo_name,
                    url=clone_url,
                    dest=local_path,
                    status="failed",
                    message=f"Clone failed: {err}",
                )
            )

    return results


def render_clone_summary(results: List[CloneResult]) -> str:
    """Format clone execution results into a formatted summary table."""
    if not results:
        return "No repositories processed."

    lines: List[str] = []
    lines.append("=" * 80)
    lines.append("                 WHEELHOUSER GIT CLONE SUMMARY")
    lines.append("=" * 80)
    lines.append(f"{'REPOSITORY':<28} {'STATUS':<14} {'DETAILS'}")
    lines.append("-" * 80)

    status_icons = {
        "cloned": "📥 CLONED",
        "synced": "🔄 SYNCED",
        "skipped": "⏩ SKIPPED",
        "dry-run": "🔎 DRY-RUN",
        "failed": "❌ FAILED",
    }

    for r in results:
        st_label = status_icons.get(r.status, r.status.upper())
        msg = r.message.splitlines()[0] if r.message else ""
        if len(msg) > 36:
            msg = msg[:33] + "..."
        lines.append(f"{r.name:<28} {st_label:<14} {msg}")

    lines.append("=" * 80)
    cloned_cnt = sum(1 for r in results if r.status == "cloned")
    synced_cnt = sum(1 for r in results if r.status == "synced")
    skipped_cnt = sum(1 for r in results if r.status == "skipped")
    failed_cnt = sum(1 for r in results if r.status == "failed")
    dry_cnt = sum(1 for r in results if r.status == "dry-run")

    summary_parts = []
    if cloned_cnt:
        summary_parts.append(f"{cloned_cnt} cloned")
    if synced_cnt:
        summary_parts.append(f"{synced_cnt} synced")
    if skipped_cnt:
        summary_parts.append(f"{skipped_cnt} skipped")
    if dry_cnt:
        summary_parts.append(f"{dry_cnt} dry-run")
    if failed_cnt:
        summary_parts.append(f"{failed_cnt} failed")

    lines.append(f"Total: {len(results)} | {', '.join(summary_parts) if summary_parts else '0 changes'}")
    lines.append("=" * 80)
    return "\n".join(lines)

"""Wheelhouser Git Tools - Persistent Configuration Management.

Manages persistent user configuration including:
- Projects Root directory (projects_root)
- Active current project selection (current_project)
- User preferences across terminal sessions

Defaults:
- Linux / macOS: ~/Projects/
- Windows: C:/Users/<user>/
"""

from __future__ import annotations

import json
import os
import platform
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


def get_config_dir() -> Path:
    """Return the configuration directory for git-tools."""
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "git-tools"
        return Path.home() / ".config" / "git-tools"

    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        return Path(xdg_config) / "git-tools"
    return Path.home() / ".config" / "git-tools"


def get_config_path() -> Path:
    """Return the path to the config.json file."""
    return get_config_dir() / "config.json"


def get_default_projects_root() -> Path:
    """Return default projects root directory.

    Default:
      - ~/Projects/ on all platforms (if it exists and is a directory).
      - If ~/Projects fails (does not exist, cannot be accessed, or is not a directory),
        falls back to ~/ (home directory) on all platforms.
    """
    projects_dir = Path.home() / "Projects"
    try:
        if projects_dir.is_dir():
            return projects_dir
    except Exception:
        pass
    return Path.home()


def load_config() -> Dict[str, Any]:
    """Load configuration from persistent storage, applying defaults."""
    cfg_path = get_config_path()
    default_root = str(get_default_projects_root())
    config: Dict[str, Any] = {
        "projects_root": default_root,
        "current_project": None,
    }

    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as fh:
                loaded = json.load(fh)
                if isinstance(loaded, dict):
                    config.update(loaded)
        except Exception:
            pass

    # Ensure projects_root is valid and not pointing to a deleted or inaccessible directory
    raw_root = config.get("projects_root")
    if not raw_root:
        config["projects_root"] = default_root
    else:
        try:
            cand = Path(raw_root).expanduser().resolve()
            if not cand.is_dir():
                config["projects_root"] = default_root
        except Exception:
            config["projects_root"] = default_root

    return config


def save_config(config: Dict[str, Any]) -> None:
    """Save configuration dictionary to persistent config.json."""
    cfg_dir = get_config_dir()
    cfg_dir.mkdir(parents=True, exist_ok=True)
    cfg_path = get_config_path()
    with open(cfg_path, "w", encoding="utf-8") as fh:
        json.dump(config, fh, indent=2)


def get_projects_root() -> Path:
    """Return the configured projects root directory as a resolved Path.

    Validates that the directory exists and is accessible.
    If the configured directory fails or does not exist, automatically falls back to:
      1. ~/Projects (if it exists)
      2. ~/ (home directory) on all platforms.
    """
    config = load_config()
    raw = config.get("projects_root")
    if raw:
        try:
            cand = Path(raw).expanduser().resolve()
            if cand.is_dir():
                return cand
        except Exception:
            pass

    return get_default_projects_root()


def set_projects_root(new_root: Path | str) -> Path:
    """Update and persist the projects root directory."""
    resolved = Path(new_root).expanduser().resolve()
    if not resolved.is_dir():
        try:
            resolved.mkdir(parents=True, exist_ok=True)
        except Exception:
            resolved = get_default_projects_root()

    config = load_config()
    config["projects_root"] = str(resolved)
    save_config(config)
    return resolved


def get_current_project() -> Optional[str]:
    """Return the name of the currently active project, if any."""
    config = load_config()
    return config.get("current_project")


def set_current_project(project_name: Optional[str]) -> None:
    """Update and persist the current active project name."""
    config = load_config()
    config["current_project"] = project_name
    save_config(config)


def get_active_project_path() -> Optional[Path]:
    """Return the resolved Path of the currently active project if it exists."""
    curr = get_current_project()
    if not curr:
        return None
    root = get_projects_root()
    proj_path = root / curr
    if proj_path.is_dir():
        return proj_path
    return None


def list_projects(root_dir: Optional[Path] = None) -> List[Path]:
    """List project directories under the given root (or configured projects_root).

    Sorts directories alphabetically. Identifies Git repositories first, then other folders.
    """
    if root_dir is None:
        root_dir = get_projects_root()

    if not root_dir.exists() or not root_dir.is_dir():
        return []

    projects: List[Path] = []
    try:
        entries = sorted(root_dir.iterdir(), key=lambda p: p.name.lower())
        for entry in entries:
            # Skip hidden files/folders (e.g. .git, .config, .cache)
            if entry.name.startswith("."):
                continue
            if entry.is_dir():
                projects.append(entry)
    except PermissionError:
        pass

    return projects

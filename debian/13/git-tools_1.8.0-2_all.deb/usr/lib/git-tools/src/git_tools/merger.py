"""Wheelhouser Git Tools - Intelligent Branch Merging Module.

Implements safe, verifiable, and structured merge workflows:
- Pre-merge test gate (AGENTS.md Rule 9)
- Conflict simulation via git merge-tree (--dry-run)
- Supported strategies: squash, ff (ff-only), rebase, no-ff
- Automated post-merge branch pruning (--prune)
- Conflict detection and reporting (git-tools conflicts)
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Tuple

OK_MARK = "[OK]" if sys.platform == "win32" else "✔"
FAIL_MARK = "[FAIL]" if sys.platform == "win32" else "❌"


def _run_git(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    """Helper to run git commands with author environment."""
    env = os.environ.copy()
    if "GIT_AUTHOR_NAME" not in env:
        env["GIT_AUTHOR_NAME"] = "Wheelhouser Engineering"
    if "GIT_AUTHOR_EMAIL" not in env:
        env["GIT_AUTHOR_EMAIL"] = "developer@wheelhouser.com"
    if "GIT_COMMITTER_NAME" not in env:
        env["GIT_COMMITTER_NAME"] = "Wheelhouser Engineering"
    if "GIT_COMMITTER_EMAIL" not in env:
        env["GIT_COMMITTER_EMAIL"] = "developer@wheelhouser.com"

    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        env=env,
        check=False,
    )


def simulate_merge(
    repo_dir: Path,
    source_branch: str,
    target_branch: Optional[str] = None,
) -> Tuple[bool, List[str], str]:
    """Simulate a merge using git merge-tree without touching index or working tree.

    Returns:
        (is_clean, conflicting_files, descriptive_message)
    """
    if target_branch is None:
        res = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_dir)
        if res.returncode != 0:
            return False, [], f"Could not determine current active branch: {res.stderr.strip()}"
        target_branch = res.stdout.strip()

    # Verify both branches exist
    r_src = _run_git(["git", "rev-parse", "--verify", source_branch], cwd=repo_dir)
    if r_src.returncode != 0:
        return False, [], f"Source branch '{source_branch}' does not exist."

    r_tgt = _run_git(["git", "rev-parse", "--verify", target_branch], cwd=repo_dir)
    if r_tgt.returncode != 0:
        return False, [], f"Target branch '{target_branch}' does not exist."

    # Try modern `git merge-tree --write-tree <target> <source>`
    res = _run_git(["git", "merge-tree", "--write-tree", target_branch, source_branch], cwd=repo_dir)
    if res.returncode == 0:
        return True, [], "Clean merge! No conflicting files detected."

    # In modern merge-tree, conflict exit code is non-zero (often 1). Output lists conflicts.
    conflicts: List[str] = []
    output = res.stdout + "\n" + res.stderr
    for line in output.splitlines():
        # Match lines like "CONFLICT (content): Merge conflict in <file>"
        m = re.search(r"CONFLICT.*?in\s+(.+)$", line)
        if m:
            cfile = m.group(1).strip()
            if cfile not in conflicts:
                conflicts.append(cfile)
        elif line.startswith("Auto-merging "):
            pass

    # If modern merge-tree was not supported or did not parse files, try base merge-tree
    if not conflicts and "unknown option" in output.lower():
        base_res = _run_git(["git", "merge-base", target_branch, source_branch], cwd=repo_dir)
        if base_res.returncode == 0:
            base_sha = base_res.stdout.strip()
            legacy_res = _run_git(["git", "merge-tree", base_sha, target_branch, source_branch], cwd=repo_dir)
            if "<<<<<<<" in legacy_res.stdout:
                # Parse conflict blocks in legacy merge-tree
                for line in legacy_res.stdout.splitlines():
                    if line.startswith("changed in both"):
                        parts = line.split()
                        if len(parts) >= 4:
                            conflicts.append(parts[-1])
            else:
                return True, [], "Clean merge! No conflicting files detected."

    if conflicts:
        msg = f"Merge conflicts detected in {len(conflicts)} file(s):\n" + "\n".join(f"  - {f}" for f in conflicts)
        return False, conflicts, msg
    else:
        return False, ["(unresolved conflicts)"], "Merge conflicts detected during simulation."


def prune_branch(repo_dir: Path, branch_name: str) -> Tuple[bool, str]:
    """Safely delete a merged or obsolete branch locally and optionally on remote origin.

    Returns:
        (success, message)
    """
    # 1. Delete local branch (-D to accommodate squash merges)
    res = _run_git(["git", "branch", "-D", branch_name], cwd=repo_dir)
    if res.returncode != 0:
        return False, f"Failed to delete local branch '{branch_name}': {res.stderr.strip()}"

    msg = f"Deleted local branch '{branch_name}'."

    # 2. Check if remote tracking branch exists and try to delete on remote
    remote_check = _run_git(["git", "rev-parse", "--verify", f"origin/{branch_name}"], cwd=repo_dir)
    if remote_check.returncode == 0:
        rem_res = _run_git(["git", "push", "origin", "--delete", branch_name], cwd=repo_dir)
        if rem_res.returncode == 0:
            msg += f" Deleted remote branch 'origin/{branch_name}'."

    return True, msg


def execute_merge(
    repo_dir: Path,
    source_branch: str,
    strategy: str = "squash",
    message: Optional[str] = None,
    prune: bool = False,
    run_tests: bool = True,
) -> Tuple[bool, str]:
    """Execute branch merge into current branch with test gate and strategy options.

    Args:
        repo_dir: Path to Git repository.
        source_branch: Branch to merge into current active branch.
        strategy: Merge strategy: 'squash', 'ff' / 'ff-only', 'rebase', 'no-ff'.
        message: Custom commit message for merge or squash commit.
        prune: If True, delete source branch upon successful merge.
        run_tests: If True, enforce Rule 9 pre-merge test gate.

    Returns:
        (success, message)
    """
    # 1. Check working tree cleanliness
    stat_res = _run_git(["git", "status", "--porcelain"], cwd=repo_dir)
    if stat_res.returncode != 0:
        return False, f"Git status failed: {stat_res.stderr.strip()}"
    if stat_res.stdout.strip():
        return False, "Working tree has uncommitted changes. Stash or commit changes before merging."

    # 2. Check target branch
    cur_res = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_dir)
    if cur_res.returncode != 0:
        return False, "Unable to determine current active branch."
    target_branch = cur_res.stdout.strip()

    if target_branch == source_branch:
        return False, f"Cannot merge branch '{source_branch}' into itself."

    # 3. Check source branch
    verify_src = _run_git(["git", "rev-parse", "--verify", source_branch], cwd=repo_dir)
    if verify_src.returncode != 0:
        return False, f"Source branch '{source_branch}' does not exist."

    # 4. Pre-merge test gate (Rule 9)
    if run_tests:
        test_runner = repo_dir / "tests" / "run_tests.sh"
        if test_runner.is_file() and os.access(test_runner, os.X_OK):
            print(f"==> [Gate 1] Running pre-merge test suite ({test_runner.name})...")
            test_proc = subprocess.run(
                ["bash", str(test_runner)],
                cwd=repo_dir,
                capture_output=True,
                text=True,
            )
            if test_proc.returncode != 0:
                return False, f"Pre-merge test gate FAILED (exit code {test_proc.returncode}). Merge aborted per AGENTS.md Rule 9."
            print(f"  {OK_MARK} Pre-merge test gate PASSED.")

    # 5. Execute merge strategy
    norm_strategy = strategy.lower().strip()

    if norm_strategy in ("ff", "ff-only"):
        res = _run_git(["git", "merge", "--ff-only", source_branch], cwd=repo_dir)
        if res.returncode != 0:
            return False, f"Fast-forward merge failed (divergent branches): {res.stderr.strip()}"

    elif norm_strategy == "squash":
        res = _run_git(["git", "merge", "--squash", source_branch], cwd=repo_dir)
        if res.returncode != 0:
            _run_git(["git", "reset", "--hard", "HEAD"], cwd=repo_dir)
            return False, f"Squash merge failed: {res.stderr.strip()}"

        commit_msg = message if message else f"Merge branch '{source_branch}' into {target_branch} (squash)"
        c_res = _run_git(["git", "commit", "-m", commit_msg], cwd=repo_dir)
        if c_res.returncode != 0:
            return False, f"Squash commit failed: {c_res.stderr.strip()}"

    elif norm_strategy == "rebase":
        # Rebase source branch onto target, then fast-forward target
        reb_res = _run_git(["git", "rebase", target_branch, source_branch], cwd=repo_dir)
        if reb_res.returncode != 0:
            _run_git(["git", "rebase", "--abort"], cwd=repo_dir)
            return False, f"Rebase failed with conflicts: {reb_res.stderr.strip()}"

        # Switch back to target branch and fast-forward
        _run_git(["git", "checkout", target_branch], cwd=repo_dir)
        ff_res = _run_git(["git", "merge", "--ff-only", source_branch], cwd=repo_dir)
        if ff_res.returncode != 0:
            return False, f"Fast-forward after rebase failed: {ff_res.stderr.strip()}"

    elif norm_strategy == "no-ff":
        commit_msg = message if message else f"Merge branch '{source_branch}' into {target_branch}"
        res = _run_git(["git", "merge", "--no-ff", "-m", commit_msg, source_branch], cwd=repo_dir)
        if res.returncode != 0:
            _run_git(["git", "merge", "--abort"], cwd=repo_dir)
            return False, f"Merge failed: {res.stderr.strip()}"

    else:
        return False, f"Unknown merge strategy '{strategy}'. Supported strategies: squash, ff, rebase, no-ff."

    out_msg = f"Successfully merged '{source_branch}' into '{target_branch}' using '{norm_strategy}' strategy."

    # 6. Branch pruning
    if prune:
        prune_ok, prune_detail = prune_branch(repo_dir, source_branch)
        if prune_ok:
            out_msg += f" {prune_detail}"
        else:
            out_msg += f" Warning: {prune_detail}"

    return True, out_msg


def detect_conflicts(repo_dir: Path) -> List[Tuple[Path, List[Tuple[int, str]]]]:
    """Scan working tree files for Git conflict markers (<<<<<<<, =======, >>>>>>>).

    Returns:
        List of (file_path, [(line_number, line_content), ...])
    """
    conflicts: List[Tuple[Path, List[Tuple[int, str]]]] = []

    # Exclude .git and common build/binary directories
    excluded_dirs = {".git", "build", "dist", "Output", "rpmbuild", "node_modules", "__pycache__"}

    for root, dirs, files in os.walk(repo_dir):
        dirs[:] = [d for d in dirs if d not in excluded_dirs]
        for fname in files:
            fpath = Path(root) / fname
            # Skip binary files or extensions
            if fpath.suffix.lower() in (".png", ".jpg", ".ico", ".svg", ".deb", ".rpm", ".msix", ".pyc", ".so"):
                continue

            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if "<<<<<<<" in content and ">>>>>>>" in content:
                markers = []
                for idx, line in enumerate(content.splitlines(), start=1):
                    if line.startswith("<<<<<<<") or line.startswith("=======") or line.startswith(">>>>>>>"):
                        markers.append((idx, line.strip()))
                if markers:
                    conflicts.append((fpath, markers))

    return conflicts


def format_conflicts_report(repo_dir: Path, conflicts: List[Tuple[Path, List[Tuple[int, str]]]]) -> str:
    """Format detected conflicts into a human-readable CLI report."""
    if not conflicts:
        return f"{OK_MARK} No merge conflicts detected in '{repo_dir.name}'."

    lines = [
        f"{FAIL_MARK} Merge conflicts detected in {len(conflicts)} file(s):",
        "=" * 64,
    ]

    for fpath, markers in conflicts:
        rel_path = fpath.relative_to(repo_dir) if fpath.is_relative_to(repo_dir) else fpath
        lines.append(f"\n📄 {rel_path}:")
        for line_no, content in markers:
            lines.append(f"   Line {line_no:4d}: {content}")

    lines.append("\n" + "=" * 64)
    lines.append("💡 Resolve conflict blocks in the listed files and stage them with 'git add <file>'.")
    return "\n".join(lines)

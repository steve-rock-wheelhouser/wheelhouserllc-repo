"""Wheelhouser Git Tools - Standalone Pre-flight & History Security Audit.

Scans local working tree, staged changes, and commit history for accidental
leaks of private keys, SSL certificates, tokens, and credentials.
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class SecurityFinding:
    severity: str  # "CRITICAL", "HIGH", "WARNING"
    rule_name: str
    file_path: str
    line_number: Optional[int]
    matched_snippet: str
    is_historical: bool = False


# High-risk filename extensions and globs
SUSPICIOUS_EXTENSIONS = {
    ".key",
    ".pem",
    ".p12",
    ".pkcs12",
    ".pfx",
    ".kdbx",
}

SUSPICIOUS_FILENAME_PATTERNS = [
    re.compile(r"^\.env(?:\..*)?$", re.IGNORECASE),
    re.compile(r"^id_(?:rsa|dsa|ecdsa|ed25519)(?:\.pub)?$", re.IGNORECASE),
    re.compile(r".*[-_]secret\..*", re.IGNORECASE),
    re.compile(r".*[-_]credentials\..*", re.IGNORECASE),
]

# Sensitive content regex patterns
SENSITIVE_CONTENT_PATTERNS = [
    (
        "CRITICAL",
        "Private Key Block",
        re.compile(r"-----BEGIN (?:RSA|EC|DSA|OPENSSH|PGP)?\s*PRIVATE KEY-----"),
    ),
    (
        "CRITICAL",
        "GitHub Access Token",
        re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}\b"),
    ),
    (
        "CRITICAL",
        "GitHub Fine-grained PAT",
        re.compile(r"\bgithub_pat_[A-Za-z0-9_]{22,}\b"),
    ),
    (
        "CRITICAL",
        "AWS Access Key ID",
        re.compile(r"\b(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}\b"),
    ),
    (
        "CRITICAL",
        "Slack Incoming Webhook",
        re.compile(r"https://hooks\.slack\.com/services/T[A-Za-z0-9_]{8,}/B[A-Za-z0-9_]{8,}/[A-Za-z0-9_]{20,}"),
    ),
    (
        "CRITICAL",
        "Slack API Token",
        re.compile(r"\bxox[baprs]-[A-Za-z0-9_-]{10,}\b"),
    ),
    (
        "HIGH",
        "Hardcoded Secret / Auth Token",
        re.compile(r"(?i)\b(?:api[_-]?key|auth[_-]?token|secret[_-]?key|client[_-]?secret)\s*[:=]\s*['\"]([A-Za-z0-9_\-\.]{16,})['\"]"),
    ),
]


def scan_file_content(path: Path) -> List[SecurityFinding]:
    """Scan the content of an individual file for sensitive patterns."""
    findings: List[SecurityFinding] = []
    try:
        # Skip binary or very large files (> 2 MB)
        if path.stat().st_size > 2 * 1024 * 1024:
            return findings

        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            for line_no, line in enumerate(fh, 1):
                # Mask long lines to avoid huge output
                clean_line = line.strip()
                if not clean_line:
                    continue

                for severity, rule, pattern in SENSITIVE_CONTENT_PATTERNS:
                    match = pattern.search(clean_line)
                    if match:
                        snippet = clean_line[:80] + ("..." if len(clean_line) > 80 else "")
                        findings.append(
                            SecurityFinding(
                                severity=severity,
                                rule_name=rule,
                                file_path=str(path),
                                line_number=line_no,
                                matched_snippet=snippet,
                                is_historical=False,
                            )
                        )
                        break
    except OSError:
        pass
    return findings


def scan_working_tree(repo_path: Path) -> List[SecurityFinding]:
    """Scan all working tree files (staged, modified, untracked)."""
    findings: List[SecurityFinding] = []

    # Get all non-ignored files in git
    res = subprocess.run(
        ["git", "-C", str(repo_path), "status", "--porcelain"],
        capture_output=True,
        text=True,
        check=False,
    )

    tracked_or_changed: List[Path] = []
    if res.returncode == 0:
        for line in res.stdout.splitlines():
            if len(line) > 3:
                filepath = line[3:].strip()
                # Handle renamed files 'R  orig -> new'
                if " -> " in filepath:
                    filepath = filepath.split(" -> ")[-1]
                full_path = repo_path / filepath
                if full_path.is_file():
                    tracked_or_changed.append(full_path)

    # Also include all tracked files if working tree is clean
    if not tracked_or_changed:
        ls_files = subprocess.run(
            ["git", "-C", str(repo_path), "ls-files"],
            capture_output=True,
            text=True,
            check=False,
        )
        if ls_files.returncode == 0:
            for f in ls_files.stdout.splitlines():
                full_p = repo_path / f.strip()
                if full_p.is_file():
                    tracked_or_changed.append(full_p)
        else:
            for root, dirs, files in os.walk(repo_path):
                dirs[:] = [d for d in dirs if d != ".git"]
                for f in files:
                    tracked_or_changed.append(Path(root) / f)

    for fpath in tracked_or_changed:
        # Check filename patterns
        if fpath.suffix.lower() in SUSPICIOUS_EXTENSIONS:
            findings.append(
                SecurityFinding(
                    severity="CRITICAL",
                    rule_name=f"High-risk extension ({fpath.suffix})",
                    file_path=str(fpath.relative_to(repo_path)),
                    line_number=None,
                    matched_snippet=fpath.name,
                )
            )
            continue

        for pat in SUSPICIOUS_FILENAME_PATTERNS:
            if pat.match(fpath.name):
                findings.append(
                    SecurityFinding(
                        severity="HIGH",
                        rule_name=f"Sensitive filename pattern",
                        file_path=str(fpath.relative_to(repo_path)),
                        line_number=None,
                        matched_snippet=fpath.name,
                    )
                )
                break

        # Check content
        content_findings = scan_file_content(fpath)
        for cf in content_findings:
            cf.file_path = str(fpath.relative_to(repo_path))
            findings.append(cf)

    return findings


def scan_commit_history(repo_path: Path, depth: int = 15) -> List[SecurityFinding]:
    """Scan diffs of the last N commits for accidental secret additions."""
    findings: List[SecurityFinding] = []

    res = subprocess.run(
        ["git", "-C", str(repo_path), "log", f"-{depth}", "-p", "--format=commit %h %s"],
        capture_output=True,
        text=True,
        check=False,
    )
    if res.returncode != 0 or not res.stdout:
        return findings

    current_commit = "unknown"
    current_file = "unknown"

    for line in res.stdout.splitlines():
        if line.startswith("commit "):
            current_commit = line.split(" ", 2)[1]
        elif line.startswith("+++ b/"):
            current_file = line[6:]
        elif line.startswith("+") and not line.startswith("+++"):
            added_content = line[1:].strip()
            for severity, rule, pattern in SENSITIVE_CONTENT_PATTERNS:
                if pattern.search(added_content):
                    snippet = added_content[:80] + ("..." if len(added_content) > 80 else "")
                    findings.append(
                        SecurityFinding(
                            severity=severity,
                            rule_name=f"{rule} (in commit history)",
                            file_path=f"{current_file} (commit {current_commit})",
                            line_number=None,
                            matched_snippet=snippet,
                            is_historical=True,
                        )
                    )
                    break

    return findings

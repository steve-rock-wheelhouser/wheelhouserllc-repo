"""Wheelhouser Git Tools - Repository Initialization Module.

Automates initial repository setup with Wheelhouser standard practices:
- Default branch naming ('main' instead of 'master')
- Baseline .gitignore generation tailored to project type (python, c, bash, web, generic)
- Incorporation of Rule 13 compliance (*.local.sh, .local/) from day one
- Standard initial commit with descriptive message
- Optional remote origin configuration (git@... or https://...)
- Idempotency when target directory is already a Git repository
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

OK_MARK = "[OK]" if sys.platform == "win32" else "✔"
FAIL_MARK = "[FAIL]" if sys.platform == "win32" else "❌"

GITIGNORE_TEMPLATES = {
    "generic": """# OS junk
.DS_Store
Thumbs.db
Desktop.ini

# Editor metadata
.vscode/
.idea/
*.swp
*.swo
*~

# Build and package artifacts
build/
dist/
Output/
rpmbuild/
*.tar.gz
*.zip

# Wheelhouser Rule 13 - Local developer overrides
*.local.sh
.local/
""",
    "python": """# OS junk
.DS_Store
Thumbs.db
Desktop.ini

# Editor metadata
.vscode/
.idea/
*.swp
*.swo
*~

# Python cache and bytecode
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Testing and coverage
.pytest_cache/
.coverage
htmlcov/
.tox/
.nox/

# Packaging outputs
Output/
rpmbuild/

# Wheelhouser Rule 13 - Local developer overrides
*.local.sh
.local/
""",
    "c": """# OS junk
.DS_Store
Thumbs.db
Desktop.ini

# Editor metadata
.vscode/
.idea/
*.swp
*.swo
*~

# Object files & static/dynamic libraries
*.o
*.obj
*.so
*.dylib
*.a
*.dll
*.exe
*.out
*.app

# Build directories
build/
dist/
bin/
out/
Output/
rpmbuild/

# Wheelhouser Rule 13 - Local developer overrides
*.local.sh
.local/
""",
    "bash": """# OS junk
.DS_Store
Thumbs.db
Desktop.ini

# Editor metadata
.vscode/
.idea/
*.swp
*.swo
*~

# Logs and temp files
*.log
*.tmp
*.out

# Build artifacts
build/
dist/
Output/
rpmbuild/

# Wheelhouser Rule 13 - Local developer overrides
*.local.sh
.local/
""",
    "web": """# OS junk
.DS_Store
Thumbs.db
Desktop.ini

# Editor metadata
.vscode/
.idea/
*.swp
*.swo
*~

# Dependencies
node_modules/
.pnp
.pnp.js

# Build outputs
dist/
build/
Output/
rpmbuild/
.next/
.nuxt/
out/

# Logs
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Wheelhouser Rule 13 - Local developer overrides
*.local.sh
.local/
""",
}


def _run_git(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    """Helper to run git commands with predictable environment and author."""
    env = os.environ.copy()
    if "GIT_AUTHOR_NAME" not in env:
        env["GIT_AUTHOR_NAME"] = "Wheelhouser Engineering"
    if "GIT_AUTHOR_EMAIL" not in env:
        env["GIT_AUTHOR_EMAIL"] = "developer@wheelhouser.com"
    if "GIT_COMMITTER_NAME" not in env:
        env["GIT_COMMITTER_NAME"] = "Wheelhouser Engineering"
    if "GIT_COMMITTER_EMAIL" not in env:
        env["GIT_COMMITTER_EMAIL"] = "developer@wheelhouser.com"

    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        env=env,
        check=False,
    )


def init_repository(
    target_path: Path | str = ".",
    branch: str = "main",
    remote_url: Optional[str] = None,
    project_type: str = "generic",
    initial_commit: bool = True,
    commit_message: str = "chore: initial repository structure",
) -> Tuple[bool, str]:
    """Initialize a directory as a standardized Git repository.

    Args:
        target_path: Directory path to initialize (creates if non-existent).
        branch: Initial branch name (default: 'main').
        remote_url: Optional remote origin URL.
        project_type: Language template for .gitignore (python, c, bash, web, generic).
        initial_commit: Whether to automatically create an initial commit.
        commit_message: Message for initial commit.

    Returns:
        (success, message) tuple.
    """
    target = Path(target_path).resolve()
    target.mkdir(parents=True, exist_ok=True)

    is_already_git = (target / ".git").is_dir()

    if is_already_git:
        # Idempotency check: directory is already a Git repository
        # Check if remote needs to be added
        if remote_url:
            rem_check = _run_git(["git", "remote", "get-url", "origin"], cwd=target)
            if rem_check.returncode != 0:
                _run_git(["git", "remote", "add", "origin", remote_url], cwd=target)
        # Ensure Rule 13 tokens exist in .gitignore
        gitignore_file = target / ".gitignore"
        if gitignore_file.exists():
            gi_text = gitignore_file.read_text(encoding="utf-8")
            missing = []
            if "*.local.sh" not in gi_text:
                missing.append("*.local.sh")
            if ".local/" not in gi_text:
                missing.append(".local/")
            if missing:
                with gitignore_file.open("a", encoding="utf-8") as f:
                    f.write("\n# Wheelhouser Rule 13 - Local developer overrides\n" + "\n".join(missing) + "\n")
        else:
            tpl = GITIGNORE_TEMPLATES.get(project_type.lower(), GITIGNORE_TEMPLATES["generic"])
            gitignore_file.write_text(tpl, encoding="utf-8")

        return True, f"Directory '{target}' is already an initialized Git repository (idempotent pass)."

    # 1. Initialize Git repository with initial branch
    init_cmd = ["git", "init", f"--initial-branch={branch}"]
    res = _run_git(init_cmd, cwd=target)
    if res.returncode != 0:
        # Fallback for older git versions
        res2 = _run_git(["git", "init"], cwd=target)
        if res2.returncode != 0:
            return False, f"git init failed: {res2.stderr.strip()}"
        _run_git(["git", "checkout", "-b", branch], cwd=target)

    # 2. Generate .gitignore with Rule 13 compliance
    gitignore_file = target / ".gitignore"
    tpl = GITIGNORE_TEMPLATES.get(project_type.lower(), GITIGNORE_TEMPLATES["generic"])
    gitignore_file.write_text(tpl, encoding="utf-8")

    # 3. Configure Remote URL if specified
    if remote_url:
        rem_res = _run_git(["git", "remote", "add", "origin", remote_url], cwd=target)
        if rem_res.returncode != 0:
            return False, f"Failed to add remote origin '{remote_url}': {rem_res.stderr.strip()}"

    # 4. Generate initial commit if requested
    if initial_commit:
        _run_git(["git", "add", "."], cwd=target)
        commit_res = _run_git(["git", "commit", "-m", commit_message], cwd=target)
        if commit_res.returncode != 0:
            return False, f"Failed to create initial commit: {commit_res.stderr.strip()}"

    return True, f"Successfully initialized Git repository in '{target}' on branch '{branch}'."

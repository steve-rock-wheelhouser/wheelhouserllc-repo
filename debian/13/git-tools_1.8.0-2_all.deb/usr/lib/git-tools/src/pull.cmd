@echo off
rem Wheelhouser Git Tools - pull.cmd wrapper for Windows Command Prompt
rem Version: 1.0.0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pull.ps1" %*
exit /b %ERRORLEVEL%
